--------------------------------------------------
-- Export file for user NFS_TA@FARERD           --
-- Created by xiaoxinwt on 2015/12/25, 19:26:25 --
--------------------------------------------------

set define off
spool ta_db.log

prompt
prompt Creating table ADDON
prompt ====================
prompt
create table NFS_TA.ADDON
(
  location_code      CHAR(6) not null,
  addon_no           CHAR(13) not null,
  effective_date     DATE not null,
  discontinue_date   DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  entry_no_lastnum   NUMBER(3),
  gateway_no_lastnum NUMBER(3),
  who_last_update    CHAR(20),
  where_last_update  CHAR(6),
  when_last_update   DATE,
  currency_code      CHAR(3) default ('') not null,
  bsr_currency_code  CHAR(3) default ('') not null,
  type               CHAR(1),
  bsr                NUMBER(11,4),
  modified_flag      NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADDON
  add constraint ADDON_UX1 primary key (LOCATION_CODE, ADDON_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENDORSEMT_RESTRICTION
prompt ==========================================
prompt
create table NFS_TA.ADDON_ENDORSEMT_RESTRICTION
(
  location_code  CHAR(6) not null,
  addon_no       CHAR(13) not null,
  restriction_id NUMBER(5) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADDON_ENDORSEMT_RESTRICTION
  add constraint ADDON_ENDORSEMT_REST_UX1 primary key (LOCATION_CODE, ADDON_NO, RESTRICTION_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENTRY
prompt ==========================
prompt
create table NFS_TA.ADDON_ENTRY
(
  location_code               CHAR(6) not null,
  addon_no                    CHAR(13) not null,
  entry_no                    NUMBER(4) not null,
  code_type                   NUMBER(1),
  city_code                   CHAR(13) not null,
  journey_type                CHAR(3),
  fare_basis                  CHAR(15),
  carrier_booking_class       VARCHAR2(85),
  amount                      NUMBER(11,3),
  bsr_amount                  NUMBER(11,3),
  infant_discount_amount      NUMBER(11,3),
  infant_discount_percent     CHAR(2),
  infant_absolute_amt_entered NUMBER(1),
  child_discount_amount       NUMBER(11,3),
  child_discount_percent      CHAR(2),
  child_absolute_amt_entered  NUMBER(1),
  infant_bsr_amount           NUMBER(11,3),
  child_bsr_amount            NUMBER(11,3),
  spa                         VARCHAR2(58)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADDON_ENTRY
  add constraint ADDON_ENTRY_UX1 primary key (LOCATION_CODE, ADDON_NO, ENTRY_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENTRY_FLIGHT_NO
prompt ====================================
prompt
create table NFS_TA.ADDON_ENTRY_FLIGHT_NO
(
  location_code    CHAR(6) not null,
  addon_no         CHAR(13) not null,
  entry_no         NUMBER(4) not null,
  flight_entry_no  NUMBER(2) not null,
  carrier_code     CHAR(4) not null,
  ap_from_no       NUMBER(4),
  ap_to_no         NUMBER(4),
  ex_from_no       NUMBER(4),
  ex_to_no         NUMBER(4),
  booking_class    CHAR(2),
  booking_class2   CHAR(2),
  fare_basis_code  CHAR(15),
  fare_basis_code2 CHAR(15),
  via_point        CHAR(5)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADDON_ENTRY_FLIGHT_NO
  add constraint ADDON_ENTRY_FLIGHT_NO_UX1 primary key (LOCATION_CODE, ADDON_NO, ENTRY_NO, FLIGHT_ENTRY_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_GATEWAY
prompt ============================
prompt
create table NFS_TA.ADDON_GATEWAY
(
  location_code        CHAR(6) not null,
  addon_no             CHAR(13) not null,
  gateway_entry_no     NUMBER(4) not null,
  gateway_type         NUMBER(1) default (0) not null,
  gateway_code         CHAR(13) not null,
  stopover_or_transfer CHAR(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADDON_GATEWAY
  add constraint ADDON_GATEWAY_UX1 primary key (LOCATION_CODE, ADDON_NO, GATEWAY_ENTRY_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADJUSTMENT
prompt =========================
prompt
create table NFS_TA.ADJUSTMENT
(
  agency_id_pcc       CHAR(6) not null,
  carrier_code        CHAR(4) not null,
  location_code       CHAR(6) not null,
  ref_no              CHAR(15) not null,
  extension_id        CHAR(15) not null,
  source              CHAR(6) not null,
  fare_rec_no         NUMBER(5) not null,
  adjust_fare         NUMBER(11,3),
  adjust_fare_child   NUMBER(11,3),
  adjust_fare_infant  NUMBER(11,3),
  who_last_update     CHAR(20),
  when_last_update    DATE,
  where_last_update   CHAR(6),
  who_created         NUMBER(1) not null,
  ext_source          CHAR(15) default ('-') not null,
  adjust_value        CHAR(8),
  child_adjust_value  CHAR(8),
  infant_adjust_value CHAR(8),
  sub_fare_rec_no     NUMBER(5) default (0) not null,
  fare_category       NUMBER(1),
  base_commission_amt NUMBER(7,2),
  base_commission_pct NUMBER(2,2),
  addt_commission_amt NUMBER(7,2),
  addt_commission_pct NUMBER(2,2)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADJUSTMENT
  add constraint ADJUSTMENT_TA_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, EXTENSION_ID, SOURCE, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADJUST_RULE_TEXTUAL
prompt ==================================
prompt
create table NFS_TA.ADJUST_RULE_TEXTUAL
(
  agency_id_pcc           CHAR(6) not null,
  carrier_code            CHAR(4) not null,
  location_code           CHAR(6) not null,
  ref_no                  CHAR(15) not null,
  extension_id            CHAR(15) not null,
  source                  CHAR(6) not null,
  fare_rec_no             NUMBER(5) not null,
  sub_fare_rec_no         NUMBER(5) default (0) not null,
  advance_purchase_buffer NUMBER(3),
  application             VARCHAR2(1280),
  eligibility             VARCHAR2(1280),
  maximum_group_size      VARCHAR2(1280),
  extension_of_validity   VARCHAR2(1280),
  payment                 VARCHAR2(1280),
  ticketing               VARCHAR2(1280),
  cancellation_n_refunds  VARCHAR2(1280),
  rebooking_n_rerouting   VARCHAR2(1280),
  travel_together         VARCHAR2(1280),
  other_conditions        VARCHAR2(1280),
  fare_category           NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADJUST_RULE_TEXTUAL
  add constraint ADJUST_RULE_TEXTUAL_TA_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, EXTENSION_ID, SOURCE, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADJUST_RULE_TEXTUAL_DIS
prompt ======================================
prompt
create table NFS_TA.ADJUST_RULE_TEXTUAL_DIS
(
  agency_id_pcc           CHAR(6) not null,
  carrier_code            CHAR(4) not null,
  location_code           CHAR(6) not null,
  ref_no                  CHAR(15) not null,
  extension_id            CHAR(15) not null,
  source                  CHAR(6) not null,
  fare_rec_no             NUMBER(5) not null,
  sub_fare_rec_no         NUMBER(5) default (0) not null,
  advance_purchase_buffer NUMBER(3),
  application             VARCHAR2(1280),
  eligibility             VARCHAR2(1280),
  maximum_group_size      VARCHAR2(1280),
  extension_of_validity   VARCHAR2(1280),
  payment                 VARCHAR2(1280),
  ticketing               VARCHAR2(1280),
  cancellation_n_refunds  VARCHAR2(1280),
  rebooking_n_rerouting   VARCHAR2(1280),
  travel_together         VARCHAR2(1280),
  other_conditions        VARCHAR2(1280),
  fare_category           NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ADJUST_RULE_TEXTUAL_DIS
  add constraint ADJUST_RULE_TEXTUAL_DIS_TA_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, EXTENSION_ID, SOURCE, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AGREEMENT
prompt ========================
prompt
create table NFS_TA.AGREEMENT
(
  location_code          CHAR(6) not null,
  ref_no                 CHAR(15) not null,
  carrier_code           CHAR(4),
  send_for_approval      NUMBER(1) default (0),
  approved               NUMBER(1) default (0),
  agreement_desc         VARCHAR2(512),
  effective_date         DATE not null,
  discontinue_date       DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  fare_rec_lastnum       NUMBER(5) default (0),
  who_last_update        CHAR(20),
  where_last_update      CHAR(6),
  when_last_update       DATE default (SYSDATE),
  who_last_update_auth   CHAR(20),
  where_last_update_auth CHAR(6),
  when_last_update_auth  DATE,
  currency_code          CHAR(3) default ('') not null,
  currency_code2         CHAR(3) default ('') not null,
  algorithm_name         CHAR(4),
  prefix                 CHAR(4),
  suffix                 CHAR(4),
  remarks                VARCHAR2(256),
  who_last_update_dis    CHAR(20),
  where_last_update_dis  CHAR(6),
  when_last_update_dis   DATE,
  approving_office       NUMBER(1),
  approval_type          NUMBER(1),
  extension_id           CHAR(15) not null,
  distribution_status    NUMBER(1) default (0) not null,
  creator                NUMBER(1) default (0) not null,
  fare_category          NUMBER(1) default (0),
  rpt_file_no            VARCHAR2(30)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.AGREEMENT
  add constraint AGREEMENT_UX1 primary key (LOCATION_CODE, REF_NO, EXTENSION_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AGREEMENT_RECEIVED_CURRENT
prompt =========================================
prompt
create table NFS_TA.AGREEMENT_RECEIVED_CURRENT
(
  agency_id_pcc     VARCHAR2(37) not null,
  carrier_code      CHAR(4) not null,
  location_code     CHAR(6) not null,
  ref_no            CHAR(15) not null,
  extension_id      CHAR(15) not null,
  source            CHAR(6) not null,
  effective_date    DATE not null,
  discontinue_date  DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  level_of_sub      NUMBER(1),
  no_ext_sub        NUMBER(3),
  no_ext_internal   NUMBER(3),
  sub_last_ext      CHAR(2),
  internal_last_ext CHAR(2),
  who_distribute    CHAR(20),
  when_distribute   DATE,
  currency_code     CHAR(3),
  corporate_id      CHAR(5) default ('-') not null,
  corporate_id2     CHAR(5) default ('-') not null,
  distrib_type      NUMBER(1) not null,
  who_created       NUMBER(1) not null,
  fare_category     NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.AGREEMENT_R_C_CI1 on NFS_TA.AGREEMENT_RECEIVED_CURRENT (CARRIER_CODE, LOCATION_CODE, REF_NO, EFFECTIVE_DATE, DISCONTINUE_DATE)
  tablespace TA_IDX
  pctfree 30
  initrans 2
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.AGREEMENT_RECEIVED_CURRENT
  add constraint AGREEMENT_R_C_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, SOURCE, EXTENSION_ID, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AUDIT_TRAIL
prompt ==========================
prompt
create table NFS_TA.AUDIT_TRAIL
(
  agency_id_pcc       CHAR(6) not null,
  who                 CHAR(20) not null,
  when                DATE not null,
  transaction_code    NUMBER(3) not null,
  key                 VARCHAR2(47),
  transaction_details VARCHAR2(128)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AUTOVALUECODE
prompt ============================
prompt
create table NFS_TA.AUTOVALUECODE
(
  location_code  CHAR(6) not null,
  algorithm_name CHAR(4) not null,
  prefix         CHAR(4),
  suffix         CHAR(4),
  code_0         CHAR(1),
  code_1         CHAR(1),
  code_2         CHAR(1),
  code_3         CHAR(1),
  code_4         CHAR(1),
  code_5         CHAR(1),
  code_6         CHAR(1),
  code_7         CHAR(1),
  code_8         CHAR(1),
  code_9         CHAR(1),
  code_decimal   CHAR(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.AUTOVALUECODE
  add constraint AUTOVALUECODE_UX1 primary key (LOCATION_CODE, ALGORITHM_NAME)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table BASE_FARE
prompt ========================
prompt
create table NFS_TA.BASE_FARE
(
  location_code       VARCHAR2(6) not null,
  fare_by_rule_id     VARCHAR2(30) not null,
  carr_code           VARCHAR2(5) not null,
  fare_by_rule_dtl_id VARCHAR2(30) not null,
  basefare_id         VARCHAR2(3) not null,
  ori_code_type       NUMBER(1),
  ori_code            VARCHAR2(13),
  dest_code_type      NUMBER(1),
  dest_code           VARCHAR2(13),
  journey_type        VARCHAR2(3),
  booking_class       VARCHAR2(2),
  fare_basis          VARCHAR2(15),
  who_last_update     VARCHAR2(20),
  where_last_update   VARCHAR2(6),
  when_last_update    DATE,
  distribution_type   VARCHAR2(10),
  agency_id           VARCHAR2(6),
  source              VARCHAR2(6),
  if_d_rbd_open_seq   NUMBER(1) default 0,
  d_rbd_open_seq      VARCHAR2(151),
  z_value_min         NUMBER(5,2),
  z_value_max         NUMBER(5,2),
  z_value_min_symbol  NUMBER(1),
  z_value_max_symbol  NUMBER(1),
  if_z_value_check    NUMBER(1)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.BASE_FARE
  add constraint BASE_FARE_TA_UX1 primary key (LOCATION_CODE, FARE_BY_RULE_ID, CARR_CODE, FARE_BY_RULE_DTL_ID, BASEFARE_ID)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE
prompt ========================
prompt
create table NFS_TA.CORPORATE
(
  location_code  CHAR(6) not null,
  corporate_id   CHAR(5) not null,
  corporate_name VARCHAR2(80)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.CORPORATE
  add constraint CORPORATE_UX1 primary key (LOCATION_CODE, CORPORATE_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE2
prompt =========================
prompt
create table NFS_TA.CORPORATE2
(
  location_code   CHAR(6) not null,
  corporate_id    CHAR(5) not null,
  corporate_id2   CHAR(5) not null,
  corporate_name2 VARCHAR2(80)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.CORPORATE2
  add constraint CORPORATE2_UX1 primary key (LOCATION_CODE, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE_GROUP_ENTRY
prompt ====================================
prompt
create table NFS_TA.CORPORATE_GROUP_ENTRY
(
  location_code CHAR(6) not null,
  group_id      VARCHAR2(15) not null,
  corporate_id  CHAR(5) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.CORPORATE_GROUP_ENTRY
  add constraint CORPORATE_GORUP_ENTRY_UX1 primary key (LOCATION_CODE, GROUP_ID, CORPORATE_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CURRENCY
prompt =======================
prompt
create table NFS_TA.CURRENCY
(
  agency_id_pcc    CHAR(6) not null,
  currency_code    CHAR(3) not null,
  currency_desc    VARCHAR2(35),
  default_currency NUMBER(1),
  dual_currency    NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.CURRENCY
  add constraint CURRENCY_UX1 primary key (AGENCY_ID_PCC, CURRENCY_CODE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DISTRIBUTION
prompt ===========================
prompt
create table NFS_TA.DISTRIBUTION
(
  location_code       CHAR(6) not null,
  ref_no              CHAR(15) not null,
  agency_id_pcc       VARCHAR2(37) not null,
  extension_id        CHAR(15) not null,
  ticketing_permitted CHAR(3),
  group_id            VARCHAR2(37),
  agency_id_iata      CHAR(7),
  distrib_type        NUMBER(1) not null,
  corporate_id        CHAR(5) not null,
  corporate_id2       CHAR(5) not null,
  source              CHAR(6) default ('-') not null,
  carrier_code        CHAR(4) default ('1B') not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.DISTRIBUTION
  add constraint DISTRIBUTION_CA_UX1 primary key (LOCATION_CODE, REF_NO, AGENCY_ID_PCC, EXTENSION_ID, CORPORATE_ID, CORPORATE_ID2, SOURCE, CARRIER_CODE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ENDORSEMT_RESTRICTION
prompt ====================================
prompt
create table NFS_TA.ENDORSEMT_RESTRICTION
(
  location_code          CHAR(6) not null,
  restriction_id         NUMBER(5) not null,
  category               VARCHAR2(30),
  restriction_desc       VARCHAR2(512),
  who_last_update        CHAR(20),
  where_last_update      CHAR(6),
  when_last_update       DATE,
  restriction_type       NUMBER(1) not null,
  eterm_restriction_desc VARCHAR2(512)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ENDORSEMT_RESTRICTION
  add constraint ENDORSEMT_RESTRICTION_UX1 primary key (LOCATION_CODE, RESTRICTION_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE
prompt ===================
prompt
create table NFS_TA.FARE
(
  location_code                 CHAR(6) not null,
  ref_no                        CHAR(15) not null,
  carrier_code                  CHAR(4) not null,
  fare_rec_no                   NUMBER(15) not null,
  fare_category                 NUMBER(1) default (0),
  ori_code_type                 NUMBER(1),
  ori_code                      CHAR(13),
  ori_city_code                 CHAR(5),
  dest_code_type                NUMBER(1),
  dest_code                     CHAR(13),
  dest_city_code                CHAR(5),
  journey_type                  CHAR(3),
  fare_basis                    CHAR(15),
  booking_class                 CHAR(2),
  global_direction              CHAR(2),
  amount                        NUMBER(11,3),
  value_code                    CHAR(14),
  effective_date                DATE not null,
  discontinue_date              DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  first_travel_date             DATE,
  last_travel_date              DATE,
  first_ticketed_date           DATE,
  last_ticketed_date            DATE,
  rule_id                       CHAR(13),
  infant_discount_amount        NUMBER(11,3),
  infant_discount_percent       NUMBER(3),
  infant_absolute_amt_entered   NUMBER(1),
  child_discount_amount         NUMBER(11,3),
  child_discount_percent        NUMBER(3),
  child_absolute_amt_entered    NUMBER(1),
  free_stopover_outbound        NUMBER(2),
  chargeable_stopover_outbound  NUMBER(2),
  free_stopover_inbound         NUMBER(2),
  chargeable_stopover_inbound   NUMBER(2),
  free_stopover_total           NUMBER(2),
  chargeable_stopover_total     NUMBER(2),
  route_lastnum                 NUMBER(3) default (0),
  stopover_lastnum              NUMBER(3) default (0),
  who_last_update               CHAR(20),
  where_last_update             CHAR(6),
  when_last_update              DATE default (SYSDATE),
  fare_type                     CHAR(8),
  stopover_flag                 CHAR(1),
  booking_class_2               CHAR(2),
  child_value_code              CHAR(14),
  infant_value_code             CHAR(14),
  class_of_service              NUMBER(1),
  tour_code                     CHAR(14),
  child_tour_code               CHAR(14),
  infant_tour_code              CHAR(14),
  endorsement_restriction       VARCHAR2(255),
  fare_calculation              CHAR(15),
  published_fare_basis_code     CHAR(15),
  is_combined_fare              NUMBER(1),
  outbound_permitted            NUMBER(1),
  inbound_permitted             NUMBER(1),
  thru_fare                     NUMBER(1),
  adult_rsf_amt                 NUMBER(11,3),
  child_rsf_amt                 NUMBER(11,3),
  infant_rsf_amt                NUMBER(11,3),
  discount_code                 CHAR(2),
  child_published_fbc           CHAR(15),
  infant_published_fbc          CHAR(15),
  travel_complete_date          DATE default (to_date('2222-01-01','yyyy-MM-dd')),
  sub_fare_rec_no               NUMBER(5) default (0) not null,
  modified_flag                 NUMBER(1),
  value_code2                   CHAR(14),
  child_value_code2             CHAR(14),
  infant_value_code2            CHAR(14),
  baggage_allowance             NUMBER(2),
  child_baggage_allowance       NUMBER(2),
  infant_baggage_allowance      NUMBER(2),
  unit                          NUMBER(1),
  base_commission_amt           NUMBER(7,2),
  base_commission_pct           NUMBER(2,2),
  addt_commission_amt           NUMBER(7,2),
  addt_commission_pct           NUMBER(2,2),
  ticket_type                   NUMBER(3) default (3) not null,
  eterm_endorsement_restriction VARCHAR2(255),
  disc_per                      NUMBER(5,2)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE
  add constraint FARE_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ADDON
prompt =========================
prompt
create table NFS_TA.FARE_ADDON
(
  location_code   CHAR(6) not null,
  ref_no          CHAR(15) not null,
  fare_rec_no     NUMBER(15) not null,
  addon_no        CHAR(13) not null,
  type            CHAR(1),
  sub_fare_rec_no NUMBER(5) default (0) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_ADDON
  add constraint FARE_ADDON_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ADDON_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BAGGAGE_ALLOWANCE
prompt =====================================
prompt
create table NFS_TA.FARE_BAGGAGE_ALLOWANCE
(
  location_code            CHAR(6) not null,
  ref_no                   CHAR(15) not null,
  fare_rec_no              NUMBER(15) not null,
  sub_fare_rec_no          NUMBER(5) default (0) not null,
  entry_no                 NUMBER(3) not null,
  carrier_code             CHAR(4) not null,
  from_code                CHAR(3) not null,
  from_code_type           NUMBER(1),
  to_code                  CHAR(3) not null,
  to_code_type             NUMBER(1),
  baggage_allowance        NUMBER(2),
  child_baggage_allowance  NUMBER(2),
  infant_baggage_allowance NUMBER(2),
  unit                     NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BAGGAGE_ALLOWANCE
  add constraint FARE_BAG_ALL_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO, ENTRY_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE
prompt ===========================
prompt
create table NFS_TA.FARE_BY_RULE
(
  location_code     VARCHAR2(6) not null,
  fare_by_rule_id   VARCHAR2(30) not null,
  carr_code         VARCHAR2(5) not null,
  fbr_desc          VARCHAR2(400),
  who_last_update   VARCHAR2(20),
  where_last_update VARCHAR2(6),
  when_last_update  DATE,
  source            VARCHAR2(6),
  when_create       DATE,
  who_create        VARCHAR2(20),
  where_create      VARCHAR2(10)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BY_RULE
  add constraint FARE_BY_RULE_TA_UX1 primary key (LOCATION_CODE, FARE_BY_RULE_ID, CARR_CODE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE_DTL
prompt ===============================
prompt
create table NFS_TA.FARE_BY_RULE_DTL
(
  location_code                 VARCHAR2(6) not null,
  fare_by_rule_id               VARCHAR2(30) not null,
  carr_code                     VARCHAR2(5) not null,
  fare_by_rule_dtl_id           VARCHAR2(30) not null,
  account_code                  VARCHAR2(4000),
  fbr_dtl_prior                 NUMBER(5),
  sale_eff_date                 DATE not null,
  sale_disc_date                DATE,
  first_travel_date             DATE not null,
  last_travel_date              DATE,
  ori_code_type                 NUMBER(1),
  ori_code                      VARCHAR2(13),
  dest_code_type                NUMBER(1),
  dest_code                     VARCHAR2(13),
  journey_type                  VARCHAR2(3),
  booking_class                 VARCHAR2(151),
  basefare_type                 NUMBER(1),
  price_choose                  NUMBER(1),
  rule_no                       VARCHAR2(13),
  rule_location_code            VARCHAR2(6),
  if_same_basefare_rule         NUMBER(1),
  if_only_direct_fare           NUMBER(1),
  if_same_basefare_group        NUMBER(1),
  if_use_other_rule_restriction NUMBER(1),
  outbound_permitted            NUMBER(1),
  inbound_permitted             NUMBER(1),
  minimum_stay                  NUMBER(3),
  minimum_stay_unit             VARCHAR2(6),
  maximum_stay                  NUMBER(3),
  maximum_stay_unit             VARCHAR2(6),
  rstf_caculate_type            NUMBER(1),
  rstf_amt                      NUMBER(5),
  rstf_currency_code            VARCHAR2(5),
  rstf_percent                  NUMBER(5,2),
  round_rule                    NUMBER(1),
  rstf_display_if_same_basefare NUMBER(1),
  rstf_display_fare_basis       VARCHAR2(15),
  rstf_display_adt_cmn_amt      NUMBER(8),
  rstf_display_base_cmn_amt     NUMBER(8),
  rstf_display_adt_cmn_pct      NUMBER(3),
  rstf_display_base_cmn_pct     NUMBER(3),
  rstf_display_tourcode         VARCHAR2(14),
  rstf_display_endorsment       VARCHAR2(510),
  distribution_status           NUMBER(1),
  distribution_date             DATE,
  who_last_update               VARCHAR2(20),
  where_last_update             VARCHAR2(6),
  when_last_update              DATE,
  baggage_allowance             NUMBER(2),
  baggage_unit                  NUMBER(1),
  discount_code                 VARCHAR2(2),
  source                        VARCHAR2(6),
  rstf_display_if_free_yq       NUMBER(1),
  eterm_rstf_display_endorsment VARCHAR2(510),
  y_cabin_price_choose_if       NUMBER(1),
  min_y_cabin_price             NUMBER(5),
  max_y_cabin_price             NUMBER(5),
  account_code_flag             NUMBER(1),
  remark                        VARCHAR2(200),
  when_create                   DATE,
  who_create                    VARCHAR2(20),
  where_create                  VARCHAR2(10),
  brand_source                  VARCHAR2(5),
  sub_class_flag                NUMBER(1),
  rstf_threshold_cal_type       NUMBER(1),
  rstf_threshold_cal_percent    NUMBER(5,2)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_BY_RULE_DTL_INDEX2 on NFS_TA.FARE_BY_RULE_DTL (CARR_CODE, SALE_EFF_DATE, FIRST_TRAVEL_DATE, ORI_CODE_TYPE, ORI_CODE, DEST_CODE_TYPE, DEST_CODE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BY_RULE_DTL
  add constraint FARE_BY_RULE_DTL_TA_UX1 primary key (LOCATION_CODE, FARE_BY_RULE_ID, CARR_CODE, FARE_BY_RULE_DTL_ID)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE_DTL_DISTRIBUTION
prompt ============================================
prompt
create table NFS_TA.FARE_BY_RULE_DTL_DISTRIBUTION
(
  group_id            VARCHAR2(37) not null,
  location_code       VARCHAR2(6) not null,
  fare_by_rule_id     VARCHAR2(30) not null,
  carr_code           VARCHAR2(5) not null,
  fare_by_rule_dtl_id VARCHAR2(30) not null,
  who_last_update     VARCHAR2(20),
  where_last_update   VARCHAR2(6),
  when_last_update    DATE,
  source              VARCHAR2(6)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BY_RULE_DTL_DISTRIBUTION
  add constraint FARE_BY_RULE_DTL_DIST_TA_UX1 primary key (LOCATION_CODE, FARE_BY_RULE_ID, CARR_CODE, FARE_BY_RULE_DTL_ID, GROUP_ID)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE_DTL_EXROUTE
prompt =======================================
prompt
create table NFS_TA.FARE_BY_RULE_DTL_EXROUTE
(
  carr_code           VARCHAR2(5) not null,
  location_code       VARCHAR2(6) not null,
  fare_by_rule_id     VARCHAR2(30) not null,
  fare_by_rule_dtl_id VARCHAR2(30) not null,
  exroute_no          NUMBER(3) not null,
  entry_lastnum       NUMBER(3),
  who_last_update     VARCHAR2(20),
  where_last_update   VARCHAR2(6),
  when_last_update    DATE,
  source              VARCHAR2(6)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BY_RULE_DTL_EXROUTE
  add constraint FARE_BY_RULE_DTL_EXROUTE_PK primary key (CARR_CODE, LOCATION_CODE, FARE_BY_RULE_ID, FARE_BY_RULE_DTL_ID, EXROUTE_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE_DTL_EXROUTE_ENTRY
prompt =============================================
prompt
create table NFS_TA.FARE_BY_RULE_DTL_EXROUTE_ENTRY
(
  carr_code           VARCHAR2(5) not null,
  location_code       VARCHAR2(6) not null,
  fare_by_rule_id     VARCHAR2(30) not null,
  fare_by_rule_dtl_id VARCHAR2(30) not null,
  exroute_no          NUMBER(3) not null,
  entry_no            NUMBER(3) not null,
  from_code           VARCHAR2(13),
  to_code             VARCHAR2(13),
  source              VARCHAR2(6)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_BY_RULE_DTL_EXROUTE_ENTRY
  add constraint FBR_DTL_EXROUTE_ENTRY_PK primary key (CARR_CODE, LOCATION_CODE, FARE_BY_RULE_ID, FARE_BY_RULE_DTL_ID, EXROUTE_NO, ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_DIS_CURRENT
prompt ===============================
prompt
create table NFS_TA.FARE_DIS_CURRENT
(
  agency_id_pcc   VARCHAR2(37) not null,
  carrier_code    CHAR(4) not null,
  location_code   CHAR(6) not null,
  ref_no          CHAR(15) not null,
  source          CHAR(6) not null,
  fare_rec_no     NUMBER(15) not null,
  sub_fare_rec_no NUMBER(5) default (0) not null,
  extension_id    CHAR(15) not null,
  corporate_id    CHAR(5) default ('-') not null,
  corporate_id2   CHAR(5) default ('-') not null,
  who_created     NUMBER(1) not null,
  distrib_type    NUMBER(1) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_D_C_CI1 on NFS_TA.FARE_DIS_CURRENT (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, FARE_REC_NO)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2080K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_D_C_CI2 on NFS_TA.FARE_DIS_CURRENT (CARRIER_CODE, LOCATION_CODE, REF_NO, FARE_REC_NO)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2080K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_DIS_CURRENT
  add constraint FARE_D_C_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, SOURCE, FARE_REC_NO, SUB_FARE_REC_NO, EXTENSION_ID, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_DIS_TMP_CURRENT
prompt ===================================
prompt
create table NFS_TA.FARE_DIS_TMP_CURRENT
(
  agency_id_pcc   VARCHAR2(15) not null,
  carrier_code    CHAR(4) not null,
  location_code   CHAR(6) not null,
  ref_no          CHAR(15) not null,
  source          CHAR(6) not null,
  fare_rec_no     NUMBER(5) not null,
  sub_fare_rec_no NUMBER(5) not null,
  extension_id    CHAR(15) not null,
  corporate_id    CHAR(5) not null,
  corporate_id2   CHAR(5) not null,
  who_created     NUMBER(1) not null,
  distrib_type    NUMBER(1) not null
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_RCVD_CURRENT
prompt ================================
prompt
create table NFS_TA.FARE_RCVD_CURRENT
(
  carrier_code                  CHAR(4) not null,
  location_code                 CHAR(6) not null,
  ref_no                        CHAR(15) not null,
  source                        CHAR(6) not null,
  extension_id                  CHAR(15) not null,
  fare_rec_no                   NUMBER(15) not null,
  sub_fare_rec_no               NUMBER(5) default (0) not null,
  rule_id                       CHAR(13),
  fare_category                 NUMBER(1),
  ori_city_code                 CHAR(5),
  dest_city_code                CHAR(5),
  ori_code                      CHAR(13),
  dest_code                     CHAR(13),
  journey_type                  CHAR(3),
  fare_basis                    CHAR(15),
  booking_class                 CHAR(2),
  global_direction              CHAR(2),
  amount                        NUMBER(11,3),
  infant_discount_amount        NUMBER(11,3),
  child_discount_amount         NUMBER(11,3),
  booking_class_2               CHAR(2),
  effective_date                DATE not null,
  discontinue_date              DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  first_travel_date             DATE,
  last_travel_date              DATE,
  first_ticketed_date           DATE,
  last_ticketed_date            DATE,
  stopover_flag                 CHAR(1),
  class_of_service              NUMBER(1),
  endorsement_restriction       VARCHAR2(255),
  base_commission_amt           NUMBER(7,2),
  base_commission_pct           NUMBER(2,2),
  addt_commission_amt           NUMBER(7,2),
  addt_commission_pct           NUMBER(2,2),
  ticket_type                   NUMBER(3) default (3) not null,
  ori_addon_no                  CHAR(13),
  dest_addon_no                 CHAR(13),
  fare_addon_flag               NUMBER(1) default 0,
  eterm_endorsement_restriction VARCHAR2(255)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_RCVD_CURRENT_INDX1 on NFS_TA.FARE_RCVD_CURRENT (FARE_REC_NO, SUB_FARE_REC_NO, CARRIER_CODE, LOCATION_CODE, REF_NO, EXTENSION_ID, EFFECTIVE_DATE, DISCONTINUE_DATE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 16M
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_RCVD_CURRENT_MYINDX1 on NFS_TA.FARE_RCVD_CURRENT (REF_NO, FARE_REC_NO)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_R_C_CI1 on NFS_TA.FARE_RCVD_CURRENT (CARRIER_CODE, ORI_CITY_CODE, DEST_CITY_CODE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2080K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_R_C_CI2 on NFS_TA.FARE_RCVD_CURRENT (CARRIER_CODE, LOCATION_CODE, EXTENSION_ID, ORI_CITY_CODE, DEST_CITY_CODE, EFFECTIVE_DATE, DISCONTINUE_DATE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 3080K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_R_C_CI3 on NFS_TA.FARE_RCVD_CURRENT (CARRIER_CODE, ORI_CODE, DEST_CODE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_R_C_CI4 on NFS_TA.FARE_RCVD_CURRENT (CARRIER_CODE, ORI_CODE, DEST_CITY_CODE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FARE_R_C_CI5 on NFS_TA.FARE_RCVD_CURRENT (CARRIER_CODE, ORI_CITY_CODE, DEST_CODE)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_RCVD_CURRENT
  add constraint FARE_RCVD_C_UX1 primary key (CARRIER_CODE, LOCATION_CODE, REF_NO, SOURCE, EXTENSION_ID, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE
prompt =========================
prompt
create table NFS_TA.FARE_ROUTE
(
  location_code   CHAR(6) not null,
  ref_no          CHAR(15) not null,
  fare_rec_no     NUMBER(15) not null,
  route_no        NUMBER(3) not null,
  entry_lastnum   NUMBER(3),
  sub_fare_rec_no NUMBER(5) default (0) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_ROUTE
  add constraint FARE_ROUTE_TA_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE_ENTRY
prompt ===============================
prompt
create table NFS_TA.FARE_ROUTE_ENTRY
(
  location_code        CHAR(6) not null,
  ref_no               CHAR(15) not null,
  fare_rec_no          NUMBER(15) not null,
  route_no             NUMBER(3) not null,
  entry_no             NUMBER(3) not null,
  from_code            CHAR(13),
  from_code_type       NUMBER(1),
  to_code              CHAR(13),
  to_code_type         NUMBER(1),
  stopover_or_transfer CHAR(1),
  open_jaw_for_btwn    NUMBER(1),
  q_charge_amt         NUMBER(11,3),
  sub_fare_rec_no      NUMBER(5) default (0) not null,
  min_stay             NUMBER(3),
  max_stay             NUMBER(3)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_ROUTE_ENTRY
  add constraint FARE_ROUTE_ENTRY_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, ENTRY_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE_FLIGHT_NO
prompt ===================================
prompt
create table NFS_TA.FARE_ROUTE_FLIGHT_NO
(
  location_code    CHAR(6) not null,
  ref_no           CHAR(15) not null,
  fare_rec_no      NUMBER(15) not null,
  route_no         NUMBER(3) not null,
  entry_no         NUMBER(3) not null,
  flight_entry_no  NUMBER(2) not null,
  carrier_code     CHAR(4) not null,
  ap_from_no       NUMBER(4),
  ap_to_no         NUMBER(4),
  ex_from_no       NUMBER(4),
  ex_to_no         NUMBER(4),
  booking_class    CHAR(2),
  booking_class2   CHAR(2),
  fare_basis_code  CHAR(15),
  fare_basis_code2 CHAR(15),
  sub_fare_rec_no  NUMBER(5) default (0) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_ROUTE_FLIGHT_NO
  add constraint FARE_ROUTE_FLIGHT_NO_CA_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, ENTRY_NO, FLIGHT_ENTRY_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_RULE
prompt ========================
prompt
create table NFS_TA.FARE_RULE
(
  location_code     CHAR(6) not null,
  ref_no            CHAR(15) not null,
  fare_rec_no       NUMBER(15) not null,
  minimum_stay      NUMBER(3),
  minimum_stay_unit CHAR(6),
  maximum_stay      NUMBER(3),
  maximum_stay_unit CHAR(6),
  sub_fare_rec_no   NUMBER(5) default (0) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_RULE
  add constraint FARE_RULE_TA_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_STOPOVER
prompt ============================
prompt
create table NFS_TA.FARE_STOPOVER
(
  location_code          CHAR(6) not null,
  ref_no                 CHAR(15) not null,
  fare_rec_no            NUMBER(15) not null,
  entry_no               NUMBER(3) not null,
  stopover_city          CHAR(13),
  via_carrier_code       CHAR(20),
  booking_class          CHAR(2),
  surcharge_amt_outbound NUMBER(11,3),
  surcharge_amt_inbound  NUMBER(11,3),
  departure_city         CHAR(13),
  fare_basis_code        CHAR(15),
  surcharge_chd_outbound NUMBER(11,3),
  surcharge_chd_inbound  NUMBER(11,3),
  surcharge_inf_outbound NUMBER(11,3),
  surcharge_inf_inbound  NUMBER(11,3),
  round_trip             NUMBER(1),
  stopover_type          NUMBER(1),
  departure_type         NUMBER(1),
  ap_from_no             NUMBER(4),
  ap_to_no               NUMBER(4),
  ex_from_no             NUMBER(4),
  ex_to_no               NUMBER(4),
  q_charge_amt           NUMBER(11,3),
  sub_fare_rec_no        NUMBER(5) default (0) not null
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.FARE_STOPOVER
  add constraint FARE_STOPOVER_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ENTRY_NO, SUB_FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GROUPS
prompt =====================
prompt
create table NFS_TA.GROUPS
(
  agency_id_pcc     VARCHAR2(6) not null,
  group_id          VARCHAR2(37) not null,
  group_desc        VARCHAR2(35),
  who_last_update   VARCHAR2(20),
  when_last_update  DATE,
  where_last_update VARCHAR2(6),
  group_type        NUMBER(1) default (0)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.GROUPS
  add constraint GROUPS_UX1 primary key (AGENCY_ID_PCC, GROUP_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GROUPS_ENTRY
prompt ===========================
prompt
create table NFS_TA.GROUPS_ENTRY
(
  agency_id_pcc  VARCHAR2(6) not null,
  group_id       VARCHAR2(37) not null,
  member_id_pcc  VARCHAR2(6) not null,
  member_id_iata VARCHAR2(7),
  dis_name       VARCHAR2(10),
  agency_id_iata VARCHAR2(7),
  city_code      VARCHAR2(5),
  agency_name    VARCHAR2(50),
  sys_code       VARCHAR2(4)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.GROUPS_ENTRY_INDX2 on NFS_TA.GROUPS_ENTRY (GROUP_ID, DIS_NAME)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.GROUPS_ENTRY_UX2 on NFS_TA.GROUPS_ENTRY (MEMBER_ID_PCC, DIS_NAME)
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.GROUPS_ENTRY
  add constraint GROUPS_ENTRY_UX1 primary key (AGENCY_ID_PCC, GROUP_ID, MEMBER_ID_PCC)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LASTNUM
prompt ======================
prompt
create table NFS_TA.LASTNUM
(
  location_code CHAR(6) not null,
  key_type      CHAR(2) not null,
  lastnum       NUMBER(5)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.LASTNUM
  add constraint LASTNUM_UX1 primary key (LOCATION_CODE, KEY_TYPE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MLOG$_FARE_DIS_CURRENT
prompt =====================================
prompt
create table NFS_TA.MLOG$_FARE_DIS_CURRENT
(
  m_row$$         VARCHAR2(255),
  snaptime$$      DATE,
  dmltype$$       VARCHAR2(1),
  old_new$$       VARCHAR2(1),
  change_vector$$ RAW(255)
)
tablespace TA_DAT
  pctfree 60
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table NFS_TA.MLOG$_FARE_DIS_CURRENT
  is 'snapshot log for master table NFS_TA.FARE_DIS_CURRENT';

prompt
prompt Creating table MLOG$_FARE_RCVD_CURRENT
prompt ======================================
prompt
create table NFS_TA.MLOG$_FARE_RCVD_CURRENT
(
  m_row$$         VARCHAR2(255),
  snaptime$$      DATE,
  dmltype$$       VARCHAR2(1),
  old_new$$       VARCHAR2(1),
  change_vector$$ RAW(255)
)
tablespace TA_DAT
  pctfree 60
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table NFS_TA.MLOG$_FARE_RCVD_CURRENT
  is 'snapshot log for master table NFS_TA.FARE_RCVD_CURRENT';

prompt
prompt Creating table NEW_DISTRIBUTION
prompt ===============================
prompt
create table NFS_TA.NEW_DISTRIBUTION
(
  carrier_code      CHAR(4) not null,
  location_code     CHAR(6) not null,
  distrib_id        CHAR(6) not null,
  recpt_id          VARCHAR2(47) not null,
  ref_no            CHAR(15) not null,
  extension_id      CHAR(15) not null,
  effective_date    DATE not null,
  discontinue_date  DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  currency_code     CHAR(3),
  level_of_sub      NUMBER(1),
  no_ext_sub        NUMBER(3),
  no_ext_internal   NUMBER(3),
  sub_last_ext      CHAR(2),
  internal_last_ext CHAR(2),
  who_distribute    CHAR(20),
  when_distribute   DATE,
  group_id          VARCHAR2(37),
  corporate_id      CHAR(5) default ('-') not null,
  corporate_id2     CHAR(5) default ('-') not null,
  distrib_type      NUMBER(1) not null,
  who_created       NUMBER(1) not null,
  fare_category     NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.NEW_DISTRIBUTION_CI1 on NFS_TA.NEW_DISTRIBUTION (CARRIER_CODE, RECPT_ID, CORPORATE_ID, CORPORATE_ID2, LOCATION_CODE)
  tablespace TA_IDX
  pctfree 30
  initrans 2
  maxtrans 255
  storage
  (
    initial 2080K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.NEW_DISTRIBUTION_CI2 on NFS_TA.NEW_DISTRIBUTION (RECPT_ID)
  tablespace TA_IDX
  pctfree 30
  initrans 2
  maxtrans 255
  storage
  (
    initial 1040K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.NEW_DISTRIBUTION_CI3 on NFS_TA.NEW_DISTRIBUTION (DISTRIB_ID, CORPORATE_ID, CORPORATE_ID2)
  tablespace TA_IDX
  pctfree 30
  initrans 2
  maxtrans 255
  storage
  (
    initial 2080K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.NEW_DISTRIBUTION_CI4 on NFS_TA.NEW_DISTRIBUTION (LOCATION_CODE)
  tablespace TA_IDX
  pctfree 30
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.NEW_DISTRIBUTION
  add constraint NEW_DISTRIBUTION_UX1 primary key (CARRIER_CODE, LOCATION_CODE, DISTRIB_ID, RECPT_ID, REF_NO, EXTENSION_ID, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTE
prompt ====================
prompt
create table NFS_TA.ROUTE
(
  location_code CHAR(6) not null,
  routing_id    CHAR(13) not null,
  route_no      NUMBER(3) not null,
  entry_lastnum NUMBER(3)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ROUTE
  add constraint ROUTE_UX1 primary key (LOCATION_CODE, ROUTING_ID, ROUTE_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTE_ENTRY
prompt ==========================
prompt
create table NFS_TA.ROUTE_ENTRY
(
  location_code     CHAR(6) not null,
  routing_id        CHAR(13) not null,
  route_no          NUMBER(3) not null,
  entry_no          NUMBER(3) not null,
  from_code         CHAR(13) not null,
  from_code_type    NUMBER(1) default (0),
  to_code           CHAR(13) not null,
  to_code_type      NUMBER(1) default (0),
  open_jaw_for_btwn NUMBER(1) default (0)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ROUTE_ENTRY
  add constraint FARE_ROU_ENT_TA_UX1 primary key (LOCATION_CODE, ROUTING_ID, ROUTE_NO, ENTRY_NO, FROM_CODE, TO_CODE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTING
prompt ======================
prompt
create table NFS_TA.ROUTING
(
  location_code     CHAR(6) not null,
  routing_id        CHAR(13) not null,
  ori_code          CHAR(13) not null,
  dest_code         CHAR(13) not null,
  journey_type      CHAR(3),
  route_lastnum     NUMBER(3),
  who_last_update   CHAR(20),
  where_last_update CHAR(6),
  when_last_update  DATE default (SYSDATE),
  ori_code_type     NUMBER(1),
  dest_code_type    NUMBER(1)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ROUTING
  add constraint ROUTING_UX1 primary key (LOCATION_CODE, ROUTING_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE
prompt ===================
prompt
create table NFS_TA.RULE
(
  location_code              VARCHAR2(6) not null,
  rule_id                    VARCHAR2(13) not null,
  carr_code                  VARCHAR2(5) not null,
  minimum_stay               NUMBER(3),
  minimum_stay_unit          CHAR(6),
  maximum_stay               NUMBER(3),
  maximum_stay_unit          CHAR(6),
  construction_addons        NUMBER(1),
  day_of_week_restriction    NUMBER(3),
  advance_purchase           NUMBER(3) default (0),
  who_last_update            CHAR(20),
  where_last_update          CHAR(5),
  when_last_update           DATE,
  rule_type                  NUMBER(1) not null,
  status                     NUMBER(1),
  day_of_week_restriction_in NUMBER(3),
  fares_combination_flag     NUMBER(1) default 1,
  group_flag                 NUMBER(1) default (0) not null,
  group_from                 NUMBER(4),
  group_to                   NUMBER(4),
  separate_sale_type         NUMBER(1) default 1,
  reissue_id                 VARCHAR2(30),
  refund_rule_id             VARCHAR2(30) default '',
  combine_open_jaw_flag      NUMBER(1) default 1,
  combine_round_trip_flag    NUMBER(1) default 1,
  max_advanced_purchase      NUMBER(3),
  max_advanced_purchase_unit VARCHAR2(5) default 'Days' not null,
  min_advanced_purchase_unit VARCHAR2(5) default 'Days' not null,
  open_jaw_flag              NUMBER(1) default 0 not null,
  candidate_flag             NUMBER(1) default 0 not null,
  code_share                 NUMBER(1) default 0,
  appcxr_code_share          VARCHAR2(30),
  travel_complete_days_restr NUMBER(3),
  rule_id_no                 VARCHAR2(20),
  sector_range_lower         NUMBER(1),
  sector_range_upper         NUMBER(1),
  forbidden_journey_flag     NUMBER(1) default 0,
  position_limit_type        NUMBER(1) default 0,
  position_limit_spec        NUMBER(1),
  charter_flight_flag        NUMBER(1),
  rule_desc                  VARCHAR2(512),
  rule_seq_id                NUMBER(4),
  effective_date             DATE default to_date('19000101 00:00','yyyyMMdd HH24:mi') not null,
  discontinue_date           DATE default to_date('99991231 23:59','yyyyMMdd HH24:mi') not null,
  xml_import_flag            NUMBER(1) default 0
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE
  add constraint RULE_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE
  add unique (RULE_ID_NO)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_BLACKOUT_PERIOD
prompt ===================================
prompt
create table NFS_TA.RULE_BLACKOUT_PERIOD
(
  location_code      VARCHAR2(6) not null,
  rule_id            VARCHAR2(13) not null,
  carr_code          VARCHAR2(5) not null,
  blackout_from_date DATE not null,
  blackout_to_date   DATE,
  rule_seq_id        NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_BLACKOUT_PERIOD
  add constraint RULE_BLACKOUT_PERIOD_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, BLACKOUT_FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_BLACKOUT_PERIOD_IN
prompt ======================================
prompt
create table NFS_TA.RULE_BLACKOUT_PERIOD_IN
(
  location_code      VARCHAR2(6) not null,
  rule_id            VARCHAR2(13) not null,
  carr_code          VARCHAR2(5) not null,
  blackout_from_date DATE not null,
  blackout_to_date   DATE,
  rule_seq_id        NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_BLACKOUT_PERIOD_IN
  add primary key (LOCATION_CODE, RULE_ID, CARR_CODE, BLACKOUT_FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_COMBINATION_ENTRY
prompt =====================================
prompt
create table NFS_TA.RULE_COMBINATION_ENTRY
(
  rule_id              VARCHAR2(13) not null,
  location_code        VARCHAR2(6) not null,
  carr_code            VARCHAR2(5) not null,
  seq_id               NUMBER(3) not null,
  combine_rule_id      VARCHAR2(13),
  fare_basis           VARCHAR2(15),
  booking_class        VARCHAR2(1),
  last_update_by       VARCHAR2(20) not null,
  last_update_date     DATE not null,
  carrier_code         VARCHAR2(2) default 'CA' not null,
  is_check_all_sectors NUMBER(1) default 1 not null,
  rule_seq_id          NUMBER(4),
  ori_code             VARCHAR2(13) default '***',
  dest_code            VARCHAR2(13) default '***'
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_COMBINATION_ENTRY
  add constraint RULE_COMBINATION_ENTRY_PK primary key (RULE_ID, LOCATION_CODE, CARR_CODE, SEQ_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_ENDORSEMT_RESTRICTION
prompt =========================================
prompt
create table NFS_TA.RULE_ENDORSEMT_RESTRICTION
(
  location_code  VARCHAR2(6) not null,
  rule_id        VARCHAR2(13) not null,
  carr_code      VARCHAR2(5) not null,
  restriction_id NUMBER(5) not null,
  rule_seq_id    NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_ENDORSEMT_RESTRICTION
  add constraint RULE_ENDORSEMT_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, RESTRICTION_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_EX_FLIGHT_NO
prompt ================================
prompt
create table NFS_TA.RULE_EX_FLIGHT_NO
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FROM_NO_IDX on NFS_TA.RULE_EX_FLIGHT_NO (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.TO_NO_IDX on NFS_TA.RULE_EX_FLIGHT_NO (TO_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_EX_FLIGHT_NO
  add constraint RULE_EX_FLIGHT_NO_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_EX_FLIGHT_NO_IN
prompt ===================================
prompt
create table NFS_TA.RULE_EX_FLIGHT_NO_IN
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.TO_NO_INDEX on NFS_TA.RULE_EX_FLIGHT_NO_IN (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_EX_FLIGHT_NO_IN
  add constraint RULE_EX_FLIGHT_NO_IN_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_FLIGHT_NO_RESTRICTION
prompt =========================================
prompt
create table NFS_TA.RULE_FLIGHT_NO_RESTRICTION
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_FLIGHT_NO_RESTRICTION
  add constraint RULE_FLIGHT_NO_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_FLIGHT_NO_RESTRICTION_IN
prompt ============================================
prompt
create table NFS_TA.RULE_FLIGHT_NO_RESTRICTION_IN
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.FROM_NO_INDX on NFS_TA.RULE_FLIGHT_NO_RESTRICTION_IN (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.TO_NO_INDX on NFS_TA.RULE_FLIGHT_NO_RESTRICTION_IN (TO_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_FLIGHT_NO_RESTRICTION_IN
  add constraint RULE_FLIGHT_NO_REST_IN_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_HOUR_RESTRICTION
prompt ====================================
prompt
create table NFS_TA.RULE_HOUR_RESTRICTION
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_HOUR_RESTRICTION
  add constraint RULE_HOUR_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_HOUR_RESTRICTION_IN
prompt =======================================
prompt
create table NFS_TA.RULE_HOUR_RESTRICTION_IN
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_HOUR_RESTRICTION_IN
  add constraint RULE_HOUR_RESTRICTION_IN_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REFUND
prompt ==========================
prompt
create table NFS_TA.RULE_REFUND
(
  refund_rule_id       VARCHAR2(30) not null,
  location_code        VARCHAR2(6) not null,
  refund_type          NUMBER(1) not null,
  unused_sector_tax    NUMBER(1),
  voluntary_txt        VARCHAR2(150),
  involuntary_txt      VARCHAR2(150),
  last_update_by       VARCHAR2(20) not null,
  last_update_date     DATE not null,
  rule_type            NUMBER(1) default 0 not null,
  refund_yqtax_allowed NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_REFUND
  add constraint RULE_REFUND_PK primary key (REFUND_RULE_ID, RULE_TYPE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REFUND_ENTRY
prompt ================================
prompt
create table NFS_TA.RULE_REFUND_ENTRY
(
  refund_rule_id            VARCHAR2(30) not null,
  seq_id                    NUMBER(3) not null,
  passenger_type            VARCHAR2(2),
  journey_type              VARCHAR2(2),
  booking_class             VARCHAR2(26),
  fare_basis                VARCHAR2(15),
  ticket_use_type           NUMBER(1) not null,
  first_ticketed_time       NUMBER(4),
  last_ticketed_time        NUMBER(4),
  departrue_time_type       NUMBER(1),
  first_departrue_time      NUMBER(4),
  last_departrue_time       NUMBER(4),
  cal_used_sector_type      NUMBER(1),
  cal_booking_class         VARCHAR2(1),
  cal_unused_sector_type    NUMBER(1) not null,
  percent                   NUMBER(3),
  minimum_amount            NUMBER(4),
  fixed_amount              NUMBER(4),
  tax_refund_type           NUMBER(1) not null,
  last_update_by            VARCHAR2(20) not null,
  last_update_date          DATE not null,
  entry_translate           VARCHAR2(4000),
  spec_rbd                  VARCHAR2(1),
  lower_value               NUMBER(3),
  lower_relate              VARCHAR2(2),
  upper_value               NUMBER(3),
  upper_relate              VARCHAR2(2),
  ticketed_time_unit        VARCHAR2(1) default 'H',
  departrue_time_unit       VARCHAR2(1) default 'H',
  cal_unused_pfare_percent  NUMBER(3),
  special_production_tag    NUMBER(1),
  priority_type             NUMBER(1),
  priority_list             VARCHAR2(100),
  rule_type                 NUMBER(1) default 0 not null,
  refund_allowed_tag        NUMBER(1) default 1,
  refund_yqtax_allowed      NUMBER(1),
  other_refund_carrier_list VARCHAR2(100)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_REFUND_ENTRY
  add constraint RULE_REFUND_ENTRY_PK primary key (REFUND_RULE_ID, SEQ_ID, RULE_TYPE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE
prompt ===========================
prompt
create table NFS_TA.RULE_REISSUE
(
  reissue_id               VARCHAR2(30) not null,
  location_code            VARCHAR2(6) not null,
  change_tag               VARCHAR2(1),
  voluntary_changed_text   VARCHAR2(450),
  involuntary_changed_text VARCHAR2(450),
  who_last_update          VARCHAR2(20),
  where_last_update        VARCHAR2(5),
  when_last_update         DATE default (SYSDATE),
  rule_type                NUMBER(1) default 0 not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_REISSUE
  add constraint RULE_REISSUE_PK primary key (REISSUE_ID, RULE_TYPE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE_DETAIL
prompt ==================================
prompt
create table NFS_TA.RULE_REISSUE_DETAIL
(
  reissue_id                 VARCHAR2(30) not null,
  seq_number                 NUMBER(3) not null,
  passenger_type             VARCHAR2(3),
  fare_basis                 VARCHAR2(15),
  booking_class              VARCHAR2(26),
  journey_type               VARCHAR2(2),
  ticket_used_tag            NUMBER(1),
  flight_launch_tag          VARCHAR2(1),
  flight_launch_unit         VARCHAR2(1),
  flight_launch_number       NUMBER(3),
  free_change_times          VARCHAR2(1),
  charge_type                NUMBER(1),
  charge_currency_code       VARCHAR2(3),
  charge_amount              NUMBER(5),
  discount_calculate_type    NUMBER(1),
  discount_booking_class     VARCHAR2(1),
  discount_percent           NUMBER(5,2),
  charge_unit                NUMBER(1),
  carry_unit                 NUMBER(1),
  round_type                 NUMBER(1),
  charge_min_amount          NUMBER(5),
  charge_min_currency_code   VARCHAR2(3),
  reissue_charge_tag         NUMBER(1),
  reissue_restriction_id     NUMBER(7) not null,
  who_last_update            VARCHAR2(20),
  where_last_update          VARCHAR2(5),
  when_last_update           DATE default (SYSDATE),
  detail_translate           VARCHAR2(4000),
  lower_value                NUMBER(3),
  lower_relate               VARCHAR2(2),
  upper_value                NUMBER(3),
  upper_relate               VARCHAR2(2),
  special_production_tag     NUMBER(1),
  priority_type              NUMBER(1),
  priority_list              VARCHAR2(100),
  rule_type                  NUMBER(1) default 0 not null,
  other_reissue_carrier_list VARCHAR2(100),
  first_ticketed_time        NUMBER(4),
  last_ticketed_time         NUMBER(4),
  ticketed_time_unit         VARCHAR2(1) default 'H',
  departrue_time_type        NUMBER(1),
  first_departrue_time       NUMBER(4),
  last_departrue_time        NUMBER(4),
  departrue_time_unit        VARCHAR2(1) default 'H',
  reissue_allowed_tag        NUMBER(1) default 1,
  discount_code              VARCHAR2(2)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_REISSUE_DETAIL
  add constraint RULE_REISSUE_DETAIL_PK primary key (REISSUE_ID, SEQ_NUMBER, RULE_TYPE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE_RESTRICTION
prompt =======================================
prompt
create table NFS_TA.RULE_REISSUE_RESTRICTION
(
  id                            NUMBER(7) not null,
  process_tag                   NUMBER(1) not null,
  date_changed_tag              NUMBER(1) not null,
  first_flight_tag              NUMBER(1) not null,
  flight_date_tag               VARCHAR2(1),
  same_flight_tag               NUMBER(1) not null,
  upgrade_tag                   NUMBER(1) not null,
  fare_display_tag              NUMBER(1) not null,
  endorsment_tag                NUMBER(1) not null,
  endorsment_prefix             VARCHAR2(10),
  endorsment_suffix             VARCHAR2(10),
  new_endorsment                VARCHAR2(82),
  who_last_update               VARCHAR2(20),
  where_last_update             VARCHAR2(5),
  when_last_update              DATE default (SYSDATE),
  flight_date_num               NUMBER(3),
  flight_date_unit              VARCHAR2(1),
  not_permit_cabin_list         VARCHAR2(100),
  rule_type                     NUMBER(1) default 0 not null,
  upgrade_fee_tag               NUMBER(1) default 0,
  other_carrier_list            VARCHAR2(100),
  modclass_newfare_allowlow_tag NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_REISSUE_RESTRICTION
  add constraint RULE_REISSUE_RESTRICTION_PK primary key (ID, RULE_TYPE)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_SEASONALITY
prompt ===============================
prompt
create table NFS_TA.RULE_SEASONALITY
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_date     DATE not null,
  to_date       DATE,
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_TA.RULE_SEASONALITY_INDX on NFS_TA.RULE_SEASONALITY (LOCATION_CODE, RULE_ID)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_SEASONALITY
  add constraint RULE_SEASONALITY_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_SEASONALITY_IN
prompt ==================================
prompt
create table NFS_TA.RULE_SEASONALITY_IN
(
  location_code VARCHAR2(6) not null,
  rule_id       VARCHAR2(13) not null,
  carr_code     VARCHAR2(5) not null,
  from_date     DATE not null,
  to_date       DATE,
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_SEASONALITY_IN
  add constraint RULE_SEASONALITY_IN_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE, FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_TEXTUAL
prompt ===========================
prompt
create table NFS_TA.RULE_TEXTUAL
(
  location_code          VARCHAR2(6) not null,
  rule_id                VARCHAR2(13) not null,
  carr_code              VARCHAR2(5) not null,
  application            VARCHAR2(4000),
  eligibility            VARCHAR2(4000),
  maximum_group_size     VARCHAR2(4000),
  extension_of_validity  VARCHAR2(4000),
  payment                VARCHAR2(4000),
  ticketing              VARCHAR2(4000),
  cancellation_n_refunds VARCHAR2(4000),
  rebooking_n_rerouting  VARCHAR2(4000),
  travel_together        VARCHAR2(4000),
  other_conditions       VARCHAR2(4000),
  rule_seq_id            NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.RULE_TEXTUAL
  add constraint RULE_TEXTUAL_UX1 primary key (LOCATION_CODE, RULE_ID, CARR_CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SALES_OFFICE
prompt ===========================
prompt
create table NFS_TA.SALES_OFFICE
(
  location_code        CHAR(6) not null,
  so_type              NUMBER(1) not null,
  so_desc              VARCHAR2(35),
  parent_location_code CHAR(5),
  activated            CHAR(12),
  approval_required    NUMBER(1),
  who_last_update      CHAR(20),
  where_last_update    CHAR(6),
  when_last_update     DATE,
  print_option         NUMBER(1) default (3) not null,
  approving_office     NUMBER(1) default (0),
  approval_type        NUMBER(1) default (0),
  bsp_access           CHAR(4),
  exchange_rate        NUMBER(11,4)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.SALES_OFFICE
  add constraint SALES_OFFICE_UX1 primary key (LOCATION_CODE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SUBDISTRIBUTION
prompt ==============================
prompt
create table NFS_TA.SUBDISTRIBUTION
(
  agency_id_pcc CHAR(6) not null,
  carrier_code  CHAR(4) not null,
  location_code CHAR(6) not null,
  ref_no        CHAR(15) not null,
  extension_id  CHAR(15) not null,
  source        CHAR(6) not null,
  recpt_id_pcc  CHAR(6) not null,
  recpt_id_iata CHAR(7) not null,
  group_id      CHAR(13)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.SUBDISTRIBUTION
  add constraint SUBDISTRIBUTION_UX1 primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, EXTENSION_ID, SOURCE, RECPT_ID_PCC, RECPT_ID_IATA)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table USERS
prompt ====================
prompt
create table NFS_TA.USERS
(
  agency_id_pcc       CHAR(6) not null,
  user_id             CHAR(20) not null,
  name                VARCHAR2(35),
  password            VARCHAR2(20) not null,
  user_level          CHAR(20),
  core_user_id        CHAR(5),
  contact_no          CHAR(20),
  sita_telex_code     CHAR(10),
  email_address       VARCHAR2(40),
  address             VARCHAR2(128),
  last_login_datetime DATE,
  who_last_update     CHAR(20),
  when_last_update    DATE,
  fax_no              CHAR(20),
  status              CHAR(3)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.USERS
  add constraint USERS_UX1 primary key (AGENCY_ID_PCC, USER_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPFARE_RCVD_CURRENT
prompt ===================================
prompt
create table NFS_TA.VIPFARE_RCVD_CURRENT
(
  agency_id_pcc     VARCHAR2(37) not null,
  carrier_code      VARCHAR2(4) not null,
  location_code     VARCHAR2(5) not null,
  ref_no            VARCHAR2(15) not null,
  fare_rec_no       NUMBER(5) not null,
  sale_eff_date     DATE not null,
  sale_disc_date    DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  travel_eff_date   DATE not null,
  travel_disc_date  DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  ori_code_type     NUMBER(1) not null,
  ori_code          VARCHAR2(13) not null,
  dest_code_type    NUMBER(1) not null,
  dest_code         VARCHAR2(13) not null,
  fare_basis        VARCHAR2(15),
  vip_code          VARCHAR2(10) not null,
  algorithm         NUMBER(2) not null,
  discount_percent  NUMBER(3),
  who_last_update   VARCHAR2(20),
  when_last_update  DATE default (SYSDATE),
  where_last_update VARCHAR2(5)
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.VIPFARE_RCVD_CURRENT
  add constraint VIPFARE_RCVD_CURRENT_PK primary key (AGENCY_ID_PCC, CARRIER_CODE, LOCATION_CODE, REF_NO, FARE_REC_NO)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ZONE
prompt ===================
prompt
create table NFS_TA.ZONE
(
  location_code     CHAR(6) not null,
  zone_id           CHAR(13) not null,
  zone_desc         VARCHAR2(35),
  country_ind       NUMBER(1),
  who_last_update   CHAR(20),
  where_last_update CHAR(6),
  when_last_update  DATE
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ZONE
  add constraint ZONE_TA_UX1 primary key (LOCATION_CODE, ZONE_ID)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ZONE_ENTRY
prompt =========================
prompt
create table NFS_TA.ZONE_ENTRY
(
  location_code CHAR(6) not null,
  zone_id       CHAR(13) not null,
  code_type     CHAR(10) not null,
  code          CHAR(5) not null,
  name          VARCHAR2(35),
  country_code  CHAR(3)
)
tablespace TA_DAT
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_TA.ZONE_ENTRY
  add constraint ZONE_ENTRY_TA_UX1 primary key (LOCATION_CODE, ZONE_ID, CODE_TYPE, CODE)
  using index 
  tablespace TA_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating materialized view MV_ALL_FARE_3U
prompt =========================================
prompt
CREATE MATERIALIZED VIEW NFS_TA.MV_ALL_FARE_3U
REFRESH FAST ON COMMIT
AS
SELECT t1.rowid rowid1, t2.rowid rowid2, t3.rowid rowid3, t1.CARRIER_CODE CARRIER_CODE, 
  t1.LOCATION_CODE LOCATION_CODE, t1.REF_NO REF_NO,	t1.FARE_REC_NO FARE_REC_NO, t2.TICKET_TYPE TICKET_TYPE, 
  t2.BASE_COMMISSION_AMT BASE_COMMISSION_AMT, t2.BASE_COMMISSION_PCT BASE_COMMISSION_PCT, 
  t2.ADDT_COMMISSION_AMT ADDT_COMMISSION_AMT, t2.ADDT_COMMISSION_PCT ADDT_COMMISSION_PCT, 
  t2.DISCOUNT_CODE DISCOUNT_CODE, t1.SOURCE SOURCE, t1.ORI_CITY_CODE ORI_CITY_CODE, 
  t1.DEST_CITY_CODE DEST_CITY_CODE, t1.JOURNEY_TYPE JOURNEY_TYPE, t1.FARE_BASIS FARE_BASIS, 
  t1.BOOKING_CLASS BOOKING_CLASS, t1.BOOKING_CLASS_2 BOOKING_CLASS_2, t1.GLOBAL_DIRECTION GLOBAL_DIRECTION, 
  t1.AMOUNT AMOUNT, t1.INFANT_DISCOUNT_AMOUNT INFANT_DISCOUNT_AMOUNT, t1.CHILD_DISCOUNT_AMOUNT CHILD_DISCOUNT_AMOUNT, 
  t1.DISCONTINUE_DATE DISCONTINUE_DATE,	t2.VALUE_CODE VALUE_CODE, t2.CHILD_VALUE_CODE CHILD_VALUE_CODE, 
  t2.INFANT_VALUE_CODE INFANT_VALUE_CODE, t2.TOUR_CODE TOUR_CODE, t2.CHILD_TOUR_CODE CHILD_TOUR_CODE, 
  t2.INFANT_TOUR_CODE INFANT_TOUR_CODE, t1.FIRST_TRAVEL_DATE FIRST_TRAVEL_DATE1, 	t1.LAST_TRAVEL_DATE LAST_TRAVEL_DATE1,
  t1.FIRST_TICKETED_DATE FIRST_TICKETED_DATE,	t1.LAST_TICKETED_DATE LAST_TICKETED_DATE,	t2.FARE_TYPE FARE_TYPE, 
  t2.ENDORSEMENT_RESTRICTION ENDORSEMENT_RESTRICTION, t3.WHO_CREATED WHO_CREATED, t3.EXTENSION_ID EXTENSION_ID, 
  t3.SUB_FARE_REC_NO SUB_FARE_REC_NO, t2.OUTBOUND_PERMITTED OUTBOUND_PERMITTED, t2.INBOUND_PERMITTED INBOUND_PERMITTED, 
  t2.PUBLISHED_FARE_BASIS_CODE PUBLISHED_FARE_BASIS_CODE, t2.CHILD_PUBLISHED_FBC CHILD_PUBLISHED_FBC, 
  t2.INFANT_PUBLISHED_FBC INFANT_PUBLISHED_FBC, t2.THRU_FARE THRU_FARE, t1.ORI_ADDON_NO ORI_ADDON_NO, 
  t1.DEST_ADDON_NO DEST_ADDON_NO, t1.FARE_ADDON_FLAG FARE_ADDON_FLAG, t1.ORI_CODE ORI_CODE,	t1.DEST_CODE DEST_CODE,	
  t1.FARE_CATEGORY FARE_CATEGORY,	t1.EFFECTIVE_DATE EFFECTIVE_DATE,	t2.TRAVEL_COMPLETE_DATE TRAVEL_COMPLETE_DATE,	
  t3.CORPORATE_ID CORPORATE_ID,	t3.AGENCY_ID_PCC AGENCY_ID_PCC, t3.CORPORATE_ID2 CORPORATE_ID2	
  FROM 	NFS_TA.FARE_DIS_CURRENT t3,	NFS_TA.FARE_RCVD_CURRENT t1,
  NFS_3u.FARE t2 
   WHERE t3.CARRIER_CODE = t1.CARRIER_CODE  AND t3.LOCATION_CODE = t1.LOCATION_CODE  AND t3.REF_NO = t1.REF_NO 
  AND t3.SOURCE = t1.SOURCE AND t3.FARE_REC_NO = t1.FARE_REC_NO AND t3.SUB_FARE_REC_NO = t1.SUB_FARE_REC_NO 
  AND t3.EXTENSION_ID = t1.EXTENSION_ID AND t1.CARRIER_CODE = '3U' AND t1.LOCATION_CODE = t2.LOCATION_CODE 
  AND t1.REF_NO = t2.REF_NO AND t1.FARE_REC_NO = t2.FARE_REC_NO AND t1.SUB_FARE_REC_NO = t2.SUB_FARE_REC_NO;

prompt
prompt Creating materialized view MV_ALL_FARE_CZ
prompt =========================================
prompt
CREATE MATERIALIZED VIEW NFS_TA.MV_ALL_FARE_CZ
REFRESH FAST ON COMMIT
AS
SELECT t1.rowid rowid1, t2.rowid rowid2, t3.rowid rowid3, t1.CARRIER_CODE CARRIER_CODE, t1.LOCATION_CODE LOCATION_CODE, t1.REF_NO REF_NO,	t1.FARE_REC_NO FARE_REC_NO, t2.TICKET_TYPE TICKET_TYPE, t2.BASE_COMMISSION_AMT BASE_COMMISSION_AMT, t2.BASE_COMMISSION_PCT BASE_COMMISSION_PCT, t2.ADDT_COMMISSION_AMT ADDT_COMMISSION_AMT, t2.ADDT_COMMISSION_PCT ADDT_COMMISSION_PCT, t2.DISCOUNT_CODE DISCOUNT_CODE, t1.SOURCE SOURCE, t1.ORI_CITY_CODE ORI_CITY_CODE, t1.DEST_CITY_CODE DEST_CITY_CODE, t1.JOURNEY_TYPE JOURNEY_TYPE, t1.FARE_BASIS FARE_BASIS, t1.BOOKING_CLASS BOOKING_CLASS, t1.BOOKING_CLASS_2 BOOKING_CLASS_2, t1.GLOBAL_DIRECTION GLOBAL_DIRECTION, t1.AMOUNT AMOUNT, t1.INFANT_DISCOUNT_AMOUNT INFANT_DISCOUNT_AMOUNT, t1.CHILD_DISCOUNT_AMOUNT CHILD_DISCOUNT_AMOUNT, t1.DISCONTINUE_DATE DISCONTINUE_DATE,	t2.VALUE_CODE VALUE_CODE, t2.CHILD_VALUE_CODE CHILD_VALUE_CODE, t2.INFANT_VALUE_CODE INFANT_VALUE_CODE, t2.TOUR_CODE TOUR_CODE, t2.CHILD_TOUR_CODE CHILD_TOUR_CODE, t2.INFANT_TOUR_CODE INFANT_TOUR_CODE, t1.FIRST_TRAVEL_DATE FIRST_TRAVEL_DATE1, 	t1.LAST_TRAVEL_DATE LAST_TRAVEL_DATE1,t1.FIRST_TICKETED_DATE FIRST_TICKETED_DATE,	t1.LAST_TICKETED_DATE LAST_TICKETED_DATE,	t2.FARE_TYPE FARE_TYPE, t2.ENDORSEMENT_RESTRICTION ENDORSEMENT_RESTRICTION, t3.WHO_CREATED WHO_CREATED, t3.EXTENSION_ID EXTENSION_ID, t3.SUB_FARE_REC_NO SUB_FARE_REC_NO, t2.OUTBOUND_PERMITTED OUTBOUND_PERMITTED, t2.INBOUND_PERMITTED INBOUND_PERMITTED, t2.PUBLISHED_FARE_BASIS_CODE PUBLISHED_FARE_BASIS_CODE, t2.CHILD_PUBLISHED_FBC CHILD_PUBLISHED_FBC, t2.INFANT_PUBLISHED_FBC INFANT_PUBLISHED_FBC, t2.THRU_FARE THRU_FARE, t1.ORI_ADDON_NO ORI_ADDON_NO, t1.DEST_ADDON_NO DEST_ADDON_NO, t1.FARE_ADDON_FLAG FARE_ADDON_FLAG, t1.ORI_CODE ORI_CODE,	t1.DEST_CODE DEST_CODE,	t1.FARE_CATEGORY FARE_CATEGORY,	t1.EFFECTIVE_DATE EFFECTIVE_DATE,	t2.TRAVEL_COMPLETE_DATE TRAVEL_COMPLETE_DATE,	t3.CORPORATE_ID CORPORATE_ID,	t3.AGENCY_ID_PCC AGENCY_ID_PCC, t3.CORPORATE_ID2 CORPORATE_ID2	FROM 	NFS_TA.FARE_DIS_CURRENT t3,	NFS_TA.FARE_RCVD_CURRENT t1,NFS_CZ.FARE t2  WHERE t3.CARRIER_CODE = t1.CARRIER_CODE  AND t3.LOCATION_CODE = t1.LOCATION_CODE  AND t3.REF_NO = t1.REF_NO AND t3.SOURCE = t1.SOURCE AND t3.FARE_REC_NO = t1.FARE_REC_NO AND t3.SUB_FARE_REC_NO = t1.SUB_FARE_REC_NO AND t3.EXTENSION_ID = t1.EXTENSION_ID AND t1.CARRIER_CODE = 'CZ' AND t1.LOCATION_CODE = t2.LOCATION_CODE AND t1.REF_NO = t2.REF_NO AND t1.FARE_REC_NO = t2.FARE_REC_NO AND t1.SUB_FARE_REC_NO = t2.SUB_FARE_REC_NO;

prompt
prompt Creating materialized view MV_ALL_FARE_FM
prompt =========================================
prompt
CREATE MATERIALIZED VIEW NFS_TA.MV_ALL_FARE_FM
REFRESH FAST ON COMMIT
AS
SELECT t1.rowid rowid1, t2.rowid rowid2, t3.rowid rowid3, t1.CARRIER_CODE CARRIER_CODE, t1.LOCATION_CODE LOCATION_CODE, t1.REF_NO REF_NO,	t1.FARE_REC_NO FARE_REC_NO, t2.TICKET_TYPE TICKET_TYPE, t2.BASE_COMMISSION_AMT BASE_COMMISSION_AMT, t2.BASE_COMMISSION_PCT BASE_COMMISSION_PCT, t2.ADDT_COMMISSION_AMT ADDT_COMMISSION_AMT, t2.ADDT_COMMISSION_PCT ADDT_COMMISSION_PCT, t2.DISCOUNT_CODE DISCOUNT_CODE, t1.SOURCE SOURCE, t1.ORI_CITY_CODE ORI_CITY_CODE, t1.DEST_CITY_CODE DEST_CITY_CODE, t1.JOURNEY_TYPE JOURNEY_TYPE, t1.FARE_BASIS FARE_BASIS, t1.BOOKING_CLASS BOOKING_CLASS, t1.BOOKING_CLASS_2 BOOKING_CLASS_2, t1.GLOBAL_DIRECTION GLOBAL_DIRECTION, t1.AMOUNT AMOUNT, t1.INFANT_DISCOUNT_AMOUNT INFANT_DISCOUNT_AMOUNT, t1.CHILD_DISCOUNT_AMOUNT CHILD_DISCOUNT_AMOUNT, t1.DISCONTINUE_DATE DISCONTINUE_DATE,	t2.VALUE_CODE VALUE_CODE, t2.CHILD_VALUE_CODE CHILD_VALUE_CODE, t2.INFANT_VALUE_CODE INFANT_VALUE_CODE, t2.TOUR_CODE TOUR_CODE, t2.CHILD_TOUR_CODE CHILD_TOUR_CODE, t2.INFANT_TOUR_CODE INFANT_TOUR_CODE, t1.FIRST_TRAVEL_DATE FIRST_TRAVEL_DATE1, 	t1.LAST_TRAVEL_DATE LAST_TRAVEL_DATE1,t1.FIRST_TICKETED_DATE FIRST_TICKETED_DATE,	t1.LAST_TICKETED_DATE LAST_TICKETED_DATE,	t2.FARE_TYPE FARE_TYPE, t2.ENDORSEMENT_RESTRICTION ENDORSEMENT_RESTRICTION, t3.WHO_CREATED WHO_CREATED, t3.EXTENSION_ID EXTENSION_ID, t3.SUB_FARE_REC_NO SUB_FARE_REC_NO, t2.OUTBOUND_PERMITTED OUTBOUND_PERMITTED, t2.INBOUND_PERMITTED INBOUND_PERMITTED, t2.PUBLISHED_FARE_BASIS_CODE PUBLISHED_FARE_BASIS_CODE, t2.CHILD_PUBLISHED_FBC CHILD_PUBLISHED_FBC, t2.INFANT_PUBLISHED_FBC INFANT_PUBLISHED_FBC, t2.THRU_FARE THRU_FARE, t1.ORI_ADDON_NO ORI_ADDON_NO, t1.DEST_ADDON_NO DEST_ADDON_NO, t1.FARE_ADDON_FLAG FARE_ADDON_FLAG, t1.ORI_CODE ORI_CODE,	t1.DEST_CODE DEST_CODE,	t1.FARE_CATEGORY FARE_CATEGORY,	t1.EFFECTIVE_DATE EFFECTIVE_DATE,	t2.TRAVEL_COMPLETE_DATE TRAVEL_COMPLETE_DATE,	t3.CORPORATE_ID CORPORATE_ID,	t3.AGENCY_ID_PCC AGENCY_ID_PCC, t3.CORPORATE_ID2 CORPORATE_ID2	FROM 	NFS_TA.FARE_DIS_CURRENT t3,	NFS_TA.FARE_RCVD_CURRENT t1,NFS_FM.FARE t2  WHERE t3.CARRIER_CODE = t1.CARRIER_CODE  AND t3.LOCATION_CODE = t1.LOCATION_CODE  AND t3.REF_NO = t1.REF_NO AND t3.SOURCE = t1.SOURCE AND t3.FARE_REC_NO = t1.FARE_REC_NO AND t3.SUB_FARE_REC_NO = t1.SUB_FARE_REC_NO AND t3.EXTENSION_ID = t1.EXTENSION_ID AND t1.CARRIER_CODE = 'FM' AND t1.LOCATION_CODE = t2.LOCATION_CODE AND t1.REF_NO = t2.REF_NO AND t1.FARE_REC_NO = t2.FARE_REC_NO AND t1.SUB_FARE_REC_NO = t2.SUB_FARE_REC_NO;

prompt
prompt Creating materialized view MV_ALL_FARE_HU
prompt =========================================
prompt
CREATE MATERIALIZED VIEW NFS_TA.MV_ALL_FARE_HU
REFRESH FAST ON COMMIT
AS
SELECT t1.rowid rowid1, t2.rowid rowid2, t3.rowid rowid3, t1.CARRIER_CODE CARRIER_CODE, t1.LOCATION_CODE LOCATION_CODE, t1.REF_NO REF_NO,	t1.FARE_REC_NO FARE_REC_NO, t2.TICKET_TYPE TICKET_TYPE, t2.BASE_COMMISSION_AMT BASE_COMMISSION_AMT, t2.BASE_COMMISSION_PCT BASE_COMMISSION_PCT, t2.ADDT_COMMISSION_AMT ADDT_COMMISSION_AMT, t2.ADDT_COMMISSION_PCT ADDT_COMMISSION_PCT, t2.DISCOUNT_CODE DISCOUNT_CODE, t1.SOURCE SOURCE, t1.ORI_CITY_CODE ORI_CITY_CODE, t1.DEST_CITY_CODE DEST_CITY_CODE, t1.JOURNEY_TYPE JOURNEY_TYPE, t1.FARE_BASIS FARE_BASIS, t1.BOOKING_CLASS BOOKING_CLASS, t1.BOOKING_CLASS_2 BOOKING_CLASS_2, t1.GLOBAL_DIRECTION GLOBAL_DIRECTION, t1.AMOUNT AMOUNT, t1.INFANT_DISCOUNT_AMOUNT INFANT_DISCOUNT_AMOUNT, t1.CHILD_DISCOUNT_AMOUNT CHILD_DISCOUNT_AMOUNT, t1.DISCONTINUE_DATE DISCONTINUE_DATE,	t2.VALUE_CODE VALUE_CODE, t2.CHILD_VALUE_CODE CHILD_VALUE_CODE, t2.INFANT_VALUE_CODE INFANT_VALUE_CODE, t2.TOUR_CODE TOUR_CODE, t2.CHILD_TOUR_CODE CHILD_TOUR_CODE, t2.INFANT_TOUR_CODE INFANT_TOUR_CODE, t1.FIRST_TRAVEL_DATE FIRST_TRAVEL_DATE1, 	t1.LAST_TRAVEL_DATE LAST_TRAVEL_DATE1,t1.FIRST_TICKETED_DATE FIRST_TICKETED_DATE,	t1.LAST_TICKETED_DATE LAST_TICKETED_DATE,	t2.FARE_TYPE FARE_TYPE, t2.ENDORSEMENT_RESTRICTION ENDORSEMENT_RESTRICTION, t3.WHO_CREATED WHO_CREATED, t3.EXTENSION_ID EXTENSION_ID, t3.SUB_FARE_REC_NO SUB_FARE_REC_NO, t2.OUTBOUND_PERMITTED OUTBOUND_PERMITTED, t2.INBOUND_PERMITTED INBOUND_PERMITTED, t2.PUBLISHED_FARE_BASIS_CODE PUBLISHED_FARE_BASIS_CODE, t2.CHILD_PUBLISHED_FBC CHILD_PUBLISHED_FBC, t2.INFANT_PUBLISHED_FBC INFANT_PUBLISHED_FBC, t2.THRU_FARE THRU_FARE, t1.ORI_ADDON_NO ORI_ADDON_NO, t1.DEST_ADDON_NO DEST_ADDON_NO, t1.FARE_ADDON_FLAG FARE_ADDON_FLAG, t1.ORI_CODE ORI_CODE,	t1.DEST_CODE DEST_CODE,	t1.FARE_CATEGORY FARE_CATEGORY,	t1.EFFECTIVE_DATE EFFECTIVE_DATE,	t2.TRAVEL_COMPLETE_DATE TRAVEL_COMPLETE_DATE,	t3.CORPORATE_ID CORPORATE_ID,	t3.AGENCY_ID_PCC AGENCY_ID_PCC, t3.CORPORATE_ID2 CORPORATE_ID2	FROM 	NFS_TA.FARE_DIS_CURRENT t3,	NFS_TA.FARE_RCVD_CURRENT t1,NFS_HU.FARE t2  WHERE t3.CARRIER_CODE = t1.CARRIER_CODE  AND t3.LOCATION_CODE = t1.LOCATION_CODE  AND t3.REF_NO = t1.REF_NO AND t3.SOURCE = t1.SOURCE AND t3.FARE_REC_NO = t1.FARE_REC_NO AND t3.SUB_FARE_REC_NO = t1.SUB_FARE_REC_NO AND t3.EXTENSION_ID = t1.EXTENSION_ID AND t1.CARRIER_CODE = 'HU' AND t1.LOCATION_CODE = t2.LOCATION_CODE AND t1.REF_NO = t2.REF_NO AND t1.FARE_REC_NO = t2.FARE_REC_NO AND t1.SUB_FARE_REC_NO = t2.SUB_FARE_REC_NO;

prompt
prompt Creating function CREATE_MATERIALIZED_VIEW_SQL
prompt ==============================================
prompt
create or replace function nfs_ta.create_materialized_view_sql(carr in varchar2) return varchar2
as
  v_sql varchar2(10000);
begin
  v_sql := 'create materialized view mv_all_fare_'||lower(carr)||' tablespace TA_IDX refresh fast on commit as ';
  v_sql := v_sql ||'SELECT t1.rowid rowid1, t2.rowid rowid2, t3.rowid rowid3, t1.CARRIER_CODE CARRIER_CODE, ';
  v_sql := v_sql || 't1.LOCATION_CODE LOCATION_CODE, t1.REF_NO REF_NO,	t1.FARE_REC_NO FARE_REC_NO, t2.TICKET_TYPE TICKET_TYPE, ';
  v_sql := v_sql || 't2.BASE_COMMISSION_AMT BASE_COMMISSION_AMT, t2.BASE_COMMISSION_PCT BASE_COMMISSION_PCT, ';
  v_sql := v_sql || 't2.ADDT_COMMISSION_AMT ADDT_COMMISSION_AMT, t2.ADDT_COMMISSION_PCT ADDT_COMMISSION_PCT, ';
  v_sql := v_sql || 't2.DISCOUNT_CODE DISCOUNT_CODE, t1.SOURCE SOURCE, t1.ORI_CITY_CODE ORI_CITY_CODE, ';
  v_sql := v_sql || 't1.DEST_CITY_CODE DEST_CITY_CODE, t1.JOURNEY_TYPE JOURNEY_TYPE, t1.FARE_BASIS FARE_BASIS, ';
  v_sql := v_sql || 't1.BOOKING_CLASS BOOKING_CLASS, t1.BOOKING_CLASS_2 BOOKING_CLASS_2, t1.GLOBAL_DIRECTION GLOBAL_DIRECTION, ';
  v_sql := v_sql || 't1.AMOUNT AMOUNT, t1.INFANT_DISCOUNT_AMOUNT INFANT_DISCOUNT_AMOUNT, t1.CHILD_DISCOUNT_AMOUNT CHILD_DISCOUNT_AMOUNT, ';
  v_sql := v_sql || 't1.DISCONTINUE_DATE DISCONTINUE_DATE,	t2.VALUE_CODE VALUE_CODE, t2.CHILD_VALUE_CODE CHILD_VALUE_CODE, ';
  v_sql := v_sql || 't2.INFANT_VALUE_CODE INFANT_VALUE_CODE, t2.TOUR_CODE TOUR_CODE, t2.CHILD_TOUR_CODE CHILD_TOUR_CODE, ';
  v_sql := v_sql || 't2.INFANT_TOUR_CODE INFANT_TOUR_CODE, t1.FIRST_TRAVEL_DATE FIRST_TRAVEL_DATE1, 	t1.LAST_TRAVEL_DATE LAST_TRAVEL_DATE1,';
  v_sql := v_sql || 't1.FIRST_TICKETED_DATE FIRST_TICKETED_DATE,	t1.LAST_TICKETED_DATE LAST_TICKETED_DATE,	t2.FARE_TYPE FARE_TYPE, ';
  v_sql := v_sql || 't2.ENDORSEMENT_RESTRICTION ENDORSEMENT_RESTRICTION, t3.WHO_CREATED WHO_CREATED, t3.EXTENSION_ID EXTENSION_ID, ';
  v_sql := v_sql || 't3.SUB_FARE_REC_NO SUB_FARE_REC_NO, t2.OUTBOUND_PERMITTED OUTBOUND_PERMITTED, t2.INBOUND_PERMITTED INBOUND_PERMITTED, ';
  v_sql := v_sql || 't2.PUBLISHED_FARE_BASIS_CODE PUBLISHED_FARE_BASIS_CODE, t2.CHILD_PUBLISHED_FBC CHILD_PUBLISHED_FBC, ';
  v_sql := v_sql || 't2.INFANT_PUBLISHED_FBC INFANT_PUBLISHED_FBC, t2.THRU_FARE THRU_FARE, t1.ORI_ADDON_NO ORI_ADDON_NO, ';
  v_sql := v_sql || 't1.DEST_ADDON_NO DEST_ADDON_NO, t1.FARE_ADDON_FLAG FARE_ADDON_FLAG, t1.ORI_CODE ORI_CODE,	t1.DEST_CODE DEST_CODE,	';
  v_sql := v_sql || 't1.FARE_CATEGORY FARE_CATEGORY,	t1.EFFECTIVE_DATE EFFECTIVE_DATE,	t2.TRAVEL_COMPLETE_DATE TRAVEL_COMPLETE_DATE,	';
  v_sql := v_sql || 't3.CORPORATE_ID CORPORATE_ID,	t3.AGENCY_ID_PCC AGENCY_ID_PCC, t3.CORPORATE_ID2 CORPORATE_ID2	';
  v_sql := v_sql || 'FROM 	NFS_TA.FARE_DIS_CURRENT t3,	NFS_TA.FARE_RCVD_CURRENT t1,';
  v_sql := v_sql || 'NFS_'||upper(carr)||'.FARE t2 ';
  v_sql := v_sql || ' WHERE t3.CARRIER_CODE = t1.CARRIER_CODE  AND t3.LOCATION_CODE = t1.LOCATION_CODE  AND t3.REF_NO = t1.REF_NO ';
  v_sql := v_sql || 'AND t3.SOURCE = t1.SOURCE AND t3.FARE_REC_NO = t1.FARE_REC_NO AND t3.SUB_FARE_REC_NO = t1.SUB_FARE_REC_NO ';
  v_sql := v_sql || 'AND t3.EXTENSION_ID = t1.EXTENSION_ID AND t1.CARRIER_CODE = '''||upper(carr)||''' AND t1.LOCATION_CODE = t2.LOCATION_CODE ';
  v_sql := v_sql || 'AND t1.REF_NO = t2.REF_NO AND t1.FARE_REC_NO = t2.FARE_REC_NO AND t1.SUB_FARE_REC_NO = t2.SUB_FARE_REC_NO ';
  return(v_sql);
end create_materialized_view_sql;
/

prompt
prompt Creating function ISDISTRIBUTED
prompt ===============================
prompt
create or replace function nfs_ta.IsDistributed(p_carrier         in varchar,
                                         p_location        in varchar,
                                         p_ref_no          in varchar,
                                         p_fare_rec_no     in number,
                                         p_sub_fare_rec_no in number)
  return boolean as
  v_sqlstring varchar2(4000);
  v_return    boolean;
  num         number;
begin
  v_sqlstring := 'select count(*)  from nfs_ta.FARE_DIS_CURRENT t1, nfs_ta.fare_rcvd_current t2 ,nfs_mu.groups_entry t3
                    where t1.carrier_code = t2.carrier_code 
                    and t1.location_code = t2.location_code
                    and t1.ref_no = t2.ref_no 
                    and t1.fare_rec_no = t2.fare_rec_no
                    and t1.sub_fare_rec_no = t2.sub_fare_rec_no 
                    and t3.group_id = t1.AGENCY_ID_PCC
                    AND T3.DIS_NAME = ''1E''
                    and t1.ref_no = ''TEST_TS'' ';
  execute immediate v_sqlstring
    into num;
  if (num > 0) then
    v_return := true;
  else
    v_return := false;
  end if;
  return v_return;
end;
/

prompt
prompt Creating procedure ATRAIL
prompt =========================
prompt
CREATE OR REPLACE PROCEDURE NFS_TA.ATRAIL
(PCC IN CHAR, BYWHO IN CHAR, BYDATE IN DATE,CODE IN NUMBER, KEY IN CHAR, DETAILS IN VARCHAR2)
AS
BEGIN
INSERT INTO NFS_TA.AUDIT_TRAIL VALUES
(PCC, BYWHO, BYDATE, CODE, KEY, DETAILS);
END;
/

prompt
prompt Creating procedure CREATE_MATERIALIZED_VIEW
prompt ===========================================
prompt
create or replace procedure nfs_ta.create_materialized_view(carr in varchar2)
as
  v_sql varchar2(10000);
  v_grant_sql varchar2(500);
  cursor carr_cursor is select carr_code from fcims.host_ins_carr_mapping where oper_code = 1;
  v_carr fcims.host_ins_carr_mapping.carr_code%TYPE;
begin
  open carr_cursor;
  loop
    fetch carr_cursor into v_carr;
    exit when carr_cursor%NOTFOUND;
    if lower(carr) = 'all' then
       v_sql := create_materialized_view_sql(v_carr);
       execute immediate v_sql; 
       v_grant_sql := 'grant select on mv_all_fare_'||lower(v_carr)||' to nfsdis';
       execute immediate v_grant_sql;
    else
       if lower(v_carr) = lower(carr) then 
         v_sql := create_materialized_view_sql(v_carr);
         execute immediate v_sql; 
         v_grant_sql := 'grant select on mv_all_fare_'||lower(v_carr)||' to nfsdis';
         execute immediate v_grant_sql; 
       end if;
    end if;
  end loop;

  close carr_cursor;
EXCEPTION 
  when others then 
       dbms_output.put_line('����'||v_carr||'��ͼ�쳣,������ͼ�Ѿ����� '); 
       dbms_output.put_line('�����:'||SQLCODE);
       dbms_output.put_line('������Ϣ:'||SQLERRM); 
end create_materialized_view;
/

prompt
prompt Creating procedure TEST
prompt =======================
prompt
CREATE OR REPLACE PROCEDURE NFS_TA.test(ss out varchar2)
--AUTHID CURRENT_USER
    IS
       sqlstr   VARCHAR2 (500);
    BEGIN
          select ori_code into ss from fare;
          dbms_output.put_line(ss);
    END test;
/

prompt
prompt Creating trigger AGMT_RECEIVED_CURRENT_TRIGGER
prompt ==============================================
prompt
create or replace trigger nfs_ta.AGMT_RECEIVED_CURRENT_TRIGGER before delete or update or insert on nfs_ta.agreement_received_current for each row
DECLARE
    CURSOR carrier_cur IS select * from fcims.host_ins_carr_mapping t where t.oper_code=1;    
    TYPE emp_table_type IS TABLE OF fcims.host_ins_carr_mapping%ROWTYPE;
    emp_table emp_table_type;
    carrcode VARCHAR2(20);    
BEGIN
  OPEN carrier_cur;
  FETCH carrier_cur BULK COLLECT INTO emp_table;
  CLOSE carrier_cur;

  FOR i IN 1 ..  emp_table.COUNT LOOP  
    
  carrcode := emp_table(i).carr_code;

  if trim(:old.CARRIER_CODE) = carrcode OR trim(:new.CARRIER_CODE) = carrcode then
    if inserting then
      insert into NFS_TRACE.TA_AGMT_RCVD_TRACE
      values
        (:new.AGENCY_ID_PCC,
         :new.CARRIER_CODE,
         :new.LOCATION_CODE,
         :new.REF_NO,
         :new.EXTENSION_ID,
         :new.SOURCE,
         :new.EFFECTIVE_DATE,
         :new.DISCONTINUE_DATE,
         :new.LEVEL_OF_SUB,
         :new.NO_EXT_SUB,
         :new.NO_EXT_INTERNAL,
         :new.SUB_LAST_EXT,
         :new.INTERNAL_LAST_EXT,
         :new.WHO_DISTRIBUTE,
         :new.WHEN_DISTRIBUTE,
         :new.CURRENCY_CODE,
         :new.CORPORATE_ID,
         :new.CORPORATE_ID2,
         :new.DISTRIB_TYPE,
         :new.WHO_CREATED,
         :new.FARE_CATEGORY,
         sysdate,
         user,
         'insert');
    end if;
    if updating then
      insert into NFS_TRACE.TA_AGMT_RCVD_TRACE
      values
        (:old.AGENCY_ID_PCC,
         :old.CARRIER_CODE,
         :old.LOCATION_CODE,
         :old.REF_NO,
         :old.EXTENSION_ID,
         :old.SOURCE,
         :old.EFFECTIVE_DATE,
         :old.DISCONTINUE_DATE,
         :old.LEVEL_OF_SUB,
         :old.NO_EXT_SUB,
         :old.NO_EXT_INTERNAL,
         :old.SUB_LAST_EXT,
         :old.INTERNAL_LAST_EXT,
         :old.WHO_DISTRIBUTE,
         :old.WHEN_DISTRIBUTE,
         :old.CURRENCY_CODE,
         :old.CORPORATE_ID,
         :old.CORPORATE_ID2,
         :old.DISTRIB_TYPE,
         :old.WHO_CREATED,
         :old.FARE_CATEGORY,
         sysdate,
         user,
         'update_old');
      insert into NFS_TRACE.TA_AGMT_RCVD_TRACE
      values
        (:new.AGENCY_ID_PCC,
         :new.CARRIER_CODE,
         :new.LOCATION_CODE,
         :new.REF_NO,
         :new.EXTENSION_ID,
         :new.SOURCE,
         :new.EFFECTIVE_DATE,
         :new.DISCONTINUE_DATE,
         :new.LEVEL_OF_SUB,
         :new.NO_EXT_SUB,
         :new.NO_EXT_INTERNAL,
         :new.SUB_LAST_EXT,
         :new.INTERNAL_LAST_EXT,
         :new.WHO_DISTRIBUTE,
         :new.WHEN_DISTRIBUTE,
         :new.CURRENCY_CODE,
         :new.CORPORATE_ID,
         :new.CORPORATE_ID2,
         :new.DISTRIB_TYPE,
         :new.WHO_CREATED,
         :new.FARE_CATEGORY,
         sysdate,
         user,
         'update_new');
    end if;
    if deleting then
      insert into NFS_TRACE.TA_AGMT_RCVD_TRACE
      values
        (:old.AGENCY_ID_PCC,
         :old.CARRIER_CODE,
         :old.LOCATION_CODE,
         :old.REF_NO,
         :old.EXTENSION_ID,
         :old.SOURCE,
         :old.EFFECTIVE_DATE,
         :old.DISCONTINUE_DATE,
         :old.LEVEL_OF_SUB,
         :old.NO_EXT_SUB,
         :old.NO_EXT_INTERNAL,
         :old.SUB_LAST_EXT,
         :old.INTERNAL_LAST_EXT,
         :old.WHO_DISTRIBUTE,
         :old.WHEN_DISTRIBUTE,
         :old.CURRENCY_CODE,
         :old.CORPORATE_ID,
         :old.CORPORATE_ID2,
         :old.DISTRIB_TYPE,
         :old.WHO_CREATED,
         :old.FARE_CATEGORY,
         sysdate,
         user,
         'delete');
    end if;
  end if;
  end loop;
end;
/

prompt
prompt Creating trigger FARE_DIS_CUR_TRIGGER
prompt =====================================
prompt
create or replace trigger nfs_ta.FARE_DIS_CUR_TRIGGER before insert or delete or update on NFS_TA.FARE_DIS_CURRENT for each row
DECLARE
  CURSOR carrier_cur IS select * from fcims.host_ins_carr_mapping t where t.oper_code=1;    
  TYPE emp_table_type IS TABLE OF fcims.host_ins_carr_mapping%ROWTYPE;
  emp_table emp_table_type;
  carrcode VARCHAR2(20);    
BEGIN
  OPEN carrier_cur;
  FETCH carrier_cur BULK COLLECT INTO emp_table;
  CLOSE carrier_cur;

  FOR i IN 1 ..  emp_table.COUNT LOOP  
    
  carrcode := emp_table(i).carr_code;

  if trim(:old.CARRIER_CODE) = carrcode OR trim(:new.CARRIER_CODE) = carrcode then
    if inserting then
      insert into NFS_TRACE.TA_FARE_DIS_CUR_TRACE
      values
        (:new.AGENCY_ID_PCC,
         :new.CARRIER_CODE,
         :new.LOCATION_CODE,
         :new.REF_NO,
         :new.SOURCE,
         :new.FARE_REC_NO,
         :new.SUB_FARE_REC_NO,
         :new.EXTENSION_ID,
         :new.CORPORATE_ID,
         :new.CORPORATE_ID2,
         :new.WHO_CREATED,
         :new.DISTRIB_TYPE,
         sysdate,
         user,
         'insert');
    end if;
    if updating then
      insert into NFS_TRACE.TA_FARE_DIS_CUR_TRACE
      values
        (:old.AGENCY_ID_PCC,
         :old.CARRIER_CODE,
         :old.LOCATION_CODE,
         :old.REF_NO,
         :old.SOURCE,
         :old.FARE_REC_NO,
         :old.SUB_FARE_REC_NO,
         :old.EXTENSION_ID,
         :old.CORPORATE_ID,
         :old.CORPORATE_ID2,
         :old.WHO_CREATED,
         :old.DISTRIB_TYPE,
         sysdate,
         user,
         'update_old');
      insert into NFS_TRACE.TA_FARE_DIS_CUR_TRACE
      values
        (:new.AGENCY_ID_PCC,
         :new.CARRIER_CODE,
         :new.LOCATION_CODE,
         :new.REF_NO,
         :new.SOURCE,
         :new.FARE_REC_NO,
         :new.SUB_FARE_REC_NO,
         :new.EXTENSION_ID,
         :new.CORPORATE_ID,
         :new.CORPORATE_ID2,
         :new.WHO_CREATED,
         :new.DISTRIB_TYPE,
         sysdate,
         user,
         'update_new');
    end if;
    if deleting then
      insert into NFS_TRACE.TA_FARE_DIS_CUR_TRACE
      values
        (:old.AGENCY_ID_PCC,
         :old.CARRIER_CODE,
         :old.LOCATION_CODE,
         :old.REF_NO,
         :old.SOURCE,
         :old.FARE_REC_NO,
         :old.SUB_FARE_REC_NO,
         :old.EXTENSION_ID,
         :old.CORPORATE_ID,
         :old.CORPORATE_ID2,
         :old.WHO_CREATED,
         :old.DISTRIB_TYPE,
         sysdate,
         user,
         'delete');
    end if;
  end if;
  end loop;
end;
/

prompt
prompt Creating trigger FARE_RCVD_CUR_TRIGGER
prompt ======================================
prompt
create or replace trigger nfs_ta.FARE_RCVD_CUR_TRIGGER before insert or delete or update on NFS_TA.FARE_RCVD_CURRENT for each row
DECLARE
    CURSOR carrier_cur IS select * from fcims.host_ins_carr_mapping t where t.oper_code=1;    
    TYPE emp_table_type IS TABLE OF fcims.host_ins_carr_mapping%ROWTYPE;
    emp_table emp_table_type;
    carrcode VARCHAR2(20);  
BEGIN
  OPEN carrier_cur;
  FETCH carrier_cur BULK COLLECT INTO emp_table;
  CLOSE carrier_cur;

  FOR i IN 1 ..  emp_table.COUNT LOOP  
    
  carrcode := emp_table(i).carr_code;

  if trim(:old.CARRIER_CODE) = carrcode OR trim(:new.CARRIER_CODE) = carrcode then
    if inserting then
      insert into NFS_TRACE.TA_FARE_RCVD_CUR_TRACE
      values
        (:new.CARRIER_CODE,
        :new.LOCATION_CODE,
        :new.REF_NO,
        :new.SOURCE,
        :new.EXTENSION_ID,
        :new.FARE_REC_NO,
        :new.SUB_FARE_REC_NO,
        :new.RULE_ID,
        :new.FARE_CATEGORY,
        :new.ORI_CITY_CODE,
        :new.DEST_CITY_CODE,
        :new.ORI_CODE,
        :new.DEST_CODE,
        :new.JOURNEY_TYPE,
        :new.FARE_BASIS,
        :new.BOOKING_CLASS,
        :new.GLOBAL_DIRECTION,
        :new.AMOUNT,
        :new.INFANT_DISCOUNT_AMOUNT,
        :new.CHILD_DISCOUNT_AMOUNT,
        :new.BOOKING_CLASS_2,
        :new.EFFECTIVE_DATE,
        :new.DISCONTINUE_DATE,
        :new.FIRST_TRAVEL_DATE,
        :new.LAST_TRAVEL_DATE,
        :new.FIRST_TICKETED_DATE,
        :new.LAST_TICKETED_DATE,
        :new.STOPOVER_FLAG,
        :new.CLASS_OF_SERVICE,
        :new.ENDORSEMENT_RESTRICTION,
        :new.BASE_COMMISSION_AMT,
        :new.BASE_COMMISSION_PCT,
        :new.ADDT_COMMISSION_AMT,
        :new.ADDT_COMMISSION_PCT,
        :new.TICKET_TYPE,
        :new.ORI_ADDON_NO,
        :new.DEST_ADDON_NO,
        :new.FARE_ADDON_FLAG,
         sysdate,
         user,
         'insert');
    end if;
    if updating then
      insert into NFS_TRACE.TA_FARE_RCVD_CUR_TRACE
      values
        (:old.CARRIER_CODE,
        :old.LOCATION_CODE,
        :old.REF_NO,
        :old.SOURCE,
        :old.EXTENSION_ID,
        :old.FARE_REC_NO,
        :old.SUB_FARE_REC_NO,
        :old.RULE_ID,
        :old.FARE_CATEGORY,
        :old.ORI_CITY_CODE,
        :old.DEST_CITY_CODE,
        :old.ORI_CODE,
        :old.DEST_CODE,
        :old.JOURNEY_TYPE,
        :old.FARE_BASIS,
        :old.BOOKING_CLASS,
        :old.GLOBAL_DIRECTION,
        :old.AMOUNT,
        :old.INFANT_DISCOUNT_AMOUNT,
        :old.CHILD_DISCOUNT_AMOUNT,
        :old.BOOKING_CLASS_2,
        :old.EFFECTIVE_DATE,
        :old.DISCONTINUE_DATE,
        :old.FIRST_TRAVEL_DATE,
        :old.LAST_TRAVEL_DATE,
        :old.FIRST_TICKETED_DATE,
        :old.LAST_TICKETED_DATE,
        :old.STOPOVER_FLAG,
        :old.CLASS_OF_SERVICE,
        :old.ENDORSEMENT_RESTRICTION,
        :old.BASE_COMMISSION_AMT,
        :old.BASE_COMMISSION_PCT,
        :old.ADDT_COMMISSION_AMT,
        :old.ADDT_COMMISSION_PCT,
        :old.TICKET_TYPE,
        :old.ORI_ADDON_NO,
        :old.DEST_ADDON_NO,
        :old.FARE_ADDON_FLAG,
         sysdate,
         user,
         'update_old');
      insert into NFS_TRACE.TA_FARE_RCVD_CUR_TRACE
      values
        (:new.CARRIER_CODE,
        :new.LOCATION_CODE,
        :new.REF_NO,
        :new.SOURCE,
        :new.EXTENSION_ID,
        :new.FARE_REC_NO,
        :new.SUB_FARE_REC_NO,
        :new.RULE_ID,
        :new.FARE_CATEGORY,
        :new.ORI_CITY_CODE,
        :new.DEST_CITY_CODE,
        :new.ORI_CODE,
        :new.DEST_CODE,
        :new.JOURNEY_TYPE,
        :new.FARE_BASIS,
        :new.BOOKING_CLASS,
        :new.GLOBAL_DIRECTION,
        :new.AMOUNT,
        :new.INFANT_DISCOUNT_AMOUNT,
        :new.CHILD_DISCOUNT_AMOUNT,
        :new.BOOKING_CLASS_2,
        :new.EFFECTIVE_DATE,
        :new.DISCONTINUE_DATE,
        :new.FIRST_TRAVEL_DATE,
        :new.LAST_TRAVEL_DATE,
        :new.FIRST_TICKETED_DATE,
        :new.LAST_TICKETED_DATE,
        :new.STOPOVER_FLAG,
        :new.CLASS_OF_SERVICE,
        :new.ENDORSEMENT_RESTRICTION,
        :new.BASE_COMMISSION_AMT,
        :new.BASE_COMMISSION_PCT,
        :new.ADDT_COMMISSION_AMT,
        :new.ADDT_COMMISSION_PCT,
        :new.TICKET_TYPE,
        :new.ORI_ADDON_NO,
        :new.DEST_ADDON_NO,
        :new.FARE_ADDON_FLAG,
         sysdate,
         user,
         'update_new');
    end if;
    if deleting then
      insert into NFS_TRACE.TA_FARE_RCVD_CUR_TRACE
      values
        (:old.CARRIER_CODE,
        :old.LOCATION_CODE,
        :old.REF_NO,
        :old.SOURCE,
        :old.EXTENSION_ID,
        :old.FARE_REC_NO,
        :old.SUB_FARE_REC_NO,
        :old.RULE_ID,
        :old.FARE_CATEGORY,
        :old.ORI_CITY_CODE,
        :old.DEST_CITY_CODE,
        :old.ORI_CODE,
        :old.DEST_CODE,
        :old.JOURNEY_TYPE,
        :old.FARE_BASIS,
        :old.BOOKING_CLASS,
        :old.GLOBAL_DIRECTION,
        :old.AMOUNT,
        :old.INFANT_DISCOUNT_AMOUNT,
        :old.CHILD_DISCOUNT_AMOUNT,
        :old.BOOKING_CLASS_2,
        :old.EFFECTIVE_DATE,
        :old.DISCONTINUE_DATE,
        :old.FIRST_TRAVEL_DATE,
        :old.LAST_TRAVEL_DATE,
        :old.FIRST_TICKETED_DATE,
        :old.LAST_TICKETED_DATE,
        :old.STOPOVER_FLAG,
        :old.CLASS_OF_SERVICE,
        :old.ENDORSEMENT_RESTRICTION,
        :old.BASE_COMMISSION_AMT,
        :old.BASE_COMMISSION_PCT,
        :old.ADDT_COMMISSION_AMT,
        :old.ADDT_COMMISSION_PCT,
        :old.TICKET_TYPE,
        :old.ORI_ADDON_NO,
        :old.DEST_ADDON_NO,
        :old.FARE_ADDON_FLAG,
         sysdate,
         user,
         'delete');
    end if;
  end if;
  end loop;
end;
/

prompt
prompt Creating trigger TA_AGR_FARE_TRIGGER
prompt ====================================
prompt
create or replace trigger nfs_ta.ta_agr_fare_trigger before insert or delete or update on new_distribution
for each row



DECLARE
effect_date agreement_received_current.effective_date%type;
BEGIN
if inserting then
insert into nfs_ta.agreement_received_current values ( :new.recpt_id , :new.carrier_code, :new.location_code,:new.ref_no, :new.extension_id, :new.distrib_id, :new.effective_date, :new.discontinue_date, :new.level_of_sub, :new.no_ext_sub,:new.no_ext_internal, :new.sub_last_ext, :new.internal_last_ext, :new.who_distribute, :new.when_distribute,:new.currency_code,:new.corporate_id,:new.corporate_id2,:new.distrib_type,:new.who_created,:new.fare_category);
end if;
if updating then
delete from nfs_ta.agreement_received_current where agency_id_pcc=:old.recpt_id and carrier_code=:old.carrier_code and location_code=:old.location_code and ref_no=:old.ref_no and source=:old.distrib_id and corporate_id=:old.corporate_id and corporate_id2=:old.corporate_id2 and extension_id=:old.extension_id;
insert into nfs_ta.agreement_received_current values ( :new.recpt_id , :new.carrier_code,:new.location_code, :new.ref_no, :new.extension_id, :new.distrib_id, :new.effective_date, :new.discontinue_date,:new.level_of_sub, :new.no_ext_sub, :new.no_ext_internal, :new.sub_last_ext,:new.internal_last_ext, :new.who_distribute, :new.when_distribute, :new.currency_code,:new.corporate_id,:new.corporate_id2,:new.distrib_type,:new.who_created,:new.fare_category);
end if;
if deleting then
delete from nfs_ta.agreement_received_current where agency_id_pcc=:old.recpt_id and carrier_code=:old.carrier_code and location_code=:old.location_code and ref_no=:old.ref_no and source=:old.distrib_id and corporate_id=:old.corporate_id and corporate_id2=:old.corporate_id2 and extension_id=:old.extension_id;
end if;
end;
/


spool off
