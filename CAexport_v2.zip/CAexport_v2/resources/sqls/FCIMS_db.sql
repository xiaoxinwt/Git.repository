--------------------------------------------------
-- Export file for user FCIMS@FARERD            --
-- Created by xiaoxinwt on 2015/12/25, 19:33:37 --
--------------------------------------------------

set define off
spool FCIMS_db.log

prompt
prompt Creating table AABBCCDDDDD
prompt ==========================
prompt
create table FCIMS.AABBCCDDDDD
(
  org_stn VARCHAR2(5) not null,
  des_stn VARCHAR2(5) not null,
  y       NUMBER(12,3) not null,
  y4      NUMBER,
  y45     NUMBER,
  y55     NUMBER,
  dt      TIMESTAMP(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AABBCCDDDDD_RESULT
prompt =================================
prompt
create table FCIMS.AABBCCDDDDD_RESULT
(
  org_stn VARCHAR2(5) not null,
  des_stn VARCHAR2(5) not null,
  y       NUMBER(12,3) not null,
  y4      NUMBER,
  y45     NUMBER,
  y55     NUMBER
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ACS
prompt ==================
prompt
create table FCIMS.ACS
(
  num      NUMBER(4),
  str      VARCHAR2(5),
  d        DATE,
  ts       DATE default systimestamp,
  testchar CHAR(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.IDX_1 on FCIMS.ACS (REVERSE(STR))
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AIRPORT_CITY
prompt ===========================
prompt
create table FCIMS.AIRPORT_CITY
(
  airport_code VARCHAR2(3),
  city_code    VARCHAR2(3)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AIRTIS_DOT
prompt =========================
prompt
create table FCIMS.AIRTIS_DOT
(
  dotname VARCHAR2(10),
  count   NUMBER default 0
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 384K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table APP_LOG
prompt ======================
prompt
create table FCIMS.APP_LOG
(
  app_id    NUMBER(10),
  app_name  VARCHAR2(30),
  starttime DATE,
  endtime   DATE,
  status    NUMBER(1),
  info      VARCHAR2(1000)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table BOOKING_CLASS_RULE
prompt =================================
prompt
create table FCIMS.BOOKING_CLASS_RULE
(
  carrier              VARCHAR2(6) not null,
  booking_class        VARCHAR2(50) not null,
  physical_cabin       VARCHAR2(30),
  virtual_cabin        VARCHAR2(30),
  physical_sequence_no NUMBER(3),
  virtual_sequence_no  NUMBER(3),
  effective_date       DATE not null,
  discontinue_date     DATE not null,
  last_update_date     DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CAAC_AUTUMN_ROUTE
prompt ================================
prompt
create table FCIMS.CAAC_AUTUMN_ROUTE
(
  carr_code    VARCHAR2(2),
  descprion_cn VARCHAR2(50),
  codestring   VARCHAR2(30),
  org_stn      VARCHAR2(6),
  des_stn      VARCHAR2(6),
  row_num      NUMBER
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CAAC_CARR_NOTROUTE
prompt =================================
prompt
create table FCIMS.CAAC_CARR_NOTROUTE
(
  carr_code VARCHAR2(5) not null,
  org_stn   VARCHAR2(5) not null,
  des_stn   VARCHAR2(5) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CAAC_DIS_ROUTE
prompt =============================
prompt
create table FCIMS.CAAC_DIS_ROUTE
(
  carr_code VARCHAR2(5) not null,
  org_stn   VARCHAR2(5) not null,
  des_stn   VARCHAR2(5) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CAAC_PSFPP
prompt =========================
prompt
create table FCIMS.CAAC_PSFPP
(
  carr_code VARCHAR2(5) not null,
  org_stn   VARCHAR2(5) not null,
  des_stn   VARCHAR2(5) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 448K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CABIN_CLASS
prompt ==========================
prompt
create table FCIMS.CABIN_CLASS
(
  prod_id             VARCHAR2(5) not null,
  carrier_code        VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  cabin               VARCHAR2(30) not null,
  bookingclass_code1  VARCHAR2(2) not null,
  bookingclass_code2  VARCHAR2(2),
  bookingclass_code3  VARCHAR2(2),
  bookingclass_code4  VARCHAR2(2),
  bookingclass_code5  VARCHAR2(2),
  bookingclass_code6  VARCHAR2(2),
  bookingclass_code7  VARCHAR2(2),
  bookingclass_code8  VARCHAR2(2),
  bookingclass_code9  VARCHAR2(2),
  bookingclass_code10 VARCHAR2(2),
  bookingclass_code11 VARCHAR2(2),
  bookingclass_code12 VARCHAR2(2),
  bookingclass_code13 VARCHAR2(2),
  bookingclass_code14 VARCHAR2(2),
  bookingclass_code15 VARCHAR2(2),
  bookingclass_code16 VARCHAR2(2),
  bookingclass_code17 VARCHAR2(2),
  bookingclass_code18 VARCHAR2(2),
  bookingclass_code19 VARCHAR2(2),
  bookingclass_code20 VARCHAR2(2),
  bookingclass_code21 VARCHAR2(2),
  bookingclass_code22 VARCHAR2(2),
  bookingclass_code23 VARCHAR2(2),
  bookingclass_code24 VARCHAR2(2),
  bookingclass_code25 VARCHAR2(2),
  bookingclass_code26 VARCHAR2(2),
  bookingclass_code27 VARCHAR2(2),
  bookingclass_code28 VARCHAR2(2),
  bookingclass_code29 VARCHAR2(2),
  bookingclass_code30 VARCHAR2(2),
  bookingclass_code31 VARCHAR2(2),
  bookingclass_code32 VARCHAR2(2),
  bookingclass_code33 VARCHAR2(2),
  bookingclass_code34 VARCHAR2(2),
  bookingclass_code35 VARCHAR2(2),
  bookingclass_code36 VARCHAR2(2),
  bookingclass_code37 VARCHAR2(2),
  bookingclass_code38 VARCHAR2(2),
  bookingclass_code39 VARCHAR2(2),
  bookingclass_code40 VARCHAR2(2),
  bookingclass_code41 VARCHAR2(2),
  bookingclass_code42 VARCHAR2(2),
  bookingclass_code43 VARCHAR2(2),
  bookingclass_code44 VARCHAR2(2),
  bookingclass_code45 VARCHAR2(2),
  bookingclass_code46 VARCHAR2(2),
  bookingclass_code47 VARCHAR2(2),
  bookingclass_code48 VARCHAR2(2),
  bookingclass_code49 VARCHAR2(2),
  bookingclass_code50 VARCHAR2(2),
  bookingclass_code51 VARCHAR2(2),
  bookingclass_code52 VARCHAR2(2),
  who_last_update     VARCHAR2(32) not null,
  when_last_update    DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CABIN_CLASS
  add constraint CABIN_CLASS_PK primary key (PROD_ID, CARRIER_CODE, EFF_DATE, DISC_DATE, CABIN)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CITY
prompt ===================
prompt
create table FCIMS.CITY
(
  record_format_version  NUMBER(2),
  issue_date             DATE,
  gfs_id                 VARCHAR2(8),
  prod_id                VARCHAR2(8),
  data_ind               VARCHAR2(1),
  city_code              VARCHAR2(5) not null,
  state                  VARCHAR2(2),
  country_code           VARCHAR2(2) not null,
  zone_code              VARCHAR2(3) not null,
  international_city_ind VARCHAR2(1),
  spare1                 VARCHAR2(1),
  us_territory_ind       VARCHAR2(1) default 'n' not null,
  spare2                 VARCHAR2(1),
  spare3                 VARCHAR2(1),
  spare4                 VARCHAR2(1),
  spare5                 VARCHAR2(1),
  spare6                 VARCHAR2(1),
  alaska_tax_zone        VARCHAR2(1),
  spare7                 VARCHAR2(1),
  timezone_sign          VARCHAR2(1),
  timezone               NUMBER(2),
  gtrtn                  VARCHAR2(1),
  city_ind               VARCHAR2(1),
  latitude_deg           NUMBER(2),
  latitude_min           NUMBER(2),
  latitude_sec           NUMBER(2),
  latitude_type          VARCHAR2(1),
  longitude_deg          NUMBER(3),
  longitude_min          NUMBER(2),
  longitude_sec          NUMBER(2),
  longitude_type         VARCHAR2(1),
  spare8                 VARCHAR2(1),
  bu_tax_ind             VARCHAR2(1),
  spare9                 VARCHAR2(4),
  name                   VARCHAR2(40),
  city_name              VARCHAR2(17),
  cancel                 VARCHAR2(1),
  who_last_update        VARCHAR2(32) not null,
  when_last_update       DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.CITY.bu_tax_ind
  is 'Y=Yes; N=No';
alter table FCIMS.CITY
  add constraint CITY_PK primary key (CITY_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table COMMISSION
prompt =========================
prompt
create table FCIMS.COMMISSION
(
  record_no                  VARCHAR2(32) not null,
  batch_id                   VARCHAR2(6) not null,
  status                     VARCHAR2(1) not null,
  carrier_code               VARCHAR2(5) not null,
  oper_type_apply_tag        VARCHAR2(1),
  oper_type                  VARCHAR2(1) not null,
  sequence_no                NUMBER(7) not null,
  eff_date                   DATE not null,
  disc_date                  DATE not null,
  travel_eff_date            DATE not null,
  travel_disc_date           DATE not null,
  commission_tag             VARCHAR2(1) not null,
  commission_type            VARCHAR2(1) not null,
  percent                    NUMBER(4,2),
  amount                     NUMBER(10),
  decimal_place              NUMBER(1),
  currency                   VARCHAR2(3),
  geo_loc1_type              VARCHAR2(1),
  geo_loc1_spec              VARCHAR2(5),
  geo_loc2_type              VARCHAR2(1),
  geo_loc2_spec              VARCHAR2(5),
  via_loc_type               VARCHAR2(1),
  via_loc_spec               VARCHAR2(5),
  and_loc_type               VARCHAR2(1),
  and_loc_spec               VARCHAR2(5),
  cabin_code                 VARCHAR2(30),
  rbd_table_no198            NUMBER(8),
  pricing_source             VARCHAR2(10),
  fare_class                 VARCHAR2(8),
  ticket_designator          VARCHAR2(20),
  tour_code                  VARCHAR2(15),
  carrier_table_no990        NUMBER(8) not null,
  account_code_table_no172   NUMBER(8) not null,
  sale_location_table_no983  NUMBER(8) not null,
  passenger_type_table_no105 NUMBER(8) not null,
  who_last_update            VARCHAR2(20),
  when_last_update           DATE,
  itinerary_original_type    VARCHAR2(1),
  itinerary_original_code    VARCHAR2(5),
  itinerary_destination_type VARCHAR2(1),
  itinerary_destination_code VARCHAR2(5),
  farebasis                  VARCHAR2(50),
  rulenumber                 VARCHAR2(50),
  tariff                     VARCHAR2(50),
  newtourcode                VARCHAR2(10),
  publicfare                 VARCHAR2(10)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.COMMISSION
  add constraint COMMISSION_PK primary key (RECORD_NO, BATCH_ID, CARRIER_CODE, SEQUENCE_NO, EFF_DATE, TRAVEL_EFF_DATE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table COMMISSION_BATCH
prompt ===============================
prompt
create table FCIMS.COMMISSION_BATCH
(
  carrier_code       VARCHAR2(5) not null,
  batch_id           VARCHAR2(6) not null,
  eff_date           DATE not null,
  comments           VARCHAR2(100),
  sign_by            VARCHAR2(20),
  status             VARCHAR2(1) not null,
  submiting_datetime DATE,
  distribute_user    VARCHAR2(20),
  who_last_update    VARCHAR2(20),
  when_last_update   DATE
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.COMMISSION_BATCH
  add constraint COMMISSION_BATCH_PK primary key (CARRIER_CODE, BATCH_ID)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table COMMISSION_CONFIGURATION
prompt =======================================
prompt
create table FCIMS.COMMISSION_CONFIGURATION
(
  carrier_code                  VARCHAR2(5) not null,
  ics_oper_code                 VARCHAR2(1) not null,
  ics_default_commission        NUMBER(2),
  crs_oper_code                 VARCHAR2(1) not null,
  crs_default_commission        NUMBER(2),
  b2b_oper_code                 VARCHAR2(1) not null,
  b2b_default_commission        NUMBER(2),
  other_cxr_fare_commission_tag VARCHAR2(1) not null,
  yy_fare_commission_tag        VARCHAR2(1) not null,
  commission_selection_tag      VARCHAR2(1) not null,
  who_last_update               VARCHAR2(20),
  when_last_update              DATE,
  sita_commission_process_tag   VARCHAR2(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.COMMISSION_CONFIGURATION
  add constraint COMMISSION_CONFIGURATION_PK primary key (CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CONFIGURATION_ITEM
prompt =================================
prompt
create table FCIMS.CONFIGURATION_ITEM
(
  config_id                NUMBER(20) not null,
  office_number            VARCHAR2(6),
  channel_id               VARCHAR2(10),
  max_routings             NUMBER(3),
  max_same_routings        NUMBER(3),
  fs_max_responses         NUMBER(3),
  cabin_upsell             VARCHAR2(6),
  cabin_downsell           VARCHAR2(6),
  fs_use_interline         VARCHAR2(6),
  filter_flight            VARCHAR2(20),
  filter_addon             VARCHAR2(20),
  filter_codeshare         VARCHAR2(10),
  tace_routing             NUMBER(3),
  filter_yy_fare           VARCHAR2(6),
  av_filter_offset         NUMBER(3),
  filter_av_strict_by_date VARCHAR2(6),
  max_computed_trips       NUMBER(4),
  use_acc_travel           VARCHAR2(6),
  cabin_combine_mode       VARCHAR2(10),
  av_stopover_option       VARCHAR2(6),
  is_use_public_fare_cache VARCHAR2(6),
  candidate_online_trip    NUMBER(4),
  candidate_interline_trip NUMBER(4),
  is_pre_filter            VARCHAR2(9),
  effective_date           DATE,
  discontinue_date         DATE,
  last_update_date         DATE,
  config_state             NUMBER(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CONFIGURATION_ITEM
  add constraint PK_CONFIGURATION_ITEM primary key (CONFIG_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CONFIGURATION_PREFERENCE
prompt =======================================
prompt
create table FCIMS.CONFIGURATION_PREFERENCE
(
  cpid                     VARCHAR2(100) not null,
  coc                      VARCHAR2(10) not null,
  coc_type                 VARCHAR2(10) not null,
  det                      VARCHAR2(10) not null,
  det_type                 VARCHAR2(10) not null,
  preference_airline       VARCHAR2(100),
  hate_airline             VARCHAR2(100),
  hate_type                CHAR(1),
  preference_transfer      VARCHAR2(100),
  preference_transfer_type VARCHAR2(10),
  same_airport             CHAR(1),
  hate_transfer            VARCHAR2(100),
  hate_transfer_type       VARCHAR2(10),
  effect_start_date        DATE,
  effect_stop_date         DATE,
  sell_start_date          DATE,
  sell_stop_date           DATE,
  users                    VARCHAR2(10),
  office                   VARCHAR2(10) not null,
  client                   VARCHAR2(10) not null,
  hashcode                 VARCHAR2(100) not null,
  preferenceminimumtime    NUMBER(4),
  preferencemaximumtime    NUMBER(4),
  lastupdateuser           VARCHAR2(100),
  lastupdatetime           DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.CONFIGURATION_PREFERENCE.cpid
  is 'ƫ��Id';
comment on column FCIMS.CONFIGURATION_PREFERENCE.coc
  is 'ʼ����';
comment on column FCIMS.CONFIGURATION_PREFERENCE.coc_type
  is 'ʼ��������';
comment on column FCIMS.CONFIGURATION_PREFERENCE.det
  is 'Ŀ�ĵ�';
comment on column FCIMS.CONFIGURATION_PREFERENCE.det_type
  is 'Ŀ�ĵ�����';
comment on column FCIMS.CONFIGURATION_PREFERENCE.preference_airline
  is 'ƫ�ú��չ�˾';
comment on column FCIMS.CONFIGURATION_PREFERENCE.hate_airline
  is '��񺽿չ�˾';
comment on column FCIMS.CONFIGURATION_PREFERENCE.hate_type
  is '��񺽿չ�˾����';
comment on column FCIMS.CONFIGURATION_PREFERENCE.preference_transfer
  is 'ƫ����ת��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.preference_transfer_type
  is 'ƫ����ת������';
comment on column FCIMS.CONFIGURATION_PREFERENCE.same_airport
  is '�Ƿ���ͬ����ת��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.hate_transfer
  is '�����ת��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.hate_transfer_type
  is '�����ת������';
comment on column FCIMS.CONFIGURATION_PREFERENCE.effect_start_date
  is '��Ч��ʼʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.effect_stop_date
  is '��Ч����ʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.sell_start_date
  is '���ۿ�ʼʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.sell_stop_date
  is '���۽���ʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.users
  is '�û���';
comment on column FCIMS.CONFIGURATION_PREFERENCE.office
  is 'office��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.client
  is 'ͨ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.hashcode
  is 'hashcode����';
comment on column FCIMS.CONFIGURATION_PREFERENCE.preferenceminimumtime
  is '��ת��Сʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.preferencemaximumtime
  is '��ת���ʱ��';
comment on column FCIMS.CONFIGURATION_PREFERENCE.lastupdateuser
  is '�޸���';
comment on column FCIMS.CONFIGURATION_PREFERENCE.lastupdatetime
  is '�޸�ʱ��';
alter table FCIMS.CONFIGURATION_PREFERENCE
  add constraint PK_CONFIGURATION_PREFERENCE primary key (CPID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CPUB_T_LOOKUPINFO
prompt ================================
prompt
create table FCIMS.CPUB_T_LOOKUPINFO
(
  lookup_type VARCHAR2(5) not null,
  description VARCHAR2(50) not null,
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_LOOKUPINFO
  add constraint PK_CPUB_T_LOOKUPINFO primary key (LOOKUP_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CPUB_T_LOOKUPDTL
prompt ===============================
prompt
create table FCIMS.CPUB_T_LOOKUPDTL
(
  lookup_type VARCHAR2(5) not null,
  lookup_code VARCHAR2(20) not null,
  description VARCHAR2(50),
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_LOOKUPDTL
  add constraint PK_CPUB_T_LOOKUPDTL primary key (LOOKUP_TYPE, LOOKUP_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_LOOKUPDTL
  add constraint FK_CPUB_T_LOOKUPINFO foreign key (LOOKUP_TYPE)
  references FCIMS.CPUB_T_LOOKUPINFO (LOOKUP_TYPE) on delete cascade;

prompt
prompt Creating table CPUB_T_MENUS
prompt ===========================
prompt
create table FCIMS.CPUB_T_MENUS
(
  f_menu      VARCHAR2(20) not null,
  f_menu_name VARCHAR2(60) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_MENUS
  add constraint PK_CPUB_T_MENUS primary key (F_MENU)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CPUB_T_ROLES
prompt ===========================
prompt
create table FCIMS.CPUB_T_ROLES
(
  role_id     VARCHAR2(20) not null,
  role_name   VARCHAR2(50) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_ROLES
  add constraint PK_CPUB_T_ROLES primary key (ROLE_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CPUB_T_ROLEMENUS
prompt ===============================
prompt
create table FCIMS.CPUB_T_ROLEMENUS
(
  role_id     VARCHAR2(20) not null,
  role_name   VARCHAR2(50) not null,
  f_menu      VARCHAR2(20) not null,
  f_menu_name VARCHAR2(60) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_ROLEMENUS
  add constraint PK_CPUB_T_ROLEMENUS primary key (ROLE_ID, F_MENU)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_ROLEMENUS
  add constraint FK_CPUB_T_MENUS foreign key (F_MENU)
  references FCIMS.CPUB_T_MENUS (F_MENU) on delete cascade;
alter table FCIMS.CPUB_T_ROLEMENUS
  add constraint FK_CPUB_T_ROLES foreign key (ROLE_ID)
  references FCIMS.CPUB_T_ROLES (ROLE_ID) on delete cascade;

prompt
prompt Creating table CPUB_T_USERS
prompt ===========================
prompt
create table FCIMS.CPUB_T_USERS
(
  user_id     VARCHAR2(20) not null,
  user_name   VARCHAR2(50) not null,
  user_pwd    VARCHAR2(20) not null,
  unit_id     VARCHAR2(40) not null,
  unit_name   VARCHAR2(50) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null,
  role_type   NUMBER(1),
  office_tel  VARCHAR2(20),
  fax_no      VARCHAR2(20),
  mobile_tel  VARCHAR2(20),
  email_addr  VARCHAR2(50),
  post_addr   VARCHAR2(200)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_USERS
  add constraint PK_CPUB_T_USERS primary key (USER_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CPUB_T_USERROLES
prompt ===============================
prompt
create table FCIMS.CPUB_T_USERROLES
(
  user_id     VARCHAR2(20) not null,
  user_name   VARCHAR2(50) not null,
  role_id     VARCHAR2(20) not null,
  role_name   VARCHAR2(50) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_USERROLES
  add constraint PK_CPUB_T_USERROLES primary key (USER_ID, ROLE_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CPUB_T_USERROLES
  add constraint FK_CPUB_T_USERROLES foreign key (ROLE_ID)
  references FCIMS.CPUB_T_ROLES (ROLE_ID) on delete cascade;
alter table FCIMS.CPUB_T_USERROLES
  add constraint FK_CPUB_T_USERS foreign key (USER_ID)
  references FCIMS.CPUB_T_USERS (USER_ID) on delete cascade;

prompt
prompt Creating table CSIM_T_ALEVEL
prompt ============================
prompt
create table FCIMS.CSIM_T_ALEVEL
(
  ap_code       VARCHAR2(20) not null,
  apply_date    DATE not null,
  ap_level      VARCHAR2(20) not null,
  ap_level_name VARCHAR2(50) not null,
  ap_name       VARCHAR2(50) not null,
  alevel_number NUMBER(3),
  appr_date     DATE,
  memo          VARCHAR2(100),
  flag          VARCHAR2(2),
  create_by     VARCHAR2(8) not null,
  update_by     VARCHAR2(8) not null,
  create_date   DATE not null,
  update_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_ALEVEL
  add constraint PK_CSIM_T_ALEVEL primary key (AP_CODE, APPLY_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_ALEVEL
  add constraint CHECK_FLAG
  check (FLAG IN ('Y','N','YC'));

prompt
prompt Creating table CSIM_T_AGUARANTEE
prompt ================================
prompt
create table FCIMS.CSIM_T_AGUARANTEE
(
  ap_code          VARCHAR2(20) not null,
  apply_date       DATE not null,
  level_code       VARCHAR2(20) not null,
  level_name       VARCHAR2(50) not null,
  appr_description NUMBER(3),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_AGUARANTEE
  add constraint PK_CSIM_T_AGUARANTEE primary key (AP_CODE, APPLY_DATE, LEVEL_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_AGUARANTEE
  add constraint FK_CSIM_T_ALEVEL foreign key (AP_CODE, APPLY_DATE)
  references FCIMS.CSIM_T_ALEVEL (AP_CODE, APPLY_DATE) on delete cascade;

prompt
prompt Creating table CSIM_T_AIRCRAFT
prompt ==============================
prompt
create table FCIMS.CSIM_T_AIRCRAFT
(
  aircraft_type VARCHAR2(20) not null,
  aircraft_name VARCHAR2(50) not null,
  max_capacity  NUMBER(11,2) not null,
  max_takeoff   NUMBER(11,2) not null,
  w_unit        VARCHAR2(20) not null,
  size_type     CHAR(1) not null,
  seating       NUMBER(4) not null,
  create_by     VARCHAR2(8) not null,
  update_by     VARCHAR2(8) not null,
  create_date   DATE not null,
  update_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_AIRCRAFT
  add constraint PK_CSIM_T_AIRCRAFT primary key (AIRCRAFT_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_ASERVICE
prompt ==============================
prompt
create table FCIMS.CSIM_T_ASERVICE
(
  ap_code          VARCHAR2(20) not null,
  apply_date       DATE not null,
  serve_code       VARCHAR2(20) not null,
  serve_name       VARCHAR2(50) not null,
  appr_description NUMBER(3),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_ASERVICE
  add constraint PK_CSIM_T_ASERVICE primary key (AP_CODE, APPLY_DATE, SERVE_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_ASERVICE
  add constraint FK_CSIM_T_ALEVEL1 foreign key (AP_CODE, APPLY_DATE)
  references FCIMS.CSIM_T_ALEVEL (AP_CODE, APPLY_DATE) on delete cascade;

prompt
prompt Creating table CSIM_T_FPARAMETERS
prompt =================================
prompt
create table FCIMS.CSIM_T_FPARAMETERS
(
  parameter_type_id   VARCHAR2(50) not null,
  parameter_type_name VARCHAR2(50) not null,
  parameter_item_id   VARCHAR2(50) not null,
  parameter_item_name VARCHAR2(50) not null,
  create_by           VARCHAR2(8) not null,
  update_by           VARCHAR2(8) not null,
  create_date         DATE not null,
  update_date         DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_FPARAMETERS
  add constraint PK_CSIM_T_FPARAMETERS primary key (PARAMETER_TYPE_ID, PARAMETER_ITEM_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_FPROTOCOL
prompt ===============================
prompt
create table FCIMS.CSIM_T_FPROTOCOL
(
  protocol_header_id      VARCHAR2(50) not null,
  protocol_header_name    VARCHAR2(50) not null,
  calculate_mode          VARCHAR2(10),
  group_number            NUMBER(2) not null,
  and_flag                CHAR(3),
  cal_parameter_type_id   VARCHAR2(50),
  cal_parameter_type_name VARCHAR2(50),
  cal_parameter_id        VARCHAR2(50),
  cal_parameter_name      VARCHAR2(50),
  com_parameter_type_id   VARCHAR2(50),
  com_parameter_type_name VARCHAR2(50),
  com_parameter_id        VARCHAR2(50) not null,
  com_parameter_name      VARCHAR2(50),
  start_value             VARCHAR2(20),
  start_operation         VARCHAR2(10),
  end_value               VARCHAR2(20),
  end_operation           VARCHAR2(10),
  currency_code           VARCHAR2(20),
  unit_amount             NUMBER(11,2),
  base_amount             NUMBER(11,2),
  refer_protocol_id       VARCHAR2(50),
  refer_protocol_name     VARCHAR2(50),
  percent                 NUMBER(3,2),
  create_by               VARCHAR2(8) not null,
  update_by               VARCHAR2(8) not null,
  create_date             DATE not null,
  update_date             DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_FPROTOCOL
  add constraint PK_CSIM_T_FPROTOCOL primary key (PROTOCOL_HEADER_ID, GROUP_NUMBER, COM_PARAMETER_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_FTAKEOFFLANDING
prompt =====================================
prompt
create table FCIMS.CSIM_T_FTAKEOFFLANDING
(
  aircraft_type    VARCHAR2(20) not null,
  aircraft_name    VARCHAR2(50) not null,
  max_takeoff      NUMBER(11,2),
  max_capacity     NUMBER(11,2),
  size_type        CHAR(1),
  seating          NUMBER(4),
  ap_code          VARCHAR2(20) not null,
  ap_name          VARCHAR2(50) not null,
  ap_level         VARCHAR2(20),
  fly_type_id      VARCHAR2(20) not null,
  fly_type_name    VARCHAR2(50) not null,
  distance         NUMBER(11,2),
  night_fly        CHAR(1),
  lighting         CHAR(1),
  parking_tiime    NUMBER(3),
  skyway_id        VARCHAR2(20),
  skyway_name      VARCHAR2(50),
  passenger_number NUMBER(4),
  attribute1       NUMBER(11,2),
  attribute2       NUMBER(11,2),
  attribute3       NUMBER(11,2),
  attribute4       NUMBER(11,2),
  attribute5       NUMBER(11,2),
  attribute6       NUMBER(11,2),
  attribute7       NUMBER(11,2),
  attribute8       NUMBER(11,2),
  attribute9       NUMBER(11,2),
  attribute10      NUMBER(11,2),
  attribute11      NUMBER(11,2),
  attribute12      NUMBER(11,2),
  attribute13      NUMBER(11,2),
  attribute14      NUMBER(11,2),
  attribute15      NUMBER(11,2),
  attribute16      NUMBER(11,2),
  attribute17      NUMBER(11,2),
  attribute18      NUMBER(11,2),
  attribute19      NUMBER(11,2),
  attribute20      NUMBER(11,2),
  attribute21      NUMBER(11,2),
  attribute22      NUMBER(11,2),
  attribute23      NUMBER(11,2),
  attribute24      NUMBER(11,2),
  attribute25      NUMBER(11,2),
  attribute26      NUMBER(11,2),
  attribute27      NUMBER(11,2),
  attribute28      NUMBER(11,2),
  attribute29      NUMBER(11,2),
  attribute30      NUMBER(11,2),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_FTAKEOFFLANDING
  add constraint PK_CSIM_T_FTAKEOFFLANDING primary key (AIRCRAFT_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_KPARAMETERS
prompt =================================
prompt
create table FCIMS.CSIM_T_KPARAMETERS
(
  parameter_type_id   VARCHAR2(50) not null,
  parameter_type_name VARCHAR2(50) not null,
  parameter_item_id   VARCHAR2(50) not null,
  parameter_item_name VARCHAR2(50) not null,
  create_by           VARCHAR2(8) not null,
  update_by           VARCHAR2(8) not null,
  create_date         DATE not null,
  update_date         DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_KPARAMETERS
  add constraint PK_CSIM_T_KPARAMETERS primary key (PARAMETER_TYPE_ID, PARAMETER_ITEM_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_KPROTOCOL
prompt ===============================
prompt
create table FCIMS.CSIM_T_KPROTOCOL
(
  protocol_header_id      VARCHAR2(50) not null,
  protocol_header_name    VARCHAR2(50) not null,
  calculate_mode          VARCHAR2(10),
  group_number            NUMBER(2) not null,
  and_flag                CHAR(3),
  cal_parameter_type_id   VARCHAR2(50),
  cal_parameter_type_name VARCHAR2(50),
  cal_parameter_id        VARCHAR2(50),
  cal_parameter_name      VARCHAR2(50),
  com_parameter_type_id   VARCHAR2(50),
  com_parameter_type_name VARCHAR2(50),
  com_parameter_id        VARCHAR2(50) not null,
  com_parameter_name      VARCHAR2(50),
  start_value             VARCHAR2(20),
  start_operation         VARCHAR2(10),
  end_value               VARCHAR2(20),
  end_operation           VARCHAR2(10),
  currency_code           VARCHAR2(20),
  unit_amount             NUMBER(11,2),
  base_amount             NUMBER(11,2),
  refer_protocol_id       VARCHAR2(50),
  refer_protocol_name     VARCHAR2(50),
  percent                 NUMBER(3,2),
  create_by               VARCHAR2(8) not null,
  update_by               VARCHAR2(8) not null,
  create_date             DATE not null,
  update_date             DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_KPROTOCOL
  add constraint PK_CSIM_T_KPROTOCOL primary key (PROTOCOL_HEADER_ID, GROUP_NUMBER, COM_PARAMETER_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_KTAKEOFFLANDING
prompt =====================================
prompt
create table FCIMS.CSIM_T_KTAKEOFFLANDING
(
  aircraft_type    VARCHAR2(20) not null,
  aircraft_name    VARCHAR2(50) not null,
  max_takeoff      NUMBER(11,2),
  max_capacity     NUMBER(11,2),
  size_type        CHAR(1),
  seating          NUMBER(4),
  ap_code          VARCHAR2(20) not null,
  ap_name          VARCHAR2(50) not null,
  ap_level         VARCHAR2(20),
  fly_type_id      VARCHAR2(20) not null,
  fly_type_name    VARCHAR2(50) not null,
  distance         NUMBER(11,2),
  night_fly        CHAR(1),
  lighting         CHAR(1),
  parking_tiime    NUMBER(3),
  skyway_id        VARCHAR2(20),
  skyway_name      VARCHAR2(50),
  passenger_number NUMBER(4),
  attribute1       NUMBER(11,2),
  attribute2       NUMBER(11,2),
  attribute3       NUMBER(11,2),
  attribute4       NUMBER(11,2),
  attribute5       NUMBER(11,2),
  attribute6       NUMBER(11,2),
  attribute7       NUMBER(11,2),
  attribute8       NUMBER(11,2),
  attribute9       NUMBER(11,2),
  attribute10      NUMBER(11,2),
  attribute11      NUMBER(11,2),
  attribute12      NUMBER(11,2),
  attribute13      NUMBER(11,2),
  attribute14      NUMBER(11,2),
  attribute15      NUMBER(11,2),
  attribute16      NUMBER(11,2),
  attribute17      NUMBER(11,2),
  attribute18      NUMBER(11,2),
  attribute19      NUMBER(11,2),
  attribute20      NUMBER(11,2),
  attribute21      NUMBER(11,2),
  attribute22      NUMBER(11,2),
  attribute23      NUMBER(11,2),
  attribute24      NUMBER(11,2),
  attribute25      NUMBER(11,2),
  attribute26      NUMBER(11,2),
  attribute27      NUMBER(11,2),
  attribute28      NUMBER(11,2),
  attribute29      NUMBER(11,2),
  attribute30      NUMBER(11,2),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_KTAKEOFFLANDING
  add constraint PK_CSIM_T_KTAKEOFFLANDING primary key (AIRCRAFT_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_OTHERCHRG
prompt ===============================
prompt
create table FCIMS.CSIM_T_OTHERCHRG
(
  charge_name VARCHAR2(50) not null,
  start_date  DATE not null,
  charge      VARCHAR2(100) not null,
  file_no     VARCHAR2(50),
  audit_unit  VARCHAR2(50),
  memo        VARCHAR2(100),
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_OTHERCHRG
  add constraint PK_CSIM_T_OTHERCHRG primary key (CHARGE_NAME, START_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_PARAMETERS
prompt ================================
prompt
create table FCIMS.CSIM_T_PARAMETERS
(
  parameter_type_id   VARCHAR2(50) not null,
  parameter_type_name VARCHAR2(50) not null,
  parameter_item_id   VARCHAR2(50) not null,
  parameter_item_name VARCHAR2(50) not null,
  create_by           VARCHAR2(8) not null,
  update_by           VARCHAR2(8) not null,
  create_date         DATE not null,
  update_date         DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_PARAMETERS
  add constraint PK_CSIM_T_PARAMETERS primary key (PARAMETER_TYPE_ID, PARAMETER_ITEM_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_PROTOCOL
prompt ==============================
prompt
create table FCIMS.CSIM_T_PROTOCOL
(
  protocol_header_id      VARCHAR2(50) not null,
  protocol_header_name    VARCHAR2(50) not null,
  calculate_mode          VARCHAR2(10),
  group_number            NUMBER(2) not null,
  and_flag                CHAR(3),
  cal_parameter_type_id   VARCHAR2(50),
  cal_parameter_type_name VARCHAR2(50),
  cal_parameter_id        VARCHAR2(50),
  cal_parameter_name      VARCHAR2(50),
  com_parameter_type_id   VARCHAR2(50),
  com_parameter_type_name VARCHAR2(50),
  com_parameter_id        VARCHAR2(50) not null,
  com_parameter_name      VARCHAR2(50),
  start_value             VARCHAR2(20),
  start_operation         VARCHAR2(10),
  end_value               VARCHAR2(20),
  end_operation           VARCHAR2(10),
  currency_code           VARCHAR2(20),
  unit_amount             NUMBER(11,2),
  base_amount             NUMBER(11,2),
  refer_protocol_id       VARCHAR2(50),
  refer_protocol_name     VARCHAR2(50),
  percent                 NUMBER(3,2),
  create_by               VARCHAR2(8) not null,
  update_by               VARCHAR2(8) not null,
  create_date             DATE not null,
  update_date             DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_PROTOCOL
  add constraint PK_CSIM_T_PROTOCOL primary key (PROTOCOL_HEADER_ID, GROUP_NUMBER, COM_PARAMETER_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_PRPLANEINFO
prompt =================================
prompt
create table FCIMS.CSIM_T_PRPLANEINFO
(
  file_no     VARCHAR2(50) not null,
  f_nation    VARCHAR2(50) not null,
  visitor     VARCHAR2(50),
  memo        VARCHAR2(100),
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_PRPLANEINFO
  add constraint PRIMARYKEY_CSIM_T_PRPLANEINFO primary key (FILE_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_PRPLANEDTL
prompt ================================
prompt
create table FCIMS.CSIM_T_PRPLANEDTL
(
  file_no       VARCHAR2(50) not null,
  serial_no     NUMBER(7) not null,
  aircraft_type VARCHAR2(20),
  max_takeoff   NUMBER(11,2),
  ap_name       VARCHAR2(50),
  rate_name     VARCHAR2(50),
  rate_off      NUMBER(3,2),
  sale_off      NUMBER(11,2),
  mile          NUMBER(10,2),
  voyage        VARCHAR2(50),
  start_date    DATE not null,
  end_date      DATE not null,
  create_by     VARCHAR2(8) not null,
  update_by     VARCHAR2(8) not null,
  create_date   DATE not null,
  update_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_PRPLANEDTL
  add constraint PRIMARYKEY_CSIM_T_PRPLANEDTL primary key (FILE_NO, SERIAL_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_PRPLANEDTL
  add constraint FOK_CSIM_T_PRPLANEINFO foreign key (FILE_NO)
  references FCIMS.CSIM_T_PRPLANEINFO (FILE_NO) on delete cascade;

prompt
prompt Creating table CSIM_T_SKYWAY
prompt ============================
prompt
create table FCIMS.CSIM_T_SKYWAY
(
  skyway_id   VARCHAR2(20) not null,
  skyway_name VARCHAR2(50) not null,
  distance    NUMBER(11,2) not null,
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_SKYWAY
  add constraint PK_CSIM_T_SKYWAY primary key (SKYWAY_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CSIM_T_TAKEOFFLANDING
prompt ====================================
prompt
create table FCIMS.CSIM_T_TAKEOFFLANDING
(
  aircraft_type    VARCHAR2(20) not null,
  aircraft_name    VARCHAR2(50) not null,
  max_takeoff      NUMBER(11,2),
  max_capacity     NUMBER(11,2),
  size_type        CHAR(1),
  seating          NUMBER(4),
  ap_code          VARCHAR2(20) not null,
  ap_name          VARCHAR2(50) not null,
  ap_level         VARCHAR2(20),
  fly_type_id      VARCHAR2(20) not null,
  fly_type_name    VARCHAR2(50) not null,
  distance         NUMBER(11,2),
  night_fly        CHAR(1),
  lighting         CHAR(1),
  parking_tiime    NUMBER(3),
  skyway_id        VARCHAR2(20),
  skyway_name      VARCHAR2(50),
  passenger_number NUMBER(4),
  attribute1       NUMBER(11,2),
  attribute2       NUMBER(11,2),
  attribute3       NUMBER(11,2),
  attribute4       NUMBER(11,2),
  attribute5       NUMBER(11,2),
  attribute6       NUMBER(11,2),
  attribute7       NUMBER(11,2),
  attribute8       NUMBER(11,2),
  attribute9       NUMBER(11,2),
  attribute10      NUMBER(11,2),
  attribute11      NUMBER(11,2),
  attribute12      NUMBER(11,2),
  attribute13      NUMBER(11,2),
  attribute14      NUMBER(11,2),
  attribute15      NUMBER(11,2),
  attribute16      NUMBER(11,2),
  attribute17      NUMBER(11,2),
  attribute18      NUMBER(11,2),
  attribute19      NUMBER(11,2),
  attribute20      NUMBER(11,2),
  attribute21      NUMBER(11,2),
  attribute22      NUMBER(11,2),
  attribute23      NUMBER(11,2),
  attribute24      NUMBER(11,2),
  attribute25      NUMBER(11,2),
  attribute26      NUMBER(11,2),
  attribute27      NUMBER(11,2),
  attribute28      NUMBER(11,2),
  attribute29      NUMBER(11,2),
  attribute30      NUMBER(11,2),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CSIM_T_TAKEOFFLANDING
  add constraint PK_CSIM_T_TAKEOFFLANDING primary key (AIRCRAFT_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CS_HOT_LINE
prompt ==========================
prompt
create table FCIMS.CS_HOT_LINE
(
  carrier          VARCHAR2(5) not null,
  ori_code         VARCHAR2(6) not null,
  dest_code        VARCHAR2(6) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  mem_level        NUMBER not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CURRENCY
prompt =======================
prompt
create table FCIMS.CURRENCY
(
  currency_code    CHAR(3) not null,
  currency_desc    VARCHAR2(35),
  rounding_factor  NUMBER(8,3),
  who_last_update  CHAR(20),
  when_last_update DATE,
  decimal_point    NUMBER(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.CURRENCY
  add constraint CURRENCY_PK primary key (CURRENCY_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DATASTATUS
prompt =========================
prompt
create table FCIMS.DATASTATUS
(
  tablename VARCHAR2(50) not null,
  machineid NUMBER not null,
  isload    NUMBER not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DATAVERSION
prompt ==========================
prompt
create table FCIMS.DATAVERSION
(
  tablename   VARCHAR2(50) not null,
  currversion NUMBER not null,
  maxrows     NUMBER not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DATA_TEST_1_YCR
prompt ==============================
prompt
create table FCIMS.DATA_TEST_1_YCR
(
  result VARCHAR2(64)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_ATISTOFD
prompt ==============================
prompt
create table FCIMS.DFIM_T_ATISTOFD
(
  carr_code VARCHAR2(5) not null,
  org_stn   VARCHAR2(5) not null,
  des_stn   VARCHAR2(5) not null,
  curr_date DATE default SYSDATE,
  flag      NUMBER(1) default 0
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_BATCH
prompt ===========================
prompt
create table FCIMS.DFIM_T_BATCH
(
  file_no          VARCHAR2(30) not null,
  aprv_date        DATE not null,
  adv_to_1         VARCHAR2(5),
  adv_to_2         VARCHAR2(5),
  adv_to_3         VARCHAR2(5),
  adv_to_4         VARCHAR2(5),
  adv_to_5         VARCHAR2(5),
  adv_to_6         VARCHAR2(5),
  adv_to_7         VARCHAR2(5),
  adv_to_8         VARCHAR2(5),
  adv_to_9         VARCHAR2(5),
  adv_to_10        VARCHAR2(5),
  adv_to_11        VARCHAR2(5),
  adv_to_12        VARCHAR2(5),
  adv_to_13        VARCHAR2(5),
  adv_to_14        VARCHAR2(5),
  adv_to_15        VARCHAR2(5),
  adv_to_16        VARCHAR2(5),
  adv_to_17        VARCHAR2(5),
  adv_to_18        VARCHAR2(5),
  adv_to_19        VARCHAR2(5),
  adv_to_20        VARCHAR2(5),
  adv_to_21        VARCHAR2(5),
  adv_to_22        VARCHAR2(5),
  adv_to_23        VARCHAR2(5),
  adv_to_24        VARCHAR2(5),
  adv_to_25        VARCHAR2(5),
  adv_to_26        VARCHAR2(5),
  adv_to_27        VARCHAR2(5),
  adv_to_28        VARCHAR2(5),
  adv_to_29        VARCHAR2(5),
  adv_to_30        VARCHAR2(5),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(30),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_BATCH
  add constraint FIMS_PK_T_BATCH primary key (FILE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_ROUT
prompt ==========================
prompt
create table FCIMS.DFIM_T_ROUT
(
  routing_no       NUMBER(12) not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5),
  des_stn          VARCHAR2(5),
  org_city         VARCHAR2(5),
  des_city         VARCHAR2(5),
  routing_string   VARCHAR2(1000),
  type_of_routing  VARCHAR2(10),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20),
  travel_type      VARCHAR2(2)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_ROUT
  add constraint FCIMS_PK_DFIM_ROUT primary key (ROUTING_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_ROUTD
prompt ===========================
prompt
create table FCIMS.DFIM_T_ROUTD
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5),
  des_stn          VARCHAR2(5),
  org_city         VARCHAR2(5),
  des_city         VARCHAR2(5),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_ROUTD
  add constraint FCIMS_PK_DFIM_ROUTD primary key (ROUTING_NO, CARR_CODE, S_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_ROUTD
  add constraint FCIMS_FK_DFIM_ROUTD foreign key (ROUTING_NO, CARR_CODE)
  references FCIMS.DFIM_T_ROUT (ROUTING_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CARR
prompt ==========================
prompt
create table FCIMS.DFIM_T_CARR
(
  routing_no       NUMBER(12) not null,
  carr_code        VARCHAR2(5) not null,
  s_no             NUMBER(12) not null,
  carrier          VARCHAR2(5) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 768K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CARR
  add constraint FCIMS_PK_DFIM_CARR primary key (ROUTING_NO, S_NO, CARR_CODE, CARRIER)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CARR
  add constraint FCIMS_FK_DFIM_CARR foreign key (ROUTING_NO, CARR_CODE, S_NO)
  references FCIMS.DFIM_T_ROUTD (ROUTING_NO, CARR_CODE, S_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_CAT01
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT01
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  pgsr_type        VARCHAR2(3),
  age_min          NUMBER(2),
  age_max          NUMBER(2),
  geo_spec         VARCHAR2(512),
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT01
  add constraint FIMS_PK_T_CAT01 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT02
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT02
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  date_range_start  DATE,
  date_range_stop   DATE,
  time_of_day_start NUMBER(4),
  time_of_day_stop  NUMBER(4),
  day_of_week       CHAR(6),
  text              VARCHAR2(512),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT02
  add constraint FIMS_PK_T_CAT02 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT03
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT03
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  date_range_start DATE,
  date_range_stop  DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT03
  add constraint FIMS_PK_T_CAT03 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT03_DETAIL
prompt ==================================
prompt
create table FCIMS.DFIM_T_CAT03_DETAIL
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  date_range_start DATE not null,
  date_range_stop  DATE not null,
  type             CHAR(1) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT03_DETAIL
  add constraint FIMS_PK_T_CAT03_DETAIL primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE, DATE_RANGE_START, DATE_RANGE_STOP, TYPE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT03_DETAIL
  add constraint FIMS_FK_T_CAT03_DETAIL foreign key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  references FCIMS.DFIM_T_CAT03 (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CAT04
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT04
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  flt_no1          VARCHAR2(4),
  cxr              VARCHAR2(3),
  flt_no2          VARCHAR2(4),
  val              VARCHAR2(1),
  travel_appl      VARCHAR2(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT04
  add constraint FIMS_PK_T_CAT04 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT04_DETAIL
prompt ==================================
prompt
create table FCIMS.DFIM_T_CAT04_DETAIL
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  flt_no1          VARCHAR2(4) not null,
  cxr              VARCHAR2(3) not null,
  flt_no2          VARCHAR2(4) not null,
  val              CHAR(1),
  travel_appl      CHAR(1),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT04_DETAIL
  add constraint FIMS_PK_T_CAT04_DETAIL primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE, FLT_NO1, CXR, FLT_NO2)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT04_DETAIL
  add constraint FIMS_FK_T_CAT04_DETAIL foreign key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  references FCIMS.DFIM_T_CAT04 (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CAT05
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT05
(
  category_type             VARCHAR2(30) not null,
  category_id               NUMBER(7) not null,
  carr_code                 VARCHAR2(5) not null,
  advrsvn_first_time_of_day NUMBER(4),
  advrsvn_first_period      CHAR(3),
  advrsvn_first_unit        CHAR(2),
  advrsvn_last_time_of_day  NUMBER(4),
  advrsvn_last_period       CHAR(3),
  advrsvn_last_unit         CHAR(2),
  advrsvn_tktd              CHAR(1),
  advrsvn_stand             CHAR(1),
  confirm_sector            CHAR(1),
  advtktg_time_of_day       NUMBER(4),
  advtktg_res               NUMBER(3),
  advtktg_unit1             CHAR(2),
  advtktg_dept              NUMBER(3),
  advtktg_unit2             CHAR(1),
  advtktg_both              CHAR(1),
  advtktg_waiver_text       VARCHAR2(512),
  text                      VARCHAR2(512),
  create_date               DATE not null,
  create_by                 VARCHAR2(20) not null,
  last_update_date          DATE not null,
  last_update_by            VARCHAR2(20) not null,
  attribute1                VARCHAR2(100),
  attribute2                VARCHAR2(100),
  attribute3                VARCHAR2(100),
  attribute4                VARCHAR2(100),
  attribute5                VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT05
  add constraint FIMS_PK_T_CAT05 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT06
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT06
(
  category_type      VARCHAR2(30) not null,
  category_id        NUMBER(7) not null,
  carr_code          VARCHAR2(5) not null,
  origin_day_of_week CHAR(6),
  min_stay           CHAR(3),
  unit               CHAR(2),
  min_stay_date      DATE,
  e_l                CHAR(1),
  text               VARCHAR2(512),
  create_date        DATE not null,
  create_by          VARCHAR2(20) not null,
  last_update_date   DATE not null,
  last_update_by     VARCHAR2(20) not null,
  attribute1         VARCHAR2(100),
  attribute2         VARCHAR2(100),
  attribute3         VARCHAR2(100),
  attribute4         VARCHAR2(100),
  attribute5         VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT06
  add constraint FIMS_PK_T_CAT06 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT07
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT07
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  return           CHAR(1),
  max_stay         CHAR(3),
  unit             CHAR(2),
  max_stay_date    DATE,
  e_l              CHAR(1),
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT07
  add constraint FIMS_PK_T_CAT07 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT08
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT08
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  no_of_stops_min  CHAR(2),
  no_of_stops_max  CHAR(2),
  no_of_stops_out  CHAR(2),
  no_of_stops_in   CHAR(2),
  time_min         NUMBER(3),
  time_min_unit    CHAR(1),
  time_max         NUMBER(3),
  time_max_unit    CHAR(1),
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT08
  add constraint FIMS_PK_T_CAT08 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT09
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT09
(
  category_type      VARCHAR2(30) not null,
  category_id        NUMBER(7) not null,
  carr_code          VARCHAR2(5) not null,
  no_of_transfer_min CHAR(2),
  no_of_transfer_max CHAR(2),
  no_of_transfer_out CHAR(2),
  no_of_transfer_in  CHAR(2),
  text               VARCHAR2(512),
  create_date        DATE not null,
  create_by          VARCHAR2(20) not null,
  last_update_date   DATE not null,
  last_update_by     VARCHAR2(20) not null,
  attribute1         VARCHAR2(100),
  attribute2         VARCHAR2(100),
  attribute3         VARCHAR2(100),
  attribute4         VARCHAR2(100),
  attribute5         VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT09
  add constraint FIMS_PK_T_CAT09 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT10
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT10
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT10
  add constraint FIMS_PK_T_CAT10 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT11
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT11
(
  category_type         VARCHAR2(30) not null,
  category_id           NUMBER(7) not null,
  carr_code             VARCHAR2(5) not null,
  text                  VARCHAR2(512),
  create_date           DATE not null,
  create_by             VARCHAR2(20) not null,
  last_update_date      DATE not null,
  last_update_by        VARCHAR2(20) not null,
  attribute1            VARCHAR2(100),
  attribute2            VARCHAR2(100),
  attribute3            VARCHAR2(100),
  attribute4            VARCHAR2(100),
  attribute5            VARCHAR2(100),
  restricted_date_start DATE,
  restricted_date_stop  DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT11
  add constraint FIMS_PK_T_CAT11 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT11_DETAIL
prompt ==================================
prompt
create table FCIMS.DFIM_T_CAT11_DETAIL
(
  category_type         VARCHAR2(30) not null,
  category_id           NUMBER(7) not null,
  carr_code             VARCHAR2(5) not null,
  restricted_date_start DATE not null,
  restricted_date_stop  DATE not null,
  create_date           DATE not null,
  create_by             VARCHAR2(20) not null,
  last_update_date      DATE not null,
  last_update_by        VARCHAR2(20) not null,
  attribute1            VARCHAR2(100),
  attribute2            VARCHAR2(100),
  attribute3            VARCHAR2(100),
  attribute4            VARCHAR2(100),
  attribute5            VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT11_DETAIL
  add constraint FIMS_PK_T_CAT11_DETAIL primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE, RESTRICTED_DATE_START, RESTRICTED_DATE_STOP)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT11_DETAIL
  add constraint FIMS_FK_T_CAT11_DETAIL foreign key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  references FCIMS.DFIM_T_CAT11 (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CAT12
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT12
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  date_range_start  DATE,
  date_range_stop   DATE,
  time_of_day_start NUMBER(4),
  time_of_day_stop  NUMBER(4),
  day_of_week       CHAR(6),
  eqp_code          CHAR(3),
  charges_amt       NUMBER(7),
  charges_cur       CHAR(3),
  charges_des       NUMBER(1),
  charges_percent   NUMBER(7,4),
  text              VARCHAR2(512),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT12
  add constraint FIMS_PK_T_CAT12 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT13
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT13
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT13
  add constraint FIMS_PK_T_CAT13 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT14
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT14
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  travel_dates_comm DATE,
  travel_dates_exp  DATE,
  travel_dates_ret  CHAR(1),
  travel_dates_comp DATE,
  text              VARCHAR2(512),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT14
  add constraint FIMS_PK_T_CAT14 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT15
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT15
(
  category_type            VARCHAR2(30) not null,
  category_id              NUMBER(7) not null,
  carr_code                VARCHAR2(5) not null,
  salesdates_earliest_res  DATE,
  salesdates_earliest_tktg DATE,
  salesdates_latest_res    DATE,
  salesdates_latest_tktg   DATE,
  cxr_tkt                  CHAR(1),
  e_tkt                    CHAR(1),
  bsp_tkt                  CHAR(1),
  ta_text                  VARCHAR2(512),
  text                     VARCHAR2(512),
  create_date              DATE not null,
  create_by                VARCHAR2(20) not null,
  last_update_date         DATE not null,
  last_update_by           VARCHAR2(20) not null,
  attribute1               VARCHAR2(100),
  attribute2               VARCHAR2(100),
  attribute3               VARCHAR2(100),
  attribute4               VARCHAR2(100),
  attribute5               VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT15
  add constraint FIMS_PK_T_CAT15 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT16
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT16
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  volchg           VARCHAR2(4000),
  invchg           VARCHAR2(4000),
  volref           VARCHAR2(4000),
  invref           VARCHAR2(4000),
  othtxt           VARCHAR2(4000),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT16
  add constraint FIMS_PK_T_CAT16 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT17
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT17
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT17
  add constraint FIMS_PK_T_CAT17 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT18
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT18
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  tkttext          VARCHAR2(512),
  invtext          VARCHAR2(512),
  endtext          VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(512),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT18
  add constraint FIMS_PK_T_CAT18 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT19
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT19
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  psgr_type         CHAR(3),
  psgr_age_min      NUMBER(2),
  psgr_age_max      NUMBER(2),
  psgr_fare_amt     NUMBER(7),
  psgr_fare_cur     CHAR(3),
  psgr_fare_dec     NUMBER(1),
  psgr_fare_percent NUMBER(7,4),
  othtext           VARCHAR2(1024),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT19
  add constraint FIMS_PK_T_CAT19 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT20
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT20
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  psgr_type         VARCHAR2(3),
  psgr_age_min      NUMBER(2),
  psgr_age_max      NUMBER(2),
  psgr_fare_amt     NUMBER(7),
  psgr_fare_cur     CHAR(3),
  psgr_fare_dec     NUMBER(1),
  psgr_fare_percent NUMBER(7,4),
  othtext           VARCHAR2(1024),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT20
  add constraint FIMS_PK_T_CAT20 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT21
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT21
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  psgr_type         CHAR(3),
  psgr_age_min      NUMBER(2),
  psgr_age_max      NUMBER(2),
  psgr_fare_amt     NUMBER(7),
  psgr_fare_cur     CHAR(3),
  psgr_fare_dec     NUMBER(1),
  psgr_fare_percent NUMBER(7,4),
  othtext           VARCHAR2(1024),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT21
  add constraint FIMS_PK_T_CAT21 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT22
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT22
(
  category_type     VARCHAR2(30) not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  psgr_type         CHAR(3),
  psgr_age_min      NUMBER(2),
  psgr_age_max      NUMBER(2),
  psgr_fare_amt     NUMBER(7),
  psgr_fare_cur     CHAR(3),
  psgr_fare_dec     NUMBER(1),
  psgr_fare_percent NUMBER(7,4),
  othtext           VARCHAR2(1024),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(100),
  attribute2        VARCHAR2(100),
  attribute3        VARCHAR2(100),
  attribute4        VARCHAR2(100),
  attribute5        VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT22
  add constraint FIMS_PK_T_CAT22 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT23
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT23
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  spa_text         VARCHAR2(512),
  refund_text      VARCHAR2(512),
  mix_class_text   VARCHAR2(512),
  other_text       VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT23
  add constraint FIMS_PK_T_CAT23 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT25
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT25
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT25
  add constraint FIMS_PK_T_CAT25 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT26
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT26
(
  category_type                VARCHAR2(30) not null,
  category_id                  NUMBER(7) not null,
  carr_code                    VARCHAR2(5) not null,
  type                         CHAR(3),
  min_size                     NUMBER(4),
  max_size                     NUMBER(4),
  flights_no                   NUMBER(3),
  flights_pct                  NUMBER(7,4),
  flights_max                  NUMBER(2),
  children                     NUMBER(2),
  name_req                     CHAR(1),
  additional_passengers_no     NUMBER(3),
  additional_passengers_pct    NUMBER(7,4),
  additional_passengers_tod    NUMBER(4),
  additional_passengers_period CHAR(3),
  additional_passengers_unit   CHAR(2),
  substitute_passengers_no     NUMBER(3),
  substitute_passengers_pct    NUMBER(7,4),
  substitute_passengers_tod    NUMBER(4),
  substitute_passengers_period CHAR(3),
  substitute_passengers_unit   CHAR(2),
  group_individual_travel_cond VARCHAR2(512),
  text                         VARCHAR2(512),
  create_date                  DATE not null,
  create_by                    VARCHAR2(20) not null,
  last_update_date             DATE not null,
  last_update_by               VARCHAR2(20) not null,
  attribute1                   VARCHAR2(100),
  attribute2                   VARCHAR2(100),
  attribute3                   VARCHAR2(100),
  attribute4                   VARCHAR2(100),
  attribute5                   VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT26
  add constraint FIMS_PK_T_CAT26 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT27
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT27
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT27
  add constraint FIMS_PK_T_CAT27 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT28
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT28
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  text             VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT28
  add constraint FIMS_PK_T_CAT28 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT29
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT29
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  deposit_req      CHAR(1),
  deposit_amt      NUMBER(7),
  deposit_cur      CHAR(3),
  deposit_dec      NUMBER(1),
  deposit_pct      NUMBER(7,4),
  deposit_appl     CHAR(1),
  deposit_days     NUMBER(3),
  deposit_text     VARCHAR2(512),
  refunds_non_ref  CHAR(1),
  refunds_amt      NUMBER(7),
  refunds_cur      CHAR(3),
  refunds_dec      NUMBER(1),
  refunds_pct      NUMBER(7,4),
  refunds_appl     CHAR(1),
  refunds_days     NUMBER(3),
  refund_text      VARCHAR2(512),
  waiver_text      VARCHAR2(512),
  other_text       VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT29
  add constraint FIMS_PK_T_CAT29 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT31
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT31
(
  category_type            VARCHAR2(30) default '31' not null,
  category_id              NUMBER(7) not null,
  carr_code                VARCHAR2(5) not null,
  change_tag               VARCHAR2(1),
  voluntary_changed_text   VARCHAR2(450),
  involuntary_changed_text VARCHAR2(450),
  create_by                VARCHAR2(20),
  create_date              DATE default (SYSDATE),
  last_update_by           VARCHAR2(20),
  last_update_date         DATE default (SYSDATE),
  tkt_val                  CHAR(1) default '',
  jny                      CHAR(1) default '',
  chg_ind                  CHAR(1) default '',
  other_text               VARCHAR2(512) default ''
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 464K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT31
  add constraint DFIM_T_CAT31_PK primary key (CARR_CODE, CATEGORY_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT31_DETAIL
prompt ==================================
prompt
create table FCIMS.DFIM_T_CAT31_DETAIL
(
  category_id                NUMBER(7) not null,
  carr_code                  VARCHAR2(5) not null,
  seq_number                 NUMBER(3) not null,
  passenger_type             VARCHAR2(3),
  fare_basis                 VARCHAR2(15),
  booking_class              VARCHAR2(26),
  journey_type               VARCHAR2(2),
  ticket_used_tag            NUMBER(1),
  flight_launch_tag          VARCHAR2(1),
  flight_launch_unit         VARCHAR2(1),
  flight_launch_number       NUMBER(3),
  free_change_times          VARCHAR2(1),
  charge_type                NUMBER(1),
  charge_currency_code       VARCHAR2(3),
  charge_amount              NUMBER(5),
  discount_calculate_type    NUMBER(1),
  discount_booking_class     VARCHAR2(1),
  discount_percent           NUMBER(5,2),
  charge_unit                NUMBER(1),
  carry_unit                 NUMBER(1),
  round_type                 NUMBER(1),
  charge_min_amount          NUMBER(5),
  charge_min_currency_code   VARCHAR2(3),
  reissue_charge_tag         NUMBER(1),
  reissue_restriction_id     NUMBER(7) not null,
  detail_translate           VARCHAR2(4000),
  other_reissue_carrier_list VARCHAR2(100),
  first_ticketed_time        NUMBER(4),
  last_ticketed_time         NUMBER(4),
  ticketed_time_unit         VARCHAR2(1) default 'H',
  departrue_time_type        NUMBER(1),
  first_departrue_time       NUMBER(4),
  last_departrue_time        NUMBER(4),
  departrue_time_unit        VARCHAR2(1) default 'H',
  reissue_allowed_tag        NUMBER(1) default 1
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 464K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT31_DETAIL
  add constraint DFIM_T_CAT31_DETAIL_PK primary key (CARR_CODE, CATEGORY_ID, SEQ_NUMBER)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT31_OLD
prompt ===============================
prompt
create table FCIMS.DFIM_T_CAT31_OLD
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  tkt_val          CHAR(1),
  jny              CHAR(1),
  chg_ind          CHAR(1),
  other_text       VARCHAR2(512),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT31_OLD
  add constraint FIMS_PK_T_CAT31 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT31_RESTRICTION
prompt =======================================
prompt
create table FCIMS.DFIM_T_CAT31_RESTRICTION
(
  reissue_restriction_id NUMBER(7) not null,
  process_tag            NUMBER(1) not null,
  date_changed_tag       NUMBER(1) not null,
  flight_date_tag        VARCHAR2(1),
  same_flight_tag        NUMBER(1) not null,
  upgrade_tag            NUMBER(1) not null,
  fare_display_tag       NUMBER(1) not null,
  endorsment_tag         NUMBER(1) not null,
  endorsment_prefix      VARCHAR2(10),
  endorsment_suffix      VARCHAR2(10),
  new_endorsment         VARCHAR2(82),
  flight_date_num        NUMBER(3),
  flight_date_unit       VARCHAR2(1),
  upgrade_fee_tag        NUMBER(1) default 0,
  other_carrier_list     VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 464K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT31_RESTRICTION
  add constraint DFIM_T_CAT31_REST_PK primary key (REISSUE_RESTRICTION_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT33
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT33
(
  category_type     VARCHAR2(30) default '33' not null,
  category_id       NUMBER(7) not null,
  carr_code         VARCHAR2(5) not null,
  refund_type       NUMBER(1) not null,
  unused_sector_tax NUMBER(1),
  voluntary_txt     VARCHAR2(150),
  involuntary_txt   VARCHAR2(150),
  create_by         VARCHAR2(20) default user not null,
  create_date       DATE default TRUNC(sysdate) not null,
  last_update_by    VARCHAR2(20) default user not null,
  last_update_date  DATE default TRUNC(sysdate) not null,
  attribute1        VARCHAR2(100) default '',
  attribute2        VARCHAR2(100) default '',
  attribute3        VARCHAR2(100) default '',
  attribute4        VARCHAR2(100) default '',
  attribute5        VARCHAR2(100) default ''
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT33
  add constraint PK_DFIM_CAT33 primary key (CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT33_DETAIL
prompt ==================================
prompt
create table FCIMS.DFIM_T_CAT33_DETAIL
(
  category_id              NUMBER(7) not null,
  carr_code                VARCHAR2(5) not null,
  seq_id                   NUMBER(3) not null,
  passenger_type           VARCHAR2(2),
  journey_type             VARCHAR2(2),
  booking_class            VARCHAR2(26),
  fare_basis               VARCHAR2(15),
  ticket_use_type          NUMBER(1) not null,
  first_ticketed_time      NUMBER(4),
  last_ticketed_time       NUMBER(4),
  departrue_time_type      NUMBER(1),
  first_departrue_time     NUMBER(4),
  last_departrue_time      NUMBER(4),
  cal_used_sector_type     NUMBER(1),
  cal_booking_class        VARCHAR2(1),
  cal_unused_sector_type   NUMBER(1) not null,
  percent                  NUMBER(3),
  minimum_amount           NUMBER(4),
  fixed_amount             NUMBER(4),
  tax_refund_type          NUMBER(1) not null,
  attribute1               VARCHAR2(4000) default '',
  attribute2               VARCHAR2(100) default '',
  attribute3               VARCHAR2(100) default '',
  attribute4               VARCHAR2(100) default '',
  attribute5               VARCHAR2(100) default '',
  spec_rbd                 VARCHAR2(1),
  cal_unused_pfare_percent NUMBER(3),
  ticketed_time_unit       VARCHAR2(1) default 'H',
  departrue_time_unit      VARCHAR2(1) default 'H',
  refund_allowed_tag       NUMBER(1) default 1
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT33_DETAIL
  add constraint PK_DFIM_CAT33_DETAIL primary key (CATEGORY_ID, CARR_CODE, SEQ_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT33_DETAIL
  add constraint FK_DFIM_CAT33_DETAIL foreign key (CATEGORY_ID, CARR_CODE)
  references FCIMS.DFIM_T_CAT33 (CATEGORY_ID, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CAT35
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT35
(
  category_type          VARCHAR2(30) not null,
  category_id            NUMBER(7) not null,
  carr_code              VARCHAR2(5) not null,
  commission_other_text  VARCHAR2(512),
  commission_percent     NUMBER(7,4),
  commission_amt         NUMBER(7),
  commission_cur         CHAR(3),
  commission_dec         NUMBER(1),
  upgrade                CHAR(1),
  baggage_number         NUMBER(2),
  baggage_piece_kilogram CHAR(1),
  ticketing_text         VARCHAR2(4000),
  other_text             VARCHAR2(512),
  create_date            DATE not null,
  create_by              VARCHAR2(20) not null,
  last_update_date       DATE not null,
  last_update_by         VARCHAR2(20) not null,
  attribute1             VARCHAR2(100),
  attribute2             VARCHAR2(100),
  attribute3             VARCHAR2(100),
  attribute4             VARCHAR2(100),
  attribute5             VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT35
  add constraint FIMS_PK_T_CAT35 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CAT50
prompt ===========================
prompt
create table FCIMS.DFIM_T_CAT50
(
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  carr_code        VARCHAR2(5) not null,
  other_text       VARCHAR2(4000),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CAT50
  add constraint FIMS_PK_T_CAT50 primary key (CATEGORY_TYPE, CATEGORY_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_SUBCH
prompt ===========================
prompt
create table FCIMS.DFIM_T_SUBCH
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  priority         VARCHAR2(4) not null,
  title            VARCHAR2(4000) not null,
  archv_ind        VARCHAR2(1),
  aprv_ind         VARCHAR2(1),
  rpt_date         DATE,
  aprv_date        DATE,
  sign_by          VARCHAR2(20),
  sub_type         NUMBER(1) not null,
  reason           VARCHAR2(200),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_SUBCH
  add constraint FIMS_PK_T_SUBCH primary key (RPT_FILE_NO, RPT_FROM)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 768K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CCRPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CCRPO
(
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  cargo_fare_code     VARCHAR2(1),
  cargo_code          VARCHAR2(4) not null,
  curr_code           VARCHAR2(3),
  fare_rate           NUMBER(3),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CCRPO
  add constraint DFIM_PK_T_CCRPO primary key (EFF_DATE, RPT_FILE_NO, CARGO_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CCRPO
  add constraint DFIM_FK_T_CCRPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CCRPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CCRPP
(
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  cargo_fare_code     VARCHAR2(1),
  cargo_code          VARCHAR2(4) not null,
  curr_code           VARCHAR2(3),
  fare_rate           NUMBER(3),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CCRPP
  add constraint DFIM_PK_T_CCRPP primary key (RPT_FILE_NO, EFF_DATE, CARGO_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CCRPP
  add constraint DFIM_FK_T_CCRPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CMRPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CMRPO
(
  fare_no             NUMBER(8) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30),
  rpt_from            VARCHAR2(5),
  eff_date            DATE,
  disc_date           DATE,
  cargo_fare_code     VARCHAR2(1),
  curr_code           VARCHAR2(3),
  min_rate            NUMBER(4),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CMRPO
  add constraint DFIM_PK_T_CMRPO primary key (FARE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CMRPO
  add constraint DFIM_FK_T_CMRPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CMRPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CMRPP
(
  fare_no             NUMBER(8) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30),
  rpt_from            VARCHAR2(5),
  eff_date            DATE,
  disc_date           DATE,
  cargo_fare_code     VARCHAR2(1),
  curr_code           VARCHAR2(3),
  min_rate            NUMBER(4),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CMRPP
  add constraint DFIM_PK_T_CMRPP primary key (FARE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CMRPP
  add constraint DFIM_FK_T_CMRPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CPRPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CPRPO
(
  fare_no             NUMBER(8) not null,
  carr_code           VARCHAR2(5) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  org_stn             VARCHAR2(5) not null,
  org_city            VARCHAR2(5),
  org_flg             CHAR(1),
  des_stn             VARCHAR2(5) not null,
  des_city            VARCHAR2(5),
  des_flg             CHAR(1),
  asso_routing        VARCHAR2(50),
  tmp                 NUMBER(6),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100),
  remark              VARCHAR2(4000)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRPO
  add constraint DFIM_PK_T_CPRPO primary key (FARE_NO, CARR_CODE, RPT_FILE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRPO
  add constraint DFIM_FK_T_CPRPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CPRDO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CPRDO
(
  fare_no          NUMBER(8) not null,
  rpt_file_no      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  wght_rang        VARCHAR2(5) not null,
  fare_rate        NUMBER(12,3) not null,
  cargo_fare_code  VARCHAR2(1),
  cargo_cny_km     NUMBER(12,3),
  curr_code        VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRDO
  add constraint DFIM_PK_T_CPRDO primary key (FARE_NO, RPT_FILE_NO, CARR_CODE, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRDO
  add constraint DFIM_FK_T_CPRDO foreign key (FARE_NO, CARR_CODE, RPT_FILE_NO)
  references FCIMS.DFIM_T_CPRPO (FARE_NO, CARR_CODE, RPT_FILE_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_CPRDP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CPRDP
(
  fare_no          NUMBER(8) not null,
  rpt_file_no      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  wght_rang        VARCHAR2(5) not null,
  fare_rate        NUMBER(12,3) not null,
  cargo_fare_code  VARCHAR2(1),
  cargo_cny_km     NUMBER(12,3),
  curr_code        VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRDP
  add constraint DFIM_PK_T_CPRDP primary key (FARE_NO, CARR_CODE, RPT_FILE_NO, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_CPRPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CPRPP
(
  fare_no             NUMBER(8) not null,
  carr_code           VARCHAR2(5) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  org_stn             VARCHAR2(5) not null,
  org_city            VARCHAR2(5),
  org_flg             CHAR(1),
  des_stn             VARCHAR2(5) not null,
  des_city            VARCHAR2(5),
  des_flg             CHAR(1),
  asso_routing        VARCHAR2(50),
  tmp                 NUMBER(6),
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100),
  remark              VARCHAR2(4000)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRPP
  add constraint DFIM_PK_T_CPRPP primary key (CARR_CODE, RPT_FILE_NO, FARE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CPRPP
  add constraint DFIM_FK_T_CPRPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CSRPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CSRPO
(
  fare_no             NUMBER(8) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  org_stn             VARCHAR2(5) not null,
  org_city            VARCHAR2(5),
  org_flg             CHAR(1),
  des_stn             VARCHAR2(5) not null,
  des_city            VARCHAR2(5),
  des_flg             CHAR(1),
  asso_routing        VARCHAR2(50),
  carr_code           VARCHAR2(5) not null,
  cargo_fare_code     VARCHAR2(1),
  cargo_code          VARCHAR2(4) not null,
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  rmks                VARCHAR2(4000),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRPO
  add constraint DFIM_PK_T_CSRPO primary key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRPO
  add constraint DFIM_FK_T_CSRPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CSRDO
prompt ===========================
prompt
create table FCIMS.DFIM_T_CSRDO
(
  fare_no          NUMBER(8) not null,
  rpt_file_no      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  wght_rang        VARCHAR2(5) not null,
  fare_rate        NUMBER(12,3) not null,
  curr_code        VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRDO
  add constraint DFIM_PK_T_CSRDO primary key (FARE_NO, RPT_FILE_NO, CARR_CODE, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRDO
  add constraint DFIM_FK_T_CSRDO foreign key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  references FCIMS.DFIM_T_CSRPO (FARE_NO, RPT_FILE_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_CSRPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CSRPP
(
  fare_no             NUMBER(8) not null,
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(5) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  org_stn             VARCHAR2(5) not null,
  org_city            VARCHAR2(5),
  org_flg             CHAR(1),
  des_stn             VARCHAR2(5) not null,
  des_city            VARCHAR2(5),
  des_flg             CHAR(1),
  asso_routing        VARCHAR2(50),
  carr_code           VARCHAR2(5) not null,
  cargo_fare_code     VARCHAR2(1),
  cargo_code          VARCHAR2(4) not null,
  rpt_date            DATE,
  aprv_date           DATE,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  rmks                VARCHAR2(4000),
  last_transfer_date  DATE,
  first_transfer_date DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(20) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(20) not null,
  attribute1          VARCHAR2(100),
  attribute2          VARCHAR2(100),
  attribute3          VARCHAR2(100),
  attribute4          VARCHAR2(100),
  attribute5          VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRPP
  add constraint DFIM_PK_T_CSRPP primary key (CARR_CODE, FARE_NO, RPT_FILE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRPP
  add constraint DFIM_FK_T_CSRPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_CSRDP
prompt ===========================
prompt
create table FCIMS.DFIM_T_CSRDP
(
  fare_no          NUMBER(8) not null,
  rpt_file_no      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  wght_rang        VARCHAR2(5) not null,
  fare_rate        NUMBER(12,3) not null,
  curr_code        VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRDP
  add constraint DFIM_PK_T_CSRDP primary key (CARR_CODE, FARE_NO, RPT_FILE_NO, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_CSRDP
  add constraint DFIM_FK_T_CSRDP foreign key (CARR_CODE, FARE_NO, RPT_FILE_NO)
  references FCIMS.DFIM_T_CSRPP (CARR_CODE, FARE_NO, RPT_FILE_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_DIST
prompt ==========================
prompt
create table FCIMS.DFIM_T_DIST
(
  org_stn          VARCHAR2(5) not null,
  des_stn          VARCHAR2(5) not null,
  tmp              NUMBER(6) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_DIST
  add constraint DFIM_PK_T_DIST primary key (ORG_STN, DES_STN)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PSFPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_PSFPP
(
  fare_no           NUMBER not null,
  file_no           VARCHAR2(30),
  rpt_file_no       VARCHAR2(30) not null,
  rpt_from          VARCHAR2(5) not null,
  rpt_date          DATE,
  aprv_date         DATE,
  aprv_ind          VARCHAR2(1),
  archv_ind         VARCHAR2(1),
  carr_code         VARCHAR2(5) not null,
  eff_date          DATE not null,
  disc_date         DATE not null,
  org_stn           VARCHAR2(5) not null,
  org_city          VARCHAR2(5),
  org_flg           CHAR(1),
  des_stn           VARCHAR2(5) not null,
  des_city          VARCHAR2(5),
  des_flg           CHAR(1),
  travel_type       VARCHAR2(2),
  fare_basis        VARCHAR2(15) not null,
  fare_type         VARCHAR2(3),
  cls_code          VARCHAR2(1) not null,
  curr_code         VARCHAR2(3),
  disc_per          NUMBER(5,2),
  first_sale_date   DATE,
  last_sale_date    DATE,
  rule_no           VARCHAR2(13) not null,
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  service_class     VARCHAR2(1),
  fare              NUMBER(12,3),
  flag              VARCHAR2(1),
  attribute1        VARCHAR2(20),
  attribute2        VARCHAR2(20),
  routeflag         VARCHAR2(1),
  cs_activate_date  DATE,
  cs_source_fare_pk VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 144M
    minextents 1
    maxextents unlimited
  );
create bitmap index FCIMS.DFIM_T_PSFPP_BITMAP_IND on FCIMS.DFIM_T_PSFPP (APRV_IND, CARR_CODE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 6M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_DFIM_T_PSFPP_IDX1 on FCIMS.DFIM_T_PSFPP (ORG_STN, DES_STN, EFF_DATE, DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 49M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PSFPP
  add constraint DFIM_PK_T_PSFPP primary key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 38M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PSFPP
  add constraint DFIM_FK_T_PSFPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_FROUT
prompt ===========================
prompt
create table FCIMS.DFIM_T_FROUT
(
  fare_no          NUMBER,
  carr_code        VARCHAR2(5) not null,
  rpt_file_no      VARCHAR2(30),
  routing_no       NUMBER(12) not null,
  org_stn          VARCHAR2(5),
  des_stn          VARCHAR2(5),
  org_city         VARCHAR2(5),
  des_city         VARCHAR2(5),
  routing_string   VARCHAR2(1000),
  type_of_routing  VARCHAR2(10),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FROUT
  add constraint FCIMS_PK_DFIM_FROUT primary key (ROUTING_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FROUT
  add constraint FCIMS_FK_DFIM_FROUT_PSFPP foreign key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  references FCIMS.DFIM_T_PSFPP (FARE_NO, RPT_FILE_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_FROUTD
prompt ============================
prompt
create table FCIMS.DFIM_T_FROUTD
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5),
  des_stn          VARCHAR2(5),
  org_city         VARCHAR2(5),
  des_city         VARCHAR2(5),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FROUTD
  add constraint FCIMS_PK_DFIM_FROUTD primary key (ROUTING_NO, CARR_CODE, S_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FROUTD
  add constraint FCIMS_FK_DFIM_FROUTD foreign key (ROUTING_NO, CARR_CODE)
  references FCIMS.DFIM_T_FROUT (ROUTING_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_FCARR
prompt ===========================
prompt
create table FCIMS.DFIM_T_FCARR
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(5) not null,
  carrier          VARCHAR2(5) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FCARR
  add constraint FCIMS_PK_DFIM_FCARR primary key (ROUTING_NO, S_NO, CARR_CODE, CARRIER)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 768K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FCARR
  add constraint FCIMS_FK_DFIM_FCARR foreign key (ROUTING_NO, CARR_CODE, S_NO)
  references FCIMS.DFIM_T_FROUTD (ROUTING_NO, CARR_CODE, S_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_FLEPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_FLEPO
(
  dir_no           NUMBER(9) not null,
  father_dir       NUMBER(9),
  dir_name         VARCHAR2(100) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(400),
  attribute2       VARCHAR2(400),
  attribute3       VARCHAR2(400),
  attribute4       VARCHAR2(400),
  attribute5       VARCHAR2(400)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FLEPO
  add constraint FCIMS_PK_T_FLEPO primary key (DIR_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_FLEDO
prompt ===========================
prompt
create table FCIMS.DFIM_T_FLEDO
(
  dir_no           NUMBER(9) not null,
  file_no          NUMBER(9) not null,
  file_name        VARCHAR2(100) not null,
  ext_name         VARCHAR2(3) not null,
  file_content     BLOB not null,
  remark           VARCHAR2(4000),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(400),
  attribute2       VARCHAR2(400),
  attribute3       VARCHAR2(400),
  attribute4       VARCHAR2(400),
  attribute5       VARCHAR2(400)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FLEDO
  add constraint FCIMS_PK_T_FLEDO primary key (DIR_NO, FILE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FLEDO
  add constraint FIMS_FK_T_FLEDO foreign key (DIR_NO)
  references FCIMS.DFIM_T_FLEPO (DIR_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_FLERT
prompt ===========================
prompt
create table FCIMS.DFIM_T_FLERT
(
  dir_no           NUMBER(9) not null,
  user_id          VARCHAR2(8) not null,
  user_name        VARCHAR2(20) not null,
  control          VARCHAR2(8) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(400),
  attribute2       VARCHAR2(400),
  attribute3       VARCHAR2(400),
  attribute4       VARCHAR2(400),
  attribute5       VARCHAR2(400)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FLERT
  add constraint FCIMS_PK_T_FLERT primary key (DIR_NO, USER_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_FLERT
  add constraint FIMS_FK_T_FLERT foreign key (DIR_NO)
  references FCIMS.DFIM_T_FLEPO (DIR_NO) on delete cascade;

prompt
prompt Creating table DFIM_T_IMPORTNO
prompt ==============================
prompt
create table FCIMS.DFIM_T_IMPORTNO
(
  carr_code VARCHAR2(5) not null,
  year      NUMBER(4) not null,
  importno  NUMBER(6) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PNFPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_PNFPO
(
  carr_code         VARCHAR2(5) not null,
  file_no           VARCHAR2(30),
  rpt_file_no       VARCHAR2(30) not null,
  rpt_from          VARCHAR2(5) not null,
  fare_no           NUMBER not null,
  rpt_date          DATE,
  aprv_date         DATE,
  org_stn           VARCHAR2(5) not null,
  org_city          VARCHAR2(5),
  org_flg           CHAR(1),
  des_stn           VARCHAR2(5) not null,
  des_city          VARCHAR2(5),
  des_flg           CHAR(1),
  travel_type       VARCHAR2(2),
  curr_code         VARCHAR2(3),
  fare              NUMBER(12,3) not null,
  eff_date          DATE not null,
  disc_date         DATE not null,
  aprv_ind          VARCHAR2(1),
  archv_ind         VARCHAR2(1),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(10),
  xbg_rate          NUMBER(9,3),
  first_sale_date   DATE default trunc(sysdate),
  last_sale_date    DATE default to_date(99991231,'yyyyMMdd'),
  cs_activate_date  DATE,
  cs_source_fare_pk VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 12M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_DFIM_T_PNFPO_IDX1 on FCIMS.DFIM_T_PNFPO (ORG_STN, DES_STN, EFF_DATE, DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 5M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PNFPO
  add constraint FCIMS_PK_T_PNFPO primary key (CARR_CODE, RPT_FILE_NO, FARE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 6M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PNFPO
  add constraint DFIM_FK_T_PNFPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_PNFPO_1
prompt =============================
prompt
create table FCIMS.DFIM_T_PNFPO_1
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  fare_no          NUMBER(38) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare             NUMBER(12,3) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(10),
  xbg_rate         NUMBER(9,3),
  first_sale_date  DATE,
  last_sale_date   DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PNFPO_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PNFPO_TRACE
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  fare_no          NUMBER not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare             NUMBER(12,3) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(10),
  operation        VARCHAR2(10),
  xbg_rate         NUMBER(9,3),
  last_sale_date   DATE default to_date(99991231,'yyyyMMdd'),
  first_sale_date  DATE default trunc(sysdate)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 28M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PNFPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_PNFPP
(
  carr_code         VARCHAR2(5) not null,
  file_no           VARCHAR2(30),
  rpt_file_no       VARCHAR2(30) not null,
  rpt_from          VARCHAR2(5) not null,
  fare_no           NUMBER not null,
  rpt_date          DATE,
  aprv_date         DATE,
  org_stn           VARCHAR2(5) not null,
  org_city          VARCHAR2(5),
  org_flg           CHAR(1),
  des_stn           VARCHAR2(5) not null,
  des_city          VARCHAR2(5),
  des_flg           CHAR(1),
  travel_type       VARCHAR2(2),
  curr_code         VARCHAR2(3),
  fare              NUMBER(12,3) not null,
  eff_date          DATE not null,
  disc_date         DATE not null,
  aprv_ind          VARCHAR2(1),
  archv_ind         VARCHAR2(1),
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  attribute1        VARCHAR2(10),
  xbg_rate          NUMBER(9,3),
  first_sale_date   DATE,
  last_sale_date    DATE,
  cs_activate_date  DATE,
  cs_source_fare_pk VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 12M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_DFIM_T_PNFPP_IDX1 on FCIMS.DFIM_T_PNFPP (ORG_STN, DES_STN, EFF_DATE, DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 5M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PNFPP
  add constraint FCIMS_PK_T_PNFPP primary key (CARR_CODE, RPT_FILE_NO, FARE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 4M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PNFPP
  add constraint DFIM_FK_T_PNFPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_PNFPP_1
prompt =============================
prompt
create table FCIMS.DFIM_T_PNFPP_1
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  fare_no          NUMBER(38) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare             NUMBER(12,3) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(10),
  xbg_rate         NUMBER(9,3),
  first_sale_date  DATE,
  last_sale_date   DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PNFPP_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PNFPP_TRACE
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  fare_no          NUMBER not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare             NUMBER(12,3) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(10),
  operation        VARCHAR2(10) not null,
  xbg_rate         NUMBER(9,3),
  first_sale_date  DATE default trunc(sysdate),
  last_sale_date   DATE default to_date(99991231,'yyyyMMdd')
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 11M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PPFPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_PPFPO
(
  file_no          VARCHAR2(30) not null,
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE not null,
  aprv_date        DATE not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  tmp              NUMBER(6) not null,
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare_basis       VARCHAR2(15) not null,
  fare             NUMBER(6) not null,
  xbg_rate         NUMBER(5,2),
  pax_cny_km       NUMBER(5,2),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 4M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PPFPO
  add constraint FCIMS_PK_T_PPFPO primary key (ORG_STN, DES_STN, EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 704K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PPFPO
  add constraint DFIM_FK_T_PPFPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_PPFPO_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PPFPO_TRACE
(
  file_no          VARCHAR2(30) not null,
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE not null,
  aprv_date        DATE not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  tmp              NUMBER(6) not null,
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare_basis       VARCHAR2(15) not null,
  fare             NUMBER(6) not null,
  xbg_rate         NUMBER(5,2),
  pax_cny_km       NUMBER(5,2),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  operation        VARCHAR2(10) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 6M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PPFPP
prompt ===========================
prompt
create table FCIMS.DFIM_T_PPFPP
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  tmp              NUMBER(6) not null,
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare_basis       VARCHAR2(15) not null,
  fare             NUMBER(6) not null,
  xbg_rate         NUMBER(5,2),
  pax_cny_km       NUMBER(5,2),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 4M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PPFPP
  add constraint FCIMS_PK_T_PPFPP primary key (EFF_DATE, ORG_STN, DES_STN, RPT_FROM)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PPFPP
  add constraint DFIM_FK_T_PPFPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_PPFPP_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PPFPP_TRACE
(
  carr_code        VARCHAR2(5) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  tmp              NUMBER(6) not null,
  travel_type      VARCHAR2(2),
  curr_code        VARCHAR2(3),
  fare_basis       VARCHAR2(15) not null,
  fare             NUMBER(6) not null,
  xbg_rate         NUMBER(5,2),
  pax_cny_km       NUMBER(5,2),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  operation        VARCHAR2(10) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 8M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PSFPO
prompt ===========================
prompt
create table FCIMS.DFIM_T_PSFPO
(
  fare_no           NUMBER not null,
  file_no           VARCHAR2(30),
  rpt_file_no       VARCHAR2(30) not null,
  rpt_from          VARCHAR2(5) not null,
  rpt_date          DATE,
  aprv_date         DATE,
  aprv_ind          VARCHAR2(1),
  archv_ind         VARCHAR2(1),
  carr_code         VARCHAR2(5) not null,
  eff_date          DATE not null,
  disc_date         DATE not null,
  org_stn           VARCHAR2(5) not null,
  org_city          VARCHAR2(5),
  org_flg           CHAR(1),
  des_stn           VARCHAR2(5) not null,
  des_city          VARCHAR2(5),
  des_flg           CHAR(1),
  travel_type       VARCHAR2(2),
  fare_basis        VARCHAR2(15) not null,
  fare_type         VARCHAR2(3),
  cls_code          VARCHAR2(1) not null,
  curr_code         VARCHAR2(3),
  disc_per          NUMBER(5,2),
  first_sale_date   DATE,
  last_sale_date    DATE,
  rule_no           VARCHAR2(13) not null,
  create_date       DATE not null,
  create_by         VARCHAR2(20) not null,
  last_update_date  DATE not null,
  last_update_by    VARCHAR2(20) not null,
  service_class     VARCHAR2(1),
  fare              NUMBER(12,3),
  flag              VARCHAR2(1),
  attribute1        VARCHAR2(20),
  attribute2        VARCHAR2(20),
  routeflag         VARCHAR2(1),
  rule_id_no        VARCHAR2(20),
  cs_activate_date  DATE,
  cs_source_fare_pk VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 144M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.DFIM_T_PSFPO_INDX1 on FCIMS.DFIM_T_PSFPO (ORG_CITY, DES_CITY, CARR_CODE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 27M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_DFIM_T_PSFPO_IDX1 on FCIMS.DFIM_T_PSFPO (ORG_STN, DES_STN, EFF_DATE, DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 49M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PSFPO
  add constraint DFIM_PK_T_PSFPO primary key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 38M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PSFPO
  add unique (RULE_ID_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_PSFPO
  add constraint DFIM_FK_T_PSFPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.DFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table DFIM_T_PSFPO_1
prompt =============================
prompt
create table FCIMS.DFIM_T_PSFPO_1
(
  fare_no          NUMBER(38) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  carr_code        VARCHAR2(5) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  cls_code         VARCHAR2(1) not null,
  curr_code        VARCHAR2(3),
  disc_per         NUMBER(5,2),
  first_sale_date  DATE,
  last_sale_date   DATE,
  rule_no          VARCHAR2(4) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  service_class    VARCHAR2(1),
  fare             NUMBER(12,3),
  flag             VARCHAR2(1),
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(10),
  routeflag        VARCHAR2(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PSFPO_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PSFPO_TRACE
(
  fare_no          NUMBER not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  carr_code        VARCHAR2(5) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  cls_code         VARCHAR2(1) not null,
  curr_code        VARCHAR2(3),
  disc_per         NUMBER(5,2),
  first_sale_date  DATE,
  last_sale_date   DATE,
  rule_no          VARCHAR2(4) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  service_class    VARCHAR2(1),
  fare             NUMBER(12,3),
  flag             VARCHAR2(1),
  attribute2       VARCHAR2(20),
  operation        VARCHAR2(10) not null,
  routeflag        VARCHAR2(1),
  attribute1       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 488M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PSFPP_1
prompt =============================
prompt
create table FCIMS.DFIM_T_PSFPP_1
(
  fare_no          NUMBER(38) not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  carr_code        VARCHAR2(5) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  cls_code         VARCHAR2(1) not null,
  curr_code        VARCHAR2(3),
  disc_per         NUMBER(5,2),
  first_sale_date  DATE,
  last_sale_date   DATE,
  rule_no          VARCHAR2(4) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  service_class    VARCHAR2(1),
  fare             NUMBER(12,3),
  flag             VARCHAR2(1),
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(10),
  routeflag        VARCHAR2(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_PSFPP_TRACE
prompt =================================
prompt
create table FCIMS.DFIM_T_PSFPP_TRACE
(
  fare_no          NUMBER not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(5) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  carr_code        VARCHAR2(5) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2),
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  cls_code         VARCHAR2(1) not null,
  curr_code        VARCHAR2(3),
  disc_per         NUMBER(5,2),
  first_sale_date  DATE,
  last_sale_date   DATE,
  rule_no          VARCHAR2(4) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  service_class    VARCHAR2(1),
  fare             NUMBER(12,3),
  flag             VARCHAR2(1),
  attribute2       VARCHAR2(20),
  attribute1       VARCHAR2(20),
  operation        VARCHAR2(10) not null,
  routeflag        VARCHAR2(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 248M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_ROUTESET
prompt ==============================
prompt
create table FCIMS.DFIM_T_ROUTESET
(
  org_stn          VARCHAR2(5) not null,
  org_city         VARCHAR2(5),
  org_flg          CHAR(1),
  des_stn          VARCHAR2(5) not null,
  des_city         VARCHAR2(5),
  des_flg          CHAR(1),
  travel_type      VARCHAR2(2) not null,
  routetype        NUMBER(1) not null,
  carr_code        VARCHAR2(5) not null,
  routecol_no      VARCHAR2(50) not null,
  routing_no       NUMBER(12) not null,
  routing_string   VARCHAR2(1000),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_ROUTESET
  add constraint DFIM_PK_T_ROUTESET primary key (CARR_CODE, ROUTECOL_NO, ROUTING_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_ROUTESET
  add constraint FK_DFIM_T_ROUTESET foreign key (ROUTING_NO, CARR_CODE)
  references FCIMS.DFIM_T_ROUT (ROUTING_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table DFIM_T_RTMP
prompt ==========================
prompt
create table FCIMS.DFIM_T_RTMP
(
  routing_map_no     NUMBER(9) not null,
  carr_code          VARCHAR2(5) not null,
  routing_map_string VARCHAR2(2000),
  create_date        DATE not null,
  create_by          VARCHAR2(20) not null,
  last_update_date   DATE not null,
  last_update_by     VARCHAR2(20) not null,
  attribute1         VARCHAR2(20),
  attribute2         VARCHAR2(20),
  attribute3         VARCHAR2(20),
  attribute4         VARCHAR2(20),
  attribute5         VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_RTMP
  add constraint FCIMS_PK_DFIM_RTMP primary key (ROUTING_MAP_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_RULE
prompt ==========================
prompt
create table FCIMS.DFIM_T_RULE
(
  rule_id          VARCHAR2(4) not null,
  carr_code        VARCHAR2(5) not null,
  lock_flag        VARCHAR2(6) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_RULE
  add constraint FIMS_PK_T_RULE primary key (RULE_ID, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_RULE_CATEGORY
prompt ===================================
prompt
create table FCIMS.DFIM_T_RULE_CATEGORY
(
  rule_id          VARCHAR2(4) not null,
  carr_code        VARCHAR2(5) not null,
  category_type    VARCHAR2(30) not null,
  category_id      NUMBER(7) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DFIM_T_RULE_CATEGORY
  add constraint FIMS_PK_T_RULE_CATEGORY primary key (RULE_ID, CARR_CODE, CATEGORY_TYPE, CATEGORY_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DFIM_T_SEG
prompt =========================
prompt
create table FCIMS.DFIM_T_SEG
(
  carr_code VARCHAR2(5) not null,
  org_stn   VARCHAR2(5) not null,
  des_stn   VARCHAR2(5) not null,
  curr_date DATE default SYSDATE,
  flag      NUMBER(1) default 0
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 19M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DISCONTINUE_DATE
prompt ===============================
prompt
create table FCIMS.DISCONTINUE_DATE
(
  carrier_code        VARCHAR2(5),
  location_code       VARCHAR2(6),
  ref_no              VARCHAR2(15),
  fare_rec_no         NUMBER(5),
  sub_fare_rec_no     NUMBER(5),
  fare_by_rule_id     VARCHAR2(30),
  fare_by_rule_dtl_id VARCHAR2(30),
  discontinue_date    VARCHAR2(20),
  last_ticket_date    VARCHAR2(20),
  when_last_date      VARCHAR2(20),
  flag                NUMBER(1),
  status              NUMBER(1),
  gds_process_time    VARCHAR2(25),
  cache_process_time  DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DOMESTIC_SHOPPING_USER_CONFIG
prompt ============================================
prompt
create table FCIMS.DOMESTIC_SHOPPING_USER_CONFIG
(
  office                VARCHAR2(10) not null,
  channel_id            VARCHAR2(10) not null,
  multi_office_no       NUMBER(10),
  rt_ts_lowest_all      VARCHAR2(6),
  is_unavailclass       VARCHAR2(20),
  is_multi_segment      VARCHAR2(6),
  is_calendar           VARCHAR2(6),
  is_free_trip          VARCHAR2(6),
  city_or_airport       NUMBER(3),
  max_journeys          NUMBER(3),
  cabin_upsell_downsell VARCHAR2(6),
  ow_interline_info     VARCHAR2(100),
  rt_interline_info     VARCHAR2(100),
  is_return_av          VARCHAR2(6),
  effective_date        DATE,
  discontinue_date      DATE,
  last_update_date      DATE,
  source_system         VARCHAR2(10) not null,
  channel_type          VARCHAR2(10) not null,
  virtual_office        VARCHAR2(10),
  av_type               VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.DOMESTIC_SHOPPING_USER_CONFIG
  add constraint PK_DOM_SHOP_USER_CONFIG primary key (OFFICE, CHANNEL_ID, SOURCE_SYSTEM, CHANNEL_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BY_RULE_DTL
prompt ===============================
prompt
create table FCIMS.FARE_BY_RULE_DTL
(
  location_code                 VARCHAR2(5) not null,
  fare_by_rule_id               VARCHAR2(30) not null,
  carr_code                     VARCHAR2(5) not null,
  fare_by_rule_dtl_id           VARCHAR2(30) not null,
  account_code                  VARCHAR2(10),
  fbr_dtl_prior                 NUMBER(5),
  sale_eff_date                 DATE not null,
  sale_disc_date                DATE,
  first_travel_date             DATE not null,
  last_travel_date              DATE,
  ori_code_type                 NUMBER(1),
  ori_code                      VARCHAR2(13),
  dest_code_type                NUMBER(1),
  dest_code                     VARCHAR2(13),
  journey_type                  VARCHAR2(3),
  booking_class                 VARCHAR2(26),
  basefare_type                 NUMBER(1),
  price_choose                  NUMBER(1),
  rule_no                       VARCHAR2(13),
  rule_location_code            VARCHAR2(5),
  if_same_basefare_rule         NUMBER(1),
  if_only_direct_fare           NUMBER(1),
  if_same_basefare_group        NUMBER(1),
  if_use_other_rule_restriction NUMBER(1),
  outbound_permitted            NUMBER(1),
  inbound_permitted             NUMBER(1),
  minimum_stay                  NUMBER(3),
  minimum_stay_unit             VARCHAR2(6),
  maximum_stay                  NUMBER(3),
  maximum_stay_unit             VARCHAR2(6),
  rstf_caculate_type            NUMBER(1),
  rstf_amt                      NUMBER(5),
  rstf_currency_code            VARCHAR2(5),
  rstf_percent                  NUMBER(3),
  round_rule                    NUMBER(1),
  rstf_display_if_same_basefare NUMBER(1),
  rstf_display_fare_basis       VARCHAR2(15),
  rstf_display_adt_cmn_amt      NUMBER(8),
  rstf_display_base_cmn_amt     NUMBER(8),
  rstf_display_adt_cmn_pct      NUMBER(3),
  rstf_display_base_cmn_pct     NUMBER(3),
  rstf_display_tourcode         VARCHAR2(14),
  rstf_display_endorsment       VARCHAR2(510),
  distribution_status           NUMBER(1),
  distribution_date             DATE,
  baggage_allowance             NUMBER(2),
  baggage_unit                  NUMBER(1),
  who_last_update               VARCHAR2(20),
  where_last_update             VARCHAR2(5),
  when_last_update              DATE
)
tablespace TA_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FARE_BY_RULE_DTL
  add constraint FARE_BY_RULE_DTL_TA_UX1 primary key (LOCATION_CODE, FARE_BY_RULE_ID, CARR_CODE, FARE_BY_RULE_DTL_ID)
  using index 
  tablespace TA_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FCIMS_CITY
prompt =========================
prompt
create table FCIMS.FCIMS_CITY
(
  record_format_version  NUMBER(2),
  issue_date             DATE,
  gfs_id                 VARCHAR2(8),
  prod_id                VARCHAR2(8),
  data_ind               VARCHAR2(1),
  city_code              VARCHAR2(5) not null,
  state                  VARCHAR2(2),
  country_code           VARCHAR2(2) not null,
  zone_code              VARCHAR2(3) not null,
  international_city_ind VARCHAR2(1),
  spare1                 VARCHAR2(1),
  us_territory_ind       VARCHAR2(1) default 'N' not null,
  spare2                 VARCHAR2(1),
  spare3                 VARCHAR2(1),
  spare4                 VARCHAR2(1),
  spare5                 VARCHAR2(1),
  spare6                 VARCHAR2(1),
  alaska_tax_zone        VARCHAR2(1),
  spare7                 VARCHAR2(1),
  timezone_sign          VARCHAR2(1),
  timezone               NUMBER(2),
  gtrtn                  VARCHAR2(1),
  city_ind               VARCHAR2(1) not null,
  latitude_deg           NUMBER(2),
  latitude_min           NUMBER(2),
  latitude_sec           NUMBER(2),
  latitude_type          VARCHAR2(1),
  longitude_deg          NUMBER(3),
  longitude_min          NUMBER(2),
  longitude_sec          NUMBER(2),
  longitude_type         VARCHAR2(1),
  spare8                 VARCHAR2(1),
  bu_tax_ind             VARCHAR2(1) default 'N' not null,
  spare9                 VARCHAR2(4),
  name                   VARCHAR2(40),
  city_name              VARCHAR2(17),
  cancel                 VARCHAR2(1),
  last_update_user       VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date       DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table FCIMS.FCIMS_CITY
  is '�������С���������Ӧ������Ϣ������ʱ';
comment on column FCIMS.FCIMS_CITY.data_ind
  is '''x'' = invalid data';
comment on column FCIMS.FCIMS_CITY.international_city_ind
  is 'Y=Yes; N=No';
comment on column FCIMS.FCIMS_CITY.spare1
  is 'Y=Yes; N=No';
comment on column FCIMS.FCIMS_CITY.us_territory_ind
  is 'Y=Yes; N=No';
comment on column FCIMS.FCIMS_CITY.spare2
  is 'Y=Yes; N=No';
comment on column FCIMS.FCIMS_CITY.spare3
  is 'Y=Yes; N=No';
comment on column FCIMS.FCIMS_CITY.timezone_sign
  is '+/-';
comment on column FCIMS.FCIMS_CITY.timezone
  is '��Сʱ * ���ֶ�ֵ';
comment on column FCIMS.FCIMS_CITY.city_ind
  is 'a = airport, b = airport and city,c=city';
comment on column FCIMS.FCIMS_CITY.latitude_type
  is 'N = North��γ ; S = South��γ';
comment on column FCIMS.FCIMS_CITY.longitude_type
  is 'E = East����;  W=West����';
comment on column FCIMS.FCIMS_CITY.spare8
  is 'Y=Yes; N=No';
alter table FCIMS.FCIMS_CITY
  add constraint PK_CITY primary key (CITY_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FCIMS_ZONE
prompt =========================
prompt
create table FCIMS.FCIMS_ZONE
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  zone_no               VARCHAR2(3) not null,
  zone_desc             VARCHAR2(3) not null,
  zone_include          VARCHAR2(60),
  sub_area              VARCHAR2(30),
  parent_zone_no        VARCHAR2(3),
  cancel                VARCHAR2(1),
  last_update_user      VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date      DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.FCIMS_ZONE.data_ind
  is '''x'' = invalid data';
comment on column FCIMS.FCIMS_ZONE.zone_no
  is '��ţ��������ַ���ʽ���';
comment on column FCIMS.FCIMS_ZONE.zone_desc
  is 'tc1, tc2 or tc3';
comment on column FCIMS.FCIMS_ZONE.zone_include
  is '�����ı�';
alter table FCIMS.FCIMS_ZONE
  add constraint PK_ZONE primary key (ZONE_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FETCHER_CONFIG
prompt =============================
prompt
create table FCIMS.FETCHER_CONFIG
(
  command_type   VARCHAR2(100) not null,
  command_tag    VARCHAR2(50) not null,
  eff_date       DATE not null,
  disc_date      DATE not null,
  service_type   VARCHAR2(10),
  service_addr   VARCHAR2(50),
  service_port   VARCHAR2(10),
  service_name   VARCHAR2(50),
  request_format VARCHAR2(500),
  result_format  VARCHAR2(200),
  attribute1     VARCHAR2(100),
  attribute2     VARCHAR2(100),
  attribute3     VARCHAR2(100),
  data_type      VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_FETCHER_CONFIG_IDX1 on FCIMS.FETCHER_CONFIG (EFF_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FETCHER_TYPE
prompt ===========================
prompt
create table FCIMS.FETCHER_TYPE
(
  request_type NUMBER(2) not null,
  sequence_no  NUMBER(2) not null,
  eff_date     DATE not null,
  disc_date    DATE not null,
  fetcher1     NUMBER(2),
  fetcher2     NUMBER(2),
  fetcher3     NUMBER(2),
  fetcher4     NUMBER(2),
  fetcher5     NUMBER(2),
  fetcher6     NUMBER(2),
  fetcher7     NUMBER(2),
  fetcher8     NUMBER(2),
  fetcher9     NUMBER(2),
  fetcher10    NUMBER(2)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FETCHER_TYPE
  add constraint FETCHER_TYPE_UX1 primary key (REQUEST_TYPE, SEQUENCE_NO, EFF_DATE, DISC_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FHI_ESHOP_USE_MULTI_CARRIERS
prompt ===========================================
prompt
create table FCIMS.FHI_ESHOP_USE_MULTI_CARRIERS
(
  office                VARCHAR2(10) not null,
  channel               VARCHAR2(10) not null,
  system_type           VARCHAR2(5) not null,
  is_use_multi_carriers VARCHAR2(6) not null,
  carriers              VARCHAR2(300) not null,
  description           VARCHAR2(200),
  last_update_date      DATE,
  last_update_by        VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FHI_ESHOP_USE_MULTI_CARRIERS
  add constraint OFFICE_CHANNEL primary key (OFFICE, CHANNEL)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FHI_FETCHER_CONFIG
prompt =================================
prompt
create table FCIMS.FHI_FETCHER_CONFIG
(
  command_type    VARCHAR2(20) not null,
  command_tag     VARCHAR2(50) not null,
  eff_date        DATE not null,
  disc_date       DATE not null,
  service_type    VARCHAR2(10) not null,
  service_addr    VARCHAR2(50),
  service_port    VARCHAR2(10),
  service_name    VARCHAR2(50) not null,
  request_format  VARCHAR2(500) not null,
  result_format   VARCHAR2(200) not null,
  attribute1      VARCHAR2(100),
  attribute2      VARCHAR2(100),
  attribute3      VARCHAR2(100),
  library         VARCHAR2(500),
  pre_command     VARCHAR2(100),
  next_command    VARCHAR2(100),
  data_type       VARCHAR2(20),
  mode_type       VARCHAR2(10) default 'XML',
  result_rootname VARCHAR2(50),
  compress_type   VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_FHI_FETCHER_CONFIG_IDX1 on FCIMS.FHI_FETCHER_CONFIG (EFF_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FHI_FETCHER_CONFIG
  add constraint FCIMS_FHI_FETCHER_CONFIG_UX1 primary key (COMMAND_TYPE, EFF_DATE, DISC_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FHI_FORMAT_CONFIG
prompt ================================
prompt
create table FCIMS.FHI_FORMAT_CONFIG
(
  request_type   VARCHAR2(50) not null,
  input_cmd      VARCHAR2(100) not null,
  output_cmd     VARCHAR2(100) not null,
  fathernode_cmd VARCHAR2(100) not null,
  introduction   VARCHAR2(20) not null,
  region         VARCHAR2(20) not null,
  response_type  VARCHAR2(50)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FHI_FORMAT_CONFIG
  add constraint FCIMS_FHI_FORMAT_CONFIG_UX1 primary key (REQUEST_TYPE, INPUT_CMD, OUTPUT_CMD, FATHERNODE_CMD)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FHI_RAPID_CODE
prompt =============================
prompt
create table FCIMS.FHI_RAPID_CODE
(
  lookup_type      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  lookup_code      VARCHAR2(20) not null,
  description      VARCHAR2(500),
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI'),
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI'),
  last_update_date DATE default sysdate,
  last_update_by   VARCHAR2(20) default '1E'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_FHI_RAPID_CODE_IDX1 on FCIMS.FHI_RAPID_CODE (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FHI_RAPID_CODE
  add constraint FCIMS_FHI_RAPID_CODE_UX1 primary key (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE, SALE_EFF_DATE, TRAVEL_EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FHI_USER_CONFIG
prompt ==============================
prompt
create table FCIMS.FHI_USER_CONFIG
(
  command   VARCHAR2(10),
  carrier   VARCHAR2(5),
  apply_tag VARCHAR2(2),
  system    VARCHAR2(5),
  content   VARCHAR2(1000),
  eff_date  DATE not null,
  disc_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_FHI_USER_CONFIG_INDEX1 on FCIMS.FHI_USER_CONFIG (COMMAND, EFF_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_3UDISCOUNT
prompt ================================
prompt
create table FCIMS.FPUB_T_3UDISCOUNT
(
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  cls_code         VARCHAR2(26) not null,
  flight_no        VARCHAR2(100) not null,
  discount         VARCHAR2(2) not null,
  eff_date         DATE not null,
  disc_date        DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  create_date      DATE default sysdate not null,
  create_by        VARCHAR2(20) default '1E' not null,
  last_update_date DATE default sysdate,
  last_update_by   VARCHAR2(20) default '1E',
  org_stn_type     NUMBER(1) not null,
  des_stn_type     NUMBER(1) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 384K
    minextents 1
    maxextents unlimited
  );
create unique index FCIMS.FPUB_PK_T_3UTEST on FCIMS.FPUB_T_3UDISCOUNT (ORG_STN, DES_STN, CLS_CODE, FLIGHT_NO, EFF_DATE, DISC_DATE, SALE_EFF_DATE, SALE_DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 384K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_3UDISCOUNT
  add constraint FPUB_PK_T_3UDISCOUNT primary key (ORG_STN, DES_STN, CLS_CODE, FLIGHT_NO, EFF_DATE, SALE_EFF_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_CARGOCODE
prompt ===============================
prompt
create table FCIMS.FPUB_T_CARGOCODE
(
  seq_num          NUMBER(8) not null,
  first_level      VARCHAR2(20) not null,
  second_level     VARCHAR2(20),
  third_level      VARCHAR2(20),
  des_cn           VARCHAR2(4000) not null,
  des_en           VARCHAR2(4000),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_CARGOCODE
  add constraint FPUB_PK_T_CARGOCODE primary key (SEQ_NUM)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_CLASS_TEMPLATE
prompt ====================================
prompt
create table FCIMS.FPUB_T_CLASS_TEMPLATE
(
  template_name    VARCHAR2(50) not null,
  carr_code        VARCHAR2(5) not null,
  class_code       VARCHAR2(3) not null,
  description      VARCHAR2(50),
  create_date      DATE,
  create_by        VARCHAR2(20),
  last_update_date DATE,
  last_update_by   VARCHAR2(20),
  disc_per         NUMBER(5,2),
  service_class    VARCHAR2(1),
  fare_basis       VARCHAR2(15),
  rule_no          VARCHAR2(13)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_CLASS_TEMPLATE
  add constraint PK_CLASS_TEMPLATE primary key (TEMPLATE_NAME, CARR_CODE, CLASS_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_CODE_SHARE_PARAM
prompt ======================================
prompt
create table FCIMS.FPUB_T_CODE_SHARE_PARAM
(
  carr_code        VARCHAR2(10) not null,
  key              VARCHAR2(100) not null,
  value            VARCHAR2(20),
  type             VARCHAR2(20) not null,
  create_by        VARCHAR2(20),
  create_time      DATE,
  last_update_by   VARCHAR2(20),
  last_update_date DATE,
  fare_basis       VARCHAR2(15)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_CODE_SHARE_PARAM
  add constraint PK_T_CODE_SHARE_PARAM_NEW primary key (CARR_CODE, TYPE, KEY)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_EQUIPMENTTYPEFORTAX
prompt =========================================
prompt
create table FCIMS.FPUB_T_EQUIPMENTTYPEFORTAX
(
  equipment_type   VARCHAR2(20) not null,
  description      VARCHAR2(50),
  tax              NUMBER(8,2),
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20),
  sales_eff_date   DATE default TO_DATE('1900-01-01', 'YYYY-MM-DD') not null,
  sales_disc_date  DATE default TO_DATE('2222-01-01', 'YYYY-MM-DD'),
  travel_eff_date  DATE default TO_DATE('1900-01-01', 'YYYY-MM-DD') not null,
  travel_disc_date DATE default TO_DATE('2222-01-01', 'YYYY-MM-DD')
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 384K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_EQUIPMENTTYPEFORTAX
  add constraint FPUB_PK_T_EQUIPMENTTYPEFORTAX primary key (EQUIPMENT_TYPE, SALES_EFF_DATE, TRAVEL_EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 344K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FLOATRATE
prompt ===============================
prompt
create table FCIMS.FPUB_T_FLOATRATE
(
  flight_type      VARCHAR2(10) not null,
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  upper_limit      VARCHAR2(3) not null,
  lower_limit      VARCHAR2(3) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(10),
  attribute2       VARCHAR2(10),
  attribute3       VARCHAR2(10),
  attribute4       VARCHAR2(10),
  attribute5       VARCHAR2(10),
  tpm              NUMBER(8) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 4M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FLOATRATE
  add constraint FPUB_PK_T_FLOATRATE primary key (ORG_STN, DES_STN)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FORMULA
prompt =============================
prompt
create table FCIMS.FPUB_T_FORMULA
(
  formula_id          VARCHAR2(10) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  carr_code           VARCHAR2(5),
  attribute1          NUMBER(20,10) default 0,
  attribute2          NUMBER(20,10) default 0,
  attribute3          NUMBER(20,10) default 0,
  attribute4          NUMBER(20,10) default 0,
  attribute5          NUMBER(20,10) default 0,
  attribute6          NUMBER(20,10) default 0,
  attribute7          NUMBER(20,10) default 0,
  attribute8          NUMBER(20,10) default 0,
  attribute9          NUMBER(20,10) default 0,
  attribute10         NUMBER(20,10) default 0,
  attribute11         NUMBER(20,10) default 0,
  attribute12         NUMBER(20,10) default 0,
  attribute13         NUMBER(20,10) default 0,
  attribute14         NUMBER(20,10) default 0,
  attribute15         NUMBER(20,10) default 0,
  formula_discription VARCHAR2(200) default 0,
  formula_formula     VARCHAR2(200)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 10M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FORMULA
  add constraint FIMS_PK_T_FORMULA primary key (FORMULA_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FORMULA_20070510
prompt ======================================
prompt
create table FCIMS.FPUB_T_FORMULA_20070510
(
  formula_id          VARCHAR2(10) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  carr_code           VARCHAR2(5),
  attribute1          NUMBER(20,10),
  attribute2          NUMBER(20,10),
  attribute3          NUMBER(20,10),
  attribute4          NUMBER(20,10),
  attribute5          NUMBER(20,10),
  attribute6          NUMBER(20,10),
  attribute7          NUMBER(20,10),
  attribute8          NUMBER(20,10),
  attribute9          NUMBER(20,10),
  attribute10         NUMBER(20,10),
  attribute11         NUMBER(20,10),
  attribute12         NUMBER(20,10),
  attribute13         NUMBER(20,10),
  attribute14         NUMBER(20,10),
  attribute15         NUMBER(20,10),
  formula_discription VARCHAR2(200),
  formula_formula     VARCHAR2(200)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FUELTAX
prompt =============================
prompt
create table FCIMS.FPUB_T_FUELTAX
(
  upper_tpm        NUMBER(12) not null,
  lower_tpm        NUMBER(12) not null,
  tax              NUMBER(5,2) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  eff_date         DATE not null,
  disc_date        DATE not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE not null,
  passenger_type   VARCHAR2(20) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FUELTAX
  add constraint FPUB_PK_T_FUELTAX primary key (UPPER_TPM, LOWER_TPM, EFF_DATE, DISC_DATE, SALE_EFF_DATE, SALE_DISC_DATE, PASSENGER_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FUELTAX_20071104
prompt ======================================
prompt
create table FCIMS.FPUB_T_FUELTAX_20071104
(
  upper_tpm        NUMBER(12) not null,
  lower_tpm        NUMBER(12) not null,
  tax              NUMBER(5,2) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  eff_date         DATE not null,
  disc_date        DATE not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE not null,
  passenger_type   VARCHAR2(20) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FUELTAX_O
prompt ===============================
prompt
create table FCIMS.FPUB_T_FUELTAX_O
(
  org_stn          VARCHAR2(3) not null,
  org_type         VARCHAR2(1) not null,
  org_city         VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  des_type         VARCHAR2(1) not null,
  des_city         VARCHAR2(3) not null,
  carrier_code     VARCHAR2(2) not null,
  amount           NUMBER(11,2) not null,
  sales_eff_date   DATE not null,
  sales_disc_date  DATE not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE,
  create_date      DATE,
  last_update_date DATE,
  create_by        VARCHAR2(20) not null,
  update_by        VARCHAR2(20) not null,
  key              VARCHAR2(30) not null,
  status           VARCHAR2(1),
  tpm              NUMBER(10) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FUELTAX_O
  add constraint PK_T_FUELTAX_O primary key (ORG_STN, DES_STN, CARRIER_CODE, SALES_EFF_DATE, TRAVEL_EFF_DATE, KEY)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FUELTAX_P
prompt ===============================
prompt
create table FCIMS.FPUB_T_FUELTAX_P
(
  org_stn          VARCHAR2(3) not null,
  org_type         VARCHAR2(1) not null,
  org_city         VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  des_type         VARCHAR2(1) not null,
  des_city         VARCHAR2(3) not null,
  carrier_code     VARCHAR2(2) not null,
  amount           NUMBER(11,2) not null,
  sales_eff_date   DATE not null,
  sales_disc_date  DATE not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE,
  create_date      DATE,
  last_update_date DATE,
  create_by        VARCHAR2(20) not null,
  update_by        VARCHAR2(20) not null,
  key              VARCHAR2(30) not null,
  status           VARCHAR2(1),
  tpm              NUMBER(10) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FUELTAX_P
  add constraint PK_T_FUELTAX_P primary key (ORG_STN, DES_STN, CARRIER_CODE, SALES_EFF_DATE, TRAVEL_EFF_DATE, KEY)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_FUELTAX_PARAMS
prompt ====================================
prompt
create table FCIMS.FPUB_T_FUELTAX_PARAMS
(
  param1           NUMBER(9,8) not null,
  param2           NUMBER(10,2) not null,
  attribute1       INTEGER,
  attribute2       INTEGER,
  attribute3       INTEGER,
  attribute4       INTEGER,
  attribute5       INTEGER,
  upper_limit      NUMBER(11,2) not null,
  lower_limit      NUMBER(11,2) not null,
  effective_date   DATE not null,
  disc_date        DATE not null,
  amount           NUMBER(11,2) not null,
  key              NUMBER(30),
  create_date      DATE,
  last_update_date DATE,
  create_by        VARCHAR2(20),
  update_by        VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FPUB_T_FUELTAX_PARAMS_INDEX1 on FCIMS.FPUB_T_FUELTAX_PARAMS (UPPER_LIMIT, LOWER_LIMIT, EFFECTIVE_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_FUELTAX_PARAMS
  add primary key (PARAM1, PARAM2, UPPER_LIMIT, LOWER_LIMIT, EFFECTIVE_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_GEN_DISCOUNT
prompt ==================================
prompt
create table FCIMS.FPUB_T_GEN_DISCOUNT
(
  rec_no             NUMBER(15) not null,
  carr_code          VARCHAR2(5) not null,
  flight_type        NUMBER(1) not null,
  org_stn            VARCHAR2(5) not null,
  org_stn_type       NUMBER(1) not null,
  des_stn            VARCHAR2(5) not null,
  des_stn_type       NUMBER(1) not null,
  outbound_flight_no VARCHAR2(100) not null,
  outbound_cls_code  VARCHAR2(30) not null,
  inbound_flight_no  VARCHAR2(100),
  inbound_cls_code   VARCHAR2(30),
  discount           NUMBER(2) not null,
  sale_eff_date      DATE not null,
  sale_disc_date     DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date    DATE not null,
  travel_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by     VARCHAR2(20) not null,
  last_update_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_GEN_DISCOUNT
  add constraint FPUB_PK_T_GEN_DISCOUNT primary key (REC_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_HUDISCOUNT
prompt ================================
prompt
create table FCIMS.FPUB_T_HUDISCOUNT
(
  fare_basis            VARCHAR2(15) not null,
  ori_code              VARCHAR2(5) not null,
  first_flight_no       VARCHAR2(100) not null,
  interline_code        VARCHAR2(5),
  second_flight_no      VARCHAR2(100) not null,
  dest_code             VARCHAR2(5) not null,
  base_discount         NUMBER(3) not null,
  third_sector_discount NUMBER(3),
  nonstop_discount      NUMBER(3),
  warning_addition      NUMBER(4),
  sale_eff_date         DATE not null,
  sale_disc_date        DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date       DATE not null,
  travel_disc_date      DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  create_by             VARCHAR2(20) default '1E' not null,
  create_date           DATE default sysdate not null,
  last_update_by        VARCHAR2(20) default '1E' not null,
  last_update_date      DATE default sysdate not null,
  rec_no                NUMBER(15) not null,
  ori_code_type         NUMBER(1) not null,
  dest_code_type        NUMBER(1) not null,
  interline_code_type   NUMBER(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FPUB_T_HUDISCOUNT_INDEX on FCIMS.FPUB_T_HUDISCOUNT (FARE_BASIS, ORI_CODE, FIRST_FLIGHT_NO, SECOND_FLIGHT_NO, DEST_CODE, SALE_EFF_DATE, SALE_DISC_DATE, TRAVEL_EFF_DATE, TRAVEL_DISC_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 56K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_HUDISCOUNT
  add constraint FIMS_PK_T_HUDISCOUNT primary key (REC_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_IMPORT_CONTROL
prompt ====================================
prompt
create table FCIMS.FPUB_T_IMPORT_CONTROL
(
  row_id      NUMBER not null,
  user_id     VARCHAR2(20) not null,
  path        VARCHAR2(100) not null,
  file_name   VARCHAR2(50) not null,
  type        VARCHAR2(20) not null,
  flag        VARCHAR2(10) not null,
  create_date DATE not null,
  update_date DATE not null,
  attribute1  VARCHAR2(20),
  attribute2  VARCHAR2(20),
  attribute3  VARCHAR2(20),
  attribute4  VARCHAR2(20),
  attribute5  VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 320K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_IMPORT_CONTROL
  add constraint PK_FPUB_T_IMPORT_CONTROL primary key (ROW_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 320K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_IMPORTERR_CONTROL
prompt =======================================
prompt
create table FCIMS.FPUB_T_IMPORTERR_CONTROL
(
  row_id        NUMBER not null,
  source_row_id NUMBER not null,
  user_id       VARCHAR2(20) not null,
  path          VARCHAR2(100) not null,
  file_name     VARCHAR2(50) not null,
  type          VARCHAR2(20) not null,
  flag          VARCHAR2(10) not null,
  create_date   DATE not null,
  update_date   DATE not null,
  attribute1    VARCHAR2(20),
  attribute2    VARCHAR2(20),
  attribute3    VARCHAR2(20),
  attribute4    VARCHAR2(20),
  attribute5    VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 320K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_IMPORTERR_CONTROL
  add constraint PK_FPUB_T_IMPORTERR_CONTROL primary key (ROW_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 320K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_IMPORTERR_CONTROL
  add constraint FK_FPUB_T_IMPORTERR_CONTROL foreign key (SOURCE_ROW_ID)
  references FCIMS.FPUB_T_IMPORT_CONTROL (ROW_ID) on delete cascade;

prompt
prompt Creating table FPUB_T_INFORMATIONMANAGER
prompt ========================================
prompt
create table FCIMS.FPUB_T_INFORMATIONMANAGER
(
  root_no          VARCHAR2(48) not null,
  my_no            VARCHAR2(40) not null,
  son_maxno        NUMBER(8),
  lb_no            NUMBER(2) not null,
  lb_desc          VARCHAR2(100),
  zw_title         VARCHAR2(200),
  zw_content       VARCHAR2(4000),
  fj_title         VARCHAR2(200),
  fj_content       VARCHAR2(4000),
  fj_name          VARCHAR2(200),
  dot              NUMBER(8),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_INFORMATIONMANAGER
  add constraint FPUB_PK_T_INFORMATIONMANAGER primary key (ROOT_NO, MY_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_INFO_ROOT_RELATION
prompt ========================================
prompt
create table FCIMS.FPUB_T_INFO_ROOT_RELATION
(
  relation_root_no NUMBER(8) not null,
  relation_my_no   VARCHAR2(40) not null,
  son_maxno        NUMBER(8),
  lb_no            NUMBER(2) not null,
  lb_desc          VARCHAR2(100),
  zw_title         VARCHAR2(200),
  dot              NUMBER(8),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_INFO_ROOT_RELATION
  add constraint FPUB_PK_T_INFO_ROOT_RELATION primary key (RELATION_ROOT_NO, RELATION_MY_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_LINFO
prompt ===========================
prompt
create table FCIMS.FPUB_T_LINFO
(
  lookup_type      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  description      VARCHAR2(50),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_LINFO
  add constraint FIMS_PK_T_LINFO primary key (LOOKUP_TYPE, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_LDTAL
prompt ===========================
prompt
create table FCIMS.FPUB_T_LDTAL
(
  lookup_type      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  lookup_code      VARCHAR2(20) not null,
  description      VARCHAR2(50),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  attribute6       VARCHAR2(100),
  attribute7       VARCHAR2(100),
  attribute8       VARCHAR2(100),
  attribute9       VARCHAR2(100),
  attribute10      VARCHAR2(200),
  attribute11      VARCHAR2(100),
  attribute12      VARCHAR2(100),
  attribute13      VARCHAR2(100),
  attribute14      VARCHAR2(100),
  attribute15      VARCHAR2(100),
  attribute16      VARCHAR2(100),
  attribute17      VARCHAR2(100),
  attribute18      VARCHAR2(100),
  attribute19      VARCHAR2(100),
  attribute20      VARCHAR2(100),
  model_name       VARCHAR2(30)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FIMS_PK_T_LDTIL on FCIMS.FPUB_T_LDTAL (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_LDTAL
  add constraint FIMS_FK_LOOKUP_TYPE_LOOKUP_DTL foreign key (LOOKUP_TYPE, CARR_CODE)
  references FCIMS.FPUB_T_LINFO (LOOKUP_TYPE, CARR_CODE) on delete cascade
  disable
  novalidate;

prompt
prompt Creating table FPUB_T_MODEL
prompt ===========================
prompt
create table FCIMS.FPUB_T_MODEL
(
  model_name       VARCHAR2(30) not null,
  create_by        VARCHAR2(30) not null,
  last_update_date DATE default sysdate,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  attribute6       VARCHAR2(100),
  attribute7       VARCHAR2(100),
  attribute8       VARCHAR2(100),
  attribute9       VARCHAR2(100),
  attribute10      VARCHAR2(100)
)
tablespace FCIMS_IDX
  pctfree 20
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_MODEL
  add constraint FPUB_T_MODEL_PK primary key (MODEL_NAME)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_MULTISECTOR
prompt =================================
prompt
create table FCIMS.FPUB_T_MULTISECTOR
(
  rec_no           NUMBER(15) not null,
  carr_code        VARCHAR2(5) not null,
  endorsement      VARCHAR2(255) not null,
  first_flight_no  VARCHAR2(100) not null,
  first_cls_code   VARCHAR2(26) not null,
  discount         NUMBER(3) not null,
  float_discount   NUMBER(4,2) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_MULTISECTOR
  add constraint FPUB_PK_T_MULTISECTOR primary key (REC_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_NAVI_RIGHTS
prompt =================================
prompt
create table FCIMS.FPUB_T_NAVI_RIGHTS
(
  ori_code         VARCHAR2(5) not null,
  dest_code        VARCHAR2(5) not null,
  carrier          VARCHAR2(5) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  seq_num          NUMBER(8) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_NAVI_RIGHTS
  add constraint FPUB_PK_T_NAVI_RIGHTS primary key (SEQ_NUM)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 704K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_PARAMETER
prompt ===============================
prompt
create table FCIMS.FPUB_T_PARAMETER
(
  parameter_id     VARCHAR2(10) not null,
  eff_date         DATE default TO_DATE('1900-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  disc_date        DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  parameter1       VARCHAR2(10),
  parameter2       VARCHAR2(10),
  parameter3       VARCHAR2(10),
  parameter4       VARCHAR2(10),
  parameter5       VARCHAR2(10),
  attribute1       NUMBER(20,10),
  attribute2       NUMBER(20,10),
  attribute3       NUMBER(20,10),
  attribute4       NUMBER(20,10),
  attribute5       NUMBER(20,10),
  attribute6       NUMBER(20,10),
  attribute7       NUMBER(20,10),
  attribute8       NUMBER(20,10),
  attribute9       NUMBER(20,10),
  attribute10      NUMBER(20,10),
  attribute11      NUMBER(20,10),
  attribute12      NUMBER(20,10),
  attribute13      NUMBER(20,10),
  attribute14      NUMBER(20,10),
  attribute15      NUMBER(20,10),
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  update_date      DATE default sysdate,
  update_man       VARCHAR2(20) default '1E',
  parameter1_type  NUMBER(1) not null,
  z_value          NUMBER(3),
  tour_code        VARCHAR2(15),
  parameter2_type  NUMBER(1),
  id               NUMBER(20) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 448K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FPUB_T_PARAMETER_INDEX on FCIMS.FPUB_T_PARAMETER (PARAMETER1, SALE_EFF_DATE, TRAVEL_EFF_DATE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_PARAMETER
  add constraint FPUB_T_PARAMETER_PK primary key (ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_PARAMETER_TCZ
prompt ===================================
prompt
create table FCIMS.FPUB_T_PARAMETER_TCZ
(
  parameter_id     VARCHAR2(10) not null,
  eff_date         DATE default TO_DATE('1900-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  disc_date        DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  parameter1       VARCHAR2(10) not null,
  parameter2       VARCHAR2(10),
  parameter3       VARCHAR2(10),
  parameter4       VARCHAR2(10),
  parameter5       VARCHAR2(10),
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  update_date      DATE default sysdate,
  update_man       VARCHAR2(20) default '1E',
  parameter1_type  NUMBER(1) not null,
  z_value          NUMBER(3),
  tour_code        VARCHAR2(15),
  parameter2_type  NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_ROUNDTRIP
prompt ===============================
prompt
create table FCIMS.FPUB_T_ROUNDTRIP
(
  rec_no             NUMBER(15) not null,
  carr_code          VARCHAR2(5) not null,
  endorsement        VARCHAR2(255) not null,
  org_stn            VARCHAR2(5) not null,
  org_stn_type       NUMBER(1) not null,
  des_stn            VARCHAR2(5) not null,
  des_stn_type       NUMBER(1) not null,
  outbound_flight_no VARCHAR2(100) not null,
  outbound_cls_code  VARCHAR2(26) not null,
  outbound_discount  NUMBER(3) not null,
  inbound_flight_no  VARCHAR2(100) not null,
  inbound_cls_code   VARCHAR2(26) not null,
  inbound_discount   NUMBER(3) not null,
  sale_eff_date      DATE not null,
  sale_disc_date     DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date    DATE not null,
  travel_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by     VARCHAR2(20) not null,
  last_update_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_ROUNDTRIP
  add constraint FPUB_PK_T_ROUNDTRIP primary key (REC_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_ROUTERIGHT
prompt ================================
prompt
create table FCIMS.FPUB_T_ROUTERIGHT
(
  route_no         NUMBER,
  route_descrption VARCHAR2(100),
  carr_code        VARCHAR2(3),
  org_stn          VARCHAR2(8),
  des_stn          VARCHAR2(8)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 384K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_RPTFILENO_REFNO
prompt =====================================
prompt
create table FCIMS.FPUB_T_RPTFILENO_REFNO
(
  rpt_file_no      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  ref_no           VARCHAR2(15) not null,
  who_last_update  VARCHAR2(20),
  when_last_update DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_RULE_I18N
prompt ===============================
prompt
create table FCIMS.FPUB_T_RULE_I18N
(
  carr_code      VARCHAR2(300) not null,
  md5            VARCHAR2(32) not null,
  id             NUMBER(6) not null,
  type           VARCHAR2(20) not null,
  all_status     VARCHAR2(150) not null,
  en_content     CLOB not null,
  sim_en_content CLOB,
  create_by      VARCHAR2(20) not null,
  create_time    DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_RULE_I18N
  add constraint PK_FPUB_T_RULE_I18N primary key (MD5)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_RULE_I18N_DETAIL
prompt ======================================
prompt
create table FCIMS.FPUB_T_RULE_I18N_DETAIL
(
  md5              VARCHAR2(32) not null,
  status           VARCHAR2(1) not null,
  language_type    VARCHAR2(3) not null,
  content          CLOB,
  sim_content      CLOB,
  first_trans_by   VARCHAR2(20),
  first_trans_time DATE,
  first_apprv_by   VARCHAR2(20),
  first_apprv_time DATE,
  last_update_by   VARCHAR2(20),
  last_update_date DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_RULE_I18N_DETAIL
  add constraint PK_FPUB_T_RULE_I18N_DETAIL primary key (MD5, LANGUAGE_TYPE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_SHIELDSECTOR
prompt ==================================
prompt
create table FCIMS.FPUB_T_SHIELDSECTOR
(
  rec_no           NUMBER(15) not null,
  carr_code        VARCHAR2(5) not null,
  org_stn          VARCHAR2(5) not null,
  org_stn_type     NUMBER(1) not null,
  des_stn          VARCHAR2(5) not null,
  des_stn_type     NUMBER(1) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_SHIELDSECTOR
  add constraint FPUB_PK_SHIELDSECTOR primary key (REC_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_SINGLESECTOR
prompt ==================================
prompt
create table FCIMS.FPUB_T_SINGLESECTOR
(
  rec_no                     NUMBER(15) not null,
  carr_code                  VARCHAR2(5) not null,
  endorsement                VARCHAR2(255) not null,
  first_flight_no            VARCHAR2(100) not null,
  discount                   NUMBER(3) not null,
  advance_purchase           NUMBER(3) not null,
  sale_eff_date              DATE default sysdate not null,
  sale_disc_date             DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date            DATE not null,
  travel_disc_date           DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by             VARCHAR2(20) not null,
  last_update_date           DATE not null,
  max_advanced_purchase      NUMBER(3),
  max_advanced_purchase_unit VARCHAR2(5) default 'Days',
  min_advanced_purchase_unit VARCHAR2(5) default 'Days',
  travel_complete_days_restr NUMBER(3)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_SINGLESECTOR
  add constraint FPUB_PK_T_SINGLESECTOR primary key (REC_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_SK
prompt ========================
prompt
create table FCIMS.FPUB_T_SK
(
  carr_code VARCHAR2(3) not null,
  org_stn   VARCHAR2(3) not null,
  des_stn   VARCHAR2(3) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_STOPOVER_DISCOUNT
prompt =======================================
prompt
create table FCIMS.FPUB_T_STOPOVER_DISCOUNT
(
  carr_code        VARCHAR2(5) not null,
  lookup_code      VARCHAR2(20) not null,
  minimum_stay     NUMBER(5) not null,
  maximum_stay     NUMBER(5) default '99999' not null,
  discount         NUMBER(3) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  create_by        VARCHAR2(20) default '1E' not null,
  create_date      DATE default sysdate not null,
  last_update_by   VARCHAR2(20) default '1E' not null,
  last_update_date DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_STOPOVER_DISCOUNT
  add constraint FPUB_T_STOPOVER_DISCOUNT primary key (CARR_CODE, LOOKUP_CODE, MINIMUM_STAY, MAXIMUM_STAY, SALE_EFF_DATE, TRAVEL_EFF_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_SUBCLASSCODE
prompt ==================================
prompt
create table FCIMS.FPUB_T_SUBCLASSCODE
(
  carr_code        VARCHAR2(5) not null,
  cls_code         VARCHAR2(26) not null,
  sub_cls_code     VARCHAR2(26) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null,
  fare_basis       VARCHAR2(15) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_SUBCLASSCODE
  add constraint FIMS_PK_FPUB_T_SUBCLASSCODE primary key (CARR_CODE, CLS_CODE, SUB_CLS_CODE, SALE_EFF_DATE, TRAVEL_EFF_DATE, FARE_BASIS)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FPUB_T_TYPE
prompt ==========================
prompt
create table FCIMS.FPUB_T_TYPE
(
  lookup_type      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  lookup_code      VARCHAR2(20) not null,
  description      VARCHAR2(500),
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI'),
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI'),
  last_update_date DATE default sysdate,
  last_update_by   VARCHAR2(20) default '1E'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FIMS_PK_T_TYPE on FCIMS.FPUB_T_TYPE (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FPUB_T_TYPE
  add constraint FIMS_PK_FPUB_T_TYPE primary key (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE, SALE_EFF_DATE, TRAVEL_EFF_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_ALLIANCE_CARRIER
prompt ===================================
prompt
create table FCIMS.FSI_ALLIANCE_CARRIER
(
  carrier          VARCHAR2(6) not null,
  alliance         VARCHAR2(6) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE default (sysdate) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_AV_PID_POOL
prompt ==============================
prompt
create table FCIMS.FSI_AV_PID_POOL
(
  machine_id        CHAR(10) not null,
  pid_low_boundary  NUMBER not null,
  pid_high_boundary NUMBER not null,
  last_update_date  DATE,
  last_update_by    CHAR(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_AV_PID_POOL
  add constraint KEY primary key (MACHINE_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_BOOKING_CLASS_RULE
prompt =====================================
prompt
create table FCIMS.FSI_BOOKING_CLASS_RULE
(
  carrier              VARCHAR2(6) not null,
  booking_class        VARCHAR2(50) not null,
  physical_cabin       VARCHAR2(30),
  virtual_cabin        VARCHAR2(80),
  physical_sequence_no NUMBER(3),
  virtual_sequence_no  NUMBER(3),
  effective_date       DATE not null,
  discontinue_date     DATE not null,
  last_update_date     DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_BOOKING_CLASS_RULE_TEST
prompt ==========================================
prompt
create table FCIMS.FSI_BOOKING_CLASS_RULE_TEST
(
  carrier              VARCHAR2(6) not null,
  booking_class        VARCHAR2(50) not null,
  physical_cabin       VARCHAR2(30),
  virtual_cabin        VARCHAR2(80),
  physical_sequence_no NUMBER(3),
  virtual_sequence_no  NUMBER(3),
  effective_date       DATE not null,
  discontinue_date     DATE not null,
  last_update_date     DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_BRAND_OC_RULE
prompt ================================
prompt
create table FCIMS.FSI_BRAND_OC_RULE
(
  carrier            VARCHAR2(6) not null,
  channel            VARCHAR2(10) not null,
  brand_name         VARCHAR2(100) not null,
  brand_level        NUMBER(10) not null,
  booking_class_list VARCHAR2(100) not null,
  ori                VARCHAR2(20) not null,
  ori_type           VARCHAR2(6) not null,
  des                VARCHAR2(20) not null,
  des_type           VARCHAR2(6) not null,
  direction          VARCHAR2(10) not null,
  combinable         VARCHAR2(10) not null,
  sequence_no        NUMBER(10) not null,
  cabin_name         VARCHAR2(30) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null,
  travel_eff_date    DATE,
  travel_dis_date    DATE,
  description_en     VARCHAR2(200),
  description_cn     VARCHAR2(200),
  oc_table_number    NUMBER(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_BRAND_RULE
prompt =============================
prompt
create table FCIMS.FSI_BRAND_RULE
(
  carrier            VARCHAR2(6) not null,
  channel            VARCHAR2(10) not null,
  brand_name         VARCHAR2(100) not null,
  brand_level        NUMBER(10) not null,
  booking_class_list VARCHAR2(100) not null,
  ori                VARCHAR2(20) not null,
  ori_type           VARCHAR2(6) not null,
  des                VARCHAR2(20) not null,
  des_type           VARCHAR2(6) not null,
  direction          VARCHAR2(10) not null,
  combinable         VARCHAR2(10) not null,
  sequence_no        NUMBER(10) not null,
  cabin_name         VARCHAR2(30) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null,
  travel_eff_date    DATE default to_date('20120101','yyyymmdd') not null,
  travel_dis_date    DATE default to_date('20991231','yyyymmdd') not null,
  last_update_by     VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_BRAND_RULE_PRODUCT
prompt =====================================
prompt
create table FCIMS.FSI_BRAND_RULE_PRODUCT
(
  carrier            VARCHAR2(6) not null,
  channel            VARCHAR2(10) not null,
  brand_name         VARCHAR2(100) not null,
  brand_level        NUMBER(10) not null,
  booking_class_list VARCHAR2(100) not null,
  ori                VARCHAR2(20) not null,
  ori_type           VARCHAR2(6) not null,
  des                VARCHAR2(20) not null,
  des_type           VARCHAR2(6) not null,
  direction          VARCHAR2(10) not null,
  combinable         VARCHAR2(10) not null,
  sequence_no        NUMBER(10) not null,
  cabin_name         VARCHAR2(30) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CABIN_CLASS
prompt ==============================
prompt
create table FCIMS.FSI_CABIN_CLASS
(
  id                VARCHAR2(32) not null,
  rec_type          VARCHAR2(3) not null,
  carrier_code      VARCHAR2(3) not null,
  filler1           VARCHAR2(9),
  sequence_number   NUMBER(7) not null,
  eff_date          DATE not null,
  disc_date         DATE not null,
  area_indicator    VARCHAR2(2),
  geo_loc_type1     VARCHAR2(1),
  geo_loc_spec1     VARCHAR2(5),
  geo_loc_type2     VARCHAR2(1),
  geo_loc_spec2     VARCHAR2(5),
  first_ticket_date DATE not null,
  last_ticket_date  DATE not null,
  filler            VARCHAR2(14),
  last_update_user  VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date  DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CABIN_CLASS_SEGMENT
prompt ======================================
prompt
create table FCIMS.FSI_CABIN_CLASS_SEGMENT
(
  id                  VARCHAR2(32) not null,
  parent_id           VARCHAR2(32) not null,
  cabin               VARCHAR2(1),
  bookingclass_code1  VARCHAR2(2),
  bookingclass_code2  VARCHAR2(2),
  bookingclass_code3  VARCHAR2(2),
  bookingclass_code4  VARCHAR2(2),
  bookingclass_code5  VARCHAR2(2),
  bookingclass_code6  VARCHAR2(2),
  bookingclass_code7  VARCHAR2(2),
  bookingclass_code8  VARCHAR2(2),
  bookingclass_code9  VARCHAR2(2),
  bookingclass_code10 VARCHAR2(2),
  last_update_user    VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date    DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CABIN_COMBINE_RULE
prompt =====================================
prompt
create table FCIMS.FSI_CABIN_COMBINE_RULE
(
  carrier            VARCHAR2(6) not null,
  cabin_combine_rule VARCHAR2(100),
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate),
  channel            VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CABIN_RULE
prompt =============================
prompt
create table FCIMS.FSI_CABIN_RULE
(
  carrier            VARCHAR2(6) not null,
  cabin_name         VARCHAR2(30),
  cabin_level        NUMBER(10),
  booking_class_list VARCHAR2(100) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null,
  travel_eff_date    DATE,
  travel_dis_date    DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CABIN_RULE_PRODUCT
prompt =====================================
prompt
create table FCIMS.FSI_CABIN_RULE_PRODUCT
(
  carrier            VARCHAR2(6) not null,
  cabin_name         VARCHAR2(30),
  cabin_level        NUMBER(10),
  booking_class_list VARCHAR2(100) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CACHE_TIMEOUT
prompt ================================
prompt
create table FCIMS.FSI_CACHE_TIMEOUT
(
  client           VARCHAR2(10) not null,
  channel          VARCHAR2(10),
  carrier          VARCHAR2(6),
  ori              VARCHAR2(6) not null,
  des              VARCHAR2(6) not null,
  is_ow            VARCHAR2(6),
  cache_timeout    NUMBER(7,2),
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CARRIER_RFS_IP
prompt =================================
prompt
create table FCIMS.FSI_CARRIER_RFS_IP
(
  carrier          VARCHAR2(6) not null,
  rfs_ip           VARCHAR2(200) not null,
  last_update_user VARCHAR2(32) not null,
  last_update_date DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CAT_TXT
prompt ==========================
prompt
create table FCIMS.FSI_CAT_TXT
(
  seq           VARCHAR2(32) not null,
  cat4_text     CLOB,
  last_update   DATE,
  within_cn     CLOB,
  within_cn_md5 VARCHAR2(32),
  status        VARCHAR2(2),
  cat_num       NUMBER(10) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_CAT_TXT
  add constraint SEQ primary key (SEQ)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_CITY
prompt =======================
prompt
create table FCIMS.FSI_CITY
(
  record_format_version  NUMBER(2),
  issue_date             DATE,
  gfs_id                 VARCHAR2(8),
  prod_id                VARCHAR2(8),
  data_ind               VARCHAR2(1),
  city_code              VARCHAR2(5) not null,
  state                  VARCHAR2(2),
  country_code           VARCHAR2(2) not null,
  zone_code              VARCHAR2(3) not null,
  international_city_ind VARCHAR2(1),
  spare1                 VARCHAR2(1),
  us_territory_ind       VARCHAR2(1) default 'N' not null,
  spare2                 VARCHAR2(1),
  spare3                 VARCHAR2(1),
  spare4                 VARCHAR2(1),
  spare5                 VARCHAR2(1),
  spare6                 VARCHAR2(1),
  alaska_tax_zone        VARCHAR2(1),
  spare7                 VARCHAR2(1),
  timezone_sign          VARCHAR2(1),
  timezone               NUMBER(2),
  gtrtn                  VARCHAR2(1),
  city_ind               VARCHAR2(1) not null,
  latitude_deg           NUMBER(2),
  latitude_min           NUMBER(2),
  latitude_sec           NUMBER(2),
  latitude_type          VARCHAR2(1),
  longitude_deg          NUMBER(3),
  longitude_min          NUMBER(2),
  longitude_sec          NUMBER(2),
  longitude_type         VARCHAR2(1),
  spare8                 VARCHAR2(1),
  bu_tax_ind             VARCHAR2(1) default 'N' not null,
  spare9                 VARCHAR2(4),
  name                   VARCHAR2(40),
  city_name              VARCHAR2(17),
  cancel                 VARCHAR2(1),
  last_update_user       VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date       DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table FCIMS.FSI_CITY
  is '�������С���������Ӧ������Ϣ������ʱ';
comment on column FCIMS.FSI_CITY.data_ind
  is '''x'' = invalid data';
comment on column FCIMS.FSI_CITY.international_city_ind
  is 'Y=Yes; N=No';
comment on column FCIMS.FSI_CITY.spare1
  is 'Y=Yes; N=No';
comment on column FCIMS.FSI_CITY.us_territory_ind
  is 'Y=Yes; N=No';
comment on column FCIMS.FSI_CITY.spare2
  is 'Y=Yes; N=No';
comment on column FCIMS.FSI_CITY.spare3
  is 'Y=Yes; N=No';
comment on column FCIMS.FSI_CITY.timezone_sign
  is '+/-';
comment on column FCIMS.FSI_CITY.timezone
  is '��Сʱ * ���ֶ�ֵ';
comment on column FCIMS.FSI_CITY.city_ind
  is 'a = airport, b = airport and city,c=city';
comment on column FCIMS.FSI_CITY.latitude_type
  is 'N = North��γ ; S = South��γ';
comment on column FCIMS.FSI_CITY.longitude_type
  is 'E = East����;  W=West����';
comment on column FCIMS.FSI_CITY.spare8
  is 'Y=Yes; N=No';
alter table FCIMS.FSI_CITY
  add constraint PK_FSI_CITY primary key (CITY_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_COMMISSION
prompt =============================
prompt
create table FCIMS.FSI_COMMISSION
(
  airline          VARCHAR2(2) not null,
  percent          NUMBER(8) not null,
  decimal_place    NUMBER(8) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_COMMISSION
  add primary key (AIRLINE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_COMMON_CHANNEL
prompt =================================
prompt
create table FCIMS.FSI_COMMON_CHANNEL
(
  channel VARCHAR2(30)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_COUNTRY_CURRENCY
prompt ===================================
prompt
create table FCIMS.FSI_COUNTRY_CURRENCY
(
  country_code     VARCHAR2(2) not null,
  country_name     VARCHAR2(20),
  currency_code    VARCHAR2(3) not null,
  currency_name    VARCHAR2(20) not null,
  currency_type    NUMBER(2) not null,
  usage            VARCHAR2(3) not null,
  itinerary_type   VARCHAR2(1) default 'b' not null,
  sequence_no      VARCHAR2(2) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  bbr_to_bsr_flag  VARCHAR2(1) not null,
  from_geo_type    VARCHAR2(1),
  from_geo_code    VARCHAR2(5),
  to_geo_type      VARCHAR2(1),
  to_geo_code      VARCHAR2(5),
  biodirect        VARCHAR2(1),
  carrier_code1    VARCHAR2(3),
  carrier_code2    VARCHAR2(3),
  carrier_code3    VARCHAR2(3),
  carrier_code4    VARCHAR2(3),
  carrier_code5    VARCHAR2(3),
  carrier_code6    VARCHAR2(3),
  cat1             VARCHAR2(3),
  cat2             VARCHAR2(3),
  cat3             VARCHAR2(3),
  cat4             VARCHAR2(3),
  cat5             VARCHAR2(3),
  cat6             VARCHAR2(3),
  ptc1             VARCHAR2(3),
  ptc2             VARCHAR2(3),
  ptc3             VARCHAR2(3),
  ptc4             VARCHAR2(3),
  ptc5             VARCHAR2(3),
  ptc6             VARCHAR2(3),
  sale_geo_type    VARCHAR2(1),
  sale_geo_code    VARCHAR2(5),
  fare_rnd_act     VARCHAR2(1),
  fare_rnd_unit    NUMBER,
  fare_dec         NUMBER(1),
  tax_rnd_act      VARCHAR2(1),
  tax_rnd_unit     NUMBER,
  tax_dec          NUMBER(1),
  prime_curr_ind   VARCHAR2(1) default 'N' not null,
  default_curr_ind VARCHAR2(1),
  emu_member       VARCHAR2(1),
  euro_itin        VARCHAR2(1),
  description      VARCHAR2(40),
  last_update_user VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.FSI_COUNTRY_CURRENCY.usage
  is 'ntl or sel';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.itinerary_type
  is 'i = International Itinerary
d = Domestic Itinerary
b = both';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.from_geo_type
  is '
Blank or
a = Area
s = Country/State
z = Zone
c = City
n = Country
p = Airport
q = Geographic Group';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.to_geo_type
  is '
Blank or
a = Area
s = Country/State
z = Zone
c = City
n = Country
p = Airport
q = Geographic Group';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.sale_geo_type
  is '
Blank or
a = Area
s = Country/State
z = Zone
c = City
n = Country
p = Airport
q = Geographic Group';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.fare_rnd_act
  is 'n = Round Off
u = Round Up
d = Round Down';
comment on column FCIMS.FSI_COUNTRY_CURRENCY.tax_rnd_act
  is 'n = Round Off
u = Round Up
d = Round Down
Blank = selcu usage';
alter table FCIMS.FSI_COUNTRY_CURRENCY
  add constraint FSI_COUNTRY_CURRENCY_PK primary key (COUNTRY_CODE, CURRENCY_CODE, USAGE, SEQUENCE_NO, EFF_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_END_ON_END_CONFIG
prompt ====================================
prompt
create table FCIMS.FSI_END_ON_END_CONFIG
(
  client            VARCHAR2(10) not null,
  channel           VARCHAR2(10) not null,
  carrier           VARCHAR2(6),
  ori               VARCHAR2(10) not null,
  des               VARCHAR2(10) not null,
  end_point1        VARCHAR2(10),
  end_point1_type   VARCHAR2(3),
  end_point2        VARCHAR2(10),
  end_point2_type   VARCHAR2(3),
  marketing_carrier VARCHAR2(6),
  effective_date    DATE not null,
  discontinue_date  DATE not null,
  ori_type          VARCHAR2(3),
  des_type          VARCHAR2(3),
  first_travel_date DATE,
  last_travel_date  DATE,
  major_carrier     VARCHAR2(20),
  last_update_date  DATE default sysdate not null,
  fix_end_on_end    VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_EQUIPMENT
prompt ============================
prompt
create table FCIMS.FSI_EQUIPMENT
(
  equip_code       VARCHAR2(6) not null,
  range            VARCHAR2(10),
  detail           VARCHAR2(20),
  aisle_type       VARCHAR2(20) not null,
  decker_type      VARCHAR2(20),
  new_equip        VARCHAR2(5),
  equip_series     VARCHAR2(10) not null,
  star_equip       VARCHAR2(10),
  effective_date   DATE default to_date('30-01-2013', 'dd-mm-yyyy'),
  discontinue_date DATE default to_date('31-12-2099', 'dd-mm-yyyy')
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_EQUIPMENT
  add constraint EQUIP_CODE primary key (EQUIP_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_FILTER_BY_OD
prompt ===============================
prompt
create table FCIMS.FSI_FILTER_BY_OD
(
  client           VARCHAR2(10) not null,
  channel          VARCHAR2(10) not null,
  carrier          VARCHAR2(6),
  ori              VARCHAR2(6) not null,
  ori_type         VARCHAR2(6) not null,
  des              VARCHAR2(6) not null,
  des_type         VARCHAR2(6) not null,
  sequence_no      NUMBER(6) not null,
  direction        VARCHAR2(6) not null,
  filter_mode      VARCHAR2(20) not null,
  last_update_by   VARCHAR2(10),
  last_update_time DATE default sysdate,
  filter_codeshare VARCHAR2(10),
  av_use_seamless  VARCHAR2(6) default 'N'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_FPUB_T_LDTAL
prompt ===============================
prompt
create table FCIMS.FSI_FPUB_T_LDTAL
(
  lookup_type      VARCHAR2(30) not null,
  carr_code        VARCHAR2(5) not null,
  lookup_code      VARCHAR2(20) not null,
  description      VARCHAR2(50),
  create_date      DATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100),
  attribute6       VARCHAR2(100),
  attribute7       VARCHAR2(100),
  attribute8       VARCHAR2(100),
  attribute9       VARCHAR2(100),
  attribute10      VARCHAR2(200),
  attribute11      VARCHAR2(100),
  attribute12      VARCHAR2(100),
  attribute13      VARCHAR2(100),
  attribute14      VARCHAR2(100),
  attribute15      VARCHAR2(100),
  attribute16      VARCHAR2(100),
  attribute17      VARCHAR2(100),
  attribute18      VARCHAR2(100),
  attribute19      VARCHAR2(100),
  attribute20      VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FSI_PK_T_LDTIL on FCIMS.FSI_FPUB_T_LDTAL (LOOKUP_TYPE, CARR_CODE, LOOKUP_CODE)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_FPUB_T_LDTAL
  add constraint FSI_FK_LOOKUP_TYPE_LOOKUP_DTL foreign key (LOOKUP_TYPE, CARR_CODE)
  references FCIMS.FPUB_T_LINFO (LOOKUP_TYPE, CARR_CODE) on delete cascade
  disable
  novalidate;

prompt
prompt Creating table FSI_FSD_RESULT
prompt =============================
prompt
create table FCIMS.FSI_FSD_RESULT
(
  ori                   VARCHAR2(6),
  des                   VARCHAR2(6),
  carrier               VARCHAR2(10),
  fare_basis            VARCHAR2(100),
  fare_appl_type        VARCHAR2(20),
  rule_cookie1          VARCHAR2(500),
  rule_cookie2          VARCHAR2(500),
  restrictions_index    VARCHAR2(32),
  advance_purchase_unit VARCHAR2(10),
  min_stay              VARCHAR2(10),
  min_stay_unit         VARCHAR2(10),
  max_stay              VARCHAR2(10),
  max_stay_unit         VARCHAR2(10),
  cat4_seq              VARCHAR2(32),
  rbd                   VARCHAR2(10),
  advance_purchase      VARCHAR2(10),
  last_update           DATE,
  first_ticketing_date  VARCHAR2(30),
  last_ticketing_date   VARCHAR2(30),
  rule_no               VARCHAR2(20),
  amount                VARCHAR2(30),
  office                VARCHAR2(10),
  cat2_seq              VARCHAR2(32),
  status                VARCHAR2(1),
  farestatus            VARCHAR2(15),
  originaddonfare       VARCHAR2(30),
  specifiedfare         VARCHAR2(30),
  destinationaddonfare  VARCHAR2(30),
  gateway1              VARCHAR2(6),
  gateway2              VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_FSD_RESULT_CAT4
prompt ==================================
prompt
create table FCIMS.FSI_FSD_RESULT_CAT4
(
  ori                   VARCHAR2(6),
  des                   VARCHAR2(6),
  carrier               VARCHAR2(10),
  fare_basis            VARCHAR2(100),
  fare_appl_type        VARCHAR2(20),
  rule_cookie1          VARCHAR2(500),
  rule_cookie2          VARCHAR2(500),
  restrictions_index    VARCHAR2(32),
  advance_purchase_unit VARCHAR2(10),
  min_stay              VARCHAR2(10),
  min_stay_unit         VARCHAR2(10),
  max_stay              VARCHAR2(10),
  max_stay_unit         VARCHAR2(10),
  cat4_seq              VARCHAR2(32),
  rbd                   VARCHAR2(10),
  advance_purchase      VARCHAR2(10),
  last_update           DATE,
  first_ticketing_date  VARCHAR2(30),
  last_ticketing_date   VARCHAR2(30),
  rule_no               VARCHAR2(20),
  amount                VARCHAR2(30),
  office                VARCHAR2(10),
  cat2_seq              VARCHAR2(32),
  status                VARCHAR2(1),
  farestatus            VARCHAR2(15),
  originaddonfare       VARCHAR2(30),
  specifiedfare         VARCHAR2(30),
  destinationaddonfare  VARCHAR2(30),
  gateway1              VARCHAR2(6),
  gateway2              VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_FSD_RESULT_CZ_HOT
prompt ====================================
prompt
create table FCIMS.FSI_FSD_RESULT_CZ_HOT
(
  ori                   VARCHAR2(6),
  des                   VARCHAR2(6),
  carrier               VARCHAR2(10),
  fare_basis            VARCHAR2(100),
  fare_appl_type        VARCHAR2(20),
  rule_cookie1          VARCHAR2(500),
  rule_cookie2          VARCHAR2(500),
  restrictions_index    VARCHAR2(32),
  advance_purchase_unit VARCHAR2(10),
  min_stay              VARCHAR2(10),
  min_stay_unit         VARCHAR2(10),
  max_stay              VARCHAR2(10),
  max_stay_unit         VARCHAR2(10),
  cat4_seq              VARCHAR2(32),
  rbd                   VARCHAR2(10),
  advance_purchase      VARCHAR2(10),
  last_update           DATE,
  first_ticketing_date  VARCHAR2(30),
  last_ticketing_date   VARCHAR2(30),
  rule_no               VARCHAR2(20),
  amount                VARCHAR2(30),
  office                VARCHAR2(10),
  cat2_seq              VARCHAR2(32),
  status                VARCHAR2(1),
  farestatus            VARCHAR2(15),
  originaddonfare       VARCHAR2(30),
  specifiedfare         VARCHAR2(30),
  destinationaddonfare  VARCHAR2(30),
  gateway1              VARCHAR2(6),
  gateway2              VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_HOT_CITY_PAIR
prompt ================================
prompt
create table FCIMS.FSI_HOT_CITY_PAIR
(
  city1            VARCHAR2(6) not null,
  city2            VARCHAR2(6) not null,
  time_out         NUMBER(10),
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null,
  office           VARCHAR2(10),
  description      VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_LOAD_FSD
prompt ===========================
prompt
create table FCIMS.FSI_LOAD_FSD
(
  ori        VARCHAR2(6) not null,
  des        VARCHAR2(6) not null,
  carriers   VARCHAR2(100),
  date_range VARCHAR2(6) not null,
  od_type    NUMBER,
  routing    VARCHAR2(100),
  office     VARCHAR2(10),
  iatano     VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_LOAD_FSD_ALL
prompt ===============================
prompt
create table FCIMS.FSI_LOAD_FSD_ALL
(
  ori        VARCHAR2(6) not null,
  des        VARCHAR2(6) not null,
  carriers   VARCHAR2(100),
  date_range VARCHAR2(6) not null,
  od_type    NUMBER,
  routing    VARCHAR2(100),
  office     VARCHAR2(10),
  iatano     VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_LOAD_FSD_CZ_HOT
prompt ==================================
prompt
create table FCIMS.FSI_LOAD_FSD_CZ_HOT
(
  ori        VARCHAR2(6) not null,
  des        VARCHAR2(6) not null,
  carriers   VARCHAR2(100),
  date_range VARCHAR2(6) not null,
  od_type    NUMBER,
  routing    VARCHAR2(100),
  office     VARCHAR2(10),
  iatano     VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_LOAD_FSD_DOMESTIC
prompt ====================================
prompt
create table FCIMS.FSI_LOAD_FSD_DOMESTIC
(
  ori        VARCHAR2(6) not null,
  des        VARCHAR2(6) not null,
  carriers   VARCHAR2(2000),
  date_range VARCHAR2(6) not null,
  od_type    NUMBER,
  routing    VARCHAR2(100),
  office     VARCHAR2(10),
  iatano     VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_LOCTION
prompt ==========================
prompt
create table FCIMS.FSI_LOCTION
(
  loc_code    VARCHAR2(50),
  loc_type    VARCHAR2(1),
  description VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_MEAL
prompt =======================
prompt
create table FCIMS.FSI_MEAL
(
  meal_code        VARCHAR2(5) not null,
  meal_detail      VARCHAR2(50) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_MEAL
  add constraint MEAL_CODE primary key (MEAL_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_MULTI_AIRPORT
prompt ================================
prompt
create table FCIMS.FSI_MULTI_AIRPORT
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  airport_code          VARCHAR2(5) not null,
  city_code             VARCHAR2(5) not null,
  domestic_app_ind      NUMBER(1),
  international_app_ind NUMBER(1),
  include_ind           NUMBER(1),
  exclude_ind           NUMBER(1),
  carrier_code          VARCHAR2(3) not null,
  tariff_no             VARCHAR2(3),
  cancel                VARCHAR2(1),
  last_update_user      VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date      DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table FCIMS.FSI_MULTI_AIRPORT
  is '���л����Ķ�Ӧ��ϵ';
comment on column FCIMS.FSI_MULTI_AIRPORT.data_ind
  is '''x'' = invalid data';
comment on column FCIMS.FSI_MULTI_AIRPORT.domestic_app_ind
  is '0=NO, 1=YES';
comment on column FCIMS.FSI_MULTI_AIRPORT.international_app_ind
  is '0=NO, 1=YES';
comment on column FCIMS.FSI_MULTI_AIRPORT.include_ind
  is '0=NO, 1=YES���������µĺ��չ�˾��Tariff';
comment on column FCIMS.FSI_MULTI_AIRPORT.exclude_ind
  is '0=NO, 1=YES���ų����µĺ��չ�˾��Tariff';
comment on column FCIMS.FSI_MULTI_AIRPORT.tariff_no
  is 'Tariff No���������ַ���ʽ���';
alter table FCIMS.FSI_MULTI_AIRPORT
  add constraint PK_FSI_MULTI_AIRPORT primary key (AIRPORT_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_NEGO_RBD
prompt ===========================
prompt
create table FCIMS.FSI_NEGO_RBD
(
  office           VARCHAR2(6) not null,
  carrier          VARCHAR2(6) not null,
  ori              VARCHAR2(20) not null,
  ori_type         VARCHAR2(6) not null,
  des              VARCHAR2(20) not null,
  des_type         VARCHAR2(6) not null,
  journey_type     VARCHAR2(6) not null,
  account_code     VARCHAR2(30) not null,
  sequence_no      NUMBER(10) not null,
  rbd              VARCHAR2(100) not null,
  travel_eff_date  DATE not null,
  travel_dis_date  DATE not null,
  last_update_date DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_OC_RULE
prompt ==========================
prompt
create table FCIMS.FSI_OC_RULE
(
  table_number     NUMBER(10) not null,
  sequence_number  NUMBER(10) not null,
  group_code       VARCHAR2(50) not null,
  sub_code         VARCHAR2(50) not null,
  type             VARCHAR2(2) not null,
  service_name_en  VARCHAR2(100) not null,
  service_name_cn  VARCHAR2(100) not null,
  appl             VARCHAR2(2) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_OD_FARE
prompt ==========================
prompt
create table FCIMS.FSI_OD_FARE
(
  ori              VARCHAR2(5),
  des              VARCHAR2(5),
  carrier          VARCHAR2(5),
  rbd              VARCHAR2(5),
  amount           NUMBER(20,2),
  effective_date   DATE default (to_date('30-01-2013', 'dd-mm-yyyy')),
  discontinue_date DATE default (to_date('31-12-2099', 'dd-mm-yyyy')),
  rulenumber       VARCHAR2(10),
  tariff           VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_OFFICE_PRIVATE_OD
prompt ====================================
prompt
create table FCIMS.FSI_OFFICE_PRIVATE_OD
(
  client           VARCHAR2(10),
  ori_code         VARCHAR2(5),
  des_code         VARCHAR2(5),
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE default sysdate not null,
  description      VARCHAR2(30)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PRECACHE_CITY
prompt ================================
prompt
create table FCIMS.FSI_PRECACHE_CITY
(
  ori              VARCHAR2(6) not null,
  des              VARCHAR2(6) not null,
  journey_type     VARCHAR2(6) not null,
  date_range       NUMBER(5) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE default sysdate not null,
  office           VARCHAR2(6),
  carrier          VARCHAR2(6),
  rt_date_interval VARCHAR2(60)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PRECACHE_POS
prompt ===============================
prompt
create table FCIMS.FSI_PRECACHE_POS
(
  office           VARCHAR2(6) not null,
  channel          VARCHAR2(9) not null,
  carrier          VARCHAR2(6),
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE default sysdate not null,
  iata_no          VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PREFER_ROUTING
prompt =================================
prompt
create table FCIMS.FSI_PREFER_ROUTING
(
  office           VARCHAR2(10) not null,
  channel          VARCHAR2(10) not null,
  carrier          VARCHAR2(10),
  ori              VARCHAR2(10) not null,
  des              VARCHAR2(10) not null,
  routings         VARCHAR2(50) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PRIMARY_FLIGHT_RULE
prompt ======================================
prompt
create table FCIMS.FSI_PRIMARY_FLIGHT_RULE
(
  carrier          VARCHAR2(6) not null,
  channel          VARCHAR2(10) not null,
  ori              VARCHAR2(20) not null,
  ori_type         VARCHAR2(6) not null,
  des              VARCHAR2(20) not null,
  des_type         VARCHAR2(6) not null,
  distance         NUMBER(10) not null,
  sequence         NUMBER(5) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PRODUCT_BRAND_RULE
prompt =====================================
prompt
create table FCIMS.FSI_PRODUCT_BRAND_RULE
(
  carrier            VARCHAR2(6) not null,
  channel            VARCHAR2(10) not null,
  brand_name         VARCHAR2(100) not null,
  brand_level        NUMBER(10) not null,
  booking_class_list VARCHAR2(100) not null,
  ori                VARCHAR2(20) not null,
  ori_type           VARCHAR2(6) not null,
  des                VARCHAR2(20) not null,
  des_type           VARCHAR2(6) not null,
  direction          VARCHAR2(10) not null,
  combinable         VARCHAR2(10) not null,
  sequence_no        NUMBER(10) not null,
  cabin_name         VARCHAR2(30) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_PRODUCT_CABIN_RULE
prompt =====================================
prompt
create table FCIMS.FSI_PRODUCT_CABIN_RULE
(
  carrier            VARCHAR2(6) not null,
  cabin_name         VARCHAR2(30),
  cabin_level        NUMBER(10),
  booking_class_list VARCHAR2(100) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE default (sysdate) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_R2CXXX_1
prompt ===========================
prompt
create table FCIMS.FSI_R2CXXX_1
(
  seq              VARCHAR2(32) not null,
  rule_trf_num     NUMBER(10) not null,
  carr_cde         VARCHAR2(3) not null,
  rule_num         VARCHAR2(4) not null,
  cat_num          NUMBER(10) not null,
  cat_seq_num      NUMBER(10) not null,
  db_iss_eff_dte   DATE not null,
  db_tvl_eff_dte   DATE not null,
  data_tbl_seq_num NUMBER(5) not null,
  tbl_rel_cde      VARCHAR2(1) not null,
  tbl_cat_num      NUMBER(10) not null,
  data_tbl_num     NUMBER(10) not null,
  inbnd_otbnd_cde  VARCHAR2(1) not null,
  cat_cntl_dir_cde VARCHAR2(1) not null,
  lst_upd_dte      DATE not null,
  lst_upd_id       VARCHAR2(8) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_R3C004
prompt =========================
prompt
create table FCIMS.FSI_R3C004
(
  tbl_num           NUMBER(10) not null,
  appl_cde          VARCHAR2(1) not null,
  op_carr_cde       VARCHAR2(3) not null,
  appl_flt_num_1    VARCHAR2(4) not null,
  carr_cde_1        VARCHAR2(3) not null,
  carr_tbl_num_1    NUMBER(10) not null,
  rel_cde_1         VARCHAR2(1) not null,
  appl_flt_num_2    VARCHAR2(4) not null,
  carr_cde_2        VARCHAR2(3) not null,
  carr_tbl_num_2    NUMBER(10) not null,
  rel_cde_2         VARCHAR2(1) not null,
  appl_flt_num_3    VARCHAR2(4) not null,
  carr_cde_3        VARCHAR2(3) not null,
  flt_day_wk_appl_1 VARCHAR2(1) not null,
  flt_day_wk_appl_2 VARCHAR2(1) not null,
  flt_day_wk_appl_3 VARCHAR2(1) not null,
  flt_day_wk_appl_4 VARCHAR2(1) not null,
  flt_day_wk_appl_5 VARCHAR2(1) not null,
  flt_day_wk_appl_6 VARCHAR2(1) not null,
  tvl_io            VARCHAR2(1) not null,
  tvl_appl          VARCHAR2(1) not null,
  tvl_loc           VARCHAR2(1) not null,
  btwn_via_tbl_num  NUMBER(10) not null,
  and_via_tbl_num   NUMBER(10) not null,
  tvl_via_cde       VARCHAR2(1) not null,
  via_geo_tbl_num   NUMBER(10) not null,
  tvl_hidden        VARCHAR2(1) not null,
  flt_appl_non_stp  VARCHAR2(1) not null,
  flt_appl_dir_flt  VARCHAR2(1) not null,
  flt_appl_mult_stp VARCHAR2(1) not null,
  flt_appl_one_stp  VARCHAR2(1) not null,
  flt_appl_onl_conn VARCHAR2(1) not null,
  flt_appl_il_conn  VARCHAR2(1) not null,
  flt_appl_same_flt VARCHAR2(1) not null,
  flt_appl_eqp      VARCHAR2(1) not null,
  flt_appl_eqp_cde  VARCHAR2(3) not null,
  dte_tbl_num       NUMBER(10) not null,
  txt_tbl_num       NUMBER(10) not null,
  unavail_data_cde  VARCHAR2(1) not null,
  lst_upd_dte       DATE not null,
  lst_upd_id        VARCHAR2(8) not null,
  between_loc_cde   VARCHAR2(50) not null,
  and_loc_cde       VARCHAR2(50) not null,
  via_loc_cde       VARCHAR2(50) not null,
  between_loc_type  VARCHAR2(1),
  and_loc_type      VARCHAR2(1),
  via_loc_type      VARCHAR2(1)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_RAILWAY_CODE
prompt ===============================
prompt
create table FCIMS.FSI_RAILWAY_CODE
(
  carrier   VARCHAR2(6) not null,
  channel   VARCHAR2(10) not null,
  surfare   VARCHAR2(5) not null,
  rbdlist   VARCHAR2(30),
  eff_date  DATE not null,
  disc_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_RAILWAY_CODE
  add constraint FSI_RAILWAY_CODE_PK primary key (CARRIER, CHANNEL, SURFARE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_RESTRICTIONS
prompt ===============================
prompt
create table FCIMS.FSI_RESTRICTIONS
(
  ind                         VARCHAR2(32) not null,
  date_restriction_appl1      VARCHAR2(10) not null,
  first_date_restriction1     VARCHAR2(20) not null,
  last_date_restriction1      VARCHAR2(20) not null,
  season_blackout1            VARCHAR2(5) not null,
  date_restriction_appl2      VARCHAR2(10) not null,
  first_date_restriction2     VARCHAR2(20) not null,
  last_date_restriction2      VARCHAR2(20) not null,
  season_blackout2            VARCHAR2(5) not null,
  date_restriction_appl3      VARCHAR2(10) not null,
  first_date_restriction3     VARCHAR2(20) not null,
  last_date_restriction3      VARCHAR2(20) not null,
  season_blackout3            VARCHAR2(5) not null,
  day_of_week1                VARCHAR2(10) not null,
  dow_app1                    VARCHAR2(10) not null,
  dow_restrictionexistsind1   VARCHAR2(5) not null,
  dow_includeexcludeuseind1   VARCHAR2(5) not null,
  day_of_week2                VARCHAR2(10) not null,
  dow_app2                    VARCHAR2(10) not null,
  dow_restrictionexistsind2   VARCHAR2(5) not null,
  dow_includeexcludeuseind2   VARCHAR2(5) not null,
  day_of_week3                VARCHAR2(10) not null,
  dow_app3                    VARCHAR2(10) not null,
  dow_restrictionexistsind3   VARCHAR2(5) not null,
  dow_includeexcludeuseind3   VARCHAR2(5) not null,
  first_sale_date_restriction VARCHAR2(10) not null,
  last_sale_date_restriction  VARCHAR2(10) not null,
  sale_restriction_indicator  VARCHAR2(5) not null,
  global_indicator_code       VARCHAR2(3) not null,
  maximum_permitted_mileage   VARCHAR2(6) not null,
  include_indicator           VARCHAR2(5) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_RESTRICTIONS
  add constraint FSI_RESTRICTIONS_PK primary key (IND, DATE_RESTRICTION_APPL1, FIRST_DATE_RESTRICTION1, LAST_DATE_RESTRICTION1, SEASON_BLACKOUT1, DATE_RESTRICTION_APPL2, FIRST_DATE_RESTRICTION2, LAST_DATE_RESTRICTION2, SEASON_BLACKOUT2, DATE_RESTRICTION_APPL3, FIRST_DATE_RESTRICTION3, LAST_DATE_RESTRICTION3, SEASON_BLACKOUT3, DAY_OF_WEEK1, DOW_APP1, DOW_RESTRICTIONEXISTSIND1, DOW_INCLUDEEXCLUDEUSEIND1, DAY_OF_WEEK2, DOW_APP2, DOW_RESTRICTIONEXISTSIND2, DOW_INCLUDEEXCLUDEUSEIND2, DAY_OF_WEEK3, DOW_APP3, DOW_RESTRICTIONEXISTSIND3, DOW_INCLUDEEXCLUDEUSEIND3, FIRST_SALE_DATE_RESTRICTION, LAST_SALE_DATE_RESTRICTION, SALE_RESTRICTION_INDICATOR, GLOBAL_INDICATOR_CODE, MAXIMUM_PERMITTED_MILEAGE, INCLUDE_INDICATOR)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SAME_CARRIER
prompt ===============================
prompt
create table FCIMS.FSI_SAME_CARRIER
(
  carrier          VARCHAR2(6),
  same_carrier     VARCHAR2(200) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE default sysdate not null,
  client           VARCHAR2(6) not null,
  channel          VARCHAR2(10),
  apply_scope      VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SHOPPER_CONFIG
prompt =================================
prompt
create table FCIMS.FSI_SHOPPER_CONFIG
(
  client                         VARCHAR2(10),
  channel                        VARCHAR2(10),
  carrier                        VARCHAR2(6),
  max_routings                   NUMBER(3),
  max_same_routings              NUMBER(3),
  max_connections                NUMBER(3),
  max_journeys                   NUMBER(3),
  max_physical_cabins            NUMBER(3),
  max_virtual_cabins             NUMBER(3),
  fs_max_responses               NUMBER(3),
  cs_max_ow_windows              NUMBER(3),
  cs_max_rt_windows              NUMBER(3),
  cabin_upsell                   VARCHAR2(6),
  cabin_downsell                 VARCHAR2(6),
  fs_use_interline               VARCHAR2(6),
  cs_use_interline               VARCHAR2(6),
  fs_use_cache                   VARCHAR2(20),
  cs_use_cache                   VARCHAR2(20),
  is_use_tace                    VARCHAR2(6),
  effective_date                 DATE,
  discontinue_date               DATE,
  last_update_date               DATE,
  is_use_axi                     VARCHAR2(6),
  tace_priority_host             NUMBER(3),
  tace_priority_naf              NUMBER(3),
  tace_priority_od               NUMBER(3),
  tace_priority_sita             NUMBER(3),
  tace_priority_comp             NUMBER(3),
  flight_combine_flag            VARCHAR2(10),
  break_point                    VARCHAR2(10),
  filter_flight                  VARCHAR2(20) default ('Y'),
  filter_flight_step2            VARCHAR2(6) default ('Y'),
  filter_addon                   VARCHAR2(20) default ('Y'),
  filter_addon_step2             VARCHAR2(6) default ('Y'),
  cs_use_tace                    VARCHAR2(6),
  filter_codeshare               VARCHAR2(10),
  filter_same_carrier_codeshare  VARCHAR2(6),
  filter_other_carrier           VARCHAR2(6),
  tace_routing                   NUMBER(3),
  is_simple_brand                VARCHAR2(6) default ('N'),
  calendar_combine_logic         VARCHAR2(10) default ('ALL'),
  fs_use_tace                    VARCHAR2(6),
  is_od_use_airport              VARCHAR2(6),
  description                    VARCHAR2(100),
  od_end_on_end                  VARCHAR2(6),
  od_end_on_end_timeout          NUMBER(11),
  negologic                      VARCHAR2(20),
  filter_yy_fare                 VARCHAR2(6),
  iata_no                        VARCHAR2(20),
  is_brand_multi_avopt           VARCHAR2(6),
  cat35_all_type                 VARCHAR2(6),
  is_use_routing_prefer          VARCHAR2(6),
  rfs_ip_product                 VARCHAR2(200) default ('10.6.137.118:9111'),
  rfs_ip_backup                  VARCHAR2(200),
  av_filter_offset               NUMBER(3),
  filter_av_strict_by_date       VARCHAR2(6),
  primary_flight_rule            VARCHAR2(10),
  max_cartesion_class            NUMBER(3),
  cs_combine_flag                VARCHAR2(20),
  brand_apply_scope              VARCHAR2(10),
  max_computed_trips             NUMBER(4),
  fs_max_tps                     NUMBER(7,2),
  cs_max_tps                     NUMBER(7,2),
  fs_max_requests_daily          NUMBER(4),
  cs_max_requests_daily          NUMBER(4),
  is_use_temp_commission_engine  VARCHAR2(6),
  is_use_duration_shopping       VARCHAR2(6),
  ds_max_window                  NUMBER(3),
  ds_duration_range              NUMBER(3),
  fs_use_fuzzy_query             VARCHAR2(6),
  fuzzy_query_time_range         NUMBER(4),
  use_hot_city                   VARCHAR2(6),
  use_acc_travel                 VARCHAR2(6),
  max_vcabins_when_av_given      NUMBER(4),
  memcache_summary_percent       NUMBER(4),
  is_use_bbqmrestart             VARCHAR2(6) default ('Y'),
  max_channel_tps                NUMBER(7,2),
  max_channel_requests           NUMBER(7,2),
  is_use_agent_cs                VARCHAR2(6) default ('N'),
  is_use_local_matrix            VARCHAR2(6) default ('N'),
  bbqm_availability_sort         VARCHAR2(6) default ('N'),
  is_use_railway_code            VARCHAR2(6) default ('N'),
  matrix_socket_timeout          VARCHAR2(10),
  cabin_combine_mode             VARCHAR2(10),
  use_detailrule                 VARCHAR2(7) default ('true'),
  max_trip_number_per_matrix_req NUMBER(4),
  bbqm_limit_alternates          NUMBER(4),
  bbqm_limit_total_segments      NUMBER(4),
  bbqm_max_groups_number         NUMBER(4),
  bbqm_number_per_group          NUMBER(4),
  tace_option                    VARCHAR2(6),
  max_seg_number_per_av_request  NUMBER(4),
  av_stopover_option             VARCHAR2(6),
  max_flight_combines            NUMBER(6),
  is_new_client                  VARCHAR2(6),
  is_use_asi                     VARCHAR2(6),
  is_use_oc                      VARCHAR2(6),
  is_use_public_fare_cache       VARCHAR2(6),
  candidate_online_trip          NUMBER(4),
  candidate_interline_trip       NUMBER(4),
  candidate_rbd_num              NUMBER(4),
  matrix_break_point_flag        VARCHAR2(9),
  is_pre_filter                  VARCHAR2(9),
  debugrecord_effective_date     DATE,
  debugrecord_discontinue_date   DATE,
  is_use_multi_iata              VARCHAR2(6),
  brand_entry_form               VARCHAR2(6),
  av_use_seamless                VARCHAR2(6) default ('N'),
  is_use_carrier_rfs_ip          VARCHAR2(6),
  directflight_compute_all       VARCHAR2(6) default 'N',
  rout_sort_by_primary           VARCHAR2(6) default 'N',
  preferences_path_max_num       NUMBER(4),
  is_use_baggage                 VARCHAR2(6) default ('N'),
  id                             NUMBER(10) not null,
  is_flt_no_special              VARCHAR2(6) default ('N')
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint FSI_SHOPPER_CONFIG_PK primary key (ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint BIN$BDFvDpkDoKDgU6weCimgoA==$0
  check ("RFS_IP_PRODUCT" IS NOT NULL);
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint BIN$BDFvDpkEoKDgU6weCimgoA==$0
  check ("CLIENT" IS NOT NULL);
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint BIN$BDFvDpkFoKDgU6weCimgoA==$0
  check ("EFFECTIVE_DATE" IS NOT NULL);
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint BIN$BDFvDpkGoKDgU6weCimgoA==$0
  check ("DISCONTINUE_DATE" IS NOT NULL);
alter table FCIMS.FSI_SHOPPER_CONFIG
  add constraint BIN$BDFvDpkHoKDgU6weCimgoA==$0
  check ("LAST_UPDATE_DATE" IS NOT NULL);

prompt
prompt Creating table FSI_SHOPPER_CONFIG_1
prompt ===================================
prompt
create table FCIMS.FSI_SHOPPER_CONFIG_1
(
  client                         VARCHAR2(10) not null,
  channel                        VARCHAR2(10),
  carrier                        VARCHAR2(6),
  max_routings                   NUMBER(3),
  max_same_routings              NUMBER(3),
  max_connections                NUMBER(3),
  max_journeys                   NUMBER(3),
  max_physical_cabins            NUMBER(3),
  max_virtual_cabins             NUMBER(3),
  fs_max_responses               NUMBER(3),
  cs_max_ow_windows              NUMBER(3),
  cs_max_rt_windows              NUMBER(3),
  cabin_upsell                   VARCHAR2(6),
  cabin_downsell                 VARCHAR2(6),
  fs_use_interline               VARCHAR2(6),
  cs_use_interline               VARCHAR2(6),
  fs_use_cache                   VARCHAR2(20),
  cs_use_cache                   VARCHAR2(20),
  effective_date                 DATE not null,
  discontinue_date               DATE not null,
  last_update_date               DATE not null,
  is_use_axi                     VARCHAR2(6),
  tace_priority_host             NUMBER(3),
  tace_priority_naf              NUMBER(3),
  tace_priority_od               NUMBER(3),
  tace_priority_sita             NUMBER(3),
  tace_priority_comp             NUMBER(3),
  flight_combine_flag            VARCHAR2(10),
  break_point                    VARCHAR2(10),
  filter_flight                  VARCHAR2(20),
  filter_flight_step2            VARCHAR2(6),
  filter_addon                   VARCHAR2(20),
  filter_addon_step2             VARCHAR2(6),
  cs_use_tace                    VARCHAR2(6),
  filter_codeshare               VARCHAR2(10),
  filter_same_carrier_codeshare  VARCHAR2(6),
  filter_other_carrier           VARCHAR2(6),
  tace_routing                   NUMBER(3),
  fs_use_tace                    VARCHAR2(6),
  is_od_use_airport              VARCHAR2(6),
  description                    VARCHAR2(100),
  od_end_on_end                  VARCHAR2(6),
  od_end_on_end_timeout          NUMBER(11),
  negologic                      VARCHAR2(20),
  filter_yy_fare                 VARCHAR2(6),
  iata_no                        VARCHAR2(20),
  is_brand_multi_avopt           VARCHAR2(6),
  cat35_all_type                 VARCHAR2(6),
  is_use_routing_prefer          VARCHAR2(6),
  rfs_ip_product                 VARCHAR2(200) not null,
  rfs_ip_backup                  VARCHAR2(200),
  av_filter_offset               NUMBER(3),
  filter_av_strict_by_date       VARCHAR2(6),
  primary_flight_rule            VARCHAR2(10),
  max_cartesion_class            NUMBER(3),
  cs_combine_flag                VARCHAR2(20),
  brand_apply_scope              VARCHAR2(10),
  max_computed_trips             NUMBER(4),
  fs_max_tps                     NUMBER(7,2),
  cs_max_tps                     NUMBER(7,2),
  fs_max_requests_daily          NUMBER(4),
  cs_max_requests_daily          NUMBER(4),
  is_use_temp_commission_engine  VARCHAR2(6),
  is_use_duration_shopping       VARCHAR2(6),
  ds_max_window                  NUMBER(3),
  ds_duration_range              NUMBER(3),
  fs_use_fuzzy_query             VARCHAR2(6),
  fuzzy_query_time_range         NUMBER(4),
  use_hot_city                   VARCHAR2(6),
  use_acc_travel                 VARCHAR2(6),
  max_vcabins_when_av_given      NUMBER(4),
  memcache_summary_percent       NUMBER(4),
  is_use_bbqmrestart             VARCHAR2(6),
  max_channel_tps                NUMBER(7,2),
  max_channel_requests           NUMBER(7,2),
  is_use_agent_cs                VARCHAR2(6),
  is_use_local_matrix            VARCHAR2(6),
  bbqm_availability_sort         VARCHAR2(6),
  is_use_railway_code            VARCHAR2(6),
  matrix_socket_timeout          VARCHAR2(10),
  cabin_combine_mode             VARCHAR2(10),
  use_detailrule                 VARCHAR2(7),
  max_trip_number_per_matrix_req NUMBER(4),
  bbqm_limit_alternates          NUMBER(4),
  bbqm_limit_total_segments      NUMBER(4),
  bbqm_max_groups_number         NUMBER(4),
  bbqm_number_per_group          NUMBER(4),
  tace_option                    VARCHAR2(6),
  max_seg_number_per_av_request  NUMBER(4),
  av_stopover_option             VARCHAR2(6),
  max_flight_combines            NUMBER(6),
  is_new_client                  VARCHAR2(6),
  is_use_asi                     VARCHAR2(6),
  is_use_oc                      VARCHAR2(6),
  is_use_public_fare_cache       VARCHAR2(6),
  candidate_online_trip          NUMBER(4),
  candidate_interline_trip       NUMBER(4),
  candidate_rbd_num              NUMBER(4),
  matrix_break_point_flag        VARCHAR2(9),
  is_pre_filter                  VARCHAR2(9),
  debugrecord_effective_date     DATE,
  debugrecord_discontinue_date   DATE,
  is_use_multi_iata              VARCHAR2(6),
  brand_entry_form               VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SHOPPER_CONFIG_3
prompt ===================================
prompt
create table FCIMS.FSI_SHOPPER_CONFIG_3
(
  client                         VARCHAR2(10) not null,
  channel                        VARCHAR2(10),
  carrier                        VARCHAR2(6),
  max_routings                   NUMBER(3),
  max_same_routings              NUMBER(3),
  max_connections                NUMBER(3),
  max_journeys                   NUMBER(3),
  max_physical_cabins            NUMBER(3),
  max_virtual_cabins             NUMBER(3),
  fs_max_responses               NUMBER(3),
  cs_max_ow_windows              NUMBER(3),
  cs_max_rt_windows              NUMBER(3),
  cabin_upsell                   VARCHAR2(6),
  cabin_downsell                 VARCHAR2(6),
  fs_use_interline               VARCHAR2(6),
  cs_use_interline               VARCHAR2(6),
  fs_use_cache                   VARCHAR2(20),
  cs_use_cache                   VARCHAR2(20),
  effective_date                 DATE not null,
  discontinue_date               DATE not null,
  last_update_date               DATE not null,
  is_use_axi                     VARCHAR2(6),
  tace_priority_host             NUMBER(3),
  tace_priority_naf              NUMBER(3),
  tace_priority_od               NUMBER(3),
  tace_priority_sita             NUMBER(3),
  tace_priority_comp             NUMBER(3),
  flight_combine_flag            VARCHAR2(10),
  break_point                    VARCHAR2(10),
  filter_flight                  VARCHAR2(20) default ('Y'),
  filter_flight_step2            VARCHAR2(6) default ('Y'),
  filter_addon                   VARCHAR2(20) default ('Y'),
  filter_addon_step2             VARCHAR2(6) default ('Y'),
  is_od_use_airport              VARCHAR2(6),
  cs_use_tace                    VARCHAR2(6),
  filter_codeshare               VARCHAR2(10),
  filter_same_carrier_codeshare  VARCHAR2(6),
  filter_other_carrier           VARCHAR2(6),
  tace_routing                   NUMBER(3),
  fs_use_tace                    VARCHAR2(6),
  description                    VARCHAR2(100),
  negologic                      VARCHAR2(20),
  od_end_on_end                  VARCHAR2(6),
  od_end_on_end_timeout          NUMBER(11),
  filter_yy_fare                 VARCHAR2(6),
  iata_no                        VARCHAR2(20),
  is_brand_multi_avopt           VARCHAR2(6),
  cat35_all_type                 VARCHAR2(6),
  is_use_routing_prefer          VARCHAR2(6),
  av_filter_offset               NUMBER(3),
  rfs_ip_product                 VARCHAR2(200) default ('10.6.137.118:9111') not null,
  rfs_ip_backup                  VARCHAR2(200),
  filter_av_strict_by_date       VARCHAR2(6),
  primary_flight_rule            VARCHAR2(10),
  max_cartesion_class            NUMBER(3),
  cs_combine_flag                VARCHAR2(20),
  brand_apply_scope              VARCHAR2(10),
  max_computed_trips             NUMBER(4),
  fs_max_tps                     NUMBER(7,2),
  cs_max_tps                     NUMBER(7,2),
  fs_max_requests_daily          NUMBER(4),
  cs_max_requests_daily          NUMBER(4),
  is_use_temp_commission_engine  VARCHAR2(6),
  use_acc_travel                 VARCHAR2(6),
  is_use_duration_shopping       VARCHAR2(6),
  ds_max_window                  NUMBER(3),
  ds_duration_range              NUMBER(3),
  fs_use_fuzzy_query             VARCHAR2(6),
  fuzzy_query_time_range         NUMBER(4),
  use_hot_city                   VARCHAR2(6),
  max_vcabins_when_av_given      NUMBER(4),
  memcache_summary_percent       NUMBER(4),
  is_use_bbqmrestart             VARCHAR2(6),
  is_use_agent_cs                VARCHAR2(6),
  is_use_local_matrix            VARCHAR2(6),
  bbqm_availability_sort         VARCHAR2(6),
  max_channel_tps                NUMBER(7,2),
  max_channel_requests           NUMBER(7,2),
  is_use_railway_code            VARCHAR2(6),
  matrix_socket_timeout          VARCHAR2(10),
  cabin_combine_mode             VARCHAR2(10),
  use_detailrule                 VARCHAR2(7),
  max_trip_number_per_matrix_req NUMBER(4),
  bbqm_limit_alternates          NUMBER(4),
  bbqm_limit_total_segments      NUMBER(4),
  bbqm_max_groups_number         NUMBER(4),
  bbqm_number_per_group          NUMBER(4),
  tace_option                    VARCHAR2(6),
  max_seg_number_per_av_request  NUMBER(6),
  av_stopover_option             VARCHAR2(6),
  max_flight_combines            NUMBER(6),
  is_new_client                  VARCHAR2(6),
  is_use_asi                     VARCHAR2(6),
  is_use_oc                      VARCHAR2(6),
  is_use_public_fare_cache       VARCHAR2(6),
  candidate_online_trip          NUMBER(4),
  candidate_interline_trip       NUMBER(4),
  candidate_rbd_num              NUMBER(4),
  matrix_break_point_flag        VARCHAR2(9),
  is_pre_filter                  VARCHAR2(9),
  last_update_by                 VARCHAR2(10),
  debugrecord_effective_date     DATE,
  debugrecord_discontinue_date   DATE,
  is_use_multi_iata              VARCHAR2(6),
  brand_entry_form               VARCHAR2(6),
  av_use_seamless                VARCHAR2(6) default 'N'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SHOPPER_CONFIG_TEST
prompt ======================================
prompt
create table FCIMS.FSI_SHOPPER_CONFIG_TEST
(
  client              VARCHAR2(10) not null,
  channel             VARCHAR2(10),
  carrier             VARCHAR2(6),
  max_routings        NUMBER(3),
  max_same_routings   NUMBER(3),
  max_connections     NUMBER(3),
  max_journeys        NUMBER(3),
  max_physical_cabins NUMBER(3),
  max_virtual_cabins  NUMBER(3),
  fs_max_responses    NUMBER(3),
  cs_max_ow_windows   NUMBER(3),
  cs_max_rt_windows   NUMBER(3),
  cabin_upsell        VARCHAR2(6),
  cabin_downsell      VARCHAR2(6),
  fs_use_interline    VARCHAR2(6),
  cs_use_interline    VARCHAR2(6),
  fs_use_cache        VARCHAR2(6),
  cs_use_cache        VARCHAR2(6),
  is_use_tace         VARCHAR2(6),
  effective_date      DATE not null,
  discontinue_date    DATE not null,
  last_update_date    DATE not null,
  is_use_axi          VARCHAR2(6),
  tace_priority_host  NUMBER(3),
  tace_priority_naf   NUMBER(3),
  tace_priority_od    NUMBER(3),
  tace_priority_sita  NUMBER(3),
  tace_priority_comp  NUMBER(3),
  flight_combine_flag VARCHAR2(10),
  break_point         VARCHAR2(10),
  filter_flight       VARCHAR2(6) default ('Y'),
  filter_flight_step2 VARCHAR2(6) default ('Y'),
  filter_addon        VARCHAR2(6) default ('Y'),
  filter_addon_step2  VARCHAR2(6) default ('Y'),
  rfs_ip_product      VARCHAR2(200) default ('10.6.137.118:9111/10.6.137.132:9111') not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SHOPPER_RECV
prompt ===============================
prompt
create table FCIMS.FSI_SHOPPER_RECV
(
  client                         VARCHAR2(10) not null,
  channel                        VARCHAR2(10),
  carrier                        VARCHAR2(6),
  max_routings                   NUMBER(3),
  max_same_routings              NUMBER(3),
  max_connections                NUMBER(3),
  max_journeys                   NUMBER(3),
  max_physical_cabins            NUMBER(3),
  max_virtual_cabins             NUMBER(3),
  fs_max_responses               NUMBER(3),
  cs_max_ow_windows              NUMBER(3),
  cs_max_rt_windows              NUMBER(3),
  cabin_upsell                   VARCHAR2(6),
  cabin_downsell                 VARCHAR2(6),
  fs_use_interline               VARCHAR2(6),
  cs_use_interline               VARCHAR2(6),
  fs_use_cache                   VARCHAR2(20),
  cs_use_cache                   VARCHAR2(20),
  is_use_tace                    VARCHAR2(6),
  effective_date                 DATE not null,
  discontinue_date               DATE not null,
  last_update_date               DATE not null,
  is_use_axi                     VARCHAR2(6),
  tace_priority_host             NUMBER(3),
  tace_priority_naf              NUMBER(3),
  tace_priority_od               NUMBER(3),
  tace_priority_sita             NUMBER(3),
  tace_priority_comp             NUMBER(3),
  flight_combine_flag            VARCHAR2(10),
  break_point                    VARCHAR2(10),
  filter_flight                  VARCHAR2(20),
  filter_flight_step2            VARCHAR2(6),
  filter_addon                   VARCHAR2(20),
  filter_addon_step2             VARCHAR2(6),
  cs_use_tace                    VARCHAR2(6),
  filter_codeshare               VARCHAR2(10),
  filter_same_carrier_codeshare  VARCHAR2(6),
  filter_other_carrier           VARCHAR2(6),
  tace_routing                   NUMBER(3),
  is_simple_brand                VARCHAR2(6),
  calendar_combine_logic         VARCHAR2(10),
  fs_use_tace                    VARCHAR2(6),
  is_od_use_airport              VARCHAR2(6),
  description                    VARCHAR2(100),
  od_end_on_end                  VARCHAR2(6),
  od_end_on_end_timeout          NUMBER(11),
  negologic                      VARCHAR2(20),
  filter_yy_fare                 VARCHAR2(6),
  iata_no                        VARCHAR2(20),
  is_brand_multi_avopt           VARCHAR2(6),
  cat35_all_type                 VARCHAR2(6),
  is_use_routing_prefer          VARCHAR2(6),
  rfs_ip_product                 VARCHAR2(200) not null,
  rfs_ip_backup                  VARCHAR2(200),
  av_filter_offset               NUMBER(3),
  filter_av_strict_by_date       VARCHAR2(6),
  primary_flight_rule            VARCHAR2(10),
  max_cartesion_class            NUMBER(3),
  cs_combine_flag                VARCHAR2(20),
  brand_apply_scope              VARCHAR2(10),
  max_computed_trips             NUMBER(4),
  fs_max_tps                     NUMBER(7,2),
  cs_max_tps                     NUMBER(7,2),
  fs_max_requests_daily          NUMBER(4),
  cs_max_requests_daily          NUMBER(4),
  is_use_temp_commission_engine  VARCHAR2(6),
  is_use_duration_shopping       VARCHAR2(6),
  ds_max_window                  NUMBER(3),
  ds_duration_range              NUMBER(3),
  fs_use_fuzzy_query             VARCHAR2(6),
  fuzzy_query_time_range         NUMBER(4),
  use_hot_city                   VARCHAR2(6),
  use_acc_travel                 VARCHAR2(6),
  max_vcabins_when_av_given      NUMBER(4),
  memcache_summary_percent       NUMBER(4),
  is_use_bbqmrestart             VARCHAR2(6),
  max_channel_tps                NUMBER(7,2),
  max_channel_requests           NUMBER(7,2),
  is_use_agent_cs                VARCHAR2(6),
  is_use_local_matrix            VARCHAR2(6),
  bbqm_availability_sort         VARCHAR2(6),
  is_use_railway_code            VARCHAR2(6),
  matrix_socket_timeout          VARCHAR2(10),
  cabin_combine_mode             VARCHAR2(10),
  use_detailrule                 VARCHAR2(7),
  max_trip_number_per_matrix_req NUMBER(4),
  bbqm_limit_alternates          NUMBER(4),
  bbqm_limit_total_segments      NUMBER(4),
  bbqm_max_groups_number         NUMBER(4),
  bbqm_number_per_group          NUMBER(4),
  tace_option                    VARCHAR2(6),
  max_seg_number_per_av_request  NUMBER(4),
  av_stopover_option             VARCHAR2(6)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SHOP_END_ON_END
prompt ==================================
prompt
create table FCIMS.FSI_SHOP_END_ON_END
(
  carrier          VARCHAR2(6) not null,
  ori              VARCHAR2(6) not null,
  des              VARCHAR2(6) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SPA_CARRIER
prompt ==============================
prompt
create table FCIMS.FSI_SPA_CARRIER
(
  carrier          VARCHAR2(6) not null,
  spa_carrier      VARCHAR2(6) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_SUB_CODE_TO_SSR
prompt ==================================
prompt
create table FCIMS.FSI_SUB_CODE_TO_SSR
(
  carrier_code VARCHAR2(2) not null,
  service_type VARCHAR2(10),
  sub_code     VARCHAR2(3),
  ssr_code     VARCHAR2(10),
  description  VARCHAR2(400)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.FSI_SUB_CODE_TO_SSR.carrier_code
  is '????????';
comment on column FCIMS.FSI_SUB_CODE_TO_SSR.service_type
  is '????????';
comment on column FCIMS.FSI_SUB_CODE_TO_SSR.sub_code
  is '??????????';
comment on column FCIMS.FSI_SUB_CODE_TO_SSR.description
  is '????';

prompt
prompt Creating table FSI_TPM
prompt ======================
prompt
create table FCIMS.FSI_TPM
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  low_city              VARCHAR2(5) not null,
  high_city             VARCHAR2(5) not null,
  global_ind            VARCHAR2(2) not null,
  mileage               NUMBER(5) not null,
  eff_date              DATE not null,
  disc_date             DATE not null,
  last_update_user      VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date      DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.FSI_TPM
  add constraint PK_TPM primary key (LOW_CITY, HIGH_CITY, GLOBAL_IND, EFF_DATE, DISC_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FSI_ZONE
prompt =======================
prompt
create table FCIMS.FSI_ZONE
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  zone_no               VARCHAR2(3) not null,
  zone_desc             VARCHAR2(3) not null,
  zone_include          VARCHAR2(60),
  sub_area              VARCHAR2(30),
  parent_zone_no        VARCHAR2(3),
  cancel                VARCHAR2(1),
  last_update_user      VARCHAR2(32) default 'travelsky_fetcher' not null,
  last_update_date      DATE default sysdate not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.FSI_ZONE.data_ind
  is '''x'' = invalid data';
comment on column FCIMS.FSI_ZONE.zone_no
  is '��ţ��������ַ���ʽ���';
comment on column FCIMS.FSI_ZONE.zone_desc
  is 'tc1, tc2 or tc3';
comment on column FCIMS.FSI_ZONE.zone_include
  is '�����ı�';
alter table FCIMS.FSI_ZONE
  add constraint PK_FSI_ZONE primary key (ZONE_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FUELTAX_JOB
prompt ==========================
prompt
create table FCIMS.FUELTAX_JOB
(
  start_date   DATE,
  status       NUMBER(1),
  update_count NUMBER(10),
  limit1       NUMBER(11,2),
  limit2       NUMBER(11,2),
  update_date  DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GDS_NOTICE
prompt =========================
prompt
create table FCIMS.GDS_NOTICE
(
  notice_type       VARCHAR2(1),
  carrier_code      VARCHAR2(2),
  location_code     VARCHAR2(3),
  ref_no            VARCHAR2(15),
  fare_rec_no       NUMBER(15),
  sub_fare_rec_no   NUMBER(5),
  office_no         VARCHAR2(6),
  ori_code          VARCHAR2(3),
  dest_code         VARCHAR2(3),
  journey_type      VARCHAR2(2),
  booking_class     VARCHAR2(1),
  fare_basis        VARCHAR2(15),
  amount            NUMBER(11,3),
  effective_date    DATE,
  discontinue_date  DATE,
  first_travel_date DATE,
  last_travel_date  DATE,
  when_last_update  DATE,
  flag              NUMBER(1),
  process_status    NUMBER(1),
  process_time      DATE,
  user_id           VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GDS_NOTICE_CONFIG
prompt ================================
prompt
create table FCIMS.GDS_NOTICE_CONFIG
(
  user_name        VARCHAR2(100),
  user_id          VARCHAR2(20) not null,
  office_code      VARCHAR2(6) not null,
  effective_date   DATE default to_date('1900-01-01','yyyy-mm-dd'),
  last_update_by   VARCHAR2(20),
  last_update_date DATE default (SYSDATE)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.GDS_NOTICE_CONFIG
  add constraint FCIMS_PK_GDS_NOTICE_CONFIG primary key (OFFICE_CODE, USER_ID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HOST_INS_CARR_MAPPING
prompt ====================================
prompt
create table FCIMS.HOST_INS_CARR_MAPPING
(
  carr_code         VARCHAR2(5) not null,
  oper_code         NUMBER(6) not null,
  reissue_oper_code NUMBER(6) default 0 not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 448K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.HOST_INS_CARR_MAPPING
  add constraint PK_HOST_INS_CARR_MAPPING primary key (CARR_CODE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HOT_CITY_PAIR
prompt ============================
prompt
create table FCIMS.HOT_CITY_PAIR
(
  city1            VARCHAR2(6) not null,
  city2            VARCHAR2(6) not null,
  time_out         NUMBER(10),
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IATA_AGENCY
prompt ==========================
prompt
create table FCIMS.IATA_AGENCY
(
  office      VARCHAR2(8) not null,
  system      VARCHAR2(2) not null,
  iata_number VARCHAR2(8) not null,
  agent_code  VARCHAR2(8) not null,
  pat_flag    NUMBER(1) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null,
  attribute1  VARCHAR2(20),
  attribute2  VARCHAR2(20),
  attribute3  VARCHAR2(20),
  attribute4  VARCHAR2(20),
  attribute5  VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IATA_AGENCY
  add constraint PK_IATA_AGENCY primary key (OFFICE, SYSTEM)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 768K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IATA_AGENCY111
prompt =============================
prompt
create table FCIMS.IATA_AGENCY111
(
  office      VARCHAR2(8) not null,
  system      VARCHAR2(2) not null,
  iata_number VARCHAR2(8) not null,
  agent_code  VARCHAR2(8) not null,
  pat_flag    NUMBER(1) not null,
  create_by   VARCHAR2(20) not null,
  update_by   VARCHAR2(20) not null,
  create_date DATE not null,
  update_date DATE not null,
  attribute1  VARCHAR2(20),
  attribute2  VARCHAR2(20),
  attribute3  VARCHAR2(20),
  attribute4  VARCHAR2(20),
  attribute5  VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_FARE_FLIGHT_IN
prompt ==================================
prompt
create table FCIMS.IFIM_FARE_FLIGHT_IN
(
  pax_rule_code VARCHAR2(10) not null,
  carr_code     VARCHAR2(3) not null,
  flight_start  NUMBER(4) not null,
  flight_end    NUMBER(4)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_FARE_FLIGHT_IN_EXC
prompt ======================================
prompt
create table FCIMS.IFIM_FARE_FLIGHT_IN_EXC
(
  pax_rule_code VARCHAR2(10) not null,
  carr_code     VARCHAR2(3) not null,
  flight_start  NUMBER(4) not null,
  flight_end    NUMBER(4)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_FARE_FLIGHT_OUT
prompt ===================================
prompt
create table FCIMS.IFIM_FARE_FLIGHT_OUT
(
  pax_rule_code VARCHAR2(10) not null,
  carr_code     VARCHAR2(3) not null,
  flight_start  NUMBER(4) not null,
  flight_end    NUMBER(4)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_FARE_FLIGHT_OUT_EXC
prompt =======================================
prompt
create table FCIMS.IFIM_FARE_FLIGHT_OUT_EXC
(
  pax_rule_code VARCHAR2(10) not null,
  carr_code     VARCHAR2(3) not null,
  flight_start  NUMBER(4) not null,
  flight_end    NUMBER(4)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_BATCH
prompt ===========================
prompt
create table FCIMS.IFIM_T_BATCH
(
  file_no          VARCHAR2(30) not null,
  aprv_date        DATE not null,
  adv_to_1         VARCHAR2(3),
  adv_to_2         VARCHAR2(3),
  adv_to_3         VARCHAR2(3),
  adv_to_4         VARCHAR2(3),
  adv_to_5         VARCHAR2(3),
  adv_to_6         VARCHAR2(3),
  adv_to_7         VARCHAR2(3),
  adv_to_8         VARCHAR2(3),
  adv_to_9         VARCHAR2(3),
  adv_to_10        VARCHAR2(3),
  adv_to_11        VARCHAR2(3),
  adv_to_12        VARCHAR2(3),
  adv_to_13        VARCHAR2(3),
  adv_to_14        VARCHAR2(3),
  adv_to_15        VARCHAR2(3),
  adv_to_16        VARCHAR2(3),
  adv_to_17        VARCHAR2(3),
  adv_to_18        VARCHAR2(3),
  adv_to_19        VARCHAR2(3),
  adv_to_20        VARCHAR2(3),
  adv_to_21        VARCHAR2(3),
  adv_to_22        VARCHAR2(3),
  adv_to_23        VARCHAR2(3),
  adv_to_24        VARCHAR2(3),
  adv_to_25        VARCHAR2(3),
  adv_to_26        VARCHAR2(3),
  adv_to_27        VARCHAR2(3),
  adv_to_28        VARCHAR2(3),
  adv_to_29        VARCHAR2(3),
  adv_to_30        VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(30),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_BATCH
  add constraint FCIMS_PK_IFIM_BATCH primary key (FILE_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_ROUT
prompt ==========================
prompt
create table FCIMS.IFIM_T_ROUT
(
  routing_no       NUMBER(12) not null,
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3),
  des_stn          VARCHAR2(3),
  routing_string   VARCHAR2(1000),
  type_of_routing  VARCHAR2(10),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_ROUT
  add constraint FCIMS_PK_IFIM_ROUT primary key (ROUTING_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_ROUTD
prompt ===========================
prompt
create table FCIMS.IFIM_T_ROUTD
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(3) not null,
  rpt_file_no      VARCHAR2(30),
  org_stn          VARCHAR2(3),
  des_stn          VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_ROUTD
  add constraint FCIMS_PK_IFIM_ROUTD primary key (ROUTING_NO, CARR_CODE, S_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_ROUTD
  add constraint FCIMS_FK_IFIM_ROUTD foreign key (ROUTING_NO, CARR_CODE)
  references FCIMS.IFIM_T_ROUT (ROUTING_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table IFIM_T_CARR
prompt ==========================
prompt
create table FCIMS.IFIM_T_CARR
(
  routing_no       NUMBER(12) not null,
  carr_code        VARCHAR2(3) not null,
  s_no             NUMBER(12) not null,
  carrier          VARCHAR2(3) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CARR
  add constraint FCIMS_PK_IFIM_CARR primary key (ROUTING_NO, S_NO, CARR_CODE, CARRIER)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CARR
  add constraint FCIMS_FK_IFIM_CARR foreign key (ROUTING_NO, CARR_CODE, S_NO)
  references FCIMS.IFIM_T_ROUTD (ROUTING_NO, CARR_CODE, S_NO) on delete cascade;

prompt
prompt Creating table IFIM_T_SUBCH
prompt ===========================
prompt
create table FCIMS.IFIM_T_SUBCH
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  priority         VARCHAR2(4) not null,
  title            VARCHAR2(80) not null,
  archv_ind        VARCHAR2(1),
  aprv_ind         VARCHAR2(1),
  rpt_date         DATE,
  aprv_date        DATE,
  sign_by          VARCHAR2(8),
  sub_type         NUMBER(1) not null,
  reason           VARCHAR2(200),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_SUBCH
  add constraint FCIMS_PK_IFIM_SUBCH primary key (RPT_FILE_NO, RPT_FROM)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_CPRPO
prompt ===========================
prompt
create table FCIMS.IFIM_T_CPRPO
(
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(3) not null,
  rpt_date            DATE,
  aprv_date           DATE,
  carr_code           VARCHAR2(3) not null,
  org_stn             VARCHAR2(3) not null,
  des_stn             VARCHAR2(3) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  rmks                VARCHAR2(1000),
  first_transfer_date DATE,
  last_transfer_date  DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(8) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(8) not null,
  attribute1          VARCHAR2(20),
  attribute2          VARCHAR2(20),
  attribute3          VARCHAR2(20),
  attribute4          VARCHAR2(20),
  attribute5          VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRPO
  add constraint FCIMS_PK_IFIM_CPRPO primary key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRPO
  add constraint FCIMS_FK_T_CPRPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_CPRDO
prompt ===========================
prompt
create table FCIMS.IFIM_T_CPRDO
(
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  eff_date         DATE not null,
  wght_rang        VARCHAR2(5) not null,
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRDO
  add constraint FCIMS_PK_IFIM_CPRDO primary key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRDO
  add constraint FCIMS_FK_T_CPRDO foreign key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE)
  references FCIMS.IFIM_T_CPRPO (CARR_CODE, ORG_STN, DES_STN, EFF_DATE) on delete cascade;

prompt
prompt Creating table IFIM_T_CPRPP
prompt ===========================
prompt
create table FCIMS.IFIM_T_CPRPP
(
  file_no             VARCHAR2(30),
  rpt_file_no         VARCHAR2(30) not null,
  rpt_from            VARCHAR2(3) not null,
  rpt_date            DATE,
  aprv_date           DATE,
  carr_code           VARCHAR2(3) not null,
  org_stn             VARCHAR2(3) not null,
  des_stn             VARCHAR2(3) not null,
  eff_date            DATE not null,
  disc_date           DATE not null,
  aprv_ind            VARCHAR2(1),
  archv_ind           VARCHAR2(1),
  rmks                VARCHAR2(1000),
  first_transfer_date DATE,
  last_transfer_date  DATE,
  create_date         DATE not null,
  create_by           VARCHAR2(8) not null,
  last_update_date    DATE not null,
  last_update_by      VARCHAR2(8) not null,
  attribute1          VARCHAR2(20),
  attribute2          VARCHAR2(20),
  attribute3          VARCHAR2(20),
  attribute4          VARCHAR2(20),
  attribute5          VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRPP
  add constraint FCIMS_PK_IFIM_CPRPP primary key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRPP
  add constraint FCIMS_FK_T_CPRPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_CPRDP
prompt ===========================
prompt
create table FCIMS.IFIM_T_CPRDP
(
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  eff_date         DATE not null,
  wght_rang        VARCHAR2(5) not null,
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRDP
  add constraint FCIMS_PK_IFIM_CPRDP primary key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE, WGHT_RANG)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_CPRDP
  add constraint FCIMS_FK_T_CPRDP foreign key (CARR_CODE, ORG_STN, DES_STN, EFF_DATE)
  references FCIMS.IFIM_T_CPRPP (CARR_CODE, ORG_STN, DES_STN, EFF_DATE) on delete cascade;

prompt
prompt Creating table IFIM_T_FROUT
prompt ===========================
prompt
create table FCIMS.IFIM_T_FROUT
(
  fare_no          NUMBER,
  carr_code        VARCHAR2(3) not null,
  rpt_file_no      VARCHAR2(30),
  routing_no       NUMBER(12) not null,
  org_stn          VARCHAR2(3),
  des_stn          VARCHAR2(3),
  routing_string   VARCHAR2(1000),
  type_of_routing  VARCHAR2(10),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_FROUT
  add constraint FCIMS_PK_IFIM_FROUT primary key (ROUTING_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_FROUTD
prompt ============================
prompt
create table FCIMS.IFIM_T_FROUTD
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3),
  des_stn          VARCHAR2(3),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_FROUTD
  add constraint FCIMS_PK_IFIM_FROUTD primary key (ROUTING_NO, CARR_CODE, S_NO)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_FROUTD
  add constraint FCIMS_FK_IFIM_FROUTD foreign key (ROUTING_NO, CARR_CODE)
  references FCIMS.IFIM_T_FROUT (ROUTING_NO, CARR_CODE) on delete cascade;

prompt
prompt Creating table IFIM_T_FCARR
prompt ===========================
prompt
create table FCIMS.IFIM_T_FCARR
(
  routing_no       NUMBER(12) not null,
  s_no             NUMBER(12) not null,
  carr_code        VARCHAR2(3) not null,
  carrier          VARCHAR2(3) not null,
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_FCARR
  add constraint FCIMS_PK_IFIM_FCARR primary key (ROUTING_NO, S_NO, CARR_CODE, CARRIER)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_FCARR
  add constraint FCIMS_FK_IFIM_FCARR foreign key (ROUTING_NO, CARR_CODE, S_NO)
  references FCIMS.IFIM_T_FROUTD (ROUTING_NO, CARR_CODE, S_NO) on delete cascade;

prompt
prompt Creating table IFIM_T_OOCPO
prompt ===========================
prompt
create table FCIMS.IFIM_T_OOCPO
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  oc_type          VARCHAR2(20) not null,
  dsp_type         CHAR(1) not null,
  opr_sym          CHAR(1),
  num_val          NUMBER(12,3),
  rpt_date         DATE,
  aprv_date        DATE,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  rmks             VARCHAR2(1000),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_OOCPO
  add constraint FCIMS_PK_IFIM_OOCPO primary key (OC_TYPE, EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_OOCPO
  add constraint FCIMS_FK_T_OOCPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_OOCPP
prompt ===========================
prompt
create table FCIMS.IFIM_T_OOCPP
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  oc_type          VARCHAR2(20) not null,
  dsp_type         CHAR(1) not null,
  opr_sym          CHAR(1),
  num_val          NUMBER(12,3),
  rpt_date         DATE,
  aprv_date        DATE,
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  rmks             VARCHAR2(1000),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_OOCPP
  add constraint FCIMS_PK_IFIM_OOCPP primary key (OC_TYPE, EFF_DATE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_OOCPP
  add constraint FCIMS_FK_T_OOCPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_PAFPO
prompt ===========================
prompt
create table FCIMS.IFIM_T_PAFPO
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  carr_code        VARCHAR2(3) not null,
  gateway          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  fare_basis       VARCHAR2(15) not null,
  travel_type      VARCHAR2(2) not null,
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  add_on_area      VARCHAR2(10) not null,
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  eff_date         DATE not null,
  disc_date        DATE not null,
  pax_rule_code    VARCHAR2(10) not null,
  gi               VARCHAR2(2),
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PAFPO
  add constraint FCIMS_PK_T_PAFPO primary key (CARR_CODE, GATEWAY, DES_STN, FARE_BASIS, EFF_DATE, TRAVEL_TYPE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PAFPO
  add constraint FCIMS_FK_T_PAFPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_PAFPP
prompt ===========================
prompt
create table FCIMS.IFIM_T_PAFPP
(
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  carr_code        VARCHAR2(3) not null,
  gateway          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  fare_basis       VARCHAR2(15) not null,
  travel_type      VARCHAR2(2) not null,
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  add_on_area      VARCHAR2(10) not null,
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  eff_date         DATE not null,
  disc_date        DATE not null,
  pax_rule_code    VARCHAR2(10) not null,
  gi               VARCHAR2(2),
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PAFPP
  add constraint FCIMS_PK_T_PAFPP primary key (CARR_CODE, GATEWAY, DES_STN, FARE_BASIS, EFF_DATE, TRAVEL_TYPE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PAFPP
  add constraint FCIMS_FK_T_PAFPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_PPFPO
prompt ===========================
prompt
create table FCIMS.IFIM_T_PPFPO
(
  fare_no          NUMBER not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  pax_rule_code    VARCHAR2(10) not null,
  tmp              NUMBER(6) not null,
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  travel_type      VARCHAR2(2),
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  pax_cny_km       NUMBER(5,2),
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  gi               VARCHAR2(2),
  pat_rule_code    VARCHAR2(6),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  mpm              NUMBER(5),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PPFPO
  add constraint FCIMS_PK_IFIM_PPFPO primary key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PPFPO
  add constraint FCIMS_FK_IFIM_PPFPO foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_PPFPP
prompt ===========================
prompt
create table FCIMS.IFIM_T_PPFPP
(
  fare_no          NUMBER not null,
  file_no          VARCHAR2(30),
  rpt_file_no      VARCHAR2(30) not null,
  rpt_from         VARCHAR2(3) not null,
  rpt_date         DATE,
  aprv_date        DATE,
  carr_code        VARCHAR2(3) not null,
  org_stn          VARCHAR2(3) not null,
  des_stn          VARCHAR2(3) not null,
  pax_rule_code    VARCHAR2(10) not null,
  tmp              NUMBER(6) not null,
  fare_basis       VARCHAR2(15) not null,
  fare_type        VARCHAR2(3),
  travel_type      VARCHAR2(2),
  fare             NUMBER(12,3) not null,
  fare1            NUMBER(12,3),
  fare2            NUMBER(12,3),
  pax_cny_km       NUMBER(5,2),
  curr_code        VARCHAR2(3),
  curr_code1       VARCHAR2(3),
  curr_code2       VARCHAR2(3),
  eff_date         DATE not null,
  disc_date        DATE not null,
  aprv_ind         VARCHAR2(1),
  archv_ind        VARCHAR2(1),
  gi               VARCHAR2(2),
  pat_rule_code    VARCHAR2(6),
  rmks             VARCHAR2(1000),
  first_sale_date  DATE,
  last_sale_date   DATE,
  mpm              NUMBER(5),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PPFPP
  add constraint FCIMS_PK_IFIM_PPFPP primary key (FARE_NO, RPT_FILE_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_PPFPP
  add constraint FCIMS_FK_IFIM_PPFPP foreign key (RPT_FILE_NO, RPT_FROM)
  references FCIMS.IFIM_T_SUBCH (RPT_FILE_NO, RPT_FROM) on delete cascade;

prompt
prompt Creating table IFIM_T_RTMP
prompt ==========================
prompt
create table FCIMS.IFIM_T_RTMP
(
  routing_map_no     NUMBER(9) not null,
  carr_code          VARCHAR2(3) not null,
  routing_map_string VARCHAR2(2000),
  create_date        DATE not null,
  create_by          VARCHAR2(8) not null,
  last_update_date   DATE not null,
  last_update_by     VARCHAR2(8) not null,
  attribute1         VARCHAR2(20),
  attribute2         VARCHAR2(20),
  attribute3         VARCHAR2(20),
  attribute4         VARCHAR2(20),
  attribute5         VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 576K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_RTMP
  add constraint FCIMS_PK_IFIM_RTMP primary key (ROUTING_MAP_NO, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IFIM_T_RULE
prompt ==========================
prompt
create table FCIMS.IFIM_T_RULE
(
  pax_rule_code    VARCHAR2(10) not null,
  carr_code        VARCHAR2(3) not null,
  bkg_cls          VARCHAR2(1),
  min_stay         VARCHAR2(4),
  max_stay         VARCHAR2(4),
  adv_purchase     VARCHAR2(4),
  reservation      VARCHAR2(4),
  min_grp_size     VARCHAR2(3),
  eligibility_doc  VARCHAR2(50),
  addon_comb_ind   VARCHAR2(1),
  chd_disc         NUMBER(4,2),
  inf_disc         NUMBER(4,2),
  season_code      VARCHAR2(4),
  from1            DATE,
  from2            DATE,
  from3            DATE,
  from4            DATE,
  from5            DATE,
  to1              DATE,
  to2              DATE,
  to3              DATE,
  to4              DATE,
  to5              DATE,
  day              VARCHAR2(7),
  time_code        VARCHAR2(3),
  from_hour1       NUMBER(4),
  from_hour2       NUMBER(4),
  from_hour3       NUMBER(4),
  from_hour4       NUMBER(4),
  from_hour5       NUMBER(4),
  to_hour1         NUMBER(4),
  to_hour2         NUMBER(4),
  to_hour3         NUMBER(4),
  to_hour4         NUMBER(4),
  to_hour5         NUMBER(4),
  end_rfd_exc1     VARCHAR2(20),
  end_rfd_exc2     VARCHAR2(20),
  end_rfd_exc3     VARCHAR2(20),
  end_rfd_exc4     VARCHAR2(20),
  end_rfd_exc5     VARCHAR2(20),
  end_rfd_exc6     VARCHAR2(20),
  end_rfd_exc7     VARCHAR2(20),
  end_rfd_exc8     VARCHAR2(20),
  end_rfd_exc9     VARCHAR2(20),
  end_rfd_exc10    VARCHAR2(20),
  btw_ind          VARCHAR2(1),
  via_point        VARCHAR2(5),
  stopovers        VARCHAR2(1000),
  oth_rmks         VARCHAR2(2000),
  lock_flag        CHAR(1),
  create_date      DATE not null,
  create_by        VARCHAR2(8) not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(8) not null,
  attribute1       VARCHAR2(20),
  attribute2       VARCHAR2(20),
  attribute3       VARCHAR2(20),
  attribute4       VARCHAR2(20),
  attribute5       VARCHAR2(20)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.IFIM_T_RULE
  add constraint FCIMS_PK_IFIM_RULE primary key (PAX_RULE_CODE, CARR_CODE)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 640K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LATEMEALS
prompt ========================
prompt
create table FCIMS.LATEMEALS
(
  username         VARCHAR2(50) not null,
  work_no          VARCHAR2(6) not null,
  department       VARCHAR2(50) not null,
  apply_date       DATE not null,
  last_update_date DATE not null,
  last_update_by   VARCHAR2(50) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.LATEMEALS
  add constraint MYKEY unique (USERNAME, DEPARTMENT, APPLY_DATE, WORK_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MAIN_TOOL_USER
prompt =============================
prompt
create table FCIMS.MAIN_TOOL_USER
(
  user_id          VARCHAR2(20) not null,
  user_name        VARCHAR2(30) not null,
  user_pwd         VARCHAR2(20) not null,
  user_phone       VARCHAR2(20),
  user_mail        VARCHAR2(20),
  role_type        VARCHAR2(1) not null,
  create_by        VARCHAR2(20),
  create_date      DATE default sysdate,
  last_update_by   VARCHAR2(20),
  last_update_date DATE default sysdate,
  last_login_date  DATE default sysdate
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.MAIN_TOOL_USER
  add constraint PK_MAIN_TOOL_USER primary key (USER_ID)
  using index 
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MULTISECTOR_FARE
prompt ===============================
prompt
create table FCIMS.MULTISECTOR_FARE
(
  carr_cdoe        VARCHAR2(5) not null,
  endorsement      VARCHAR2(255) not null,
  first_flight_no  VARCHAR2(100) not null,
  first_cls_code   VARCHAR2(26) not null,
  discount         NUMBER(3) not null,
  float_discount   NUMBER(4,2) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MULTISECTOR_FARE1
prompt ================================
prompt
create table FCIMS.MULTISECTOR_FARE1
(
  carr_cdoe        VARCHAR2(5) not null,
  endorsement      VARCHAR2(255) not null,
  first_flight_no  VARCHAR2(100) not null,
  first_cls_code   VARCHAR2(26) not null,
  discount         NUMBER(3) not null,
  float_discount   NUMBER(4,2) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MULTI_AIRPORT
prompt ============================
prompt
create table FCIMS.MULTI_AIRPORT
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  airport_code          VARCHAR2(5) not null,
  city_code             VARCHAR2(5) not null,
  domestic_app_ind      NUMBER(1),
  international_app_ind NUMBER(1),
  include_ind           NUMBER(1),
  exclude_ind           NUMBER(1),
  carrier_code          VARCHAR2(3),
  tariff_no             VARCHAR2(3),
  cancel                VARCHAR2(1),
  who_last_update       VARCHAR2(32) not null,
  when_last_update      DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.MULTI_AIRPORT
  add constraint MULTI_AIRPORT_PK primary key (AIRPORT_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OCCS_T_OILINFO_C
prompt ===============================
prompt
create table FCIMS.OCCS_T_OILINFO_C
(
  file_info   VARCHAR2(50) not null,
  inure_date  DATE not null,
  sale_price  NUMBER(11,2) not null,
  oil_unit    VARCHAR2(20) not null,
  currency    VARCHAR2(20) not null,
  m_price     NUMBER(11,2) not null,
  percent     NUMBER(5,2) not null,
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.OCCS_T_OILINFO_C
  add constraint PK_OCCS_T_OILINFO_C primary key (FILE_INFO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OCCS_T_OILINFO_D
prompt ===============================
prompt
create table FCIMS.OCCS_T_OILINFO_D
(
  oc_name        VARCHAR2(50) not null,
  oplace_name    VARCHAR2(50) not null,
  oil_unit       VARCHAR2(20) not null,
  domestic_price NUMBER(11,2),
  import_price   NUMBER(11,2),
  sell_price     NUMBER(11,2),
  other_charge   NUMBER(11,2),
  other_tax      NUMBER(11,2),
  currency       VARCHAR2(20) not null,
  inure_date     DATE not null,
  f_d            CHAR(1) not null,
  airline_name   VARCHAR2(50) not null,
  file_info      VARCHAR2(50) not null,
  memo           VARCHAR2(100),
  create_by      VARCHAR2(8) not null,
  update_by      VARCHAR2(8) not null,
  create_date    DATE not null,
  update_date    DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.OCCS_T_OILINFO_D
  add constraint PRIMARYKEY_OCCS_T_OILINFO_D primary key (FILE_INFO, OC_NAME, OPLACE_NAME, F_D, AIRLINE_NAME)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OCCS_T_OILINFO_F
prompt ===============================
prompt
create table FCIMS.OCCS_T_OILINFO_F
(
  oc_name          VARCHAR2(50) not null,
  oplace_name      VARCHAR2(50) not null,
  oil_unit         VARCHAR2(20) not null,
  currency         VARCHAR2(20) not null,
  inure_date       DATE not null,
  airline_name     VARCHAR2(50) not null,
  tax              NUMBER(11,2),
  sale_price       NUMBER(11,2),
  memo             VARCHAR2(100),
  foil_price       NUMBER(11,2),
  agio_price       NUMBER(11,2),
  equipment_charge NUMBER(11,2),
  oservice_charge  NUMBER(11,2),
  other_charge     NUMBER(11,2),
  create_by        VARCHAR2(8) not null,
  update_by        VARCHAR2(8) not null,
  create_date      DATE not null,
  update_date      DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.OCCS_T_OILINFO_F
  add constraint PRIMARYKEY_OCCS_T_OILINFO_F primary key (OC_NAME, OPLACE_NAME, AIRLINE_NAME, INURE_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OCCS_T_OILINFO_N
prompt ===============================
prompt
create table FCIMS.OCCS_T_OILINFO_N
(
  file_info   VARCHAR2(50) not null,
  inure_date  DATE not null,
  sale_price  NUMBER(11,2) not null,
  oil_unit    VARCHAR2(20) not null,
  currency    VARCHAR2(20) not null,
  memo        VARCHAR2(100),
  create_by   VARCHAR2(8) not null,
  update_by   VARCHAR2(8) not null,
  create_date DATE not null,
  update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.OCCS_T_OILINFO_N
  add constraint PK_OCCS_T_OILINFO_N primary key (FILE_INFO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PASSENGER
prompt ========================
prompt
create table FCIMS.PASSENGER
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  psgr_type_code        VARCHAR2(3) not null,
  psgr_type_desc        VARCHAR2(70) not null,
  default_age           NUMBER(2),
  cat19_cat22           NUMBER(3),
  ptc_disc1             VARCHAR2(3),
  ptc_disc2             VARCHAR2(3),
  ptc_disc3             VARCHAR2(3),
  ptc_disc4             VARCHAR2(3),
  ptc_disc5             VARCHAR2(3),
  ptc_disc6             VARCHAR2(3),
  default_to_adt        VARCHAR2(1),
  ptc_fq1               VARCHAR2(3),
  ptc_fq2               VARCHAR2(3),
  ptc_fq3               VARCHAR2(3),
  ptc_fq4               VARCHAR2(3),
  ptc_fq5               VARCHAR2(3),
  ptc_fq6               VARCHAR2(3),
  child_infant_ind      VARCHAR2(1),
  cancel                VARCHAR2(1),
  who_last_update       VARCHAR2(32) not null,
  when_last_update      DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.PASSENGER
  add constraint PASSENGER_PK primary key (PSGR_TYPE_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PASSENGER_PARENT
prompt ===============================
prompt
create table FCIMS.PASSENGER_PARENT
(
  psgr_type_code        VARCHAR2(3) not null,
  psgr_parent_type_code VARCHAR2(3) not null,
  who_last_update       VARCHAR2(32) not null,
  when_last_update      DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.PASSENGER_PARENT
  add constraint PASSENGER_PARENT_PK primary key (PSGR_TYPE_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PATH
prompt ===================
prompt
create table FCIMS.PATH
(
  pid               VARCHAR2(100) not null,
  coc               VARCHAR2(10) not null,
  coc_type          VARCHAR2(10) not null,
  det               VARCHAR2(10) not null,
  det_type          VARCHAR2(10) not null,
  transfer_one      VARCHAR2(10) not null,
  transfer_one_type VARCHAR2(10) not null,
  transfer_two      VARCHAR2(10),
  transfer_two_type VARCHAR2(10),
  airline_one       VARCHAR2(10) not null,
  airline_two       VARCHAR2(10) not null,
  airline_three     VARCHAR2(10),
  effect_start_date DATE not null,
  effect_stop_date  DATE not null,
  sell_start_date   DATE not null,
  sell_stop_date    DATE not null,
  hashcode          VARCHAR2(100),
  office            VARCHAR2(10),
  client            VARCHAR2(10),
  lastupdateuser    VARCHAR2(100),
  lastupdatetime    DATE,
  flight_one        VARCHAR2(100),
  flight_two        VARCHAR2(100),
  flight_three      VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column FCIMS.PATH.pid
  is 'path��id';
comment on column FCIMS.PATH.coc
  is 'ʼ����';
comment on column FCIMS.PATH.coc_type
  is 'ʼ��������';
comment on column FCIMS.PATH.det
  is 'Ŀ�ĵ�';
comment on column FCIMS.PATH.det_type
  is 'Ŀ�ĵ�����';
comment on column FCIMS.PATH.transfer_one
  is '��ת��һ';
comment on column FCIMS.PATH.transfer_one_type
  is '��ת��һ����';
comment on column FCIMS.PATH.transfer_two
  is '��ת���';
comment on column FCIMS.PATH.transfer_two_type
  is '��ת�������';
comment on column FCIMS.PATH.airline_one
  is '���չ�˾һ';
comment on column FCIMS.PATH.airline_two
  is '���չ�˾��';
comment on column FCIMS.PATH.airline_three
  is '���չ�˾��';
comment on column FCIMS.PATH.effect_start_date
  is '��Ч��ʼʱ��';
comment on column FCIMS.PATH.effect_stop_date
  is '��Ч����ʱ��';
comment on column FCIMS.PATH.sell_start_date
  is '���ۿ�ʼʱ��';
comment on column FCIMS.PATH.sell_stop_date
  is '���۽���ʱ��';
comment on column FCIMS.PATH.hashcode
  is '�����е�hashֵ��Ψһ��ʶ�ö���';
comment on column FCIMS.PATH.office
  is 'office��';
comment on column FCIMS.PATH.client
  is 'ͨ��';
comment on column FCIMS.PATH.lastupdateuser
  is '�޸���';
comment on column FCIMS.PATH.lastupdatetime
  is '�޸�ʱ��';
alter table FCIMS.PATH
  add constraint PK_PATH primary key (PID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PLAN_TABLE
prompt =========================
prompt
create table FCIMS.PLAN_TABLE
(
  statement_id    VARCHAR2(30),
  timestamp       DATE,
  remarks         VARCHAR2(80),
  operation       VARCHAR2(30),
  options         VARCHAR2(30),
  object_node     VARCHAR2(128),
  object_owner    VARCHAR2(30),
  object_name     VARCHAR2(30),
  object_instance INTEGER,
  object_type     VARCHAR2(30),
  optimizer       VARCHAR2(255),
  search_columns  NUMBER,
  id              INTEGER,
  parent_id       INTEGER,
  position        INTEGER,
  cost            INTEGER,
  cardinality     INTEGER,
  bytes           INTEGER,
  other_tag       VARCHAR2(255),
  partition_start VARCHAR2(255),
  partition_stop  VARCHAR2(255),
  partition_id    INTEGER,
  other           LONG,
  distribution    VARCHAR2(30)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PNR_PATH1
prompt ========================
prompt
create table FCIMS.PNR_PATH1
(
  id            NUMBER(12),
  dep_loc       VARCHAR2(3) not null,
  arr_loc       VARCHAR2(3) not null,
  rout_citys    VARCHAR2(80) not null,
  rout_flights  VARCHAR2(60) not null,
  passenger_nbr NUMBER default 0,
  appear_num    NUMBER(1) default 1,
  city_direct   VARCHAR2(1),
  dep_city      VARCHAR2(3),
  arr_city      VARCHAR2(3)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.DEP_ARR1 on FCIMS.PNR_PATH1 (DEP_LOC, ARR_LOC)
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PRICING_COMMON_CONFIG
prompt ====================================
prompt
create table FCIMS.PRICING_COMMON_CONFIG
(
  lookup_type VARCHAR2(30) not null,
  carrier     VARCHAR2(5) not null,
  lookup_code VARCHAR2(20),
  description VARCHAR2(200),
  eff_date    DATE not null,
  disc_date   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_COMMON_CONFIG_INDEX1 on FCIMS.PRICING_COMMON_CONFIG (LOOKUP_TYPE, CARRIER, EFF_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PRICING_CONFIG
prompt =============================
prompt
create table FCIMS.PRICING_CONFIG
(
  user_type        VARCHAR2(20) not null,
  user_code        VARCHAR2(20) not null,
  channel_id       VARCHAR2(20) not null,
  eff_date         DATE not null,
  disc_date        DATE not null,
  office_codes     VARCHAR2(4000),
  iata_numbers     VARCHAR2(4000),
  version          VARCHAR2(20) not null,
  check_pos        NUMBER(1) not null,
  allowed_system1  NUMBER(2),
  allowed_system2  NUMBER(2),
  allowed_system3  NUMBER(2),
  allowed_system4  NUMBER(2),
  allowed_system5  NUMBER(2),
  allowed_system6  NUMBER(2),
  allowed_system7  NUMBER(2),
  allowed_system8  NUMBER(2),
  allowed_system9  NUMBER(2),
  allowed_system10 NUMBER(2)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.PRICING_CONFIG
  add constraint PRICING_CONFIG_UX1 primary key (USER_TYPE, USER_CODE, CHANNEL_ID, EFF_DATE, DISC_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PRICING_LOAD_TIME
prompt ================================
prompt
create table FCIMS.PRICING_LOAD_TIME
(
  no         NUMBER not null,
  start_time DATE not null,
  end_time   DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.PRICING_LOAD_TIME
  add primary key (NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PRICING_REQUEST_REVISE
prompt =====================================
prompt
create table FCIMS.PRICING_REQUEST_REVISE
(
  user_type    VARCHAR2(20) not null,
  user_code    VARCHAR2(20) not null,
  channel_id   VARCHAR2(20) not null,
  request_type NUMBER(2) not null,
  eff_date     DATE not null,
  disc_date    DATE not null,
  op_flag      NUMBER(1),
  op_path      VARCHAR2(300),
  op_old_value VARCHAR2(50),
  op_new_node  VARCHAR2(50),
  op_new_value VARCHAR2(50)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index FCIMS.FCIMS_P_REQUEST_REVISE_INDEX1 on FCIMS.PRICING_REQUEST_REVISE (USER_TYPE, USER_CODE, CHANNEL_ID, REQUEST_TYPE, EFF_DATE, DISC_DATE)
  tablespace FCIMS_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PUB_T_MESSA
prompt ==========================
prompt
create table FCIMS.PUB_T_MESSA
(
  create_date      DATE default SYSDATE not null,
  create_by        VARCHAR2(20) not null,
  last_update_date DATE default SYSDATE not null,
  last_update_by   VARCHAR2(20) not null,
  toid             VARCHAR2(20) not null,
  content          VARCHAR2(4000) not null,
  flag             VARCHAR2(10) not null,
  type             VARCHAR2(20) not null,
  attribute1       VARCHAR2(100),
  attribute2       VARCHAR2(100),
  attribute3       VARCHAR2(100),
  attribute4       VARCHAR2(100),
  attribute5       VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 105M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RBD_RULE
prompt =======================
prompt
create table FCIMS.RBD_RULE
(
  carrier          VARCHAR2(5) not null,
  cabin_class      VARCHAR2(3) not null,
  booking_class    VARCHAR2(3) not null,
  rbd_type         NUMBER(3) not null,
  is_combinable    VARCHAR2(3) not null,
  sequence_no      VARCHAR2(5) not null,
  rbd_apply        VARCHAR2(3) not null,
  effective_date   DATE not null,
  discontinue_date DATE default TO_DATE('2222-01-01', 'YYYY-MM-DD') not null,
  attribute1       VARCHAR2(10),
  attribute2       VARCHAR2(10),
  attribute3       VARCHAR2(10),
  create_date      DATE,
  create_by        VARCHAR2(20) default '1E' not null,
  last_update_date DATE default sysdate not null,
  last_update_by   VARCHAR2(20) default '1E' not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.RBD_RULE
  add constraint PK_RBD_RULE primary key (CARRIER, CABIN_CLASS, BOOKING_CLASS, EFFECTIVE_DATE, RBD_APPLY)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RECORDS10
prompt ========================
prompt
create table FCIMS.RECORDS10
(
  record_type                  VARCHAR2(2) not null,
  carr_cdoe                    VARCHAR2(3) not null,
  service_code                 VARCHAR2(2) not null,
  sub_code                     VARCHAR2(3) not null,
  flt_tkt_mcn                  CHAR(1) not null,
  maintenance_dates_first_last DATE not null,
  ind_cxr                      CHAR(1) not null,
  attributes_group             VARCHAR2(3),
  attributes_subgroup          VARCHAR2(3),
  attributes_description1      VARCHAR2(2),
  attributes_description2      VARCHAR2(2),
  concur                       CHAR(1),
  rfic                         CHAR(1),
  ssr_code                     VARCHAR2(4),
  dispaly_category             NUMBER(2),
  ssim_code                    CHAR(1),
  emd_type                     NUMBER(1) not null,
  booking                      NUMBER(2) not null,
  commercial_name              VARCHAR2(30) not null,
  text_table_no196             NUMBER(8) not null,
  picture_number               NUMBER(8) not null,
  last_update_by               VARCHAR2(20) not null,
  last_update_date             DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RECORDS6
prompt =======================
prompt
create table FCIMS.RECORDS6
(
  carr_cdoe        VARCHAR2(5) not null,
  record_type      VARCHAR2(255) not null,
  first_flight_no  VARCHAR2(100) not null,
  first_cls_code   VARCHAR2(26) not null,
  discount         NUMBER(3) not null,
  float_discount   NUMBER(4,2) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RECORDS8
prompt =======================
prompt
create table FCIMS.RECORDS8
(
  record_type  VARCHAR2(2) not null,
  carr_cdoe    VARCHAR2(3) not null,
  service_code VARCHAR2(2) not null,
  sub_code     VARCHAR2(3) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RECORDS9
prompt =======================
prompt
create table FCIMS.RECORDS9
(
  record_type                  VARCHAR2(2) not null,
  carr_cdoe                    VARCHAR2(3) not null,
  service_code                 VARCHAR2(2) not null,
  sub_code                     VARCHAR2(3) not null,
  flt_tkt_mcn                  CHAR(1) not null,
  maintenance_dates_first_last DATE not null,
  ind_cxr                      CHAR(1) not null,
  attributes_group             VARCHAR2(3),
  attributes_subgroup          VARCHAR2(3),
  attributes_description1      VARCHAR2(2),
  attributes_description2      VARCHAR2(2),
  concur                       CHAR(1),
  rfic                         CHAR(1),
  ssr_code                     VARCHAR2(4),
  dispaly_category             NUMBER(2),
  ssim_code                    CHAR(1),
  emd_type                     NUMBER(1) not null,
  booking                      NUMBER(2) not null,
  commercial_name              VARCHAR2(30) not null,
  text_tableno196              NUMBER(8) not null,
  picture_number               NUMBER(8) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTING
prompt ======================
prompt
create table FCIMS.ROUTING
(
  rid            VARCHAR2(100) not null,
  coc            VARCHAR2(10) not null,
  coc_type       VARCHAR2(10) not null,
  det            VARCHAR2(10) not null,
  det_type       VARCHAR2(10) not null,
  max_routing    VARCHAR2(100) not null,
  same_routing   VARCHAR2(100) not null,
  office         VARCHAR2(10),
  client         VARCHAR2(10),
  lastupdateuser VARCHAR2(100),
  lastupdatetime DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.ROUTING
  add constraint PK_ROUTING primary key (RID)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_COMBINATION_ENTRY
prompt =====================================
prompt
create table FCIMS.RULE_COMBINATION_ENTRY
(
  rule_id              VARCHAR2(13) not null,
  location_code        VARCHAR2(5) not null,
  seq_id               NUMBER(3) not null,
  combine_rule_id      VARCHAR2(13),
  fare_basis           VARCHAR2(15),
  booking_class        VARCHAR2(1),
  last_update_by       VARCHAR2(20) not null,
  last_update_date     DATE not null,
  carrier_code         VARCHAR2(2) default 'CA' not null,
  is_check_all_sectors NUMBER(1) default 1 not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.RULE_COMBINATION_ENTRY
  add constraint RULE_COMBINATION_ENTRY_PK primary key (RULE_ID, LOCATION_CODE, SEQ_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SHOPPER_CONFIG
prompt =============================
prompt
create table FCIMS.SHOPPER_CONFIG
(
  client               VARCHAR2(10) not null,
  channel              VARCHAR2(10),
  carrier              VARCHAR2(6),
  max_routings         NUMBER(3),
  max_same_routings    NUMBER(3),
  max_connections      NUMBER(3),
  max_journeys         NUMBER(3),
  max_physical_cabins  NUMBER(3),
  max_virtual_cabins   NUMBER(3),
  fs_max_responses     NUMBER(3),
  cs_max_ow_windows    NUMBER(3),
  cs_max_rt_windows    NUMBER(3),
  cabin_upsell         VARCHAR2(6),
  cabin_downsell       VARCHAR2(6),
  fs_use_interline     VARCHAR2(6),
  cs_use_interline     VARCHAR2(6),
  fs_use_cache         VARCHAR2(6),
  cs_use_cache         VARCHAR2(6),
  is_use_tace          VARCHAR2(6),
  effective_date       DATE not null,
  discontinue_date     DATE not null,
  last_update_date     DATE not null,
  is_use_axi           VARCHAR2(6),
  tace_priority_host   NUMBER(3),
  tace_priority_naf    NUMBER(3),
  tace_priority_od     NUMBER(3),
  tace_priority_sita   NUMBER(3),
  tace_priority_comp   NUMBER(3),
  flight_combine_flag  VARCHAR2(10),
  break_point          VARCHAR2(10),
  rout_sort_by_primary VARCHAR2(6) default 'N'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SHOP_CLASS_CABIN
prompt ===============================
prompt
create table FCIMS.SHOP_CLASS_CABIN
(
  carr_code        VARCHAR2(5) not null,
  booking_class    VARCHAR2(30) not null,
  cabin            VARCHAR2(20) not null,
  eff_date         DATE not null,
  disc_date        DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI'),
  last_update_date DATE default sysdate,
  last_update_by   VARCHAR2(20) default '1E'
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.SHOP_CLASS_CABIN
  add constraint FIMS_PK_SHOP_CLASS_CABIN primary key (CARR_CODE, BOOKING_CLASS, CABIN, EFF_DATE)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SHOP_END_ON_END
prompt ==============================
prompt
create table FCIMS.SHOP_END_ON_END
(
  carrier          VARCHAR2(6) not null,
  ori              VARCHAR2(6) not null,
  des              VARCHAR2(6) not null,
  effective_date   DATE not null,
  discontinue_date DATE not null,
  last_update_date DATE not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SINGLESECTOR_FARE1
prompt =================================
prompt
create table FCIMS.SINGLESECTOR_FARE1
(
  carr_code        VARCHAR2(5) not null,
  endorsement      VARCHAR2(255) not null,
  first_flight_no  VARCHAR2(100) not null,
  discount         NUMBER(3) not null,
  advance_purchase NUMBER(3) not null,
  sale_eff_date    DATE not null,
  sale_disc_date   DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  travel_eff_date  DATE not null,
  travel_disc_date DATE default TO_DATE('2222-01-01/00:00', 'YYYY-MM-DD/HH24:MI') not null,
  last_update_by   VARCHAR2(20) not null,
  last_update_date DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 3104K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TABLE105
prompt =======================
prompt
create table FCIMS.TABLE105
(
  action           NUMBER(1) not null,
  tbl_id           NUMBER(3) default 105 not null,
  tbl_no           NUMBER(8) not null,
  segment_number   NUMBER(2) not null,
  passenger_type   VARCHAR2(3) not null,
  carrier_code     VARCHAR2(5) not null,
  who_last_update  VARCHAR2(20),
  when_last_update DATE,
  rec_type         NUMBER(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TABLE105
  add constraint TABLE105_PK primary key (REC_TYPE, ACTION, TBL_ID, SEGMENT_NUMBER, TBL_NO, CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TABLE172
prompt =======================
prompt
create table FCIMS.TABLE172
(
  action           NUMBER(1) not null,
  tbl_id           NUMBER(3) default 172 not null,
  tbl_no           NUMBER(8) not null,
  account_code     VARCHAR2(20) not null,
  segment_number   NUMBER(2) not null,
  who_last_update  VARCHAR2(20),
  when_last_update DATE,
  carrier_code     VARCHAR2(5) not null,
  rec_type         NUMBER(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TABLE172
  add constraint TABLE172_PK primary key (REC_TYPE, ACTION, TBL_ID, TBL_NO, SEGMENT_NUMBER, CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TABLE198
prompt =======================
prompt
create table FCIMS.TABLE198
(
  action           NUMBER(1) not null,
  tbl_id           NUMBER(3) default 198 not null,
  tbl_no           NUMBER(8) not null,
  filler1          VARCHAR2(7),
  mkt_op           VARCHAR2(1) not null,
  cxr              VARCHAR2(3) not null,
  rbd1             VARCHAR2(2) not null,
  rbd2             VARCHAR2(2),
  rbd3             VARCHAR2(2),
  rbd4             VARCHAR2(2),
  rbd5             VARCHAR2(2),
  filler2          VARCHAR2(20),
  segment_number   NUMBER(2) not null,
  who_last_update  VARCHAR2(20),
  when_last_update DATE,
  carrier_code     VARCHAR2(5) not null,
  rec_type         NUMBER(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TABLE198
  add constraint TABLE198_PK primary key (REC_TYPE, ACTION, TBL_ID, TBL_NO, SEGMENT_NUMBER, CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TABLE983
prompt =======================
prompt
create table FCIMS.TABLE983
(
  action                   NUMBER(1) not null,
  tbl_id                   NUMBER(3) default 983 not null,
  tbl_no                   NUMBER(8) not null,
  segment_number           NUMBER(4) not null,
  appl                     VARCHAR2(1),
  geo_loc1_type            VARCHAR2(1),
  geo_loc1_spec            VARCHAR2(5),
  geo_loc2_type            VARCHAR2(1),
  geo_loc2_spec            VARCHAR2(5),
  loc_agency_type          VARCHAR2(1),
  loc_agency_code          VARCHAR2(8),
  update_flag              VARCHAR2(1),
  redistribute             VARCHAR2(1),
  sell                     VARCHAR2(1),
  ticket                   VARCHAR2(1),
  changes                  VARCHAR2(1),
  sec_seller_control_id_no VARCHAR2(18),
  who_last_update          VARCHAR2(20),
  when_last_update         DATE,
  carrier_code             VARCHAR2(5) not null,
  rec_type                 NUMBER(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TABLE983
  add constraint TABLE983_PK primary key (REC_TYPE, ACTION, TBL_ID, TBL_NO, SEGMENT_NUMBER, CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TABLE990
prompt =======================
prompt
create table FCIMS.TABLE990
(
  action           NUMBER(1) not null,
  tbl_id           NUMBER(3) default 990 not null,
  tbl_no           NUMBER(8) not null,
  segment_number   NUMBER(2) not null,
  apply_tag        VARCHAR2(1),
  carrier_code     VARCHAR2(5) not null,
  who_last_update  VARCHAR2(20),
  when_last_update DATE,
  rec_type         NUMBER(1) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TABLE990
  add constraint TABLE990_PK primary key (REC_TYPE, ACTION, TBL_ID, TBL_NO, SEGMENT_NUMBER, CARRIER_CODE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TEST
prompt ===================
prompt
create table FCIMS.TEST
(
  a INTEGER
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TEST2
prompt ====================
prompt
create table FCIMS.TEST2
(
  a DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TEST_C
prompt =====================
prompt
create table FCIMS.TEST_C
(
  cmd     VARCHAR2(100),
  sys1    VARCHAR2(10),
  rqtime  DATE,
  pid     VARCHAR2(10),
  iata    VARCHAR2(10),
  office  VARCHAR2(10),
  o       VARCHAR2(10),
  d       VARCHAR2(10),
  carrier VARCHAR2(10),
  date1   DATE
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 16K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TOSF_ROUTINFO
prompt ============================
prompt
create table FCIMS.TOSF_ROUTINFO
(
  appid     VARCHAR2(20) not null,
  sessionid VARCHAR2(61) not null,
  rout      VARCHAR2(10) not null,
  traceflag NUMBER(2) not null,
  appplugin VARCHAR2(1024) not null
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TOSF_ROUTINFO
  add constraint PK_TOSF_ROUTINFO primary key (APPID, SESSIONID)
  disable
  novalidate;

prompt
prompt Creating table TOSF_SYSCODE
prompt ===========================
prompt
create table FCIMS.TOSF_SYSCODE
(
  sys_id   VARCHAR2(10) not null,
  sys_no   NUMBER(2) not null,
  sys_desc VARCHAR2(100)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.TOSF_SYSCODE
  add constraint PK_TOSF_SYSCODE primary key (SYS_ID, SYS_NO)
  using index 
  tablespace FCIMS_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VCPROCESS_CONFIG
prompt ===============================
prompt
create table FCIMS.VCPROCESS_CONFIG
(
  cross_type           NUMBER not null,
  requirement          VARCHAR2(200) not null,
  special_ori_des_type NUMBER,
  special_region       VARCHAR2(500),
  instruction          VARCHAR2(500)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VCSELECTION_CONFIG
prompt =================================
prompt
create table FCIMS.VCSELECTION_CONFIG
(
  selection1  NUMBER,
  selection2  NUMBER,
  selection3  NUMBER,
  selection4  NUMBER,
  selection5  NUMBER,
  selection6  NUMBER,
  selection7  NUMBER,
  selection8  NUMBER,
  selection9  NUMBER,
  selection10 NUMBER,
  selection11 NUMBER,
  selection12 NUMBER,
  eff_date    DATE not null,
  disc_date   DATE not null,
  instruction VARCHAR2(500)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table YAOTT
prompt ====================
prompt
create table FCIMS.YAOTT
(
  office                VARCHAR2(10) not null,
  channel               VARCHAR2(10) not null,
  system_type           VARCHAR2(5) not null,
  is_use_multi_carriers VARCHAR2(6) not null,
  carriers              VARCHAR2(300) not null,
  description           VARCHAR2(200)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table YAOTT1
prompt =====================
prompt
create table FCIMS.YAOTT1
(
  name  CHAR(1),
  grade INTEGER
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table YTT_BRAND_RULE
prompt =============================
prompt
create table FCIMS.YTT_BRAND_RULE
(
  carrier            VARCHAR2(6) not null,
  channel            VARCHAR2(10) not null,
  brand_name         VARCHAR2(100) not null,
  brand_level        NUMBER(10) not null,
  booking_class_list VARCHAR2(100) not null,
  ori                VARCHAR2(20) not null,
  ori_type           VARCHAR2(6) not null,
  des                VARCHAR2(20) not null,
  des_type           VARCHAR2(6) not null,
  direction          VARCHAR2(10) not null,
  combinable         VARCHAR2(10) not null,
  sequence_no        NUMBER(10) not null,
  cabin_name         VARCHAR2(30) not null,
  effective_date     DATE not null,
  discontinue_date   DATE not null,
  last_update_date   DATE not null,
  travel_eff_date    DATE not null,
  travel_dis_date    DATE not null,
  last_update_by     VARCHAR2(10)
)
tablespace FCIMS_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ZONE
prompt ===================
prompt
create table FCIMS.ZONE
(
  record_format_version NUMBER(2),
  issue_date            DATE,
  gfs_id                VARCHAR2(8),
  prod_id               VARCHAR2(8),
  data_ind              VARCHAR2(1),
  zone_no               VARCHAR2(3) not null,
  zone_desc             VARCHAR2(3),
  zone_include          VARCHAR2(60),
  sub_area              VARCHAR2(30),
  parent_zone_no        VARCHAR2(3),
  cancel                VARCHAR2(1),
  who_last_update       VARCHAR2(32) not null,
  when_last_update      DATE not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table FCIMS.ZONE
  add constraint ZONE_PK primary key (ZONE_NO)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating sequence DFIM_S_DIRNO
prompt ==============================
prompt
create sequence FCIMS.DFIM_S_DIRNO
minvalue 1
maxvalue 999999999
start with 57
increment by 1
nocache;

prompt
prompt Creating sequence DFIM_S_FILENO
prompt ===============================
prompt
create sequence FCIMS.DFIM_S_FILENO
minvalue 1
maxvalue 999999999
start with 62
increment by 1
nocache;

prompt
prompt Creating sequence DFIM_S_IMPORT
prompt ===============================
prompt
create sequence FCIMS.DFIM_S_IMPORT
minvalue 1
maxvalue 999999999
start with 19
increment by 1
nocache;

prompt
prompt Creating sequence DFIM_S_IMPORTERR
prompt ==================================
prompt
create sequence FCIMS.DFIM_S_IMPORTERR
minvalue 1
maxvalue 999999999
start with 8
increment by 1
nocache;

prompt
prompt Creating sequence DFIM_S_PSFPP
prompt ==============================
prompt
create sequence FCIMS.DFIM_S_PSFPP
minvalue 1
maxvalue 999999999
start with 2702
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_CARGOCODE
prompt ==================================
prompt
create sequence FCIMS.FPUB_S_CARGOCODE
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_GEN_DISCOUNT
prompt =====================================
prompt
create sequence FCIMS.FPUB_S_GEN_DISCOUNT
minvalue 1
maxvalue 999999999999999
start with 1439
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_HUDISCOUNT
prompt ===================================
prompt
create sequence FCIMS.FPUB_S_HUDISCOUNT
minvalue 1
maxvalue 999999999999999
start with 205
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_MULTISECTOR
prompt ====================================
prompt
create sequence FCIMS.FPUB_S_MULTISECTOR
minvalue 1
maxvalue 999999999999999
start with 1154
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_NAVI_RIGHTS
prompt ====================================
prompt
create sequence FCIMS.FPUB_S_NAVI_RIGHTS
minvalue 0
maxvalue 99999999
start with 32284
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_ROUNDTRIP
prompt ==================================
prompt
create sequence FCIMS.FPUB_S_ROUNDTRIP
minvalue 1
maxvalue 999999999999999
start with 1203
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_RULE_I18N
prompt ==================================
prompt
create sequence FCIMS.FPUB_S_RULE_I18N
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_SHIELDSECTOR
prompt =====================================
prompt
create sequence FCIMS.FPUB_S_SHIELDSECTOR
minvalue 0
maxvalue 999999999999999
start with 12
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_S_SINGLESECTOR
prompt =====================================
prompt
create sequence FCIMS.FPUB_S_SINGLESECTOR
minvalue 1
maxvalue 999999999999999
start with 1451
increment by 1
nocache;

prompt
prompt Creating sequence FPUB_T_PARAMETER_ID_SEQ
prompt =========================================
prompt
create sequence FCIMS.FPUB_T_PARAMETER_ID_SEQ
minvalue 1
maxvalue 999999999
start with 6191
increment by 1
cache 10;

prompt
prompt Creating sequence FSI_SHOPPER_CONFIG_SEQUENCE
prompt =============================================
prompt
create sequence FCIMS.FSI_SHOPPER_CONFIG_SEQUENCE
minvalue 1
maxvalue 999999999999999999999999999
start with 1271
increment by 1
nocache;

prompt
prompt Creating sequence IFIM_S_PPFPP
prompt ==============================
prompt
create sequence FCIMS.IFIM_S_PPFPP
minvalue 1
maxvalue 999999999
start with 111
increment by 1
nocache;

prompt
prompt Creating sequence PLSQL_PROFILER_RUNNUMBER
prompt ==========================================
prompt
create sequence FCIMS.PLSQL_PROFILER_RUNNUMBER
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence PPSERIALNO
prompt ============================
prompt
create sequence FCIMS.PPSERIALNO
minvalue 1
maxvalue 999999999999999999999999999
start with 46
increment by 1
nocache;

prompt
prompt Creating sequence RULE_ID_NO_PUB_SEQ
prompt ====================================
prompt
create sequence FCIMS.RULE_ID_NO_PUB_SEQ
minvalue 1
maxvalue 999999999
start with 241
increment by 1
cache 10;

prompt
prompt Creating sequence RULE_ID_NO_SEQ
prompt ================================
prompt
create sequence FCIMS.RULE_ID_NO_SEQ
minvalue 1
maxvalue 999999999
start with 626501
increment by 1
cache 10;

prompt
prompt Creating sequence SEQ_PATH
prompt ==========================
prompt
create sequence FCIMS.SEQ_PATH
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence SKWC_COST_AIRPORT
prompt ===================================
prompt
create sequence FCIMS.SKWC_COST_AIRPORT
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence TABLE105_NO_SEQ
prompt =================================
prompt
create sequence FCIMS.TABLE105_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 331
increment by 1
nocache;

prompt
prompt Creating sequence TABLE172_NO_SEQ
prompt =================================
prompt
create sequence FCIMS.TABLE172_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 219
increment by 1
nocache;

prompt
prompt Creating sequence TABLE198_NO_SEQ
prompt =================================
prompt
create sequence FCIMS.TABLE198_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 288
increment by 1
nocache;

prompt
prompt Creating sequence TABLE983_NO_SEQ
prompt =================================
prompt
create sequence FCIMS.TABLE983_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 421
increment by 1
nocache;

prompt
prompt Creating sequence TABLE990_NO_SEQ
prompt =================================
prompt
create sequence FCIMS.TABLE990_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 261
increment by 1
nocache;

prompt
prompt Creating sequence TABLE_NO_SEQ
prompt ==============================
prompt
create sequence FCIMS.TABLE_NO_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 9722
increment by 1
nocache;

prompt
prompt Creating sequence TEST_NO
prompt =========================
prompt
create sequence FCIMS.TEST_NO
minvalue 1
maxvalue 999999
start with 1
increment by -1
nocache;

prompt
prompt Creating view FPUB_T_MNG_ROOT
prompt =============================
prompt
create or replace force view fcims.fpub_t_mng_root as
select t."ROOT_NO",t."MY_NO",t."SON_MAXNO",t."LB_NO",t."LB_DESC",t."ZW_TITLE",t."ZW_CONTENT",t."FJ_TITLE",t."FJ_CONTENT",t."FJ_NAME",t."DOT",t."CREATE_DATE",t."CREATE_BY",t."LAST_UPDATE_DATE",t."LAST_UPDATE_BY",t."ATTRIBUTE1",t."ATTRIBUTE2",t."ATTRIBUTE3",t."ATTRIBUTE4",t."ATTRIBUTE5",t1.relation_root_no,t1.relation_my_no,t1.zw_title relation_zw_title 
from fpub_t_informationmanager t,fpub_t_info_root_relation t1
where t.root_no=t1.relation_root_no||t1.relation_my_no;

prompt
prompt Creating procedure ADD_FCIMSDATA
prompt ================================
prompt
create or replace procedure fcims.Add_fcimsdata is

   cursor c_get_city is  
   select * from nfs_gbl.city;
   type t_city is table of varchar2(250) index by binary_integer;
   type t_idate is table of varchar2(250) index by binary_integer;
   type t_fb is table of varchar2(250) index by binary_integer;
 
   v_city t_city;
   v_idate t_idate;
   v_fb t_fb;

   i    integer;
   j    integer;
   l    integer;
   m  integer;
   fare_no integer;
begin
     v_idate(1):='20010101';
     v_idate(2):='20010102';
     v_idate(3):='20010103';
     v_idate(4):='20010104';
     v_idate(5):='20010105';
     v_idate(6):='20010106';
     v_idate(7):='20010107';
     v_idate(8):='20010108';
     v_idate(9):='20010109';
     v_idate(10):='20010110';
     
     v_fb(1):='F';
     v_fb(2):='C';
     v_fb(3):='Y';
     v_fb(4):='Y90';
     v_fb(5):='Y85';
     v_fb(6):='Y80';
     v_fb(7):='Y75';
     v_fb(8):='Y70';
     v_fb(9):='Y65';
     v_fb(10):='Y60';
     
     i := 1;
     for v_get_city in c_get_city loop
         v_city(i):=v_get_city.city_code;
         i:=i+1;
     end loop;

   	 fare_no:=1;
     for j in 1..1000 loop
       insert into FCIMS.DFIM_T_PPFPO (FILE_NO, RPT_FILE_NO, RPT_FROM, RPT_DATE, APRV_DATE, CARR_CODE, ORG_STN, DES_STN, TMP, TRAVEL_TYPE, CURR_CODE, FARE_BASIS, FARE, XBG_RATE, PAX_CNY_KM, EFF_DATE, DISC_DATE, APRV_IND, ARCHV_IND, RMKS, FIRST_SALE_DATE, LAST_SALE_DATE, CREATE_DATE, CREATE_BY, LAST_UPDATE_DATE, LAST_UPDATE_BY)
       values ('CCC', 'ccc', 'CA', to_date('17-02-2003', 'dd-mm-yyyy'), to_date('17-02-2003', 'dd-mm-yyyy'), 'CA', 'BJS', trim(v_city(j)), 1000, '0', 'CNY', 'Y90', 1000, 0, 0, to_date('01-01-2001', 'dd-mm-yyyy'), to_date('01-01-2001', 'dd-mm-yyyy'), 'O', null, null, to_date('17-02-2003', 'dd-mm-yyyy'), to_date('17-02-2003', 'dd-mm-yyyy'), to_date('17-02-2003', 'dd-mm-yyyy'), 'CALMWAVE', to_date('17-02-2003', 'dd-mm-yyyy'), 'CALMWAVE');


       for l in 1..10 loop
	        for m in 1..10 loop
              insert into FCIMS.DFIM_T_PSFPO (FARE_NO, FILE_NO, RPT_FILE_NO, RPT_FROM, RPT_DATE, APRV_DATE, APRV_IND, ARCHV_IND, CARR_CODE, EFF_DATE, DISC_DATE, ORG_STN, DES_STN, TRAVEL_TYPE, FARE_BASIS, FARE_TYPE, CLS_CODE, CURR_CODE, DISC_PER, FIRST_SALE_DATE, LAST_SALE_DATE, RULE_NO, CREATE_DATE, CREATE_BY, LAST_UPDATE_DATE, LAST_UPDATE_BY, SERVICE_CLASS, FARE, FLAG)
              values (fare_no, 'test', 'test', 'CA', to_date('17-02-2003', 'dd-mm-yyyy'), to_date('17-02-2003', 'dd-mm-yyyy'), 'O', 'Y', 'CA', to_date(v_idate(l), 'yyyymmdd'), to_date('31-12-9999', 'dd-mm-yyyy'), 'BJS', trim(v_city(j)), '0', v_fb(m), 'Y', 'Y', 'CNY', 100, to_date('17-02-2003', 'dd-mm-yyyy'), to_date('17-02-2003', 'dd-mm-yyyy'), '0001', to_date('17-02-2003', 'dd-mm-yyyy'), 'CALWMAVE', to_date('17-02-2003', 'dd-mm-yyyy'), 'CALMWAVE', 'Y', null, '0');

              fare_no:=fare_no+1;
          end loop;
       end loop;
       commit;
     end loop;
end Add_fcimsdata;
/

prompt
prompt Creating procedure COPYDOUBLERECORDPSFPP
prompt ========================================
prompt
create or replace procedure fcims.copyDoubleRecordPsfpp(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type;   --1
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_rptFrom dfim_t_psfpo.rpt_from%type;
v_rptDate dfim_t_psfpo.rpt_date%type;  --5
v_aprvDate dfim_t_psfpo.aprv_date%type;
v_aprvInd dfim_t_psfpo.aprv_ind%type;
v_archvInd dfim_t_psfpo.archv_ind%type;
v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;  --10
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_orgCity dfim_t_psfpo.org_city%type;
v_orgFlag dfim_t_psfpo.org_flg%type;
v_desStn dfim_t_psfpo.des_stn%type;  --15
v_desCity dfim_t_psfpo.des_city%type;
v_desFlag dfim_t_psfpo.des_flg%type;
v_travelType dfim_t_psfpo.travel_type%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fareType dfim_t_psfpo.fare_type%type;  --20
v_clsCode dfim_t_psfpo.cls_code%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_firstSaleDate dfim_t_psfpo.first_sale_date%type;
v_lastSaleDate dfim_t_psfpo.last_sale_date%type;  --25
v_ruleNo dfim_t_psfpo.rule_no%type;
v_createDate dfim_t_psfpo.create_date%type;
v_createBy dfim_t_psfpo.create_by%type;
v_lastUpdateDate dfim_t_psfpo.last_update_date%type;
v_lastUpdateBy dfim_t_psfpo.last_update_by%type;  --30
v_serviceClass      dfim_t_psfpo.service_class%type;
v_fare      dfim_t_psfpo.fare%type;
v_flag      dfim_t_psfpo.flag%type;  --33

v_fareno_r dfim_t_psfpo.fare_no%type;
v_rptFileNo_r dfim_t_psfpo.rpt_file_no%type;
v_carrCode_r dfim_t_psfpo.carr_code%type;

v_fareno_routing dfim_t_psfpo.fare_no%type;
v_rptFileNo_routing dfim_t_psfpo.rpt_file_no%type;
v_carrCode_routing dfim_t_psfpo.carr_code%type;


v_maxeffDate dfim_t_psfpo.eff_date%type;
v_maxfareno number;
v_number number;--������

CURSOR C_ALL_NO_FD_PPSPP IS 
select file_no, --1
       fare_no,
       rpt_file_no,
       rpt_from,
       rpt_date, --5
       aprv_date,
       aprv_ind,
       archv_ind,
       carr_code,
       eff_date,  --10
       disc_date,
       org_stn,
       org_city,
       org_flg,
       des_stn,  --15
       des_city,
       des_flg,
       travel_type,
       fare_basis,
       fare_type,  --20
       cls_code,
       curr_code,
       disc_per,
       first_sale_date,
       last_sale_date,  --25
       rule_no,
       create_date,
       create_by,
       last_update_date,
       last_update_by,  --30
       service_class,
       fare,
       flag --33
  from dfim_t_psfpp
where carr_code = 'ZH' 
AND ORG_STN||DES_STN IN 
('CKGKHN','CKGTAO','CKGTSN','CKGTXN','KMGTXN','KMGXMN','LJGKHN','LJGTAO'
,'LJGTXN','NNGKHN','NNGTSN','NNGTXN','NNGTYN'
)
and FILE_NO LIKE 'FD%'
;
  
  
CURSOR C_FIND_REVERSE IS 
SELECT fare_no,rpt_file_no,carr_code 
FROM DFIM_T_PSFPP
WHERE CARR_CODE = v_carrcode 
      AND ORG_STN = v_desstn 
      AND DES_STN = v_orgstn 
      AND CLS_CODE = v_clscode
      AND RULE_NO = v_ruleno
      AND FARE_BASIS = v_farebasis
      AND EFF_DATE = v_effdate
      AND DISC_DATE = v_discdate
      AND TRAVEL_TYPE = v_traveltype;--Ѱ�ҷ����¼�Ƿ���ڣ�

CURSOR C_FIND_MAXFARENO IS       
SELECT MAX(FARE_NO) FROM DFIM_T_PSFPP
WHERE RPT_FILE_NO = v_rptfileno
      and carr_code = v_carrcode;      
      
CURSOR C_FIND_ROUTING IS 
SELECT fare_no,rpt_file_no,carr_code 
FROM DFIM_T_FROUT
WHERE CARR_CODE = v_carrcode 
      AND FARE_NO = v_fareno
      AND RPT_FILE_NO = v_rptfileno;--��ѯ��Ҫ���Ƶ�������¼�Ƿ���ں���      

begin

  OPEN C_ALL_NO_FD_PPSPP;
  FETCH C_ALL_NO_FD_PPSPP into v_fileNo,   --1
                          v_fareNo,  
                          v_rptFileNo, 
                          v_rptFrom ,
                          v_rptDate ,
                          v_aprvDate ,
                          v_aprvInd ,
                          v_archvInd ,
                          v_carrCode ,
                          v_effDate ,
                          v_discDate ,
                          v_orgStn ,
                          v_orgCity ,
                          v_orgFlag ,
                          v_desStn ,
                          v_desCity ,
                          v_desFlag ,
                          v_travelType, 
                          v_fareBasis ,
                          v_fareType ,
                          v_clsCode ,
                          v_currCode ,
                          v_discPer ,
                          v_firstSaleDate, 
                          v_lastSaleDate ,
                          v_ruleNo ,
                          v_createDate,
                          v_createBy,
                          v_lastUpdateDate,
                          v_lastUpdateBy ,
                          v_serviceClass  ,
                          v_fare      ,
                          v_flag ;
  --dbms_output.put_line(v_fileNO);
  WHILE C_ALL_NO_FD_PPSPP%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
    
    open C_FIND_REVERSE;
    FETCH C_FIND_REVERSE into v_fareno_r,v_rptfileno_r,v_carrcode_r;--�Ƿ��з����˼�
    
    IF C_FIND_REVERSE%NOTFOUND THEN--û�з����˼�
     OPEN C_FIND_MAXFARENO;
     FETCH C_FIND_MAXFARENO into v_maxfareno;
     CLOSE C_FIND_MAXFARENO;
     --INSERT PENDING
     insert into DFIM_T_PSFPP VALUES (v_maxfareno+1,v_fileno,v_rptfileno,v_rptfrom,v_rptdate,v_aprvdate,'B',
     v_archvind,v_carrcode,v_effdate,v_discdate,v_desstn,v_descity,v_desflag,v_orgstn,v_orgcity,v_orgflag,v_traveltype,v_farebasis,
     v_faretype,v_clscode,v_currcode,v_discper,v_firstsaledate,v_lastsaledate,v_ruleno,
     v_createdate,v_createby,v_lastupdatedate,v_lastupdateby,v_serviceclass,v_fare,v_flag,'BBBBB');
     --IF v_aprvind = 'O' THEN
        insert into DFIM_T_PSFPO VALUES (v_maxfareno+1,v_fileno,v_rptfileno,v_rptfrom,v_rptdate,v_aprvdate,'B',
        v_archvind,v_carrcode,v_effdate,v_discdate,v_desstn,v_descity,v_desflag,v_orgstn,v_orgcity,v_orgflag,v_traveltype,v_farebasis,
        v_faretype,v_clscode,v_currcode,v_discper,v_firstsaledate,v_lastsaledate,v_ruleno,
        v_createdate,v_createby,v_lastupdatedate,v_lastupdateby,v_serviceclass,v_fare,v_flag,'BBBBB');
     --END IF;
     commit;
     
     --dbms_output.put_line(v_fareno_r||'--'||v_rptfileno_r||'--'||v_carrcode_r);
     --dbms_output.put_line(v_orgstn||v_desstn);
     --dbms_output.put_line(v_fareno||'--'||v_rptfileno||'--'||v_carrcode);
     
    END IF;
    close C_FIND_REVERSE;
    --dbms_output.put_line('-------====-------------');

  FETCH C_ALL_NO_FD_PPSPP into v_fileNo,   --1
                          v_fareNo,  
                          v_rptFileNo, 
                          v_rptFrom ,
                          v_rptDate ,
                          v_aprvDate ,
                          v_aprvInd ,
                          v_archvInd ,
                          v_carrCode ,
                          v_effDate ,
                          v_discDate ,
                          v_orgStn ,
                          v_orgCity ,
                          v_orgFlag ,
                          v_desStn ,
                          v_desCity ,
                          v_desFlag ,
                          v_travelType, 
                          v_fareBasis ,
                          v_fareType ,
                          v_clsCode ,
                          v_currCode ,
                          v_discPer ,
                          v_firstSaleDate, 
                          v_lastSaleDate ,
                          v_ruleNo ,
                          v_createDate,
                          v_createBy,
                          v_lastUpdateDate,
                          v_lastUpdateBy ,
                          v_serviceClass  ,
                          v_fare      ,
                          v_flag ;
  END LOOP;
  --
  CLOSE C_ALL_NO_FD_PPSPP;
  --dbms_output.put_line('errrrrrror!!!');
end copyDoubleRecordPsfpp;
/

prompt
prompt Creating procedure CREATERPTFILENO
prompt ==================================
prompt
create or replace procedure fcims.CREATERPTFILENO(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type;   --1
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_rptFrom dfim_t_psfpo.rpt_from%type;
v_rptDate dfim_t_psfpo.rpt_date%type;  --5
v_aprvDate dfim_t_psfpo.aprv_date%type;
v_aprvInd dfim_t_psfpo.aprv_ind%type;
v_archvInd dfim_t_psfpo.archv_ind%type;
v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;  --10
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_orgCity dfim_t_psfpo.org_city%type;
v_orgFlag dfim_t_psfpo.org_flg%type;
v_desStn dfim_t_psfpo.des_stn%type;  --15
v_desCity dfim_t_psfpo.des_city%type;
v_desFlag dfim_t_psfpo.des_flg%type;
v_travelType dfim_t_psfpo.travel_type%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fareType dfim_t_psfpo.fare_type%type;  --20
v_clsCode dfim_t_psfpo.cls_code%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_firstSaleDate dfim_t_psfpo.first_sale_date%type;
v_lastSaleDate dfim_t_psfpo.last_sale_date%type;  --25
v_ruleNo dfim_t_psfpo.rule_no%type;
v_createDate dfim_t_psfpo.create_date%type;
v_createBy dfim_t_psfpo.create_by%type;
v_lastUpdateDate dfim_t_psfpo.last_update_date%type;
v_lastUpdateBy dfim_t_psfpo.last_update_by%type;  --30
v_serviceClass      dfim_t_psfpo.service_class%type;
v_fare      dfim_t_psfpo.fare%type;
v_flag      dfim_t_psfpo.flag%type;  --33

v_fareno_r dfim_t_psfpo.fare_no%type;
v_rptFileNo_r dfim_t_psfpo.rpt_file_no%type;
v_carrCode_r dfim_t_psfpo.carr_code%type;

v_fareno_routing dfim_t_psfpo.fare_no%type;
v_rptFileNo_routing dfim_t_psfpo.rpt_file_no%type;
v_carrCode_routing dfim_t_psfpo.carr_code%type;

V_NUMBER NUMBER;

CURSOR ATTRIBUTEISNULL IS 
select fare_no,
       rpt_file_no,
       carr_code
  from dfim_t_pNfpP
where carr_code = 'CA' 
AND ATTRIBUTE1 IS NOT NULL;
  
  
CURSOR FIND_EFF_DATE IS 
SELECT EFF_DATE 
FROM DFIM_T_PSFPP
WHERE carr_code = v_carrcode 
      AND fare_no = V_FARENO
      AND rpt_file_no = V_RPTFILENO;--Ѱ�ҷ����¼�Ƿ���ڣ�

begin


     FOR V_NUMBER IN 1..77 LOOP
         --insert into DFIM_T_SUBCH (FILE_NO, RPT_FILE_NO, RPT_FROM, PRIORITY, TITLE, ARCHV_IND, APRV_IND, RPT_DATE, APRV_DATE, SIGN_BY, SUB_TYPE, REASON, CREATE_DATE, CREATE_BY, LAST_UPDATE_DATE, LAST_UPDATE_BY, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3, ATTRIBUTE4, ATTRIBUTE5)
         --values (null, 'MF03011-S-'||TO_CHAR(V_NUMBER), 'MF', '��ͨ', 'ȼ�ͼӼ۵���', 'Y', 'A', to_date('12-12-2003', 'dd-mm-yyyy'), null, '�ƻ���', 1, null, to_date('12-12-2003', 'dd-mm-yyyy'), '8020', to_date('12-12-2003', 'dd-mm-yyyy'), '8020', null, null, null, null, null);
         --UPDATE DFIM_T_PSFPP SET RPT_FILE_NO = 'MF03011-S-'||TO_CHAR(V_NUMBER) WHERE APRV_IND = 'A' AND RPT_FILE_NO = 'MF03011-S' AND ROWNUM <= 50;
         --COMMIT;
         dbms_output.put_line('MF03011-S-'||TO_CHAR(V_NUMBER));
     END LOOP;
         
/*  OPEN ATTRIBUTEISNULL;
  FETCH ATTRIBUTEISNULL into  V_FARENO, V_RPTFILENO, v_carrcode;
  
  WHILE ATTRIBUTEISNULL%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
    open FIND_EFF_DATE;
    FETCH FIND_EFF_DATE into V_EFFDATE;
    update dfim_t_pNfpo set eff_date = v_effdate 
    where carr_code = 'CA' AND ATTRIBUTE1 IS NOT NULL 
    AND FARE_NO = V_FARENO
    AND CARR_CODE = V_CARRCODE
    AND RPT_FILE_NO = V_RPTFILENO;
    
    update dfim_t_pNfpP set eff_date = v_effdate 
    where carr_code = 'CA' AND ATTRIBUTE1 IS NOT NULL 
    AND FARE_NO = V_FARENO
    AND CARR_CODE = V_CARRCODE
    AND RPT_FILE_NO = V_RPTFILENO;  
    COMMIT;  
    
    dbms_output.put_line(v_fareNo||'--'||v_rptFileNo||'--'||v_carrCode||'--'||V_EFFDATE);
    close FIND_EFF_DATE;
    --dbms_output.put_line('-------====-------------');
    FETCH ATTRIBUTEISNULL into  V_FARENO, V_RPTFILENO, v_carrcode;
    END LOOP;
  --
  CLOSE ATTRIBUTEISNULL;
  --dbms_output.put_line('errrrrrror!!!');*/
end CREATERPTFILENO;
/

prompt
prompt Creating procedure FCIMS
prompt ========================
prompt
create or replace procedure fcims.FCIMS is
 p_protocol_header_id csim_t_protocol.protocol_header_id%type;        ----���ڴ���շ���Ŀ
 p_group_number csim_t_protocol.group_number%type;                    ----���ڴ��Э������

 select_ifture_string       varchar2(400);                            ----���ڴ���ж������Ƿ�Ϊ��Ķ�̬sql���
 select_info_string         varchar2(200);                             ----��Ŷ�̬sql��䣬�����������ѯ�����ڼ���ĺ��ද̬����
 insert_sql_string          varchar2(200);                            ----���ڴ�Ų��붯̬sql���
 i                          integer;                                  ----������
 select_ifture_cursor       integer;                                  ----���ڴ�Ŷ�ָ̬������
 select_info_cursor         integer;                                  ----���ڴ�Ŷ�ָ̬������
 insert_sql_cursor          integer;                                  ----���ڴ�Ŷ�ָ̬������
 ignore                     integer;                                  ----���ڴ�Ŷ�̬sql���صĽ��ֵ
 p_count_group              integer;                                  ----���ڴ��ĳ���շ���Ŀ�а�����������ĸ���
 p_count_list               integer;                                  ----���ڴ��ĳ���շ���Ŀ�µ�ĳ�������е���������
 IsTureCount                integer := 0;                             ----���ڼ�¼ĳ���շ���Ŀ�µ�ĳ���������������������
 cal_res                    number(11,2) := 0;                        ----���ڴ�ż�����
 cal_para_value_var         csim_t_takeofflanding.attribute1%type := 1;                                   ----���ڴ�ż��������ʵ��ֵ
------------------------------------------------------------------------------------------------
------------                            �α궨�岿��                             ---------------
------------------------------------------------------------------------------------------------
 cursor csim_get_protocol_group is                             ----ȡ��Э���е��շ���Ŀid�����
    select distinct protocol_header_id
    from csim_t_protocol
    order by protocol_header_id;

 cursor csim_get_protocol_group_detail is                      ----ȡ��ĳ���շ���Ŀ��ĳ������
    select a.calculate_mode,a.cal_parameter_type_id,a.cal_parameter_id,a.com_parameter_type_id,
           a.com_parameter_id,a.start_value,a.start_operation,a.end_value,a.end_operation,
           a.currency_code,a.unit_amount,a.base_amount,a.percent,a.refer_protocol_id,a.refer_protocol_name
    from csim_t_protocol a
    where protocol_header_id = p_protocol_header_id
    and group_number = p_group_number
    order by a.calculate_mode desc;

------------------------------------------------------------------------------------------------
------------                          �ӹ��ܶ��岿��                             ---------------
------------------------------------------------------------------------------------------------
begin
 for v_csim_get_protocol_group in csim_get_protocol_group loop                 ----ȡ���շ���Ŀ

     select count(*)                                                           ----�����ĳ���շ���Ŀ������������ĸ���
     into p_count_group
     from csim_t_protocol
     where protocol_header_id = v_csim_get_protocol_group.protocol_header_id;

     for i in 1..p_count_group loop                                                 ----�����ѭ��
          p_protocol_header_id := v_csim_get_protocol_group.protocol_header_id;
          p_group_number := i;

          select count(*)                                                      ----�����ĳ���շ���Ŀ�µ�ĳ���������������������
          into p_count_list
          from csim_t_protocol
          where protocol_header_id = v_csim_get_protocol_group.protocol_header_id
                and group_number = i;
          IsTureCount := 0;                                                    ----�����������������Ϊ0
          for v_csim_get_protocol_detail in csim_get_protocol_group_detail  loop      ----ȡ�����������������ϸ���ݣ��������ж�
              if v_csim_get_protocol_detail.com_parameter_id = 'null'           ----��������еıȽϲ���Ϊ�յĻ�����������Ϊ��
              and v_csim_get_protocol_detail.com_Parameter_type_id = 'null' then
                      select_ifture_string := 'select 1 from dual';
              end if;
              if v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����Լ��Ƚϲ������Ͷ����ǿյĻ�����Ը����������ж�
              and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null' then
                      select_ifture_string := 'select '||v_csim_get_protocol_detail.com_parameter_id||     ----�ж������Ƿ�����Ķ�̬sql���
                           ' from '||v_csim_get_protocol_detail.com_parameter_type_id||
                           ' where '||v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.start_operation||''''||
                           v_csim_get_protocol_detail.start_value||'''';

                      if v_csim_get_protocol_detail.end_value is not null
                      and v_csim_get_protocol_detail.end_operation is not null then                ----���������е���ֵ����ֵ������
                           select_ifture_string := select_ifture_string||' and '||
                           v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.end_operation||''''||
                           v_csim_get_protocol_detail.end_value||'''';
                      end if;
               end if;
             dbms_output.put_line(to_char(p_group_number)||select_ifture_string);
               if (v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����ͱȽϲ�������һ��Ϊ�գ�һ��
                                                                                   ----��Ϊ�յĻ�������ʾ������������
                  and v_csim_get_protocol_detail.com_Parameter_type_id = 'null') or
                  (v_csim_get_protocol_detail.com_parameter_id = 'null'
                  and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null') then
                  dbms_output.put_line('��Э��������⣡');
               end if;

-----------------------------------                    ִ�ж�̬sql                ----------------------------------
              select_ifture_cursor := dbms_sql.open_cursor;
              dbms_sql.parse(select_ifture_cursor,select_ifture_string,dbms_sql.v7);
              ignore := DBMS_SQL.EXECUTE(select_ifture_cursor);
--------------------------------------------------------------------------------------------------------------------
              if dbms_sql.fetch_rows(select_ifture_cursor)<=0 then                   ----���û�м�¼����,�����Э�����������㣬����Э��Ͷ������㣬���˳�����ѭ��
                                                                                     ----���ٶԸ���Э�����µ����������жϣ�ֱ�ӽ�����һ��Э��
                  exit;
              else
                 IsTureCount := IsTureCount + 1;                                     ----Ϊ�����������ۼ�
                 if v_csim_get_protocol_detail.calculate_mode is not null then       ----�������Ϊ�����У�����calculate_mode��Ϊ�գ�����
                    if v_csim_get_protocol_detail.calculate_mode = 'UNIT' then       ----�����۷�ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.cal_parameter_id||   ----����ѡ���������ʵ��ֵ�Ķ�̬sql���
                                          ' from '||v_csim_get_protocol_detail.cal_parameter_type_id;
                     dbms_output.put_line(to_char(p_group_number)||'s-info '||select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------
                     dbms_output.put_line(to_char(p_group_number)||'c'||to_char(cal_para_value_var)||'*'||to_char(v_csim_get_protocol_detail.unit_amount));
                       cal_res := nvl(cal_para_value_var,0) * v_csim_get_protocol_detail.unit_amount;   ----�������
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                    if v_csim_get_protocol_detail.calculate_mode = 'PERCENT' then                       ----��������ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.refer_protocol_id||  ----����ѡ���ο��շ���Ŀ���Ķ�̬sql���
                                          ' from CSIM_T_TAKEOFFLANDING';
                     dbms_output.put_line(select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------

                       if cal_para_value_var IS NOT NULL THEN                                   ----�жϱ��շ���Ŀ�Ĳο��շ���Ŀ�Ƿ�����
                          cal_res := cal_para_value_var * v_csim_get_protocol_detail.percent;   ----�������
                       else
                          dbms_output.put_line('Procedure test_tutu: ���շ���Ŀ�Ĳο��շ���Ŀ��δ����');
                       end if;
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                 end if;
                 if v_csim_get_protocol_detail.base_amount is not null then                      ----������������
                    cal_res := nvl(cal_res,0)+ v_csim_get_protocol_detail.base_amount;
                 end if;
              end if;
              dbms_sql.close_cursor(select_ifture_cursor);
          end loop;
                 if IsTureCount = p_count_list then                                              ----�����������ȫ�����㣬�򽫼�����ķ���ֵ�����
                                                                                                 ----csim_t_takeofflanding�е���Ӧ����
                    insert_sql_string := 'update csim_t_takeofflanding set '||p_protocol_header_id||
                                         ' = '||to_char(cal_res);
                    insert_sql_cursor := dbms_sql.open_cursor;
                  dbms_output.put_line(to_char(p_group_number)||insert_sql_string);
                    dbms_sql.parse(insert_sql_cursor,insert_sql_string,dbms_sql.v7);
                    ignore := dbms_sql.execute(insert_sql_cursor);
                    commit;
                    dbms_sql.close_cursor(insert_sql_cursor);
                    cal_res := 0;
                 exit;
                 end if;

     end loop;
  end loop;
  exception when others then
    if dbms_sql.is_open(select_ifture_cursor) then
      dbms_sql.close_cursor(select_ifture_cursor);
    end if;
    if dbms_sql.is_open(select_info_cursor) then
      dbms_sql.close_cursor(select_info_cursor);
    end if;
    if dbms_sql.is_open(insert_sql_cursor) then
      dbms_sql.close_cursor(insert_sql_cursor);
    end if;
    raise;

end;
/

prompt
prompt Creating procedure FFCIMS
prompt =========================
prompt
create or replace procedure fcims.FFCIMS is
 p_protocol_header_id CSIM_T_Fprotocol.protocol_header_id%type;        ----���ڴ���շ���Ŀ
 p_group_number CSIM_T_Fprotocol.group_number%type;                    ----���ڴ��Э������

 select_ifture_string       varchar2(400);                            ----���ڴ���ж������Ƿ�Ϊ��Ķ�̬sql���
 select_info_string         varchar2(200);                             ----��Ŷ�̬sql��䣬�����������ѯ�����ڼ���ĺ��ද̬����
 insert_sql_string          varchar2(200);                            ----���ڴ�Ų��붯̬sql���
 i                          integer;                                  ----������
 select_ifture_cursor       integer;                                  ----���ڴ�Ŷ�ָ̬������
 select_info_cursor         integer;                                  ----���ڴ�Ŷ�ָ̬������
 insert_sql_cursor          integer;                                  ----���ڴ�Ŷ�ָ̬������
 ignore                     integer;                                  ----���ڴ�Ŷ�̬sql���صĽ��ֵ
 p_count_group              integer;                                  ----���ڴ��ĳ���շ���Ŀ�а�����������ĸ���
 p_count_list               integer;                                  ----���ڴ��ĳ���շ���Ŀ�µ�ĳ�������е���������
 IsTureCount                integer := 0;                             ----���ڼ�¼ĳ���շ���Ŀ�µ�ĳ���������������������
 cal_res                    number(11,2) := 0;                        ----���ڴ�ż�����
 cal_para_value_var         CSIM_T_Ftakeofflanding.attribute1%type := 1;                                   ----���ڴ�ż��������ʵ��ֵ
------------------------------------------------------------------------------------------------
------------                            �α궨�岿��                             ---------------
------------------------------------------------------------------------------------------------
 cursor csim_get_protocol_group is                             ----ȡ��Э���е��շ���Ŀid�����
    select distinct protocol_header_id
    from CSIM_T_Fprotocol
    order by protocol_header_id;

 cursor csim_get_protocol_group_detail is                      ----ȡ��ĳ���շ���Ŀ��ĳ������
    select a.calculate_mode,a.cal_parameter_type_id,a.cal_parameter_id,a.com_parameter_type_id,
           a.com_parameter_id,a.start_value,a.start_operation,a.end_value,a.end_operation,
           a.currency_code,a.unit_amount,a.base_amount,a.percent,a.refer_protocol_id,a.refer_protocol_name
    from CSIM_T_Fprotocol a
    where protocol_header_id = p_protocol_header_id
    and group_number = p_group_number
    order by a.calculate_mode desc;

------------------------------------------------------------------------------------------------
------------                          �ӹ��ܶ��岿��                             ---------------
------------------------------------------------------------------------------------------------
begin
 for v_csim_get_protocol_group in csim_get_protocol_group loop                 ----ȡ���շ���Ŀ

     select count(*)                                                           ----�����ĳ���շ���Ŀ������������ĸ���
     into p_count_group
     from CSIM_T_Fprotocol
     where protocol_header_id = v_csim_get_protocol_group.protocol_header_id;

     for i in 1..p_count_group loop                                                 ----�����ѭ��
          p_protocol_header_id := v_csim_get_protocol_group.protocol_header_id;
          p_group_number := i;

          select count(*)                                                      ----�����ĳ���շ���Ŀ�µ�ĳ���������������������
          into p_count_list
          from CSIM_T_Fprotocol
          where protocol_header_id = v_csim_get_protocol_group.protocol_header_id
                and group_number = i;
          IsTureCount := 0;                                                    ----�����������������Ϊ0
          for v_csim_get_protocol_detail in csim_get_protocol_group_detail  loop      ----ȡ�����������������ϸ���ݣ��������ж�
              if v_csim_get_protocol_detail.com_parameter_id = 'null'           ----��������еıȽϲ���Ϊ�յĻ�����������Ϊ��
              and v_csim_get_protocol_detail.com_Parameter_type_id = 'null' then
                      select_ifture_string := 'select 1 from dual';
              end if;
              if v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����Լ��Ƚϲ������Ͷ����ǿյĻ�����Ը����������ж�
              and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null' then
                      select_ifture_string := 'select '||v_csim_get_protocol_detail.com_parameter_id||     ----�ж������Ƿ�����Ķ�̬sql���
                           ' from '||v_csim_get_protocol_detail.com_parameter_type_id||
                           ' where '||v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.start_operation||''''||
                           v_csim_get_protocol_detail.start_value||'''';

                      if v_csim_get_protocol_detail.end_value is not null
                      and v_csim_get_protocol_detail.end_operation is not null then                ----���������е���ֵ����ֵ������
                           select_ifture_string := select_ifture_string||' and '||
                           v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.end_operation||''''||
                           v_csim_get_protocol_detail.end_value||'''';
                      end if;
               end if;
             dbms_output.put_line(to_char(p_group_number)||select_ifture_string);
               if (v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����ͱȽϲ�������һ��Ϊ�գ�һ��
                                                                                   ----��Ϊ�յĻ�������ʾ������������
                  and v_csim_get_protocol_detail.com_Parameter_type_id = 'null') or
                  (v_csim_get_protocol_detail.com_parameter_id = 'null'
                  and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null') then
                  dbms_output.put_line('��Э��������⣡');
               end if;

-----------------------------------                    ִ�ж�̬sql                ----------------------------------
              select_ifture_cursor := dbms_sql.open_cursor;
              dbms_sql.parse(select_ifture_cursor,select_ifture_string,dbms_sql.v7);
              ignore := DBMS_SQL.EXECUTE(select_ifture_cursor);
--------------------------------------------------------------------------------------------------------------------
              if dbms_sql.fetch_rows(select_ifture_cursor)<=0 then                   ----���û�м�¼����,�����Э�����������㣬����Э��Ͷ������㣬���˳�����ѭ��
                                                                                     ----���ٶԸ���Э�����µ����������жϣ�ֱ�ӽ�����һ��Э��
                  exit;
              else
                 IsTureCount := IsTureCount + 1;                                     ----Ϊ�����������ۼ�
                 if v_csim_get_protocol_detail.calculate_mode is not null then       ----�������Ϊ�����У�����calculate_mode��Ϊ�գ�����
                    if v_csim_get_protocol_detail.calculate_mode = 'UNIT' then       ----�����۷�ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.cal_parameter_id||   ----����ѡ���������ʵ��ֵ�Ķ�̬sql���
                                          ' from '||v_csim_get_protocol_detail.cal_parameter_type_id;
                     dbms_output.put_line(to_char(p_group_number)||'s-info '||select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------
                     dbms_output.put_line(to_char(p_group_number)||'c'||to_char(cal_para_value_var)||'*'||to_char(v_csim_get_protocol_detail.unit_amount));
                       cal_res := nvl(cal_para_value_var,0) * v_csim_get_protocol_detail.unit_amount;   ----�������
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                    if v_csim_get_protocol_detail.calculate_mode = 'PERCENT' then                       ----��������ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.refer_protocol_id||  ----����ѡ���ο��շ���Ŀ���Ķ�̬sql���
                                          ' from CSIM_T_FTAKEOFFLANDING';
                     dbms_output.put_line(select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------

                       if cal_para_value_var IS NOT NULL THEN                                   ----�жϱ��շ���Ŀ�Ĳο��շ���Ŀ�Ƿ�����
                          cal_res := cal_para_value_var * v_csim_get_protocol_detail.percent;   ----�������
                       else
                          dbms_output.put_line('Procedure test_tutu: ���շ���Ŀ�Ĳο��շ���Ŀ��δ����');
                       end if;
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                 end if;
                 if v_csim_get_protocol_detail.base_amount is not null then                      ----������������
                    cal_res := nvl(cal_res,0)+ v_csim_get_protocol_detail.base_amount;
                 end if;
              end if;
              dbms_sql.close_cursor(select_ifture_cursor);
          end loop;
                 if IsTureCount = p_count_list then                                              ----�����������ȫ�����㣬�򽫼�����ķ���ֵ�����
                                                                                                 ----CSIM_T_Ftakeofflanding�е���Ӧ����
                    insert_sql_string := 'update CSIM_T_Ftakeofflanding set '||p_protocol_header_id||
                                         ' = '||to_char(cal_res);
                    insert_sql_cursor := dbms_sql.open_cursor;
                  dbms_output.put_line(to_char(p_group_number)||insert_sql_string);
                    dbms_sql.parse(insert_sql_cursor,insert_sql_string,dbms_sql.v7);
                    ignore := dbms_sql.execute(insert_sql_cursor);
                    commit;
                    dbms_sql.close_cursor(insert_sql_cursor);
                    cal_res := 0;
                 exit;
                 end if;

     end loop;
  end loop;
  exception when others then
    if dbms_sql.is_open(select_ifture_cursor) then
      dbms_sql.close_cursor(select_ifture_cursor);
    end if;
    if dbms_sql.is_open(select_info_cursor) then
      dbms_sql.close_cursor(select_info_cursor);
    end if;
    if dbms_sql.is_open(insert_sql_cursor) then
      dbms_sql.close_cursor(insert_sql_cursor);
    end if;
    raise;

end;
/

prompt
prompt Creating procedure FILTERHU_PNFPOFARERECORD
prompt ===========================================
prompt
create or replace procedure fcims.filterHU_PNFPOFareRecord as
  
v_orgStn dfim_t_pNfpo.org_stn%type;
v_desStn dfim_t_pNfpo.des_stn%type; 
v_y number;
v_y4 number;
v_y45 number;
v_y55 number;

v_allcount number;
v_count number;
v_number number;
v_number1 number;--������
  
 
cursor c_filterHUFare IS 
select org_stn,des_stn,fare Y,round(fare*0.4,-1) Y4,round(fare*0.45,-1) Y45,round(fare*0.55,-1) Y55 from dfim_t_pnfpo
where carr_code = 'HU'
and eff_date <= to_date('20050315','yyyymmdd')
and disc_date >= to_date('20050315','yyyymmdd');
   
cursor c_count IS 
select count(*) from aabbccddddd;
   
begin

    OPEN c_count;
    FETCH c_count into v_allcount;
    CLOSE c_count;
    
    delete from aabbccddddd_result;
    commit; 
    
    OPEN c_filterHUFare;
    FETCH c_filterHUFare into v_orgStn,v_desStn,v_y,v_y4,v_y45,v_y55;
    FOR v_count in 1..v_allcount LOOP
        

        
        select count(*) into v_number from aabbccddddd_result;
        
        select count(*) into v_number1 from aabbccddddd_result
        where org_stn = v_desstn and des_stn = v_orgstn;
        
        if v_number = 0 or v_number1 = 0 then  
             insert into aabbccddddd_result(org_stn,des_stn,y,y4,y45,y55)
             values(v_orgStn,v_desStn,v_y,v_y4,v_y45,v_y55);
        end if;        
        
        dbms_output.put_line(v_orgStn||v_desStn);
        FETCH c_filterHUFare into v_orgStn,v_desStn,v_y,v_y4,v_y45,v_y55;
    END LOOP;
    CLOSE c_filterHUFare;
    commit;
    --
     
    --dbms_output.put_line(v_fileNo);
    --FETCH c_filterFileNo into v_fileNo;    
  --END LOOP;
  --
  --CLOSE c_filterFileNo;
end filterHU_PNFPOFareRecord;
/

prompt
prompt Creating procedure FILTERPNFPOFARERECORD
prompt ========================================
prompt
create or replace procedure fcims.filterPNFPOFareRecord(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type; 

v_carrCode dfim_t_pNfpo.carr_code%type;
v_effDate dfim_t_pNfpo.eff_date%type;
v_discDate dfim_t_pNfpo.disc_date%type;
v_orgStn dfim_t_pNfpo.org_stn%type;
v_desStn dfim_t_pNfpo.des_stn%type; 
v_fare      dfim_t_pNfpo.fare%type;
v_currCode dfim_t_pNfpo.curr_code%type;
v_fareNo  dfim_t_pNfpo.fare_no%type;
v_rptFileNo dfim_t_pNfpo.rpt_file_no%type;
v_travelType dfim_t_pNfpo.travel_type%type;

v_count number;
v_number number;--������
  
--cursor c_filterFileNo IS 
--  select file_no from dfim_t_psfpo  where file_no like 'FD��������NX-001-000001%' group by file_no;  
 
cursor c_filterFare IS 

  select COUNT(*),CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,NVL(FARE,-1),CURR_CODE,travel_type
  from dfim_t_pNfpo
  group by CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,FARE,CURR_CODE,travel_type
  having count(*)>=2; 
/*  select COUNT(*),CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,NVL(FARE,-1),CURR_CODE,NVL(DISC_PER,-1),travel_type
  from dfim_t_psfpo  where file_no = v_fileNo 
  group by CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,FARE,CURR_CODE,DISC_PER,travel_type; */
  
cursor c_deleteFare IS 
  select FARE_NO,RPT_FILE_NO 
  from dfim_t_pnfpo  
  where CARR_CODE = v_carrCode
    AND EFF_DATE = v_effDate
    AND DISC_DATE = v_discDate
    AND ORG_STN = v_orgStn
    AND DES_STN = v_desStn
    AND NVL(FARE,-1) = v_fare
    AND CURR_CODE = v_currCode
    AND TRAVEL_TYPE = v_travelType;
   
begin
  --dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  /*IF (p_carrCode = '') THEN--OR (p_carrCode = '')) THEN--||) THEN
  --BEGIN
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  --RETURN;
  --dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  END IF;*/
  --��FILE-NO���з���
  --OPEN c_filterFileNo;
  --FETCH c_filterFileNo into v_fileNO;
  --dbms_output.put_line(v_fileNO);
  --WHILE c_filterFileNo%FOUND LOOP
    --ִ�а���FILE-NO�Ĳ�ѯ
    OPEN c_filterFare;
    FETCH c_filterFare into v_count,v_carrCode,v_effDate,v_discDate,v_orgStn,v_desStn,v_fare,v_currCode,v_travelType;
    WHILE c_filterFare%FOUND LOOP
      --dbms_output.put_line('aaaaa'||'--'||v_number||v_rptFileNo||v_fareNo||v_carrCode);                     
      --�ж��Ƿ�Ϊ��������    
      --dbms_output.put_line(v_count);
      IF v_count>1 THEN
        --dbms_output.put_line(v_count||'--'||v_carrCode||'--'||v_effDate||'--'||v_discDate||'--'||v_orgStn||'--'||v_desStn||'--'||v_fare);      
        OPEN c_deleteFare;
        v_number :=0;
        FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        --dbms_output.put_line(v_fareNO||v_rptFileNo);
        WHILE c_deleteFare%FOUND LOOP
          IF v_number <> 0 THEN 
             --dbms_output.put_line('---------');
             dbms_output.put_line('DELETE'||'--'||v_number||v_rptFileNo||v_fareNo||v_carrCode);
             --DELETE FROM DFIM_T_PnFPO WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;  
             --DELETE FROM DFIM_T_PnFPP WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;             
             --commit;
          END IF;
          v_number := v_number+1;
          FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        END LOOP;
        CLOSE c_deleteFare;
                
      END IF;      
      --
    FETCH c_filterFare into v_count,v_carrCode,v_effDate,v_discDate,v_orgStn,v_desStn,v_fare,v_currCode,v_travelType;
    END LOOP;
    CLOSE c_filterFare;
    --
     
    --dbms_output.put_line(v_fileNo);
    --FETCH c_filterFileNo into v_fileNo;    
  --END LOOP;
  --
  --CLOSE c_filterFileNo;
end filterPNFPOFareRecord;
/

prompt
prompt Creating procedure FILTERSFARERECORD
prompt ====================================
prompt
create or replace procedure fcims.filterSFareRecord(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type; 

v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_desStn dfim_t_psfpo.des_stn%type;
v_clsCode dfim_t_psfpo.cls_code%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fare      dfim_t_psfpo.fare%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_travelType dfim_t_psfpo.travel_type%type;

v_count number;
v_number number;--������
  
--cursor c_filterFileNo IS 
--  select file_no from dfim_t_psfpo  where file_no like 'FD��������NX-001-000001%' group by file_no;  
 
cursor c_filterFare IS 

  select COUNT(*),CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,NVL(FARE,-1),CURR_CODE,NVL(DISC_PER,-1),travel_type
  from dfim_t_psfpo  where 
  (carr_code||org_stn||des_stn in 
  (select carr_code||org_stn||des_stn from dfim_t_psfpo t having count(*)>=1 group by carr_code,org_stn,des_stn)) 
  AND carr_code = 'CZ'--AND ORG_STN = 'XMN' AND DES_STN = 'SIA'
  group by CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,FARE,CURR_CODE,DISC_PER,travel_type
  having count(*)>=2; 
/*  select COUNT(*),CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,NVL(FARE,-1),CURR_CODE,NVL(DISC_PER,-1),travel_type
  from dfim_t_psfpo  where file_no = v_fileNo 
  group by CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,CLS_CODE,FARE_BASIS,FARE,CURR_CODE,DISC_PER,travel_type; */
  
cursor c_deleteFare IS 
  select FARE_NO,RPT_FILE_NO 
  from dfim_t_psfpo  
  where CARR_CODE = v_carrCode
    AND EFF_DATE = v_effDate
    AND DISC_DATE = v_discDate
    AND ORG_STN = v_orgStn
    AND DES_STN = v_desStn
    AND CLS_CODE = v_clsCode
    AND FARE_BASIS = v_fareBasis
    AND NVL(FARE,-1) = v_fare
    AND CURR_CODE = v_currCode
    AND NVL(DISC_PER,-1) = v_discPer
    AND TRAVEL_TYPE = v_travelType;
   
begin
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  /*IF (p_carrCode = '') THEN--OR (p_carrCode = '')) THEN--||) THEN
  --BEGIN
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  --RETURN;
  --dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  END IF;*/
  --��FILE-NO���з���
  --OPEN c_filterFileNo;
  --FETCH c_filterFileNo into v_fileNO;
  --dbms_output.put_line(v_fileNO);
  --WHILE c_filterFileNo%FOUND LOOP
    --ִ�а���FILE-NO�Ĳ�ѯ
    OPEN c_filterFare;
    FETCH c_filterFare into v_count,v_carrCode,v_effDate,v_discDate,v_orgStn,v_desStn,v_clsCode,v_fareBasis,v_fare,v_currCode,v_discPer,v_travelType;
    WHILE c_filterFare%FOUND LOOP                     
      --�ж��Ƿ�Ϊ��������    
      --dbms_output.put_line(v_count);
      IF v_count>1 THEN
        --dbms_output.put_line(v_count||'--'||v_carrCode||'--'||v_effDate||'--'||v_discDate||'--'||v_orgStn||'--'||v_desStn||'--'||v_clsCode||'--'||v_fareBasis||'--'||v_fare||'--'||v_currCode);      
        OPEN c_deleteFare;
        v_number :=0;
        FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        --dbms_output.put_line(v_fareNO||v_rptFileNo);
        WHILE c_deleteFare%FOUND LOOP
          IF v_number <> 0 THEN 
             dbms_output.put_line('DELETE'||'--'||v_number);
             --DELETE FROM DFIM_T_PSFPO WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;  
             --DELETE FROM DFIM_T_PSFPP WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;             
             --commit;
          END IF;
          v_number := v_number+1;
          FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        END LOOP;
        CLOSE c_deleteFare;
                
      END IF;      
      --
      FETCH c_filterFare into v_count,v_carrCode,v_effDate,v_discDate,v_orgStn,v_desStn,v_clsCode,v_fareBasis,v_fare,v_currCode,v_discPer,v_travelType;   
    END LOOP;
    CLOSE c_filterFare;
    --
     
    --dbms_output.put_line(v_fileNo);
    --FETCH c_filterFileNo into v_fileNo;    
  --END LOOP;
  --
  --CLOSE c_filterFileNo;
end filterSFareRecord;
/

prompt
prompt Creating procedure FINDREVERSERECORDPNFPP
prompt =========================================
prompt
create or replace procedure fcims.findReverseRecordPnfpp(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type;   --1
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_rptFrom dfim_t_psfpo.rpt_from%type;
v_rptDate dfim_t_psfpo.rpt_date%type;  --5
v_aprvDate dfim_t_psfpo.aprv_date%type;
v_aprvInd dfim_t_psfpo.aprv_ind%type;
v_archvInd dfim_t_psfpo.archv_ind%type;
v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;  --10
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_orgCity dfim_t_psfpo.org_city%type;
v_orgFlag dfim_t_psfpo.org_flg%type;
v_desStn dfim_t_psfpo.des_stn%type;  --15
v_desCity dfim_t_psfpo.des_city%type;
v_desFlag dfim_t_psfpo.des_flg%type;
v_travelType dfim_t_psfpo.travel_type%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fareType dfim_t_psfpo.fare_type%type;  --20
v_clsCode dfim_t_psfpo.cls_code%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_firstSaleDate dfim_t_psfpo.first_sale_date%type;
v_lastSaleDate dfim_t_psfpo.last_sale_date%type;  --25
v_ruleNo dfim_t_psfpo.rule_no%type;
v_createDate dfim_t_psfpo.create_date%type;
v_createBy dfim_t_psfpo.create_by%type;
v_lastUpdateDate dfim_t_psfpo.last_update_date%type;
v_lastUpdateBy dfim_t_psfpo.last_update_by%type;  --30
v_serviceClass      dfim_t_psfpo.service_class%type;
v_fare      dfim_t_psfpo.fare%type;
v_flag      dfim_t_psfpo.flag%type;  --33

v_fareno_r dfim_t_psfpo.fare_no%type;
v_rptFileNo_r dfim_t_psfpo.rpt_file_no%type;
v_carrCode_r dfim_t_psfpo.carr_code%type;

v_fareno_routing dfim_t_psfpo.fare_no%type;
v_rptFileNo_routing dfim_t_psfpo.rpt_file_no%type;
v_carrCode_routing dfim_t_psfpo.carr_code%type;


v_maxeffDate dfim_t_psfpo.eff_date%type;
v_maxfareno number;
v_number number;--������

CURSOR C_ALL_NO_FD_PNFPP IS 
select 
       fare_no,
       rpt_file_no,
       rpt_from,
       aprv_ind,
       carr_code,
       eff_date,  --10
       disc_date,
       org_stn,
       des_stn,  --15
       travel_type,
       curr_code,
       create_date,
       create_by,
       last_update_date,
       last_update_by,  --30
       fare
  from dfim_t_pNfpO
  WHERE DISC_DATE >=TO_DATE('20031215','YYYYMMDD')
  and carr_code = '3U'
/*where carr_code = 'ZH' 
AND ORG_STN||DES_STN IN 
('CKGKHN','CKGTAO','CKGTSN','CKGTXN','KMGTXN','KMGXMN','LJGKHN','LJGTAO'
,'LJGTXN','NNGKHN','NNGTSN','NNGTXN','NNGTYN'
)
and FILE_NO LIKE 'FD%'*/
;
  
  
CURSOR C_FIND_REVERSE IS 
SELECT fare_no,rpt_file_no,carr_code 
FROM DFIM_T_PNFPP
WHERE CARR_CODE = v_carrcode 
      AND ORG_STN = v_desstn 
      AND DES_STN = v_orgstn 
      AND EFF_DATE = v_effdate
      AND DISC_DATE = v_discdate
      AND FARE = V_FARE
      AND TRAVEL_TYPE = v_traveltype;--Ѱ�ҷ����¼�Ƿ���ڣ�
/*
CURSOR C_FIND_MAXFARENO IS       
SELECT MAX(FARE_NO) FROM DFIM_T_PSFPP
WHERE RPT_FILE_NO = v_rptfileno
      and carr_code = v_carrcode;    
      */  
/*      
CURSOR C_FIND_ROUTING IS 
SELECT fare_no,rpt_file_no,carr_code 
FROM DFIM_T_FROUT
WHERE CARR_CODE = v_carrcode 
      AND FARE_NO = v_fareno
      AND RPT_FILE_NO = v_rptfileno;--��ѯ��Ҫ���Ƶ�������¼�Ƿ���ں���      
*/
begin

  OPEN C_ALL_NO_FD_PNFPP;
  FETCH C_ALL_NO_FD_PNFPP into 
                          v_fareNo,  
                          v_rptFileNo, 
                          v_rptFrom ,
                          v_aprvInd ,
                          v_carrCode ,
                          v_effDate ,
                          v_discDate ,
                          v_orgStn ,
                          v_desStn ,
                          v_travelType, 
                          v_currCode ,
                          v_createDate,
                          v_createBy,
                          v_lastUpdateDate,
                          v_lastUpdateBy ,
                          v_fare;  --dbms_output.put_line(v_fileNO);
  WHILE C_ALL_NO_FD_PNFPP%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
    
    open C_FIND_REVERSE;
    FETCH C_FIND_REVERSE into v_fareno_r,v_rptfileno_r,v_carrcode_r;--�Ƿ��з����˼�
    
    IF C_FIND_REVERSE%NOTFOUND THEN--û�з����˼�
         dbms_output.put_line(v_orgstn||v_desstn||V_CARRCODE);
    END IF;
    close C_FIND_REVERSE;
    --dbms_output.put_line('-------====-------------');

  FETCH C_ALL_NO_FD_PNFPP into 
                          v_fareNo,  
                          v_rptFileNo, 
                          v_rptFrom ,
                          v_aprvInd ,
                          v_carrCode ,
                          v_effDate ,
                          v_discDate ,
                          v_orgStn ,
                          v_desStn ,
                          v_travelType, 
                          v_currCode ,
                          v_createDate,
                          v_createBy,
                          v_lastUpdateDate,
                          v_lastUpdateBy ,
                          v_fare;  --dbms_output.put_line(v_fileNO);
  END LOOP;
  --
  CLOSE C_ALL_NO_FD_PNFPP;
  --dbms_output.put_line('errrrrrror!!!');
end findReverseRecordPnfpp;
/

prompt
prompt Creating procedure INSERTVAL
prompt ============================
prompt
CREATE OR REPLACE PROCEDURE FCIMS.insertVal(p_CarrCode  dfim_t_fline.carr_code%TYPE) AS

 CURSOR c_selectFline IS
        SELECT ORIGIN_STN,DESTINATION
        FROM DFIM_T_FLINE
        WHERE CARR_CODE = p_CarrCode
        ORDER BY 1;
 TYPE t_fareBasisRecord IS RECORD(
      v_fareBsis dfim_t_psfpo.fare_basis%TYPE,
      v_discPer  dfim_t_psfpo.disc_per%TYPE
 );
 TYPE t_fareBasis IS TABLE OF t_fareBasisRecord
      INDEX BY BINARY_INTEGER;  
 v_fareBasis t_fareBasis; 
 v_fareBasisRecord t_fareBasisRecord;
 v_orgStn dfim_t_fline.origin_stn%TYPE;
 v_desStn dfim_t_fline.destination%TYPE;
 v_fareNo dfim_t_psfpo.fare_no%TYPE;
 
 v_beginDate dfim_t_psfpo.eff_date%TYPE;
 
 v_loopBeginDate date;
 v_loopEndDate date;
BEGIN

     delete from dfim_t_subch;
     
     v_beginDate := to_date('19970101','YYYYMMDD');
     
     v_fareBasisRecord.v_fareBsis := 'F';
     v_fareBasisRecord.v_discPer := 150;
     v_fareBasis(1) := v_fareBasisRecord;
     
     v_fareBasisRecord.v_fareBsis := 'C';
     v_fareBasisRecord.v_discPer := 120;
     v_fareBasis(2) := v_fareBasisRecord;
          
     v_fareBasisRecord.v_fareBsis := 'Y';
     v_fareBasisRecord.v_discPer := 100;
     v_fareBasis(3) := v_fareBasisRecord;
          
     v_fareBasisRecord.v_fareBsis := 'YB90';
     v_fareBasisRecord.v_discPer := 90;
     v_fareBasis(4) := v_fareBasisRecord;
          
     v_fareBasisRecord.v_fareBsis := 'YB80';
     v_fareBasisRecord.v_discPer := 80;
     v_fareBasis(5) := v_fareBasisRecord;
          
     v_fareBasisRecord.v_fareBsis := 'YB70';
     v_fareBasisRecord.v_discPer := 70;
     v_fareBasis(6) := v_fareBasisRecord;
          
     v_fareBasisRecord.v_fareBsis := 'YB60';
     v_fareBasisRecord.v_discPer := 60;
     v_fareBasis(7) := v_fareBasisRecord;     

   
     
     
     --�������� TEST,CA
     insert into DFIM_T_SUBCH (file_no,RPT_FILE_NO,RPT_FROM,PRIORITY,TITLE,APRV_IND,CREATE_DATE,CREATE_BY,LAST_UPDATE_DATE,LAST_UPDATE_BY) 
     values('AAA','TEST',p_CarrCode,'AAA','TITLE','O',TO_DATE('20021231','YYYYMMDD'),'ZANGL',TO_DATE('20021231','YYYYMMDD'),'ZANG');
     --�����������
     
     --�������˹����˼�
     OPEN c_selectFline;
     FETCH c_selectFline INTO v_orgStn,v_desStn;
     WHILE c_selectFline %FOUND LOOP
         --��������
         DBMS_OUTPUT.PUT_LINE(v_orgStn||'------'||v_desStn);        
         insert into DFIM_T_PPFPO (file_no,RPT_FILE_NO,RPT_FROM,RPT_DATE,APRV_DATE,CARR_CODE,ORG_STN,DES_STN,TMP,TRAVEL_TYPE,FARE_BASIS,FARE,EFF_DATE,DISC_DATE,APRV_IND,CREATE_DATE,CREATE_BY,LAST_UPDATE_DATE,LAST_UPDATE_BY) 
         values('AAA','TEST',p_CarrCode,TO_DATE('20021231','YYYYMMDD'),TO_DATE('20021231','YYYYMMDD'),p_CarrCode,v_orgStn,v_desStn,to_number('1000'),'OW','Y',to_number(1000),TO_DATE('19901231','YYYYMMDD'),TO_DATE('99991231','YYYYMMDD'),'O',TO_DATE('20021231','YYYYMMDD'),'ZANGL',TO_DATE('20021231','YYYYMMDD'),'ZANG');         
         FETCH c_selectFline INTO v_orgStn,v_desStn; 
     END LOOP;
     CLOSE c_selectFline;
     ----�������˹����˼����
     
                                                                                                                                                                                                                                                                                                                                        

     
     FOR v_count IN 1..5 LOOP
     
         v_loopBeginDate := v_beginDate;
         v_loopEndDate := v_beginDate+6;
         
         OPEN c_selectFline;
         FETCH c_selectFline INTO v_orgStn,v_desStn;
                  
         WHILE c_selectFline %FOUND LOOP
         --��������
             --����FAREBASIS
             FOR v_Counter IN v_fareBasis.FIRST..v_fareBasis.LAST LOOP
                 --DBMS_OUTPUT.PUT_LINE(v_fareBasis(v_Counter).v_fareBsis||'---------'||v_fareBasis(v_Counter).v_discPer);
                 select dfim_s_psfpp.nextval into v_fareNo from dual;
                 insert into DFIM_T_PSFPO (fare_no,FILE_NO,RPT_FILE_NO,RPT_FROM,RPT_DATE,APRV_DATE,APRV_IND,CARR_CODE,EFF_DATE,DISC_DATE,ORG_STN,DES_STN,TRAVEL_TYPE,FARE_BASIS,CLS_CODE,DISC_PER,CREATE_DATE,CREATE_BY,LAST_UPDATE_DATE,LAST_UPDATE_BY)
                 values(v_fareNo,'AAA','TEST',p_CarrCode,TO_DATE('20021231','YYYYMMDD'),TO_DATE('20021231','YYYYMMDD'),'O',p_CarrCode,v_loopBeginDate,v_loopEndDate,v_orgStn,v_desStn,'OW',v_fareBasis(v_Counter).v_fareBsis,substr(v_fareBasis(v_Counter).v_fareBsis,1,1),v_fareBasis(v_Counter).v_discPer,TO_DATE('99991231','YYYYMMDD'),'ZANGL',TO_DATE('99991231','YYYYMMDD'),'ZANGL');
             END LOOP;      --v_Counter IN v_fareBasis.FIRST..v_fareBasis.LAST LOOP
             FETCH c_selectFline INTO v_orgStn,v_desStn;
         END LOOP;--WHILE c_selectFline %FOUND LOOP
         
         CLOSE c_selectFline;
         --����FAREBASIS���   
         v_beginDate := v_loopBeginDate+7;
         --�����������
     END LOOP;--FOR v_count IN 1..2 LOOP    
   
     COMMIT;
END insertVal;
/

prompt
prompt Creating procedure KFCIMS
prompt =========================
prompt
create or replace procedure fcims.KFCIMS is
 p_protocol_header_id CSIM_T_Kprotocol.protocol_header_id%type;        ----���ڴ���շ���Ŀ
 p_group_number CSIM_T_Kprotocol.group_number%type;                    ----���ڴ��Э������

 select_ifture_string       varchar2(400);                            ----���ڴ���ж������Ƿ�Ϊ��Ķ�̬sql���
 select_info_string         varchar2(200);                             ----��Ŷ�̬sql��䣬�����������ѯ�����ڼ���ĺ��ද̬����
 insert_sql_string          varchar2(200);                            ----���ڴ�Ų��붯̬sql���
 i                          integer;                                  ----������
 select_ifture_cursor       integer;                                  ----���ڴ�Ŷ�ָ̬������
 select_info_cursor         integer;                                  ----���ڴ�Ŷ�ָ̬������
 insert_sql_cursor          integer;                                  ----���ڴ�Ŷ�ָ̬������
 ignore                     integer;                                  ----���ڴ�Ŷ�̬sql���صĽ��ֵ
 p_count_group              integer;                                  ----���ڴ��ĳ���շ���Ŀ�а�����������ĸ���
 p_count_list               integer;                                  ----���ڴ��ĳ���շ���Ŀ�µ�ĳ�������е���������
 IsTureCount                integer := 0;                             ----���ڼ�¼ĳ���շ���Ŀ�µ�ĳ���������������������
 cal_res                    number(11,2) := 0;                        ----���ڴ�ż�����
 cal_para_value_var         CSIM_T_Ktakeofflanding.attribute1%type := 1;                                   ----���ڴ�ż��������ʵ��ֵ
------------------------------------------------------------------------------------------------
------------                            �α궨�岿��                             ---------------
------------------------------------------------------------------------------------------------
 cursor csim_get_protocol_group is                             ----ȡ��Э���е��շ���Ŀid�����
    select distinct protocol_header_id
    from CSIM_T_Kprotocol
    order by protocol_header_id;

 cursor csim_get_protocol_group_detail is                      ----ȡ��ĳ���շ���Ŀ��ĳ������
    select a.calculate_mode,a.cal_parameter_type_id,a.cal_parameter_id,a.com_parameter_type_id,
           a.com_parameter_id,a.start_value,a.start_operation,a.end_value,a.end_operation,
           a.currency_code,a.unit_amount,a.base_amount,a.percent,a.refer_protocol_id,a.refer_protocol_name
    from CSIM_T_Kprotocol a
    where protocol_header_id = p_protocol_header_id
    and group_number = p_group_number
    order by a.calculate_mode desc;

------------------------------------------------------------------------------------------------
------------                          �ӹ��ܶ��岿��                             ---------------
------------------------------------------------------------------------------------------------
begin
 for v_csim_get_protocol_group in csim_get_protocol_group loop                 ----ȡ���շ���Ŀ

     select count(*)                                                           ----�����ĳ���շ���Ŀ������������ĸ���
     into p_count_group
     from CSIM_T_Kprotocol
     where protocol_header_id = v_csim_get_protocol_group.protocol_header_id;

     for i in 1..p_count_group loop                                                 ----�����ѭ��
          p_protocol_header_id := v_csim_get_protocol_group.protocol_header_id;
          p_group_number := i;

          select count(*)                                                      ----�����ĳ���շ���Ŀ�µ�ĳ���������������������
          into p_count_list
          from CSIM_T_Kprotocol
          where protocol_header_id = v_csim_get_protocol_group.protocol_header_id
                and group_number = i;
          IsTureCount := 0;                                                    ----�����������������Ϊ0
          for v_csim_get_protocol_detail in csim_get_protocol_group_detail  loop      ----ȡ�����������������ϸ���ݣ��������ж�
              if v_csim_get_protocol_detail.com_parameter_id = 'null'           ----��������еıȽϲ���Ϊ�յĻ�����������Ϊ��
              and v_csim_get_protocol_detail.com_Parameter_type_id = 'null' then
                      select_ifture_string := 'select 1 from dual';
              end if;
              if v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����Լ��Ƚϲ������Ͷ����ǿյĻ�����Ը����������ж�
              and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null' then
                      select_ifture_string := 'select '||v_csim_get_protocol_detail.com_parameter_id||     ----�ж������Ƿ�����Ķ�̬sql���
                           ' from '||v_csim_get_protocol_detail.com_parameter_type_id||
                           ' where '||v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.start_operation||''''||
                           v_csim_get_protocol_detail.start_value||'''';

                      if v_csim_get_protocol_detail.end_value is not null
                      and v_csim_get_protocol_detail.end_operation is not null then                ----���������е���ֵ����ֵ������
                           select_ifture_string := select_ifture_string||' and '||
                           v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.end_operation||''''||
                           v_csim_get_protocol_detail.end_value||'''';
                      end if;
               end if;
             dbms_output.put_line(to_char(p_group_number)||select_ifture_string);
               if (v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����ͱȽϲ�������һ��Ϊ�գ�һ��
                                                                                   ----��Ϊ�յĻ�������ʾ������������
                  and v_csim_get_protocol_detail.com_Parameter_type_id = 'null') or
                  (v_csim_get_protocol_detail.com_parameter_id = 'null'
                  and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null') then
                  dbms_output.put_line('��Э��������⣡');
               end if;

-----------------------------------                    ִ�ж�̬sql                ----------------------------------
              select_ifture_cursor := dbms_sql.open_cursor;
              dbms_sql.parse(select_ifture_cursor,select_ifture_string,dbms_sql.v7);
              ignore := DBMS_SQL.EXECUTE(select_ifture_cursor);
--------------------------------------------------------------------------------------------------------------------
              if dbms_sql.fetch_rows(select_ifture_cursor)<=0 then                   ----���û�м�¼����,�����Э�����������㣬����Э��Ͷ������㣬���˳�����ѭ��
                                                                                     ----���ٶԸ���Э�����µ����������жϣ�ֱ�ӽ�����һ��Э��
                  exit;
              else
                 IsTureCount := IsTureCount + 1;                                     ----Ϊ�����������ۼ�
                 if v_csim_get_protocol_detail.calculate_mode is not null then       ----�������Ϊ�����У�����calculate_mode��Ϊ�գ�����
                    if v_csim_get_protocol_detail.calculate_mode = 'UNIT' then       ----�����۷�ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.cal_parameter_id||   ----����ѡ���������ʵ��ֵ�Ķ�̬sql���
                                          ' from '||v_csim_get_protocol_detail.cal_parameter_type_id;
                     dbms_output.put_line(to_char(p_group_number)||'s-info '||select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------
                     dbms_output.put_line(to_char(p_group_number)||'c'||to_char(cal_para_value_var)||'*'||to_char(v_csim_get_protocol_detail.unit_amount));
                       cal_res := nvl(cal_para_value_var,0) * v_csim_get_protocol_detail.unit_amount;   ----�������
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                    if v_csim_get_protocol_detail.calculate_mode = 'PERCENT' then                       ----��������ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.refer_protocol_id||  ----����ѡ���ο��շ���Ŀ���Ķ�̬sql���
                                          ' from CSIM_T_KTAKEOFFLANDING';
                     dbms_output.put_line(select_info_string);
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------

                       if cal_para_value_var IS NOT NULL THEN                                   ----�жϱ��շ���Ŀ�Ĳο��շ���Ŀ�Ƿ�����
                          cal_res := cal_para_value_var * v_csim_get_protocol_detail.percent;   ----�������
                       else
                          dbms_output.put_line('Procedure test_tutu: ���շ���Ŀ�Ĳο��շ���Ŀ��δ����');
                       end if;
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                 end if;
                 if v_csim_get_protocol_detail.base_amount is not null then                      ----������������
                    cal_res := nvl(cal_res,0)+ v_csim_get_protocol_detail.base_amount;
                 end if;
              end if;
              dbms_sql.close_cursor(select_ifture_cursor);
          end loop;
                 if IsTureCount = p_count_list then                                              ----�����������ȫ�����㣬�򽫼�����ķ���ֵ�����
                                                                                                 ----CSIM_T_Ktakeofflanding�е���Ӧ����
                    insert_sql_string := 'update CSIM_T_Ktakeofflanding set '||p_protocol_header_id||
                                         ' = '||to_char(cal_res);
                    insert_sql_cursor := dbms_sql.open_cursor;
                  dbms_output.put_line(to_char(p_group_number)||insert_sql_string);
                    dbms_sql.parse(insert_sql_cursor,insert_sql_string,dbms_sql.v7);
                    ignore := dbms_sql.execute(insert_sql_cursor);
                    commit;
                    dbms_sql.close_cursor(insert_sql_cursor);
                    cal_res := 0;
                 exit;
                 end if;

     end loop;
  end loop;
  exception when others then
    if dbms_sql.is_open(select_ifture_cursor) then
      dbms_sql.close_cursor(select_ifture_cursor);
    end if;
    if dbms_sql.is_open(select_info_cursor) then
      dbms_sql.close_cursor(select_info_cursor);
    end if;
    if dbms_sql.is_open(insert_sql_cursor) then
      dbms_sql.close_cursor(insert_sql_cursor);
    end if;
    raise;

end;
/

prompt
prompt Creating procedure PROFIR
prompt =========================
prompt
create or replace procedure fcims.profir(v_cmd varchar2,v_sys varchar2,v_iata varchar2,v_office varchar2)
    as
      v_startTime date;
      v_endTime date;
      v_tempTime date;
      v_count number(20);
      v_start varchar2(100);
      v_end varchar2(100);
    begin
      v_startTime:=to_date('2014/7/24 00:00:00','yyyy/mm/dd hh24:mi:ss');
      v_tempTime:=v_startTime;
      v_endTime :=to_date('2014/7/25 00:00:00','yyyy/mm/dd hh24:mi:ss');

      while v_startTime<=v_endTime loop
        if v_iata is null and v_office is null then
            select count(*) into v_count from test_c where rqtime between v_startTime and v_startTime+(1/24/2) and cmd=v_cmd and sys1=v_sys;
        elsif v_office is null then
            select count(*) into v_count from test_c where rqtime between v_startTime and v_startTime+(1/24/2) and cmd=v_cmd and sys1=v_sys and iata=v_iata;
        elsif v_iata is null then
            select count(*) into v_count from test_c where rqtime between v_startTime and v_startTime+(1/24/2) and cmd=v_cmd and sys1=v_sys and office=v_office;
        else
           select count(*) into v_count from test_c where rqtime between v_startTime and v_startTime+(1/24/2) and cmd=v_cmd and sys1=v_sys and iata=v_iata and office=v_office;
        end if;
        v_tempTime:=v_startTime+(1/24/2);
        v_start:=to_char(v_startTime,'hh24:mi:ss');
        v_end:=to_char(v_tempTime,'hh24:mi:ss');
        dbms_output.put_line(v_start||'--'||v_end||':'||v_count);
        v_startTime:=v_startTime+(1/24/2);
      end loop;
    end;
/

prompt
prompt Creating procedure RECOVEREFFDATE
prompt =================================
prompt
create or replace procedure fcims.RECOVEREFFDATE(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type;   --1
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_rptFrom dfim_t_psfpo.rpt_from%type;
v_rptDate dfim_t_psfpo.rpt_date%type;  --5
v_aprvDate dfim_t_psfpo.aprv_date%type;
v_aprvInd dfim_t_psfpo.aprv_ind%type;
v_archvInd dfim_t_psfpo.archv_ind%type;
v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;  --10
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_orgCity dfim_t_psfpo.org_city%type;
v_orgFlag dfim_t_psfpo.org_flg%type;
v_desStn dfim_t_psfpo.des_stn%type;  --15
v_desCity dfim_t_psfpo.des_city%type;
v_desFlag dfim_t_psfpo.des_flg%type;
v_travelType dfim_t_psfpo.travel_type%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fareType dfim_t_psfpo.fare_type%type;  --20
v_clsCode dfim_t_psfpo.cls_code%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_firstSaleDate dfim_t_psfpo.first_sale_date%type;
v_lastSaleDate dfim_t_psfpo.last_sale_date%type;  --25
v_ruleNo dfim_t_psfpo.rule_no%type;
v_createDate dfim_t_psfpo.create_date%type;
v_createBy dfim_t_psfpo.create_by%type;
v_lastUpdateDate dfim_t_psfpo.last_update_date%type;
v_lastUpdateBy dfim_t_psfpo.last_update_by%type;  --30
v_serviceClass      dfim_t_psfpo.service_class%type;
v_fare      dfim_t_psfpo.fare%type;
v_flag      dfim_t_psfpo.flag%type;  --33

v_fareno_r dfim_t_psfpo.fare_no%type;
v_rptFileNo_r dfim_t_psfpo.rpt_file_no%type;
v_carrCode_r dfim_t_psfpo.carr_code%type;

v_fareno_routing dfim_t_psfpo.fare_no%type;
v_rptFileNo_routing dfim_t_psfpo.rpt_file_no%type;
v_carrCode_routing dfim_t_psfpo.carr_code%type;

CURSOR ATTRIBUTEISNULL IS 
select fare_no,
       rpt_file_no,
       carr_code
  from dfim_t_pNfpP
where carr_code = 'HU' 
AND ATTRIBUTE1 IS NOT NULL;
  
  
CURSOR FIND_EFF_DATE IS 
SELECT EFF_DATE 
FROM DFIM_T_PSFPP
WHERE carr_code = v_carrcode 
      AND fare_no = V_FARENO
      AND rpt_file_no = V_RPTFILENO;--Ѱ�ҷ����¼�Ƿ���ڣ�

begin

  OPEN ATTRIBUTEISNULL;
  FETCH ATTRIBUTEISNULL into  V_FARENO, V_RPTFILENO, v_carrcode;
  
  WHILE ATTRIBUTEISNULL%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
    open FIND_EFF_DATE;
    FETCH FIND_EFF_DATE into V_EFFDATE;
    
    update dfim_t_pNfpo set eff_date = v_effdate 
    where carr_code = 'HU' AND ATTRIBUTE1 IS NOT NULL 
    AND FARE_NO = V_FARENO
    AND CARR_CODE = V_CARRCODE
    AND RPT_FILE_NO = V_RPTFILENO;
    
    update dfim_t_pNfpP set eff_date = v_effdate 
    where carr_code = 'HU' AND ATTRIBUTE1 IS NOT NULL 
    AND FARE_NO = V_FARENO
    AND CARR_CODE = V_CARRCODE
    AND RPT_FILE_NO = V_RPTFILENO;  
    COMMIT;  
    
    dbms_output.put_line(v_fareNo||'--'||v_rptFileNo||'--'||v_carrCode||'--'||V_EFFDATE);
    close FIND_EFF_DATE;
    --dbms_output.put_line('-------====-------------');
    FETCH ATTRIBUTEISNULL into  V_FARENO, V_RPTFILENO, v_carrcode;
    END LOOP;
  --
  CLOSE ATTRIBUTEISNULL;
  --dbms_output.put_line('errrrrrror!!!');
end RECOVEREFFDATE;
/

prompt
prompt Creating procedure SCRECORD
prompt ===========================
prompt
create or replace procedure fcims.SCRECORD(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type; 

v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;
v_maxeffDate dfim_t_psfpo.eff_date%type;
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_desStn dfim_t_psfpo.des_stn%type;
v_clsCode dfim_t_psfpo.cls_code%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fare      dfim_t_psfpo.fare%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_travelType dfim_t_psfpo.travel_type%type;

v_count number;
v_number number;--������

CURSOR C_DISTINCT_ORGDES IS 
SELECT DISTINCT ORG_STN,DES_STN FROM DFIM_T_PSFPO
WHERE FLAG = 0 and carr_code = 'FM' and rpt_file_no = 'FD��������FM' 
AND DISC_PER IS NOT NULL;
--AND FARE = 0;--and org_stn = 'CAN'and des_stn = 'HAK' ;
  
CURSOR c_DESC_PER IS 
SELECT RPT_FILE_NO,CARR_CODE,FARE_NO 
FROM DFIM_T_PSFPO
WHERE CARR_CODE = 'FM' AND ORG_STN = v_orgstn AND DES_STN = v_desstn 
AND RPT_FILE_NO = 'FD��������FM' AND FLAG = 0
and disc_per is not null;

 
cursor c_findmaxEffdate IS 
select  max(eff_date) from DFIM_T_PSFPO  
where carr_code = 'FM' --AND FARE IS NULL --
AND fare_basis IN ('YB','Y-B','YB(CAAC)')
and rpt_file_no = 'FD��������FM'
and org_stn = v_orgstn
and des_stn = v_desstn
GROUP BY org_stn,des_stn;

cursor c_findmaxMoney IS 
select  fare from DFIM_T_PSFPO  
where carr_code = 'FM' --AND FARE IS NULL --
AND fare_basis  IN ('YB','Y-B','YB(CAAC)') 
and rpt_file_no = 'FD��������FM'
and org_stn = v_orgstn
and des_stn = v_desstn
and eff_date = v_maxeffdate;  

  

   
begin

  OPEN C_DISTINCT_ORGDES;
  FETCH C_DISTINCT_ORGDES into v_orgStn,v_desstn;
  --dbms_output.put_line(v_fileNO);
  WHILE C_DISTINCT_ORGDES%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
    
    open c_findmaxEffdate;
    FETCH c_findmaxEffdate into v_maxeffdate;--�ҵ�������Ч����
    close c_findmaxEffdate;
    
    --if (v_maxeffdate = null) then
    
    --end if;
    v_fare := 0;
    open c_findmaxMoney;
    FETCH c_findmaxMoney into v_fare;--�ҵ�������Ч���ڵ�Ǯ��
    close c_findmaxMoney;  
    --IF (v_fare = null)then
    dbms_output.put_line('errrrrrror!!!'||v_orgstn||v_desstn||v_fare);
    --end if ;
    --if (v_fare = 0) then
    --dbms_output.put_line('errrrrrror!!!'||v_orgstn||v_desstn||v_fare);  
    --end if;
    --dbms_output.put_line(v_fare||'-----'||v_maxeffdate); 
    --dbms_output.put_line(v_fare);
    
    OPEN c_DESC_PER;
    FETCH c_DESC_PER into v_rptfileno,v_carrCode,v_fareno;
    WHILE c_DESC_PER%FOUND LOOP  
      --dbms_output.put_line(v_rptfileno||v_carrCode||v_fareno);  
      
/*update DFIM_T_PSFPP set fare = trunc((v_fare*(disc_per/100))+5,-1),flag=1--,disc_per=null 
where rpt_file_no = 'FD��ʷ����CZ' and flag = 0 and carr_code = 'CZ'
and rpt_file_no = v_rptfileno and fare_no = v_fareno;
COMMIT;*/
      
       FETCH c_DESC_PER into v_rptfileno,v_carrCode,v_fareno;
    END LOOP;
    CLOSE c_DESC_PER;
    --
     
    --dbms_output.put_line(v_fileNo);
    FETCH C_DISTINCT_ORGDES into v_orgStn,v_desstn;  
  END LOOP;
  --
  CLOSE C_DISTINCT_ORGDES;
end SCRECORD;
/

prompt
prompt Creating procedure TEST_TUTU
prompt ============================
prompt
create or replace procedure fcims.test_tutu is
 p_protocol_header_id csim_t_protocol.protocol_header_id%type;        ----���ڴ���շ���Ŀ
 p_group_number csim_t_protocol.group_number%type;                    ----���ڴ��Э������
 
 select_ifture_string       varchar2(400);                            ----���ڴ���ж������Ƿ�Ϊ��Ķ�̬sql��� 
 select_info_string         varchar2(200);                             ----��Ŷ�̬sql��䣬�����������ѯ�����ڼ���ĺ��ද̬����
 insert_sql_string          varchar2(200);                            ----���ڴ�Ų��붯̬sql��� 
 i                          integer;                                  ----������
 select_ifture_cursor       integer;                                  ----���ڴ�Ŷ�ָ̬������
 select_info_cursor         integer;                                  ----���ڴ�Ŷ�ָ̬������
 insert_sql_cursor          integer;                                  ----���ڴ�Ŷ�ָ̬������
 ignore                     integer;                                  ----���ڴ�Ŷ�̬sql���صĽ��ֵ
 p_count_group              integer;                                  ----���ڴ��ĳ���շ���Ŀ�а�����������ĸ���
 p_count_list               integer;                                  ----���ڴ��ĳ���շ���Ŀ�µ�ĳ�������е��������� 
 IsTureCount                integer := 0;                             ----���ڼ�¼ĳ���շ���Ŀ�µ�ĳ���������������������
 cal_res                    number(11,2) := 0;                        ----���ڴ�ż�����
 cal_para_value_var         csim_t_takeofflanding.attribute1%type := 1;                                   ----���ڴ�ż��������ʵ��ֵ
------------------------------------------------------------------------------------------------
------------                            �α궨�岿��                             ---------------
------------------------------------------------------------------------------------------------
 cursor csim_get_protocol_group is                             ----ȡ��Э���е��շ���Ŀid�����
    select distinct protocol_header_id
    from csim_t_protocol
    order by protocol_header_id;

 cursor csim_get_protocol_group_detail is                      ----ȡ��ĳ���շ���Ŀ��ĳ������
    select a.calculate_mode,a.cal_parameter_type_id,a.cal_parameter_id,a.com_parameter_type_id,
           a.com_parameter_id,a.start_value,a.start_operation,a.end_value,a.end_operation,
           a.currency_code,a.unit_amount,a.base_amount,a.percent,a.refer_protocol_id,a.refer_protocol_name
    from csim_t_protocol a
    where protocol_header_id = p_protocol_header_id
    and group_number = p_group_number
    order by a.calculate_mode desc;
    
------------------------------------------------------------------------------------------------
------------                          �ӹ��ܶ��岿��                             ---------------
------------------------------------------------------------------------------------------------
begin
 for v_csim_get_protocol_group in csim_get_protocol_group loop                 ----ȡ���շ���Ŀ

     select count(*)                                                           ----�����ĳ���շ���Ŀ������������ĸ���
     into p_count_group
     from csim_t_protocol
     where protocol_header_id = v_csim_get_protocol_group.protocol_header_id; 
                       
     for i in 1..p_count_group loop                                                 ----�����ѭ��
          p_protocol_header_id := v_csim_get_protocol_group.protocol_header_id;
          p_group_number := i;

          select count(*)                                                      ----�����ĳ���շ���Ŀ�µ�ĳ���������������������
          into p_count_list
          from csim_t_protocol
          where protocol_header_id = v_csim_get_protocol_group.protocol_header_id
                and group_number = i;
          IsTureCount := 0;                                                    ----�����������������Ϊ0
          for v_csim_get_protocol_detail in csim_get_protocol_group_detail  loop      ----ȡ�����������������ϸ���ݣ��������ж�
              if v_csim_get_protocol_detail.com_parameter_id = 'null'           ----��������еıȽϲ���Ϊ�յĻ�����������Ϊ��
              and v_csim_get_protocol_detail.com_Parameter_type_id = 'null' then
                      select_ifture_string := 'select 1 from dual';
              end if;
              if v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����Լ��Ƚϲ������Ͷ����ǿյĻ�����Ը����������ж�
              and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null' then
                      select_ifture_string := 'select '||v_csim_get_protocol_detail.com_parameter_id||     ----�ж������Ƿ�����Ķ�̬sql���
                           ' from '||v_csim_get_protocol_detail.com_parameter_type_id||
                           ' where '||v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.start_operation||''''||
                           v_csim_get_protocol_detail.start_value||'''';
                           
                      if v_csim_get_protocol_detail.end_value is not null 
                      and v_csim_get_protocol_detail.end_operation is not null then                ----���������е���ֵ����ֵ������
                           select_ifture_string := select_ifture_string||' and '||
                           v_csim_get_protocol_detail.com_parameter_id||
                           v_csim_get_protocol_detail.end_operation||''''||
                           v_csim_get_protocol_detail.end_value||'''';
                      end if;
               end if;
             dbms_output.put_line(to_char(p_group_number)||select_ifture_string);
               if (v_csim_get_protocol_detail.com_parameter_id <> 'null'           ----��������еıȽϲ����ͱȽϲ�������һ��Ϊ�գ�һ��
                                                                                   ----��Ϊ�յĻ�������ʾ������������
                  and v_csim_get_protocol_detail.com_Parameter_type_id = 'null') or 
                  (v_csim_get_protocol_detail.com_parameter_id = 'null'
                  and v_csim_get_protocol_detail.com_Parameter_type_id <> 'null') then
                  dbms_output.put_line('��Э��������⣡');
               end if;
              
-----------------------------------                    ִ�ж�̬sql                ----------------------------------
              select_ifture_cursor := dbms_sql.open_cursor;
              dbms_sql.parse(select_ifture_cursor,select_ifture_string,dbms_sql.v7);
              ignore := DBMS_SQL.EXECUTE(select_ifture_cursor);
--------------------------------------------------------------------------------------------------------------------              
              if dbms_sql.fetch_rows(select_ifture_cursor)<=0 then                   ----���û�м�¼����,�����Э�����������㣬����Э��Ͷ������㣬���˳�����ѭ��
                                                                                     ----���ٶԸ���Э�����µ����������жϣ�ֱ�ӽ�����һ��Э��
                  exit;
              else 
                 IsTureCount := IsTureCount + 1;                                     ----Ϊ�����������ۼ�
                 if v_csim_get_protocol_detail.calculate_mode is not null then       ----�������Ϊ�����У�����calculate_mode��Ϊ�գ�����             
                    if v_csim_get_protocol_detail.calculate_mode = 'UNIT' then       ----�����۷�ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.cal_parameter_id||   ----����ѡ���������ʵ��ֵ�Ķ�̬sql���
                                          ' from '||v_csim_get_protocol_detail.cal_parameter_type_id;
                     dbms_output.put_line(to_char(p_group_number)||'s-info '||select_info_string);                                          
-----------------------------------                    ִ�ж�̬sql                ----------------------------------                                          
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);                       
                       ignore := dbms_sql.execute(select_info_cursor);
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------                                     
                     dbms_output.put_line(to_char(p_group_number)||'c'||to_char(cal_para_value_var)||'*'||to_char(v_csim_get_protocol_detail.unit_amount));
                       cal_res := nvl(cal_para_value_var,0) * v_csim_get_protocol_detail.unit_amount;   ----�������
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                    if v_csim_get_protocol_detail.calculate_mode = 'PERCENT' then                       ----��������ʽ�������
                       select_info_string := 'select '||v_csim_get_protocol_detail.refer_protocol_id||  ----����ѡ���ο��շ���Ŀ���Ķ�̬sql���
                                          ' from CSIM_T_TAKEOFFLANDING';
                     dbms_output.put_line(select_info_string);                                          
-----------------------------------                    ִ�ж�̬sql                ----------------------------------                       
                       select_info_cursor := dbms_sql.open_cursor;
                       dbms_sql.parse(select_info_cursor,select_info_string,dbms_sql.v7);
                       dbms_sql.define_column(select_info_cursor,1,cal_para_value_var);
                       ignore := dbms_sql.execute(select_info_cursor);                       
                       IF DBMS_SQL.FETCH_ROWS(select_info_cursor)>0 then
                          dbms_sql.column_value(select_info_cursor,1,cal_para_value_var);
                       end if;
--------------------------------------------------------------------------------------------------------------------                                     

                       if cal_para_value_var IS NOT NULL THEN                                   ----�жϱ��շ���Ŀ�Ĳο��շ���Ŀ�Ƿ�����
                          cal_res := cal_para_value_var * v_csim_get_protocol_detail.percent;   ----�������
                       else 
                          dbms_output.put_line('Procedure test_tutu: ���շ���Ŀ�Ĳο��շ���Ŀ��δ����');
                       end if; 
                       dbms_sql.close_cursor(select_info_cursor);
                    end if;
                 end if;                                   
                 if v_csim_get_protocol_detail.base_amount is not null then                      ----������������
                    cal_res := nvl(cal_res,0)+ v_csim_get_protocol_detail.base_amount;
                 end if;    
              end if;
              dbms_sql.close_cursor(select_ifture_cursor);
          end loop;  
                 if IsTureCount = p_count_list then                                              ----�����������ȫ�����㣬�򽫼�����ķ���ֵ�����
                                                                                                 ----csim_t_takeofflanding�е���Ӧ����
                    insert_sql_string := 'update csim_t_takeofflanding set '||p_protocol_header_id||
                                         ' = '||to_char(cal_res);
                    insert_sql_cursor := dbms_sql.open_cursor;
                  dbms_output.put_line(to_char(p_group_number)||insert_sql_string);
                    dbms_sql.parse(insert_sql_cursor,insert_sql_string,dbms_sql.v7);
                    ignore := dbms_sql.execute(insert_sql_cursor);
                    commit;
                    dbms_sql.close_cursor(insert_sql_cursor);
                    cal_res := 0;
                 exit;
                 end if;                    

     end loop;
  end loop;  
  exception when others then
    if dbms_sql.is_open(select_ifture_cursor) then
      dbms_sql.close_cursor(select_ifture_cursor);
    end if;
    if dbms_sql.is_open(select_info_cursor) then
      dbms_sql.close_cursor(select_info_cursor);
    end if;
    if dbms_sql.is_open(insert_sql_cursor) then
      dbms_sql.close_cursor(insert_sql_cursor);
    end if;
    raise;
            
end;
/

prompt
prompt Creating procedure TONGBU
prompt =========================
prompt
create or replace procedure fcims.tongbu(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type; 

v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;
v_maxeffDate dfim_t_psfpo.eff_date%type;
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_desStn dfim_t_psfpo.des_stn%type;
v_clsCode dfim_t_psfpo.cls_code%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fare      dfim_t_psfpo.fare%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_travelType dfim_t_psfpo.travel_type%type;

v_count number;
v_number number;--������

CURSOR c_psfpp IS 
SELECT rpt_file_no,carr_code,fare_no,fare,disc_per,fare FROM DFIM_T_PSFPp
WHERE aprv_ind = 'O' and flag = 0 and rpt_file_no = '��λ����SC';--and org_stn = 'CAN' AND DES_STN = 'WNZ' AND CARR_CODE = 'SC';
  
CURSOR c_DESC_PER IS 
SELECT RPT_FILE_NO,CARR_CODE,FARE_NO 
FROM DFIM_T_PSFPO 
WHERE CARR_CODE = 'SC' AND ORG_STN = v_orgstn AND DES_STN = v_desstn 
AND RPT_FILE_NO = '��λ����SC' AND FLAG = 0;

 
cursor c_findmaxEffdate IS 
select  MAX(EFF_DATE) from dfim_t_psfpo t 
where carr_code = 'SC' --AND FARE IS NULL --
AND fare_basis = 'YB' 
and rpt_file_no = 'FD��������SC'
and org_stn = v_orgstn
and des_stn = v_desstn
GROUP BY org_stn,des_stn;

cursor c_findmaxMoney IS 
select  fare from dfim_t_psfpo t 
where carr_code = 'SC' --AND FARE IS NULL --
AND fare_basis = 'YB' 
and rpt_file_no = 'FD��������SC'
and org_stn = v_orgstn
and des_stn = v_desstn
and eff_date = v_maxeffdate;  

  

   
begin
  /*IF (p_carrCode = '') THEN--OR (p_carrCode = '')) THEN--||) THEN
  --BEGIN
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  --RETURN;
  --dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  dbms_output.put_line('where file_no like '||'''FD��ʷ����'||UPPER(p_carrCode)||'%'''||' group by file_no');
  END IF;*/
  --��FILE-NO���з���
  OPEN c_psfpp;
  FETCH c_psfpp into v_rptfileno,v_carrcode,v_fareno,v_fare,v_discper,v_fare;
  --dbms_output.put_line(v_fileNO);
  WHILE c_psfpp%FOUND LOOP
    --dbms_output.put_line(v_orgstn||v_desstn);
      update dfim_t_psfpo set flag = 0,disc_per = v_discper,fare=v_fare
      where carr_code = v_carrcode 
        and rpt_file_no = v_rptfileno
        and fare_no = v_fareno;
      
      --�ж��Ƿ�Ϊ��������    
      /*IF v_count>1 THEN
        --dbms_output.put_line(v_count||'--'||v_carrCode||'--'||v_effDate||'--'||v_discDate||'--'||v_orgStn||'--'||v_desStn||'--'||v_clsCode||'--'||v_fareBasis||'--'||v_fare||'--'||v_currCode);      
        OPEN c_deleteFare;
        v_number :=0;
        FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        WHILE c_deleteFare%FOUND LOOP
          IF v_number <> 0 THEN 
             --dbms_output.put_line('DELETE'||'--'||v_number);
             DELETE FROM DFIM_T_PSFPO WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;  
             DELETE FROM DFIM_T_PSFPP WHERE CARR_CODE = v_carrCode AND RPT_FILE_NO = v_rptFileNo AND FARE_NO = v_fareNo;             
             commit;
          END IF;
          v_number := v_number+1;
          FETCH c_deleteFare into v_fareNO,v_rptFileNo;
        END LOOP;
        CLOSE c_deleteFare;
                
      END IF;*/      
      --
    --
     
    --dbms_output.put_line(v_fileNo);
    FETCH c_psfpp into v_rptfileno,v_carrcode,v_fareno,v_fare,v_discper,v_fare;  
  END LOOP;
  --
  CLOSE c_psfpp;
end tongbu;
/

prompt
prompt Creating procedure UPDATEFOR3U
prompt ==============================
prompt
create or replace procedure fcims.UPDATEFOR3U(
  p_carrCode varchar) as
  
v_fileNo dfim_t_psfpo.file_no%type;   --1
v_fareNo  dfim_t_psfpo.fare_no%type;
v_rptFileNo dfim_t_psfpo.rpt_file_no%type;
v_rptFrom dfim_t_psfpo.rpt_from%type;
v_rptDate dfim_t_psfpo.rpt_date%type;  --5
v_aprvDate dfim_t_psfpo.aprv_date%type;
v_aprvInd dfim_t_psfpo.aprv_ind%type;
v_archvInd dfim_t_psfpo.archv_ind%type;
v_carrCode dfim_t_psfpo.carr_code%type;
v_effDate dfim_t_psfpo.eff_date%type;  --10
v_discDate dfim_t_psfpo.disc_date%type;
v_orgStn dfim_t_psfpo.org_stn%type;
v_orgCity dfim_t_psfpo.org_city%type;
v_orgFlag dfim_t_psfpo.org_flg%type;
v_desStn dfim_t_psfpo.des_stn%type;  --15
v_desCity dfim_t_psfpo.des_city%type;
v_desFlag dfim_t_psfpo.des_flg%type;
v_travelType dfim_t_psfpo.travel_type%type;
v_fareBasis dfim_t_psfpo.fare_basis%type;  
v_fareType dfim_t_psfpo.fare_type%type;  --20
v_clsCode dfim_t_psfpo.cls_code%type;
v_currCode dfim_t_psfpo.curr_code%type;
v_discPer dfim_t_psfpo.disc_per%type;
v_firstSaleDate dfim_t_psfpo.first_sale_date%type;
v_lastSaleDate dfim_t_psfpo.last_sale_date%type;  --25
v_ruleNo dfim_t_psfpo.rule_no%type;
v_createDate dfim_t_psfpo.create_date%type;
v_createBy dfim_t_psfpo.create_by%type;
v_lastUpdateDate dfim_t_psfpo.last_update_date%type;
v_lastUpdateBy dfim_t_psfpo.last_update_by%type;  --30
v_serviceClass      dfim_t_psfpo.service_class%type;
v_fare      dfim_t_psfpo.fare%type;
v_flag      dfim_t_psfpo.flag%type;  --33

v_fareno_r dfim_t_psfpo.fare_no%type;
v_rptFileNo_r dfim_t_psfpo.rpt_file_no%type;
v_carrCode_r dfim_t_psfpo.carr_code%type;

v_fareno_routing dfim_t_psfpo.fare_no%type;
v_rptFileNo_routing dfim_t_psfpo.rpt_file_no%type;
v_carrCode_routing dfim_t_psfpo.carr_code%type;


v_maxeffDate dfim_t_psfpo.eff_date%type;
v_maxfareno number;
v_number number;--������

CURSOR C_ALL_UPDATE_PPSPP IS 
select FARE_NO,RPT_FILE_NO,CARR_CODE,DISC_DATE 
from dfim_t_psfpp 
where upper(attribute1) like 'UP%';

CURSOR C_FIND_PPSPO IS
select fare_no,rpt_file_no,carr_code
from dfim_t_psfpo
where fare_no = v_fareno and
      rpt_file_no = v_rptfileno and
      carr_code = v_carrcode; 
       
begin

  OPEN C_ALL_UPDATE_PPSPP;
  FETCH C_ALL_UPDATE_PPSPP into v_fareNo,v_rptFileNo,v_carrcode,v_discdate;
  --dbms_output.put_line(v_fileNO);
  WHILE C_ALL_UPDATE_PPSPP%FOUND LOOP
    dbms_output.put_line(v_fareNo||v_rptFileNo||v_carrcode);
    
    /*OPEN C_FIND_PPSPO;
    FETCH C_FIND_PPSPO into v_fareno_r,v_rptfileno_r,v_carrcode_r;
    IF  C_FIND_PPSPO%FOUND THEN
        dbms_output.put_line(v_fareNo||v_rptFileNo||v_carrcode); 
    END IF;
    CLOSE C_FIND_PPSPO;*/
    /*UPDATE dfim_t_psfpo set DISC_DATE = v_discdate,attribute1 = 'UPDATE3U' 
    where carr_code = v_carrcode and fare_no = v_fareno and rpt_file_no = v_rptfileno;*/
    
    FETCH C_ALL_UPDATE_PPSPP into v_fareNo,v_rptFileNo,v_carrcode,v_discdate;  
  END LOOP; 
  --
  CLOSE C_ALL_UPDATE_PPSPP;
end UPDATEFOR3U;
/

prompt
prompt Creating trigger DFIM_T_PSFPO_TRIGGER
prompt =====================================
prompt
create or replace trigger fcims.dfim_t_psfpo_trigger before insert on fcims.DFIM_T_PSFPO for each row
declare
  v_seq_no varchar2(20);
BEGIN
  select rule_id_no_seq.nextval||'PF' into v_seq_no from dual;
  if inserting then
     :NEW.RULE_ID_NO:=v_seq_no;
  end if;
end;
/

prompt
prompt Creating trigger FCIMS.PNFPP_TRACE_TRIGGER
prompt ==========================================
prompt
CREATE OR REPLACE TRIGGER FCIMS.
"FCIMS.PNFPP_TRACE_TRIGGER" before insert or delete or update on DFIM_T_PNFPP
for each row


BEGIN
  if inserting then
    insert into dfim_t_pnfpp_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'insert',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );
  end if;
  if updating then
    insert into dfim_t_pnfpp_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'update_old',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );
    insert into dfim_t_pnfpp_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'update_new',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );
  end if;
  if deleting then
    insert into dfim_t_pnfpp_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'delete',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );
  end if;
end;
/

prompt
prompt Creating trigger FSI_SHOPPER_CONFIG_TRIGGER
prompt ===========================================
prompt
create or replace trigger fcims.fsi_shopper_config_trigger
          before insert on fsi_shopper_config     /*���������������dectuserִ�в������ʱ�����˴�����*/
          for each row                       /*��ÿһ�ж�����Ƿ񴥷�*/
          begin                                  /*��������ʼ*/
                 select fsi_shopper_config_sequence.nextval into :new.ID from dual;   /*�������������ݣ���������ִ�еĶ������ڴ���ȡ������dectuser_tb_seq����һ��ֵ���뵽��dectuser�е�userid�ֶ���*/
          end;
/

prompt
prompt Creating trigger PNFPO_TRACE_TRIGGER_2
prompt ======================================
prompt
CREATE OR REPLACE TRIGGER FCIMS.
"FCIMS"."PNFPO_TRACE_TRIGGER_2" before insert or delete or update on fcims.DFIM_T_PNFPO
for each row


BEGIN

  if inserting then
    insert into dfim_t_pnfpo_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'insert',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );

  end if;
  if updating then
    insert into dfim_t_pnfpo_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'update_old',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );
    insert into dfim_t_pnfpo_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'update_new',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );

  end if;
  if deleting then
    insert into dfim_t_pnfpo_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'delete',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );

  end if;
end;
/

prompt
prompt Creating trigger PNFPP_TRACE_TRIGGER_2
prompt ======================================
prompt
CREATE OR REPLACE TRIGGER FCIMS.
"FCIMS"."PNFPP_TRACE_TRIGGER_2" before insert or delete or update on fcims.DFIM_T_PNFPP
for each row


BEGIN
  if inserting then
    insert into dfim_t_pnfpp_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'insert',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );
  end if;
  if updating then
    insert into dfim_t_pnfpp_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'update_old',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );
    insert into dfim_t_pnfpp_trace
    values
      (:new.CARR_CODE,
       :new.FILE_NO,
       :new.RPT_FILE_NO,
       :new.RPT_FROM,
       :new.FARE_NO,
       :new.RPT_DATE,
       :new.APRV_DATE,
       :new.ORG_STN,
       :new.ORG_CITY,
       :new.ORG_FLG,
       :new.DES_STN,
       :new.DES_CITY,
       :new.DES_FLG,
       :new.TRAVEL_TYPE,
       :new.CURR_CODE,
       :new.FARE,
       :new.EFF_DATE,
       :new.DISC_DATE,
       :new.APRV_IND,
       :new.ARCHV_IND,
       :new.CREATE_DATE,
       :new.CREATE_BY,
       sysdate,
       :new.LAST_UPDATE_BY,
       :new.ATTRIBUTE1,
       'update_new',
       :new.XBG_RATE,
       :new.FIRST_SALE_DATE,
       :new.LAST_SALE_DATE
       );
  end if;
  if deleting then
    insert into dfim_t_pnfpp_trace
    values
      (:old.CARR_CODE,
       :old.FILE_NO,
       :old.RPT_FILE_NO,
       :old.RPT_FROM,
       :old.FARE_NO,
       :old.RPT_DATE,
       :old.APRV_DATE,
       :old.ORG_STN,
       :old.ORG_CITY,
       :old.ORG_FLG,
       :old.DES_STN,
       :old.DES_CITY,
       :old.DES_FLG,
       :old.TRAVEL_TYPE,
       :old.CURR_CODE,
       :old.FARE,
       :old.EFF_DATE,
       :old.DISC_DATE,
       :old.APRV_IND,
       :old.ARCHV_IND,
       :old.CREATE_DATE,
       :old.CREATE_BY,
       sysdate,
       :old.LAST_UPDATE_BY,
       :old.ATTRIBUTE1,
       'delete',
       :old.XBG_RATE,
       :old.FIRST_SALE_DATE,
       :old.LAST_SALE_DATE
       );
  end if;
end;
/

prompt
prompt Creating trigger PPFPO_TRACE_TRIGGER
prompt ====================================
prompt
CREATE OR REPLACE TRIGGER FCIMS."PPFPO_TRACE_TRIGGER" before insert or delete or update on dfim_t_ppfpo
for each row

BEGIN

if inserting then
  insert into dfim_t_ppfpo_trace values( :new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.CARR_CODE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TMP,:new.TRAVEL_TYPE,:new.CURR_CODE,:new.FARE_BASIS,:new.FARE,:new.XBG_RATE,:new.PAX_CNY_KM,:new.EFF_DATE,:new.DISC_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.RMKS,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.CREATE_DATE,:new.CREATE_BY,sysdate,:new.LAST_UPDATE_BY,'insert');
end if;
if updating then
  insert into dfim_t_ppfpo_trace values( :old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.CARR_CODE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TMP,:old.TRAVEL_TYPE,:old.CURR_CODE,:old.FARE_BASIS,:old.FARE,:old.XBG_RATE,:old.PAX_CNY_KM,:old.EFF_DATE,:old.DISC_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.RMKS,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.CREATE_DATE,:old.CREATE_BY,sysdate,:old.LAST_UPDATE_BY,'update_old');
  insert into dfim_t_ppfpo_trace values( :new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.CARR_CODE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TMP,:new.TRAVEL_TYPE,:new.CURR_CODE,:new.FARE_BASIS,:new.FARE,:new.XBG_RATE,:new.PAX_CNY_KM,:new.EFF_DATE,:new.DISC_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.RMKS,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.CREATE_DATE,:new.CREATE_BY,sysdate,:new.LAST_UPDATE_BY,'update_new');
end if;
if deleting then
  insert into dfim_t_ppfpo_trace values( :old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.CARR_CODE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TMP,:old.TRAVEL_TYPE,:old.CURR_CODE,:old.FARE_BASIS,:old.FARE,:old.XBG_RATE,:old.PAX_CNY_KM,:old.EFF_DATE,:old.DISC_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.RMKS,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.CREATE_DATE,:old.CREATE_BY,sysdate,:old.LAST_UPDATE_BY,'delete');
end if;
end;
/

prompt
prompt Creating trigger PPFPP_TRACE_TRIGGER
prompt ====================================
prompt
CREATE OR REPLACE TRIGGER FCIMS."PPFPP_TRACE_TRIGGER" before insert or delete or update on dfim_t_ppfpp
for each row

BEGIN

if inserting then
  insert into dfim_t_ppfpp_trace values( :new.CARR_CODE,:new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TMP,:new.TRAVEL_TYPE,:new.CURR_CODE,:new.FARE_BASIS,:new.FARE,:new.XBG_RATE,:new.PAX_CNY_KM,:new.EFF_DATE,:new.DISC_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.RMKS,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.CREATE_DATE,:new.CREATE_BY,sysdate,:new.LAST_UPDATE_BY,'insert');
end if;
if updating then
  insert into dfim_t_ppfpp_trace values( :old.CARR_CODE,:old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TMP,:old.TRAVEL_TYPE,:old.CURR_CODE,:old.FARE_BASIS,:old.FARE,:old.XBG_RATE,:old.PAX_CNY_KM,:old.EFF_DATE,:old.DISC_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.RMKS,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.CREATE_DATE,:old.CREATE_BY,sysdate,:old.LAST_UPDATE_BY,'update_old');
  insert into dfim_t_ppfpp_trace values( :new.CARR_CODE,:new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TMP,:new.TRAVEL_TYPE,:new.CURR_CODE,:new.FARE_BASIS,:new.FARE,:new.XBG_RATE,:new.PAX_CNY_KM,:new.EFF_DATE,:new.DISC_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.RMKS,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.CREATE_DATE,:new.CREATE_BY,sysdate,:new.LAST_UPDATE_BY,'update_new');
end if;
if deleting then
  insert into dfim_t_ppfpp_trace values( :old.CARR_CODE,:old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TMP,:old.TRAVEL_TYPE,:old.CURR_CODE,:old.FARE_BASIS,:old.FARE,:old.XBG_RATE,:old.PAX_CNY_KM,:old.EFF_DATE,:old.DISC_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.RMKS,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.CREATE_DATE,:old.CREATE_BY,sysdate,:old.LAST_UPDATE_BY,'delete');
end if;
end;
/

prompt
prompt Creating trigger PSFPO_TRACE_TRIGGER
prompt ====================================
prompt
CREATE OR REPLACE TRIGGER FCIMS.
"FCIMS"."PSFPO_TRACE_TRIGGER" before delete or update or insert on DFIM_T_PSFPO
for each row


BEGIN

if (:new.CARR_CODE!='NX') then
  if inserting then 
      insert into dfim_t_psfpo_trace values(:new.FARE_NO,:new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.CARR_CODE,:new.EFF_DATE,:new.DISC_DATE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TRAVEL_TYPE,:new.FARE_BASIS,:new.FARE_TYPE,:new.CLS_CODE,:new.CURR_CODE,:new.DISC_PER,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.RULE_NO,:new.CREATE_DATE,:new.CREATE_BY,SYSDATE,:new.LAST_UPDATE_BY,:new.SERVICE_CLASS,:new.FARE,:new.FLAG,:new.ATTRIBUTE2,'insert',:new.ROUTEFLAG,:new.ATTRIBUTE1);
    end if;
   if updating then 
      insert into dfim_t_psfpo_trace values(:old.FARE_NO,:old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.CARR_CODE,:old.EFF_DATE,:old.DISC_DATE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TRAVEL_TYPE,:old.FARE_BASIS,:old.FARE_TYPE,:old.CLS_CODE,:old.CURR_CODE,:old.DISC_PER,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.RULE_NO,:old.CREATE_DATE,:old.CREATE_BY,SYSDATE,:old.LAST_UPDATE_BY,:old.SERVICE_CLASS,:old.FARE,:old.FLAG,:old.ATTRIBUTE2,'update_old',:old.ROUTEFLAG,:old.ATTRIBUTE1);
      insert into dfim_t_psfpo_trace values(:new.FARE_NO,:new.FILE_NO,:new.RPT_FILE_NO,:new.RPT_FROM,:new.RPT_DATE,:new.APRV_DATE,:new.APRV_IND,:new.ARCHV_IND,:new.CARR_CODE,:new.EFF_DATE,:new.DISC_DATE,:new.ORG_STN,:new.ORG_CITY,:new.ORG_FLG,:new.DES_STN,:new.DES_CITY,:new.DES_FLG,:new.TRAVEL_TYPE,:new.FARE_BASIS,:new.FARE_TYPE,:new.CLS_CODE,:new.CURR_CODE,:new.DISC_PER,:new.FIRST_SALE_DATE,:new.LAST_SALE_DATE,:new.RULE_NO,:new.CREATE_DATE,:new.CREATE_BY,SYSDATE,:new.LAST_UPDATE_BY,:new.SERVICE_CLASS,:new.FARE,:new.FLAG,:new.ATTRIBUTE2,'update_new',:new.ROUTEFLAG,:new.ATTRIBUTE1);
   end if;   
end if;
if (:old.CARR_CODE!='NX') then
    if deleting then 
      insert into dfim_t_psfpo_trace values(:old.FARE_NO,:old.FILE_NO,:old.RPT_FILE_NO,:old.RPT_FROM,:old.RPT_DATE,:old.APRV_DATE,:old.APRV_IND,:old.ARCHV_IND,:old.CARR_CODE,:old.EFF_DATE,:old.DISC_DATE,:old.ORG_STN,:old.ORG_CITY,:old.ORG_FLG,:old.DES_STN,:old.DES_CITY,:old.DES_FLG,:old.TRAVEL_TYPE,:old.FARE_BASIS,:old.FARE_TYPE,:old.CLS_CODE,:old.CURR_CODE,:old.DISC_PER,:old.FIRST_SALE_DATE,:old.LAST_SALE_DATE,:old.RULE_NO,:old.CREATE_DATE,:old.CREATE_BY,SYSDATE,:old.LAST_UPDATE_BY,:old.SERVICE_CLASS,:old.FARE,:old.FLAG,:old.ATTRIBUTE2,'delete',:old.ROUTEFLAG,:old.ATTRIBUTE1);
    end if;
end if;
end;
/


spool off
