--------------------------------------------------
-- Export file for user NFS_CA@FARERD           --
-- Created by xiaoxinwt on 2015/12/25, 19:23:23 --
--------------------------------------------------

set define off
spool ca_db.log

prompt
prompt Creating table ADDON
prompt ====================
prompt
create table NFS_CA.ADDON
(
  location_code      CHAR(5) not null,
  addon_no           CHAR(13) not null,
  effective_date     DATE not null,
  discontinue_date   DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  entry_no_lastnum   NUMBER(3),
  gateway_no_lastnum NUMBER(3),
  who_last_update    CHAR(20),
  where_last_update  CHAR(5),
  when_last_update   DATE,
  currency_code      CHAR(3) default ('') not null,
  bsr_currency_code  CHAR(3) default ('') not null,
  type               CHAR(1),
  bsr                NUMBER(6,3),
  modified_flag      NUMBER(1) default (0)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADDON
  add constraint ADDON_UX1 primary key (LOCATION_CODE, ADDON_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENDORSEMT_RESTRICTION
prompt ==========================================
prompt
create table NFS_CA.ADDON_ENDORSEMT_RESTRICTION
(
  location_code  CHAR(5) not null,
  addon_no       CHAR(13) not null,
  restriction_id NUMBER(5) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADDON_ENDORSEMT_RESTRICTION
  add constraint ADDON_ENDORSEMT_REST_UX1 primary key (LOCATION_CODE, ADDON_NO, RESTRICTION_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENTRY
prompt ==========================
prompt
create table NFS_CA.ADDON_ENTRY
(
  location_code               CHAR(5) not null,
  addon_no                    CHAR(13) not null,
  entry_no                    NUMBER(4) not null,
  code_type                   NUMBER(1),
  city_code                   CHAR(13) not null,
  journey_type                CHAR(3),
  fare_basis                  CHAR(15),
  carrier_booking_class       VARCHAR2(85),
  amount                      NUMBER(11,3),
  bsr_amount                  NUMBER(11,3),
  infant_discount_amount      NUMBER(11,3),
  infant_discount_percent     CHAR(2),
  infant_absolute_amt_entered NUMBER(1),
  child_discount_amount       NUMBER(11,3),
  child_discount_percent      CHAR(2),
  child_absolute_amt_entered  NUMBER(1),
  infant_bsr_amount           NUMBER(11,3),
  child_bsr_amount            NUMBER(11,3),
  spa                         VARCHAR2(58)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADDON_ENTRY
  add constraint ADDON_ENTRY_UX1 primary key (LOCATION_CODE, ADDON_NO, ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_ENTRY_FLIGHT_NO
prompt ====================================
prompt
create table NFS_CA.ADDON_ENTRY_FLIGHT_NO
(
  location_code    CHAR(5) not null,
  addon_no         CHAR(13) not null,
  entry_no         NUMBER(4) not null,
  flight_entry_no  NUMBER(2) not null,
  carrier_code     CHAR(4) not null,
  ap_from_no       NUMBER(4),
  ap_to_no         NUMBER(4),
  ex_from_no       NUMBER(4),
  ex_to_no         NUMBER(4),
  booking_class    CHAR(2),
  booking_class2   CHAR(2),
  fare_basis_code  CHAR(15),
  fare_basis_code2 CHAR(15),
  via_point        CHAR(5)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADDON_ENTRY_FLIGHT_NO
  add constraint ADDON_ENTRY_FLIGHT_NO_UX1 primary key (LOCATION_CODE, ADDON_NO, ENTRY_NO, FLIGHT_ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADDON_GATEWAY
prompt ============================
prompt
create table NFS_CA.ADDON_GATEWAY
(
  location_code        CHAR(5) not null,
  addon_no             CHAR(13) not null,
  gateway_entry_no     NUMBER(4) not null,
  gateway_type         NUMBER(1) default (0) not null,
  gateway_code         CHAR(13) not null,
  stopover_or_transfer CHAR(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADDON_GATEWAY
  add constraint ADDON_GATEWAY_UX1 primary key (LOCATION_CODE, ADDON_NO, GATEWAY_ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ADJUSTMENT
prompt =========================
prompt
create table NFS_CA.ADJUSTMENT
(
  location_code          CHAR(5) not null,
  ref_no                 CHAR(15) not null,
  extension_id           CHAR(15) not null,
  fare_rec_no            NUMBER(5) not null,
  sub_fare_rec_no        NUMBER(5) default (0) not null,
  adjust_fare            NUMBER(11,3),
  adjust_fare_child      NUMBER(11,3),
  adjust_fare_infant     NUMBER(11,3),
  cancellation_n_refunds VARCHAR2(1280),
  rebooking_n_rerouting  VARCHAR2(1280),
  who_last_update        CHAR(20),
  where_last_update      CHAR(5),
  when_last_update       DATE,
  adjust_value           CHAR(5),
  child_adjust_value     CHAR(5),
  fare_category          NUMBER(1),
  infant_adjust_value    CHAR(5),
  base_commission_amt    NUMBER(7,2),
  base_commission_pct    NUMBER(2,2),
  addt_commission_amt    NUMBER(7,2),
  addt_commission_pct    NUMBER(2,2)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ADJUSTMENT
  add constraint ADJUSTMENT_UX1 primary key (LOCATION_CODE, REF_NO, EXTENSION_ID, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AGREEMENT
prompt ========================
prompt
create table NFS_CA.AGREEMENT
(
  location_code          CHAR(5) not null,
  ref_no                 CHAR(15) not null,
  send_for_approval      NUMBER(1) default (0),
  approved               NUMBER(1) default (0),
  agreement_desc         VARCHAR2(512),
  effective_date         DATE not null,
  discontinue_date       DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  fare_rec_lastnum       NUMBER(5) default (0),
  who_last_update        CHAR(20),
  where_last_update      CHAR(5),
  when_last_update       DATE default (SYSDATE),
  who_last_update_auth   CHAR(20),
  where_last_update_auth CHAR(5),
  when_last_update_auth  DATE,
  who_last_update_dis    CHAR(20),
  where_last_update_dis  CHAR(5),
  when_last_update_dis   DATE,
  currency_code          CHAR(3) default ('') not null,
  currency_code2         CHAR(3) default ('') not null,
  algorithm_name         CHAR(4),
  prefix                 CHAR(4),
  suffix                 CHAR(4),
  remarks                VARCHAR2(256),
  approving_office       NUMBER(1) default (0),
  approval_type          NUMBER(1) default (0),
  extension_id           CHAR(15) not null,
  fare_category          NUMBER(1),
  distribution_status    NUMBER(1) not null,
  rpt_file_no            VARCHAR2(30)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 4640K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.AGREEMENT
  add constraint AGREEMENT_UX1 primary key (LOCATION_CODE, REF_NO, EXTENSION_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1632K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AUDIT_TRAIL
prompt ==========================
prompt
create table NFS_CA.AUDIT_TRAIL
(
  location_code       CHAR(5) not null,
  who                 CHAR(20) not null,
  when                DATE not null,
  transaction_code    NUMBER(3) not null,
  key                 VARCHAR2(47),
  transaction_details VARCHAR2(128)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 95072K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table AUTOVALUECODE
prompt ============================
prompt
create table NFS_CA.AUTOVALUECODE
(
  location_code  CHAR(5) not null,
  algorithm_name CHAR(4) not null,
  prefix         CHAR(4),
  suffix         CHAR(4),
  code_0         CHAR(1),
  code_1         CHAR(1),
  code_2         CHAR(1),
  code_3         CHAR(1),
  code_4         CHAR(1),
  code_5         CHAR(1),
  code_6         CHAR(1),
  code_7         CHAR(1),
  code_8         CHAR(1),
  code_9         CHAR(1),
  code_decimal   CHAR(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.AUTOVALUECODE
  add constraint AUTOVALUECODE_UX1 primary key (LOCATION_CODE, ALGORITHM_NAME)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table BASEAGREEMENT
prompt ============================
prompt
create table NFS_CA.BASEAGREEMENT
(
  agreement_desc   VARCHAR2(512) not null,
  ref_no           VARCHAR2(15) not null,
  rso              CHAR(3) not null,
  effective_date   DATE not null,
  discontinue_date DATE default (to_date('22220101','yyyymmdd')) not null,
  when_last_update DATE default (SYSDATE),
  who_last_update  VARCHAR2(20),
  fare_rec_lastnum NUMBER(5) default 0
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.BASEAGREEMENT
  add constraint PK_BASEAGREEMENT primary key (REF_NO, RSO)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table BASEFARE
prompt =======================
prompt
create table NFS_CA.BASEFARE
(
  fare_rec_no         NUMBER(7) not null,
  ref_no              VARCHAR2(15) not null,
  rso                 CHAR(3) not null,
  adult_fare          NUMBER(11,3),
  base_commission_pct NUMBER(2,2),
  base_commission_amt NUMBER(7,2),
  addt_commission_amt NUMBER(7,2),
  addt_commission_pct NUMBER(2,2),
  booking_class       VARCHAR2(2) not null,
  fare_type           VARCHAR2(8),
  journey_type        VARCHAR2(3) not null,
  dest_code_type      NUMBER(1),
  dest_city_code      CHAR(3),
  dest_code           VARCHAR2(3),
  ori_code_type       NUMBER(1),
  ori_city_code       CHAR(3),
  ori_code            VARCHAR2(3),
  discontinue_date    DATE default (to_date('22220101','yyyymmdd')) not null,
  effective_date      DATE not null,
  who_last_update     VARCHAR2(20),
  when_last_update    DATE default (SYSDATE),
  route_lastnum       NUMBER(3) default (0)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.BASEFARE
  add constraint PK_BASEFARE primary key (FARE_REC_NO, REF_NO, RSO)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table BASEFARE_ROUTE_ENTRY
prompt ===================================
prompt
create table NFS_CA.BASEFARE_ROUTE_ENTRY
(
  ref_no         VARCHAR2(15) not null,
  fare_rec_no    NUMBER(7) not null,
  entry_no       NUMBER(3) not null,
  from_code      VARCHAR2(3),
  from_code_type NUMBER(1),
  to_code        VARCHAR2(3),
  to_code_type   NUMBER(1),
  route_no       NUMBER(3) not null,
  rso            CHAR(3) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 800K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.BASEFARE_ROUTE_ENTRY
  add primary key (ENTRY_NO, FARE_REC_NO, REF_NO, ROUTE_NO, RSO)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1232K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE
prompt ========================
prompt
create table NFS_CA.CORPORATE
(
  location_code  CHAR(5) not null,
  corporate_id   CHAR(5) not null,
  corporate_name VARCHAR2(80)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.CORPORATE
  add constraint CORPORATE_UX1 primary key (LOCATION_CODE, CORPORATE_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE2
prompt =========================
prompt
create table NFS_CA.CORPORATE2
(
  location_code   CHAR(5) not null,
  corporate_id    CHAR(5) not null,
  corporate_id2   CHAR(5) not null,
  corporate_name2 VARCHAR2(80)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.CORPORATE2
  add constraint CORPORATE2_UX1 primary key (LOCATION_CODE, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CORPORATE_GROUP_ENTRY
prompt ====================================
prompt
create table NFS_CA.CORPORATE_GROUP_ENTRY
(
  location_code CHAR(5) not null,
  group_id      VARCHAR2(15) not null,
  corporate_id  CHAR(5) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.CORPORATE_GROUP_ENTRY
  add constraint CORPORATE_GROUP_ENTRY_UX1 primary key (LOCATION_CODE, GROUP_ID, CORPORATE_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CURRENCY
prompt =======================
prompt
create table NFS_CA.CURRENCY
(
  country_code     CHAR(3) not null,
  currency_code    CHAR(3) not null,
  default_currency NUMBER(1),
  dual_currency    NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.CURRENCY
  add constraint CURRENCY_UX1 primary key (COUNTRY_CODE, CURRENCY_CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DISTRIBUTION
prompt ===========================
prompt
create table NFS_CA.DISTRIBUTION
(
  location_code       CHAR(5) not null,
  ref_no              CHAR(15) not null,
  agency_id_pcc       VARCHAR2(37) not null,
  extension_id        CHAR(15) not null,
  ticketing_permitted CHAR(3),
  group_id            VARCHAR2(37),
  agency_id_iata      CHAR(7),
  distrib_type        NUMBER(1) not null,
  corporate_id        CHAR(5) not null,
  corporate_id2       CHAR(5) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 7232K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.DISTRIBUTION
  add constraint DISTRIBUTION_UX1 primary key (LOCATION_CODE, REF_NO, AGENCY_ID_PCC, EXTENSION_ID, CORPORATE_ID, CORPORATE_ID2)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 6896K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.DISTRIBUTION
  add check (TICKETING_PERMITTED IN ('Yes','No'));
alter table NFS_CA.DISTRIBUTION
  add check (TICKETING_PERMITTED IN ('Yes','No'));
alter table NFS_CA.DISTRIBUTION
  add check (TICKETING_PERMITTED IN ('Yes','No'));
alter table NFS_CA.DISTRIBUTION
  add check (TICKETING_PERMITTED IN ('Yes','No'));

prompt
prompt Creating table ENDORSEMT_RESTRICTION
prompt ====================================
prompt
create table NFS_CA.ENDORSEMT_RESTRICTION
(
  location_code          CHAR(5) not null,
  restriction_id         NUMBER(5) not null,
  category               VARCHAR2(30) not null,
  restriction_desc       VARCHAR2(512),
  restriction_type       NUMBER(1) default (0) not null,
  who_last_update        CHAR(20),
  where_last_update      CHAR(5),
  when_last_update       DATE,
  eterm_restriction_desc VARCHAR2(512)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ENDORSEMT_RESTRICTION
  add constraint ENDORSEMT_RESTRICTION_UX1 primary key (LOCATION_CODE, RESTRICTION_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE
prompt ===================
prompt
create table NFS_CA.FARE
(
  location_code                 CHAR(5) not null,
  ref_no                        CHAR(15) not null,
  fare_rec_no                   NUMBER(15) not null,
  fare_category                 NUMBER(1) default (0),
  ori_code_type                 NUMBER(1),
  ori_code                      CHAR(13),
  ori_city_code                 CHAR(5),
  dest_code_type                NUMBER(1),
  dest_code                     CHAR(13),
  dest_city_code                CHAR(5),
  journey_type                  CHAR(3),
  fare_basis                    CHAR(15),
  booking_class                 CHAR(2),
  global_direction              CHAR(2),
  amount                        NUMBER(11,3),
  value_code                    CHAR(14),
  effective_date                DATE not null,
  discontinue_date              DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  first_travel_date             DATE,
  last_travel_date              DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  first_ticketed_date           DATE,
  last_ticketed_date            DATE default (to_date('2222-01-01','yyyy-MM-dd')) not null,
  rule_id                       CHAR(13),
  infant_discount_amount        NUMBER(11,3),
  infant_discount_percent       NUMBER(3),
  infant_absolute_amt_entered   NUMBER(1),
  child_discount_amount         NUMBER(11,3),
  child_discount_percent        NUMBER(3),
  child_absolute_amt_entered    NUMBER(1),
  free_stopover_outbound        NUMBER(2),
  chargeable_stopover_outbound  NUMBER(2),
  free_stopover_inbound         NUMBER(2),
  chargeable_stopover_inbound   NUMBER(2),
  free_stopover_total           NUMBER(2),
  chargeable_stopover_total     NUMBER(2),
  route_lastnum                 NUMBER(3) default (0),
  stopover_lastnum              NUMBER(3) default (0),
  who_last_update               CHAR(20),
  where_last_update             CHAR(5),
  when_last_update              DATE default (SYSDATE),
  fare_type                     CHAR(8),
  stopover_flag                 CHAR(1),
  booking_class_2               CHAR(2),
  child_value_code              CHAR(14),
  infant_value_code             CHAR(14),
  class_of_service              NUMBER(1),
  tour_code                     CHAR(14),
  child_tour_code               CHAR(14),
  infant_tour_code              CHAR(14),
  endorsement_restriction       VARCHAR2(255),
  fare_calculation              CHAR(15),
  published_fare_basis_code     CHAR(15),
  is_combined_fare              NUMBER(1),
  outbound_permitted            NUMBER(1),
  inbound_permitted             NUMBER(1),
  thru_fare                     NUMBER(1),
  adult_rsf_amt                 NUMBER(11,3),
  child_rsf_amt                 NUMBER(11,3),
  infant_rsf_amt                NUMBER(11,3),
  discount_code                 CHAR(2),
  child_published_fbc           CHAR(15),
  infant_published_fbc          CHAR(15),
  travel_complete_date          DATE default (to_date('2222-01-01','yyyy-MM-dd')),
  sub_fare_rec_no               NUMBER(5) default (0) not null,
  modified_flag                 NUMBER(1) default (0),
  value_code2                   CHAR(14),
  child_value_code2             CHAR(14),
  infant_value_code2            CHAR(14),
  baggage_allowance             NUMBER(2),
  child_baggage_allowance       NUMBER(2),
  infant_baggage_allowance      NUMBER(2),
  unit                          NUMBER(1) default 0,
  base_commission_amt           NUMBER(7,2),
  base_commission_pct           NUMBER(2,2),
  addt_commission_amt           NUMBER(7,2),
  addt_commission_pct           NUMBER(2,2),
  ticket_type                   NUMBER(3) default (3) not null,
  eterm_endorsement_restriction VARCHAR2(255),
  disc_per                      NUMBER(5,2)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 526544K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.DEST_CODE_IDX on NFS_CA.FARE (DEST_CODE)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 75232K
    minextents 1
    maxextents unlimited
  );
create index FARE_CA_RULE_LOC_INDEX on NFS_CA.FARE (RULE_ID, LOCATION_CODE)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.FARE_INDX1 on NFS_CA.FARE (FARE_REC_NO, SUB_FARE_REC_NO, ORI_CODE, ORI_CITY_CODE, DEST_CITY_CODE, LOCATION_CODE)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 116488K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.FARE_MYINDX1 on NFS_CA.FARE (ORI_CODE, DEST_CODE)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 113008K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.ORI_CODE_IDX on NFS_CA.FARE (ORI_CODE)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 75256K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.REF_NO_IDX on NFS_CA.FARE (REF_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 75344K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE
  add constraint FARE_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 105360K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ADDON
prompt =========================
prompt
create table NFS_CA.FARE_ADDON
(
  location_code   CHAR(5) not null,
  ref_no          CHAR(15) not null,
  fare_rec_no     NUMBER(15) not null,
  addon_no        CHAR(13) not null,
  sub_fare_rec_no NUMBER(5) default (0) not null,
  type            CHAR(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 6896K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_ADDON
  add constraint FARE_ADDON_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ADDON_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 11824K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_BAGGAGE_ALLOWANCE
prompt =====================================
prompt
create table NFS_CA.FARE_BAGGAGE_ALLOWANCE
(
  location_code            CHAR(5) not null,
  ref_no                   CHAR(15) not null,
  fare_rec_no              NUMBER(15) not null,
  sub_fare_rec_no          NUMBER(5) default (0) not null,
  entry_no                 NUMBER(5) not null,
  carrier_code             CHAR(4) not null,
  from_code                CHAR(3) not null,
  from_code_type           NUMBER(1),
  to_code                  CHAR(3) not null,
  to_code_type             NUMBER(1),
  baggage_allowance        NUMBER(2),
  child_baggage_allowance  NUMBER(2),
  infant_baggage_allowance NUMBER(2),
  unit                     NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_BAGGAGE_ALLOWANCE
  add constraint FARE_BAG_ALL_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO, ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE
prompt =========================
prompt
create table NFS_CA.FARE_ROUTE
(
  location_code   CHAR(5) not null,
  ref_no          CHAR(15) not null,
  fare_rec_no     NUMBER(15) not null,
  route_no        NUMBER(3) not null,
  entry_lastnum   NUMBER(3),
  sub_fare_rec_no NUMBER(5) default (0) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 19376K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_ROUTE
  add constraint FARE_ROUTE_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 31920K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE_ENTRY
prompt ===============================
prompt
create table NFS_CA.FARE_ROUTE_ENTRY
(
  location_code        CHAR(5) not null,
  ref_no               CHAR(15) not null,
  fare_rec_no          NUMBER(15) not null,
  route_no             NUMBER(3) not null,
  entry_no             NUMBER(3) not null,
  from_code            CHAR(13),
  from_code_type       NUMBER(1),
  to_code              CHAR(13),
  to_code_type         NUMBER(1),
  stopover_or_transfer CHAR(1),
  open_jaw_for_btwn    NUMBER(1),
  q_charge_amt         NUMBER(11,3),
  sub_fare_rec_no      NUMBER(5) default (0) not null,
  min_stay             NUMBER(3),
  max_stay             NUMBER(3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 114048K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.FARE_ROUTE_ENTRY_INDX on NFS_CA.FARE_ROUTE_ENTRY (REF_NO, FARE_REC_NO)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 88688K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_ROUTE_ENTRY
  add constraint FARE_ROUTE_ENTRY_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, ENTRY_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 103856K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_ROUTE_FLIGHT_NO
prompt ===================================
prompt
create table NFS_CA.FARE_ROUTE_FLIGHT_NO
(
  location_code    CHAR(5) not null,
  ref_no           CHAR(15) not null,
  fare_rec_no      NUMBER(15) not null,
  route_no         NUMBER(3) not null,
  entry_no         NUMBER(3) not null,
  flight_entry_no  NUMBER(2) not null,
  carrier_code     CHAR(4) not null,
  ap_from_no       NUMBER(4),
  ap_to_no         NUMBER(4),
  ex_from_no       NUMBER(4),
  ex_to_no         NUMBER(4),
  booking_class    CHAR(2),
  booking_class2   CHAR(2),
  fare_basis_code  CHAR(15),
  fare_basis_code2 CHAR(15),
  sub_fare_rec_no  NUMBER(5) default (0) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 87856K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_ROUTE_FLIGHT_NO
  add constraint FARE_ROUTE_FLIGHT_NO_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, ROUTE_NO, ENTRY_NO, FLIGHT_ENTRY_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 109304K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_RULE
prompt ========================
prompt
create table NFS_CA.FARE_RULE
(
  location_code     CHAR(5) not null,
  ref_no            CHAR(15) not null,
  fare_rec_no       NUMBER(15) not null,
  minimum_stay      NUMBER(3),
  minimum_stay_unit CHAR(6),
  maximum_stay      NUMBER(3),
  maximum_stay_unit CHAR(6),
  sub_fare_rec_no   NUMBER(5) default (0) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 88232K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_RULE
  add constraint FARE_RULE_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 105272K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_RULE_BAK
prompt ============================
prompt
create table NFS_CA.FARE_RULE_BAK
(
  location_code     CHAR(5) not null,
  ref_no            CHAR(15) not null,
  fare_rec_no       NUMBER(5) not null,
  minimum_stay      NUMBER(3),
  minimum_stay_unit CHAR(6),
  maximum_stay      NUMBER(3),
  maximum_stay_unit CHAR(6),
  sub_fare_rec_no   NUMBER(5) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table FARE_STOPOVER
prompt ============================
prompt
create table NFS_CA.FARE_STOPOVER
(
  location_code          CHAR(5) not null,
  ref_no                 CHAR(15) not null,
  fare_rec_no            NUMBER(15) not null,
  sub_fare_rec_no        NUMBER(5) default (0) not null,
  entry_no               NUMBER(3) not null,
  stopover_city          CHAR(13),
  via_carrier_code       CHAR(20),
  booking_class          CHAR(2),
  surcharge_amt_outbound NUMBER(11,3),
  surcharge_amt_inbound  NUMBER(11,3),
  departure_city         CHAR(13),
  fare_basis_code        CHAR(15),
  surcharge_chd_outbound NUMBER(11,3),
  surcharge_chd_inbound  NUMBER(11,3),
  surcharge_inf_outbound NUMBER(11,3),
  surcharge_inf_inbound  NUMBER(11,3),
  round_trip             NUMBER(1),
  stopover_type          NUMBER(1),
  departure_type         NUMBER(1),
  ap_from_no             NUMBER(4),
  ap_to_no               NUMBER(4),
  ex_from_no             NUMBER(4),
  ex_to_no               NUMBER(4),
  q_charge_amt           NUMBER(11,3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 520K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.FARE_STOPOVER
  add constraint FARE_STOPOVER_UX1 primary key (LOCATION_CODE, REF_NO, FARE_REC_NO, SUB_FARE_REC_NO, ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GROUPS
prompt =====================
prompt
create table NFS_CA.GROUPS
(
  location_code     CHAR(5) not null,
  group_id          VARCHAR2(37) not null,
  group_desc        VARCHAR2(35),
  who_last_update   CHAR(20),
  where_last_update CHAR(5),
  when_last_update  DATE,
  group_type        NUMBER(1) default (0)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.GROUPS
  add constraint GROUPS_UX1 primary key (LOCATION_CODE, GROUP_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table GROUPS_ENTRY
prompt ===========================
prompt
create table NFS_CA.GROUPS_ENTRY
(
  location_code  CHAR(5) not null,
  group_id       VARCHAR2(37) not null,
  agency_id_pcc  CHAR(6) not null,
  agency_id_iata CHAR(7),
  city_code      CHAR(5),
  agency_name    VARCHAR2(50),
  dis_name       VARCHAR2(10),
  sys_code       VARCHAR2(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 6696K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.GROUPS_ENTRY_INDX on NFS_CA.GROUPS_ENTRY (AGENCY_ID_PCC, DIS_NAME)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2912K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.GROUPS_ENTRY_INDX2 on NFS_CA.GROUPS_ENTRY (GROUP_ID, DIS_NAME)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 3504K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.GROUPS_ENTRY
  add constraint GROUPS_ENTRY_UX1 primary key (LOCATION_CODE, GROUP_ID, AGENCY_ID_PCC)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 4520K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LASTNUM
prompt ======================
prompt
create table NFS_CA.LASTNUM
(
  location_code CHAR(5) not null,
  key_type      CHAR(2) not null,
  lastnum       NUMBER(5)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.LASTNUM
  add constraint LASTNUM_UX1 primary key (LOCATION_CODE, KEY_TYPE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MLOG$_FARE
prompt =========================
prompt
create table NFS_CA.MLOG$_FARE
(
  m_row$$         VARCHAR2(255),
  snaptime$$      DATE,
  dmltype$$       VARCHAR2(1),
  old_new$$       VARCHAR2(1),
  change_vector$$ RAW(255)
)
tablespace AIR_DAT
  pctfree 60
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on table NFS_CA.MLOG$_FARE
  is 'snapshot log for master table NFS_CA.FARE';

prompt
prompt Creating table PLAN_TABLE
prompt =========================
prompt
create table NFS_CA.PLAN_TABLE
(
  statement_id      VARCHAR2(30),
  timestamp         DATE,
  remarks           VARCHAR2(80),
  operation         VARCHAR2(30),
  options           VARCHAR2(30),
  object_node       VARCHAR2(128),
  object_owner      VARCHAR2(30),
  object_name       VARCHAR2(30),
  object_instance   INTEGER,
  object_type       VARCHAR2(30),
  optimizer         VARCHAR2(255),
  search_columns    NUMBER,
  id                INTEGER,
  parent_id         INTEGER,
  position          INTEGER,
  cost              INTEGER,
  cardinality       INTEGER,
  bytes             INTEGER,
  other_tag         VARCHAR2(255),
  partition_start   VARCHAR2(255),
  partition_stop    VARCHAR2(255),
  partition_id      INTEGER,
  other             LONG,
  distribution      VARCHAR2(30),
  cpu_cost          INTEGER,
  io_cost           INTEGER,
  temp_space        INTEGER,
  access_predicates VARCHAR2(4000),
  filter_predicates VARCHAR2(4000),
  projection        VARCHAR2(4000),
  time              INTEGER,
  qblock_name       VARCHAR2(30)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTE
prompt ====================
prompt
create table NFS_CA.ROUTE
(
  location_code CHAR(5) not null,
  routing_id    CHAR(13) not null,
  route_no      NUMBER(3) not null,
  entry_lastnum NUMBER(3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ROUTE
  add constraint ROUTE_UX1 primary key (LOCATION_CODE, ROUTING_ID, ROUTE_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTE_ENTRY
prompt ==========================
prompt
create table NFS_CA.ROUTE_ENTRY
(
  location_code     CHAR(5) not null,
  routing_id        CHAR(13) not null,
  route_no          NUMBER(3) not null,
  entry_no          NUMBER(3) not null,
  from_code         CHAR(13) not null,
  from_code_type    NUMBER(1) default (0),
  to_code           CHAR(13) not null,
  to_code_type      NUMBER(1) default (0),
  open_jaw_for_btwn NUMBER(1) default (0)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ROUTE_ENTRY
  add constraint ROUTE_ENTRY_UX1 primary key (LOCATION_CODE, ROUTING_ID, ROUTE_NO, ENTRY_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ROUTING
prompt ======================
prompt
create table NFS_CA.ROUTING
(
  location_code     CHAR(5) not null,
  routing_id        CHAR(13) not null,
  ori_code          CHAR(13) not null,
  dest_code         CHAR(13) not null,
  journey_type      CHAR(3),
  route_lastnum     NUMBER(3),
  who_last_update   CHAR(20),
  where_last_update CHAR(5),
  when_last_update  DATE default (SYSDATE),
  ori_code_type     NUMBER(1),
  dest_code_type    NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ROUTING
  add constraint ROUTING_UX1 primary key (LOCATION_CODE, ROUTING_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE
prompt ===================
prompt
create table NFS_CA.RULE
(
  location_code              CHAR(5) not null,
  rule_id                    CHAR(13) not null,
  minimum_stay               NUMBER(3),
  minimum_stay_unit          CHAR(6),
  maximum_stay               NUMBER(3),
  maximum_stay_unit          CHAR(6),
  construction_addons        NUMBER(1),
  day_of_week_restriction    NUMBER(3),
  advance_purchase           NUMBER(3) default (0),
  who_last_update            CHAR(20),
  where_last_update          CHAR(5),
  when_last_update           DATE,
  rule_type                  NUMBER(1) not null,
  status                     NUMBER(1),
  day_of_week_restriction_in NUMBER(3),
  fares_combination_flag     NUMBER(1) default 1,
  group_flag                 NUMBER(1) default (0) not null,
  group_from                 NUMBER(4),
  group_to                   NUMBER(4),
  separate_sale_type         NUMBER(1) default 1,
  refund_rule_id             VARCHAR2(30) default '',
  reissue_id                 VARCHAR2(30),
  combine_open_jaw_flag      NUMBER(1) default 0,
  combine_round_trip_flag    NUMBER(1) default 0,
  max_advanced_purchase      NUMBER(3),
  max_advanced_purchase_unit VARCHAR2(5) default 'Days' not null,
  min_advanced_purchase_unit VARCHAR2(5) default 'Days' not null,
  open_jaw_flag              NUMBER(1) default 0 not null,
  candidate_flag             NUMBER(1) default 0 not null,
  code_share                 NUMBER(1) default 0,
  appcxr_code_share          VARCHAR2(30),
  travel_complete_days_restr NUMBER(3),
  rule_id_no                 VARCHAR2(20),
  sector_range_lower         NUMBER(1),
  sector_range_upper         NUMBER(1),
  forbidden_journey_flag     NUMBER(1) default 0,
  position_limit_type        NUMBER(1) default 0,
  position_limit_spec        NUMBER(1),
  charter_flight_flag        NUMBER(1),
  rule_desc                  VARCHAR2(512),
  rule_seq_id                NUMBER(4),
  effective_date             DATE default to_date('19000101 00:00','yyyyMMdd HH24:mi') not null,
  discontinue_date           DATE default to_date('99991231 23:59','yyyyMMdd HH24:mi') not null,
  xml_import_flag            NUMBER(1) default 0
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 536K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE
  add constraint RULE_UX1 primary key (LOCATION_CODE, RULE_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 288K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE
  add unique (RULE_ID_NO)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_BLACKOUT_PERIOD
prompt ===================================
prompt
create table NFS_CA.RULE_BLACKOUT_PERIOD
(
  location_code      CHAR(5) not null,
  rule_id            CHAR(13) not null,
  blackout_from_date DATE not null,
  blackout_to_date   DATE,
  rule_seq_id        NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_BLACKOUT_PERIOD
  add constraint RULE_BLACKOUT_PERIOD_UX1 primary key (LOCATION_CODE, RULE_ID, BLACKOUT_FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_BLACKOUT_PERIOD_IN
prompt ======================================
prompt
create table NFS_CA.RULE_BLACKOUT_PERIOD_IN
(
  location_code      CHAR(5) not null,
  rule_id            CHAR(13) not null,
  blackout_from_date DATE not null,
  blackout_to_date   DATE,
  rule_seq_id        NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_BLACKOUT_PERIOD_IN
  add primary key (LOCATION_CODE, RULE_ID, BLACKOUT_FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_COMBINATION_ENTRY
prompt =====================================
prompt
create table NFS_CA.RULE_COMBINATION_ENTRY
(
  rule_id              VARCHAR2(13) not null,
  location_code        VARCHAR2(5) not null,
  seq_id               NUMBER(3) not null,
  combine_rule_id      VARCHAR2(13),
  fare_basis           VARCHAR2(15),
  booking_class        VARCHAR2(1),
  last_update_by       VARCHAR2(20) not null,
  last_update_date     DATE not null,
  carrier_code         VARCHAR2(2) default 'CA' not null,
  is_check_all_sectors NUMBER(1) default 1 not null,
  rule_seq_id          NUMBER(4),
  ori_code             VARCHAR2(13) default '***',
  dest_code            VARCHAR2(13) default '***'
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 536K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_COMBINATION_ENTRY
  add constraint RULE_COMBINATION_ENTRY_PK primary key (RULE_ID, LOCATION_CODE, SEQ_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 288K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_ENDORSEMT_RESTRICTION
prompt =========================================
prompt
create table NFS_CA.RULE_ENDORSEMT_RESTRICTION
(
  location_code  CHAR(5) not null,
  rule_id        CHAR(13) not null,
  restriction_id NUMBER(5) not null,
  rule_seq_id    NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_ENDORSEMT_RESTRICTION
  add constraint RULE_ENDORSEMT_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, RESTRICTION_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_EX_FLIGHT_NO
prompt ================================
prompt
create table NFS_CA.RULE_EX_FLIGHT_NO
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.FROM_NO_IDX on NFS_CA.RULE_EX_FLIGHT_NO (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.TO_NO_IDX on NFS_CA.RULE_EX_FLIGHT_NO (TO_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_EX_FLIGHT_NO
  add constraint RULE_EX_FLIGHT_NO_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_EX_FLIGHT_NO_IN
prompt ===================================
prompt
create table NFS_CA.RULE_EX_FLIGHT_NO_IN
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.TO_NO_INDEX on NFS_CA.RULE_EX_FLIGHT_NO_IN (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_EX_FLIGHT_NO_IN
  add constraint RULE_EX_FLIGHT_NO_IN_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_FLIGHT_NO_RESTRICTION
prompt =========================================
prompt
create table NFS_CA.RULE_FLIGHT_NO_RESTRICTION
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 536K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_FLIGHT_NO_RESTRICTION
  add constraint RULE_FLIGHT_NO_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 536K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_FLIGHT_NO_RESTRICTION_IN
prompt ============================================
prompt
create table NFS_CA.RULE_FLIGHT_NO_RESTRICTION_IN
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.FROM_NO_INDX on NFS_CA.RULE_FLIGHT_NO_RESTRICTION_IN (FROM_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.TO_NO_INDX on NFS_CA.RULE_FLIGHT_NO_RESTRICTION_IN (TO_NO)
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_FLIGHT_NO_RESTRICTION_IN
  add constraint RULE_FLIGHT_NO_REST_IN_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 560K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_HOUR_RESTRICTION
prompt ====================================
prompt
create table NFS_CA.RULE_HOUR_RESTRICTION
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_HOUR_RESTRICTION
  add constraint RULE_HOUR_RESTRICTION_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_HOUR_RESTRICTION_IN
prompt =======================================
prompt
create table NFS_CA.RULE_HOUR_RESTRICTION_IN
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4),
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_HOUR_RESTRICTION_IN
  add constraint RULE_HOUR_RESTRICTION_IN_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REFUND
prompt ==========================
prompt
create table NFS_CA.RULE_REFUND
(
  refund_rule_id       VARCHAR2(30) not null,
  location_code        VARCHAR2(5) not null,
  refund_type          NUMBER(1) not null,
  unused_sector_tax    NUMBER(1),
  voluntary_txt        VARCHAR2(150),
  involuntary_txt      VARCHAR2(150),
  last_update_by       VARCHAR2(20) not null,
  last_update_date     DATE not null,
  rule_type            NUMBER(1) default 0 not null,
  refund_yqtax_allowed NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_REFUND
  add constraint RULE_REFUND_PK primary key (REFUND_RULE_ID, RULE_TYPE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REFUND_ENTRY
prompt ================================
prompt
create table NFS_CA.RULE_REFUND_ENTRY
(
  refund_rule_id            VARCHAR2(30) not null,
  seq_id                    NUMBER(3) not null,
  passenger_type            VARCHAR2(2),
  journey_type              VARCHAR2(2),
  booking_class             VARCHAR2(26),
  fare_basis                VARCHAR2(15),
  ticket_use_type           NUMBER(1) not null,
  first_ticketed_time       NUMBER(4),
  last_ticketed_time        NUMBER(4),
  departrue_time_type       NUMBER(1),
  first_departrue_time      NUMBER(4),
  last_departrue_time       NUMBER(4),
  cal_used_sector_type      NUMBER(1),
  cal_booking_class         VARCHAR2(1),
  cal_unused_sector_type    NUMBER(1) not null,
  percent                   NUMBER(3),
  minimum_amount            NUMBER(4),
  fixed_amount              NUMBER(4),
  tax_refund_type           NUMBER(1) not null,
  last_update_by            VARCHAR2(20) not null,
  last_update_date          DATE not null,
  spec_rbd                  VARCHAR2(1),
  entry_translate           VARCHAR2(4000),
  ticketed_time_unit        VARCHAR2(1) default 'H',
  departrue_time_unit       VARCHAR2(1) default 'H',
  cal_unused_pfare_percent  NUMBER(3),
  lower_value               NUMBER(3),
  lower_relate              VARCHAR2(2),
  upper_value               NUMBER(3),
  upper_relate              VARCHAR2(2),
  rule_type                 NUMBER(1) default 0 not null,
  refund_allowed_tag        NUMBER(1) default 1,
  refund_yqtax_allowed      NUMBER(1),
  other_refund_carrier_list VARCHAR2(100)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_REFUND_ENTRY
  add constraint RULE_REFUND_ENTRY_PK primary key (REFUND_RULE_ID, SEQ_ID, RULE_TYPE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE
prompt ===========================
prompt
create table NFS_CA.RULE_REISSUE
(
  reissue_id               VARCHAR2(30) not null,
  location_code            VARCHAR2(5) not null,
  change_tag               VARCHAR2(1),
  voluntary_changed_text   VARCHAR2(2000),
  involuntary_changed_text VARCHAR2(2000),
  who_last_update          VARCHAR2(20),
  where_last_update        VARCHAR2(5),
  when_last_update         DATE default (SYSDATE),
  rule_type                NUMBER(1) default 0 not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_REISSUE
  add constraint RULE_REISSUE_PK primary key (REISSUE_ID, RULE_TYPE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE_DETAIL
prompt ==================================
prompt
create table NFS_CA.RULE_REISSUE_DETAIL
(
  reissue_id                 VARCHAR2(30) not null,
  seq_number                 NUMBER(3) not null,
  passenger_type             VARCHAR2(3),
  fare_basis                 VARCHAR2(15),
  booking_class              VARCHAR2(26),
  journey_type               VARCHAR2(2),
  ticket_used_tag            NUMBER(1),
  flight_launch_tag          VARCHAR2(1),
  flight_launch_unit         VARCHAR2(1),
  flight_launch_number       NUMBER(3),
  free_change_times          VARCHAR2(2),
  charge_type                NUMBER(1),
  charge_currency_code       VARCHAR2(3),
  charge_amount              NUMBER(5),
  discount_calculate_type    NUMBER(1),
  discount_booking_class     VARCHAR2(1),
  discount_percent           NUMBER(5,2),
  charge_unit                NUMBER(1),
  carry_unit                 NUMBER(1),
  round_type                 NUMBER(1),
  charge_min_amount          NUMBER(5),
  charge_min_currency_code   VARCHAR2(3),
  reissue_charge_tag         NUMBER(1),
  reissue_restriction_id     NUMBER(7) not null,
  who_last_update            VARCHAR2(20),
  where_last_update          VARCHAR2(5),
  when_last_update           DATE default (SYSDATE),
  detail_translate           VARCHAR2(4000),
  lower_value                NUMBER(3),
  lower_relate               VARCHAR2(2),
  upper_value                NUMBER(3),
  upper_relate               VARCHAR2(2),
  other_reissue_carrier_list VARCHAR2(100),
  rule_type                  NUMBER(1) default 0 not null,
  special_production_tag     NUMBER(1),
  priority_type              NUMBER(1),
  priority_list              VARCHAR2(100),
  first_ticketed_time        NUMBER(4),
  last_ticketed_time         NUMBER(4),
  ticketed_time_unit         VARCHAR2(1) default 'H',
  departrue_time_type        NUMBER(1),
  first_departrue_time       NUMBER(4),
  last_departrue_time        NUMBER(4),
  departrue_time_unit        VARCHAR2(1) default 'H',
  reissue_allowed_tag        NUMBER(1) default 1,
  discount_code              VARCHAR2(2)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_REISSUE_DETAIL
  add constraint RULE_REISSUE_DETAIL_PK primary key (REISSUE_ID, SEQ_NUMBER, RULE_TYPE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_REISSUE_RESTRICTION
prompt =======================================
prompt
create table NFS_CA.RULE_REISSUE_RESTRICTION
(
  id                            NUMBER(7) not null,
  process_tag                   NUMBER(1) not null,
  date_changed_tag              NUMBER(1) not null,
  first_flight_tag              NUMBER(1) not null,
  flight_date_tag               VARCHAR2(1),
  same_flight_tag               NUMBER(1) not null,
  upgrade_tag                   NUMBER(1) not null,
  fare_display_tag              NUMBER(1) not null,
  endorsment_tag                NUMBER(1) not null,
  endorsment_prefix             VARCHAR2(10),
  endorsment_suffix             VARCHAR2(10),
  new_endorsment                VARCHAR2(82),
  who_last_update               VARCHAR2(20),
  where_last_update             VARCHAR2(5),
  when_last_update              DATE default (SYSDATE),
  flight_date_num               NUMBER(3),
  flight_date_unit              VARCHAR2(1),
  upgrade_fee_tag               NUMBER(1) default 0,
  other_carrier_list            VARCHAR2(100),
  rule_type                     NUMBER(1) default 0 not null,
  not_permit_cabin_list         VARCHAR2(100),
  modclass_newfare_allowlow_tag NUMBER(1)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_REISSUE_RESTRICTION
  add constraint RULE_REISSUE_RESTRICTION_PK primary key (ID, RULE_TYPE)
  using index 
  tablespace AIR_DAT
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_SEASONALITY
prompt ===============================
prompt
create table NFS_CA.RULE_SEASONALITY
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_date     DATE not null,
  to_date       DATE,
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
create index NFS_CA.RULE_SEASONALITY_INDX on NFS_CA.RULE_SEASONALITY (LOCATION_CODE, RULE_ID)
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_SEASONALITY
  add constraint RULE_SEASONALITY_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_SEASONALITY_IN
prompt ==================================
prompt
create table NFS_CA.RULE_SEASONALITY_IN
(
  location_code CHAR(5) not null,
  rule_id       CHAR(13) not null,
  from_date     DATE not null,
  to_date       DATE,
  rule_seq_id   NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_SEASONALITY_IN
  add constraint RULE_SEASONALITY_IN_UX1 primary key (LOCATION_CODE, RULE_ID, FROM_DATE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RULE_TEXTUAL
prompt ===========================
prompt
create table NFS_CA.RULE_TEXTUAL
(
  location_code          CHAR(5) not null,
  rule_id                CHAR(13) not null,
  application            VARCHAR2(4000),
  eligibility            VARCHAR2(4000),
  maximum_group_size     VARCHAR2(4000),
  extension_of_validity  VARCHAR2(4000),
  payment                VARCHAR2(4000),
  ticketing              VARCHAR2(4000),
  cancellation_n_refunds VARCHAR2(4000),
  rebooking_n_rerouting  VARCHAR2(4000),
  travel_together        VARCHAR2(4000),
  other_conditions       VARCHAR2(4000),
  rule_seq_id            NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 6688K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.RULE_TEXTUAL
  add constraint RULE_TEXTUAL_UX1 primary key (LOCATION_CODE, RULE_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 288K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SALES_OFFICE
prompt ===========================
prompt
create table NFS_CA.SALES_OFFICE
(
  location_code        CHAR(5) not null,
  so_type              NUMBER(1) not null,
  so_desc              VARCHAR2(35),
  parent_location_code CHAR(5),
  activated            CHAR(12),
  approval_required    NUMBER(1),
  who_last_update      CHAR(20),
  where_last_update    CHAR(5),
  when_last_update     DATE,
  print_option         NUMBER(1) default (3) not null,
  approving_office     NUMBER(1) default (0),
  approval_type        NUMBER(1) default (0),
  bsp_access           CHAR(4) default ('No'),
  exchange_rate        NUMBER(6,3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.SALES_OFFICE
  add constraint SALES_OFFICE_UX1 primary key (LOCATION_CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table USERS
prompt ====================
prompt
create table NFS_CA.USERS
(
  location_code       CHAR(5) not null,
  user_id             CHAR(20) not null,
  name                VARCHAR2(35),
  password            VARCHAR2(20) not null,
  user_level          CHAR(20),
  contact_no          CHAR(20),
  sita_telex_code     CHAR(10),
  email_address       VARCHAR2(40),
  address             VARCHAR2(128),
  last_login_datetime DATE,
  who_last_update     CHAR(20),
  where_last_update   CHAR(5),
  when_last_update    DATE,
  fax_no              CHAR(20),
  status              CHAR(3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.USERS
  add constraint USERS_UX1 primary key (LOCATION_CODE, USER_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPAGREEMENT
prompt ===========================
prompt
create table NFS_CA.VIPAGREEMENT
(
  location_code       VARCHAR2(5) not null,
  ref_no              VARCHAR2(15) not null,
  sale_eff_date       DATE not null,
  sale_disc_date      DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  travel_eff_date     DATE not null,
  travel_disc_date    DATE default TO_DATE('2222-01-01 00:00', 'YYYY-MM-DD HH24:MI') not null,
  vip_code            VARCHAR2(10) not null,
  endorsement         VARCHAR2(100),
  distribution_status NUMBER(1) not null,
  fare_rec_lastnum    NUMBER(5) default (0) not null,
  city_in_rec_lastnum NUMBER(5) default (0) not null,
  who_last_update     VARCHAR2(20),
  when_last_update    DATE default (SYSDATE),
  where_last_update   VARCHAR2(5)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.VIPAGREEMENT
  add constraint VIPAGREEMENT_PK primary key (LOCATION_CODE, REF_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPAGREEMENT_CITY_IN_CODE
prompt ========================================
prompt
create table NFS_CA.VIPAGREEMENT_CITY_IN_CODE
(
  location_code    VARCHAR2(5) not null,
  ref_no           VARCHAR2(15) not null,
  rec_no           NUMBER(5) not null,
  city_in_code     VARCHAR2(5),
  discount_percent NUMBER(2),
  fare_basis       VARCHAR2(15)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.VIPAGREEMENT_CITY_IN_CODE
  add constraint VIPAGREEMENT_CITY_IN_CODE_PK primary key (LOCATION_CODE, REF_NO, REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPAGREEMENT_EX_CITY_CODE
prompt ========================================
prompt
create table NFS_CA.VIPAGREEMENT_EX_CITY_CODE
(
  location_code VARCHAR2(5) not null,
  ref_no        VARCHAR2(15) not null,
  ex_city_code  VARCHAR2(5) not null
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.VIPAGREEMENT_EX_CITY_CODE
  add constraint VIPAGREEMENT_EX_CITY_CODE_PK primary key (LOCATION_CODE, REF_NO, EX_CITY_CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPAGREEMENT_IN_FLIGHT_NO
prompt ========================================
prompt
create table NFS_CA.VIPAGREEMENT_IN_FLIGHT_NO
(
  location_code VARCHAR2(5) not null,
  ref_no        VARCHAR2(15) not null,
  from_no       NUMBER(4) not null,
  to_no         NUMBER(4)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.VIPAGREEMENT_IN_FLIGHT_NO
  add constraint VIPAGREEMENT_IN_FLIGHT_NO_PK primary key (LOCATION_CODE, REF_NO, FROM_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table VIPFARE
prompt ======================
prompt
create table NFS_CA.VIPFARE
(
  location_code    VARCHAR2(5) not null,
  ref_no           VARCHAR2(15) not null,
  fare_rec_no      NUMBER(5) not null,
  ori_code_type    NUMBER(1) not null,
  ori_code         VARCHAR2(5) not null,
  dest_code_type   NUMBER(1) not null,
  dest_code        VARCHAR2(5) not null,
  fare_basis       VARCHAR2(15),
  algorithm        NUMBER(2) not null,
  discount_percent NUMBER(2)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.VIPFARE
  add constraint VIPFARE_PK primary key (LOCATION_CODE, REF_NO, FARE_REC_NO)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table WEBID_GROUPS_ENTRY
prompt =================================
prompt
create table NFS_CA.WEBID_GROUPS_ENTRY
(
  location_code CHAR(5) not null,
  group_id      VARCHAR2(15) not null,
  webid         CHAR(6) not null,
  webid_desc    VARCHAR2(40)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.WEBID_GROUPS_ENTRY
  add constraint WEBID_GROUPS_ENTRY_UX1 primary key (LOCATION_CODE, GROUP_ID, WEBID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 80K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ZONE
prompt ===================
prompt
create table NFS_CA.ZONE
(
  location_code     CHAR(5) not null,
  zone_id           CHAR(13) not null,
  zone_desc         VARCHAR2(35),
  country_ind       NUMBER(1),
  who_last_update   CHAR(20),
  where_last_update CHAR(5),
  when_last_update  DATE
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ZONE
  add constraint ZONE_UX1 primary key (LOCATION_CODE, ZONE_ID)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ZONE_ENTRY
prompt =========================
prompt
create table NFS_CA.ZONE_ENTRY
(
  location_code CHAR(5) not null,
  zone_id       CHAR(13) not null,
  code_type     CHAR(10) not null,
  code          CHAR(5) not null,
  name          VARCHAR2(35),
  country_code  CHAR(3)
)
tablespace AIR_DAT
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 280K
    minextents 1
    maxextents unlimited
  );
alter table NFS_CA.ZONE_ENTRY
  add constraint ZONE_ENTRY_UX1 primary key (LOCATION_CODE, ZONE_ID, CODE_TYPE, CODE)
  using index 
  tablespace AIR_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 160K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating sequence BASEFAREROUTEENTRYSEQ
prompt =======================================
prompt
create sequence NFS_CA.BASEFAREROUTEENTRYSEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating procedure ATRAIL
prompt =========================
prompt
CREATE OR REPLACE Procedure NFS_CA.ATrail (Location In Char,ByWho In Char,ByDate In Date,Code In Number,Key In Char,Details In VarChar2) As Begin Insert Into NFS_CA.Audit_Trail Values(Location,ByWho,ByDate,Code,Key,Details); End;
/

prompt
prompt Creating procedure PRINTAGREEMENT
prompt =================================
prompt
create or replace procedure nfs_ca.PrintAgreement(p_location in varchar,
                                           p_refno    in varchar) as
  v_sqlstring varchar2(4000);
  v_cursor    number;
  v_stat      number;

  v_currency  varchar2(10);
  v_currency2 varchar2(10);

begin
  v_sqlstring := 'select t1.currency_code,t1.currency_code2
                 from AGREEMENT t1
                 where TRIM(t1.location_code) = :location_code and  trim(t1.ref_no) = :ref_no';
  v_cursor    := dbms_sql.open_cursor;
  dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
  dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
  dbms_sql.bind_variable(v_cursor, ':ref_no', TRIM(p_refno));

  dbms_sql.define_column(v_cursor, 1, v_currency, 10);
  dbms_sql.define_column(v_cursor, 2, v_currency2, 10);

  v_stat := dbms_sql.execute(v_cursor);

  loop
    EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
    dbms_sql.column_value(v_cursor, 1, v_currency);
    dbms_sql.column_value(v_cursor, 2, v_currency2);
    dbms_output.put_line('AgreementCurrency:  ' || v_currency || ' ' ||
                         v_currency2);
  end loop;
  dbms_sql.close_cursor(v_cursor);
end PrintAgreement;
/

prompt
prompt Creating procedure PRINTCOMBINERULE
prompt ===================================
prompt
create or replace procedure nfs_ca.PrintCombineRule(p_location in varchar,
                                             p_ruleid   in varchar) as
  v_sqlstring varchar2(4000);
  v_cursor    number;
  v_stat      number;
  v_rows      number;

  v_combineruleid varchar2(100);
  v_fb            varchar2(40);
  v_class         varchar2(40);
begin
  v_sqlstring := 'select t1.combine_rule_id,t1.fare_basis,t1.booking_class
                 from rule_combination_entry  t1
                 where TRIM(t1.location_code) = :location_code and  trim(t1.rule_id) = :rule_id
                 order by t1.seq_id';
  v_cursor    := dbms_sql.open_cursor;
  dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
  dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
  dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

  dbms_sql.define_column(v_cursor, 1, v_combineruleid, 100);
  dbms_sql.define_column(v_cursor, 2, v_fb, 40);
  dbms_sql.define_column(v_cursor, 3, v_class, 40);

  v_stat := dbms_sql.execute(v_cursor);
  v_rows := 0;

  loop
    EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
    v_rows := v_rows + 1;
    if (v_rows = 1) then
      dbms_output.put_line('<CombineRule>');
    end if;
    dbms_sql.column_value(v_cursor, 1, v_combineruleid);
    dbms_sql.column_value(v_cursor, 2, v_fb);
    dbms_sql.column_value(v_cursor, 3, v_class);

    dbms_output.put_line('    ' || v_combineruleid || '    ' || v_fb ||
                         '    ' || v_class);
  end loop;
  if (v_rows > 0) then
    dbms_output.put_line('</CombineRule>');
  end if;
  dbms_sql.close_cursor(v_cursor);
end PrintCombineRule;
/

prompt
prompt Creating procedure PRINTFLIGHTNUMBER
prompt ====================================
prompt
create or replace procedure nfs_ca.PrintFlightNumber(p_location in varchar,
                                              p_ruleid   in varchar) as

  procedure PrintFlightNumber2(p_location   in varchar,
                               p_ruleid     in varchar,
                               p_inoutbound in varchar,
                               p_ex_ap_flag in varchar) as
    v_sqlstring varchar2(4000);
    v_cursor    number;
    v_stat      number;
    v_rows      number;

    v_tablename varchar2(50);
    v_from      number;
    v_to        number;
  begin
    if (p_ex_ap_flag = 'EX') then
      v_tablename := 'rule_ex_flight_no';
    else
      v_tablename := 'rule_flight_no_restriction';
    end if;
    if (p_inoutbound = 'I') then
      v_tablename := v_tablename || '_IN';
    end if;
    v_tablename := v_tablename || ' t1 ';
    v_sqlstring := 'select  t1.from_no,t1.to_no from ' || v_tablename ||
                   'where
                     TRIM(t1.location_code) = :location_code and
                     trim(t1.rule_id) = :rule_id ';
    v_cursor    := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
    dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

    dbms_sql.define_column(v_cursor, 1, v_from);
    dbms_sql.define_column(v_cursor, 2, v_to);

    v_stat := dbms_sql.execute(v_cursor);
    v_rows := 0;
    loop
      EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
      v_rows := v_rows + 1;
      dbms_sql.column_value(v_cursor, 1, v_from);
      dbms_sql.column_value(v_cursor, 2, v_to);
      IF (v_rows = 1 and p_ex_ap_flag = 'AP' and v_from = 0 and v_to = 9999) then
        v_rows := 0;
        exit;
      elsif (v_rows = 1) then
        dbms_output.put_line('<' || p_ex_ap_flag || 'FlightNumber' || '_' ||
                             p_inoutbound || '>');
      end if;
      dbms_output.put_line('    ' || v_from || ' --> ' || v_to);
    end loop;
    IF (v_rows > 0) THEN
      dbms_output.put_line('</' || p_ex_ap_flag || 'FlightNumber' || '_' ||
                           p_inoutbound || '>');
      dbms_output.put_line('');
    END IF;
    dbms_sql.close_cursor(v_cursor);
  end PrintFlightNumber2;
begin
  PrintFlightNumber2(p_location, p_ruleid, 'O', 'EX');
  PrintFlightNumber2(p_location, p_ruleid, 'O', 'AP');
  PrintFlightNumber2(p_location, p_ruleid, 'I', 'EX');
  PrintFlightNumber2(p_location, p_ruleid, 'I', 'AP');
end;
/

prompt
prompt Creating procedure PRINTROUTING
prompt ===============================
prompt
create or replace procedure nfs_ca.PrintRouting(p_location        in varchar,
                                         p_ref_no          in varchar,
                                         p_fare_rec_no     in number,
                                         p_sub_fare_rec_no in number) as
  v_sqlstring    varchar2(4000);
  v_cursor       number;
  v_stat         number;
  v_from         varchar(4);
  v_to           varchar(4);
  v_stopoverflag varchar(2);
  v_routeno      number;
  v_entryno      number;
  v_rows         number;
  procedure PrintFlightEntry(p_location        in varchar,
                             p_ref_no          in varchar,
                             p_fare_rec_no     in number,
                             p_sub_fare_rec_no in number,
                             p_route_no        in number,
                             p_entry_no        in number) as
    v_sqlstring  varchar2(4000);
    v_cursor     number;
    v_stat       number;
    v_carrier    varchar2(3);
    v_class      varchar2(2);
    v_ap_from_no number;
    v_ap_to_no   number;
    v_ex_from_no number;
    v_ex_to_no   number;

  begin
    v_sqlstring := 'select TRIM(t1.carrier_code), TRIM(t1.booking_class),
                t1.ap_from_no, t1.ap_to_no,t1.ex_from_no,t1.ex_to_no
                from fare_route_flight_no t1
                where TRIM(t1.ref_no) = :ref_no';

    if (p_location is not null) then
      v_sqlstring := v_sqlstring ||
                     ' and trim(T1.LOCATION_CODE) = :location_code';
    end if;

    if (p_fare_rec_no is not null) then
      v_sqlstring := v_sqlstring || ' and T1.fare_rec_no = :fare_rec_no';
    end if;

    if (p_sub_fare_rec_no is not null) then
      v_sqlstring := v_sqlstring ||
                     ' and T1.sub_fare_rec_no = :sub_fare_rec_no';
    end if;

    if (p_route_no is not null) then
      v_sqlstring := v_sqlstring || ' and T1.route_no = :route_no';
    end if;

    if (p_entry_no is not null) then
      v_sqlstring := v_sqlstring || ' and T1.entry_no = :entry_no';
    end if;

    v_sqlstring := v_sqlstring || ' ORDER BY T1.flight_entry_no';

    v_cursor := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
    dbms_sql.bind_variable(v_cursor, ':ref_no', TRIM(p_ref_no));

    if (p_location is not null) then
      dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
    end if;

    if (p_fare_rec_no is not null) then
      dbms_sql.bind_variable(v_cursor, ':fare_rec_no', p_fare_rec_no);
    end if;

    if (p_sub_fare_rec_no is not null) then
      dbms_sql.bind_variable(v_cursor,
                             ':sub_fare_rec_no',
                             p_sub_fare_rec_no);
    end if;

    if (p_route_no is not null) then
      dbms_sql.bind_variable(v_cursor, ':route_no', p_route_no);
    end if;

    if (p_entry_no is not null) then
      dbms_sql.bind_variable(v_cursor, ':entry_no', p_entry_no);
    end if;

    dbms_sql.define_column(v_cursor, 1, v_carrier, 3);
    dbms_sql.define_column(v_cursor, 2, v_class, 2);
    dbms_sql.define_column(v_cursor, 3, v_ap_from_no);
    dbms_sql.define_column(v_cursor, 4, v_ap_to_no);
    dbms_sql.define_column(v_cursor, 5, v_ex_from_no);
    dbms_sql.define_column(v_cursor, 6, v_ex_to_no);
    v_stat := dbms_sql.execute(v_cursor);
    loop
      EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;

      dbms_sql.column_value(v_cursor, 1, v_carrier);
      dbms_sql.column_value(v_cursor, 2, v_class);
      dbms_sql.column_value(v_cursor, 3, v_ap_from_no);
      dbms_sql.column_value(v_cursor, 4, v_ap_to_no);
      dbms_sql.column_value(v_cursor, 5, v_ex_from_no);
      dbms_sql.column_value(v_cursor, 6, v_ex_to_no);

      dbms_output.put(v_carrier || '(' || v_class || ') ');
      if (v_ex_from_no is not null and v_ex_to_no is not null) then
        dbms_output.put('����:' || v_ex_from_no || ' --> ' || v_ex_to_no || ' ');
      end if;
      if (v_ap_from_no is not null and v_ap_to_no is not null) then
        dbms_output.put('����: ' || v_ap_from_no || ' --> ' || v_ap_to_no || ' ');
      end if;
    end loop;
    dbms_sql.close_cursor(v_cursor);
  end PrintFlightEntry;
begin

  v_sqlstring := 'select TRIM(t1.from_code), TRIM(t1.to_code),TRIM(T1.STOPOVER_OR_TRANSFER),
                t1.route_no, t1.entry_no
                from fare_route_entry t1
                where TRIM(t1.ref_no) = :ref_no';

  if (p_location is not null) then
    v_sqlstring := v_sqlstring ||
                   ' and trim(T1.LOCATION_CODE) = :location_code';
  end if;

  if (p_fare_rec_no is not null) then
    v_sqlstring := v_sqlstring || ' and T1.fare_rec_no = :fare_rec_no';
  end if;

  if (p_sub_fare_rec_no is not null) then
    v_sqlstring := v_sqlstring ||
                   ' and T1.sub_fare_rec_no = :sub_fare_rec_no';
  end if;

  v_sqlstring := v_sqlstring || ' ORDER BY T1.ROUTE_NO, T1.ENTRY_NO';

  v_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
  dbms_sql.bind_variable(v_cursor, ':ref_no', TRIM(p_ref_no));

  if (p_location is not null) then
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
  end if;

  if (p_fare_rec_no is not null) then
    dbms_sql.bind_variable(v_cursor, ':fare_rec_no', p_fare_rec_no);
  end if;

  if (p_sub_fare_rec_no is not null) then
    dbms_sql.bind_variable(v_cursor, ':sub_fare_rec_no', p_sub_fare_rec_no);
  end if;

  dbms_sql.define_column(v_cursor, 1, v_from, 4);
  dbms_sql.define_column(v_cursor, 2, v_to, 4);
  dbms_sql.define_column(v_cursor, 3, v_stopoverflag, 2);
  dbms_sql.define_column(v_cursor, 4, v_routeno);
  dbms_sql.define_column(v_cursor, 5, v_entryno);
  v_stat := dbms_sql.execute(v_cursor);
  v_rows := 0;
  loop
    EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
    v_rows := v_rows + 1;
    if (v_rows = 1) then
      dbms_output.put_line('<Routing>');
      dbms_output.put_line('--- O = all, S > 24h , X <= 24h ---');
    end if;
    dbms_sql.column_value(v_cursor, 1, v_from);
    dbms_sql.column_value(v_cursor, 2, v_to);
    dbms_sql.column_value(v_cursor, 3, v_stopoverflag);
    dbms_sql.column_value(v_cursor, 4, v_routeno);
    dbms_sql.column_value(v_cursor, 5, v_entryno);

    if (v_entryno = 0 and v_routeno != 0) then
      dbms_output.put_line('');
    end if;
    dbms_output.put(v_from || ' ' || v_to || ' ' || v_stopoverflag || ' ');
    PrintFlightEntry(p_location,
                     p_ref_no,
                     p_fare_rec_no,
                     p_sub_fare_rec_no,
                     v_routeno,
                     v_entryno);
    dbms_output.put_line('');
  end loop;
  if (v_rows > 0) then
    dbms_output.put_line('</Routing>');
  end if;
  dbms_sql.close_cursor(v_cursor);

end PrintRouting;
/

prompt
prompt Creating procedure PRINTRULE
prompt ============================
prompt
create or replace procedure nfs_ca.PrintRule(p_location in varchar,
                                      p_ruleid   in varchar) as
  v_sqlstring varchar2(4000);
  v_cursor    number;
  v_stat      number;
  v_rows      number;

  v_min             number;
  v_minunit         varchar2(6);
  v_max             number;
  v_maxunit         varchar2(6);
  v_dayweek         number;
  v_dayweekIn       number;
  v_advancepurchase number;
  v_separateflag    number;
  v_combineflag     number;
  v_groupflag       number;
  v_groupfrom       number;
  v_groupto         number;

begin

  v_sqlstring := 'select t1.minimum_stay,t1.minimum_stay_unit,t1.maximum_stay,t1.maximum_stay_unit,
                 t1.day_of_week_restriction,t1.day_of_week_restriction_in,
                 t1.advance_purchase,t1.separate_sale_type,t1.fares_combination_flag,
                 t1.group_flag,t1.group_from,t1.group_to
                 from rule t1
                 where TRIM(t1.location_code) = :location_code and  trim(t1.rule_id) = :rule_id';

  --dbms_output.put_line(v_sqlstring);
  --dbms_output.put_line(p_location || ' ' || p_ruleid);
  v_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
  dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
  dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

  dbms_sql.define_column(v_cursor, 1, v_min);
  dbms_sql.define_column(v_cursor, 2, v_minunit, 6);
  dbms_sql.define_column(v_cursor, 3, v_max);
  dbms_sql.define_column(v_cursor, 4, v_maxunit, 6);
  dbms_sql.define_column(v_cursor, 5, v_dayweek);
  dbms_sql.define_column(v_cursor, 6, v_dayweekIn);
  dbms_sql.define_column(v_cursor, 7, v_advancepurchase);
  dbms_sql.define_column(v_cursor, 8, v_separateflag);
  dbms_sql.define_column(v_cursor, 9, v_combineflag);
  dbms_sql.define_column(v_cursor, 10, v_groupflag);
  dbms_sql.define_column(v_cursor, 11, v_groupfrom);
  dbms_sql.define_column(v_cursor, 12, v_groupto);

  v_stat := dbms_sql.execute(v_cursor);
  v_rows := 0;
  dbms_output.put_line('<Rule>');
  loop
    EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
    v_rows := v_rows + 1;

    dbms_sql.column_value(v_cursor, 1, v_min);
    dbms_sql.column_value(v_cursor, 2, v_minunit);
    dbms_sql.column_value(v_cursor, 3, v_max);
    dbms_sql.column_value(v_cursor, 4, v_maxunit);
    dbms_sql.column_value(v_cursor, 5, v_dayweek);
    dbms_sql.column_value(v_cursor, 6, v_dayweekIn);
    dbms_sql.column_value(v_cursor, 7, v_advancepurchase);
    dbms_sql.column_value(v_cursor, 8, v_separateflag);
    dbms_sql.column_value(v_cursor, 9, v_combineflag);
    dbms_sql.column_value(v_cursor, 10, v_groupflag);
    dbms_sql.column_value(v_cursor, 11, v_groupfrom);
    dbms_sql.column_value(v_cursor, 12, v_groupto);

    if (v_min is not null) then
      dbms_output.put_line('Min(FARE_RULE):' || v_min || v_minunit);
    end if;

    if (v_max is not null) then
      dbms_output.put_line('Max(FARE_RULE):' || v_max || v_maxunit);
    end if;

    if (v_dayweek != 127 and v_dayweek != 0) then
      dbms_output.put_line('Week:          ' || v_dayweek || ' ' ||
                           v_dayweekIn);
    end if;

    if (v_advancepurchase is not null and v_advancepurchase != 0) then
      dbms_output.put_line('Advance:       ' || v_advancepurchase);
    end if;

    if (v_separateflag = 0) then
      dbms_output.put_line('Separateflag:  ' || v_separateflag);
    end if;

    if (v_groupflag != 0) then
      dbms_output.put_line('Group:         ' || v_groupflag || ' (' ||
                           v_groupfrom || ',' || v_groupto || ')');
    end if;

    if (v_combineflag != 1) then
      dbms_output.put_line('Combineflag :  ' || v_combineflag ||
                           ' (0: CAN''T COMBINE  1:COMBINE ALLWAYS  2:COMBINE SOMETIMES)');
    end if;

  end loop;
  dbms_output.put_line('</Rule>');
  dbms_sql.close_cursor(v_cursor);

end PrintRule;
/

prompt
prompt Creating procedure PRINTSEASON
prompt ==============================
prompt
create or replace procedure nfs_ca.PrintSeason(p_location in varchar,
                                        p_ruleid   in varchar) as

  procedure PrintBlackout(p_location   in varchar,
                          p_ruleid     in varchar,
                          p_inoutbound in varchar) as
    v_sqlstring varchar2(4000);
    v_cursor    number;
    v_stat      number;
    v_rows      number;

    v_tablename varchar2(50);
    v_from      varchar2(10);
    v_to        varchar2(10);
  begin
    v_tablename := 'RULE_BLACKOUT_PERIOD';
    if (p_inoutbound = 'I') then
      v_tablename := v_tablename || '_IN';
    end if;
    v_tablename := v_tablename || ' t1 ';
    v_sqlstring := 'select
                     TO_CHAR(t1.blackout_from_date, ''DDMONYY''),
                     TO_CHAR(t1.blackout_to_date, ''DDMONYY'') from ' ||
                   v_tablename ||
                   ' where
                     TRIM(t1.location_code) = :location_code and
                     trim(t1.rule_id) = :rule_id  ';
    v_cursor    := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
    dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

    dbms_sql.define_column(v_cursor, 1, v_from, 10);
    dbms_sql.define_column(v_cursor, 2, v_to, 10);

    v_stat := dbms_sql.execute(v_cursor);
    v_rows := 0;
    loop
      EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
      v_rows := v_rows + 1;
      IF (v_rows = 1) then
        dbms_output.put_line('<Blackout' || '_' || p_inoutbound || '>');
      end if;
      dbms_sql.column_value(v_cursor, 1, v_from);
      dbms_sql.column_value(v_cursor, 2, v_to);
      dbms_output.put_line('    ' || v_from || ' --> ' || v_to);
    end loop;
    IF (v_rows > 0) THEN
      dbms_output.put_line('</Blackout' || '_' || p_inoutbound || '>');
      dbms_output.put_line('');
    END IF;
    dbms_sql.close_cursor(v_cursor);
  end PrintBlackout;

  procedure PrintFromTo(p_location   in varchar,
                        p_ruleid     in varchar,
                        p_inoutbound in varchar) as
    v_sqlstring varchar2(4000);
    v_cursor    number;
    v_stat      number;
    v_rows      number;

    v_tablename varchar2(50);
    v_from      varchar2(10);
    v_to        varchar2(10);
  begin
    v_tablename := 'RULE_SEASONALITY';
    if (p_inoutbound = 'I') then
      v_tablename := v_tablename || '_IN';
    end if;
    v_tablename := v_tablename || ' t1 ';
    v_sqlstring := 'select
                     TO_CHAR(t1.from_date, ''DDMONYY''),
                     TO_CHAR(t1.to_date, ''DDMONYY'') from ' ||
                   v_tablename ||
                   'where
                     TRIM(t1.location_code) = :location_code and
                     trim(t1.rule_id) = :rule_id ';
    v_cursor    := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
    dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

    dbms_sql.define_column(v_cursor, 1, v_from, 10);
    dbms_sql.define_column(v_cursor, 2, v_to, 10);

    v_stat := dbms_sql.execute(v_cursor);
    v_rows := 0;
    loop
      EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
      v_rows := v_rows + 1;
      IF (v_rows = 1) then
        dbms_output.put_line('<Season' || '_' || p_inoutbound || '>');
      end if;
      dbms_sql.column_value(v_cursor, 1, v_from);
      dbms_sql.column_value(v_cursor, 2, v_to);
      dbms_output.put_line('    ' || v_from || ' --> ' || v_to);
    end loop;
    IF (v_rows > 0) THEN
      dbms_output.put_line('</Season' || '_' || p_inoutbound || '>');
      dbms_output.put_line('');
    end if;
    dbms_sql.close_cursor(v_cursor);
  end PrintFromTo;
begin
  PrintBlackout(p_location, p_ruleid, 'O');
  PrintFromTo(p_location, p_ruleid, 'O');
  PrintBlackout(p_location, p_ruleid, 'I');
  PrintFromTo(p_location, p_ruleid, 'I');
end;
/

prompt
prompt Creating procedure PRINTTIME
prompt ============================
prompt
create or replace procedure nfs_ca.PrintTime(p_location in varchar,
                                      p_ruleid   in varchar) as

  procedure PrintTime2(p_location   in varchar,
                       p_ruleid     in varchar,
                       p_inoutbound in varchar) as
    v_sqlstring varchar2(4000);
    v_cursor    number;
    v_stat      number;
    v_rows      number;

    v_tablename varchar2(50);
    v_from      number;
    v_to        number;
  begin
    v_tablename := 'rule_hour_restriction';
    if (p_inoutbound = 'I') then
      v_tablename := v_tablename || '_IN';
    end if;
    v_tablename := v_tablename || ' t1 ';
    v_sqlstring := 'select t1.from_no, t1.to_no from ' || v_tablename ||
                   'where
                     TRIM(t1.location_code) = :location_code and
                     trim(t1.rule_id) = :rule_id ';
    v_cursor    := dbms_sql.open_cursor;
    --dbms_output.put_line(v_sqlstring);
    dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
    dbms_sql.bind_variable(v_cursor, ':rule_id', TRIM(p_ruleid));

    dbms_sql.define_column(v_cursor, 1, v_from);
    dbms_sql.define_column(v_cursor, 2, v_to);

    v_stat := dbms_sql.execute(v_cursor);
    v_rows := 0;
    loop
      EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
      v_rows := v_rows + 1;
      dbms_sql.column_value(v_cursor, 1, v_from);
      dbms_sql.column_value(v_cursor, 2, v_to);
      IF (v_rows = 1 and v_from = 0 and v_to = 2359) then
        v_rows := 0;
        exit;
      elsif (v_rows = 1) then
        dbms_output.put_line('<Time' || '_' || p_inoutbound || '>');
      end if;
      dbms_output.put_line('    ' || v_from || ' --> ' || v_to);
    end loop;
    IF (v_rows > 0) THEN
      dbms_output.put_line('</Time' || '_' || p_inoutbound || '>');
      dbms_output.put_line('');
    END IF;
    dbms_sql.close_cursor(v_cursor);
  end PrintTime2;

begin
  PrintTime2(p_location, p_ruleid, 'O');
  PrintTime2(p_location, p_ruleid, 'I');
end PrintTime;
/

prompt
prompt Creating procedure PRINTFARE
prompt ============================
prompt
create or replace procedure nfs_ca.PrintFare(p_location        in out varchar,
                                      p_ref_no          in varchar,
                                      p_fare_rec_no     in out number,
                                      p_sub_fare_rec_no in out number) as
  v_sqlstring varchar2(4000);
  v_cursor    number;
  v_stat      number;
  v_rows      number;

  v_oricity            varchar2(4);
  v_descity            varchar2(4);
  v_jouneytype         varchar2(3);
  v_farebasis          varchar2(40);
  v_class              varchar2(2);
  v_class2             varchar2(2);
  v_amount             number;
  v_infantamount       number;
  v_childamount        number;
  v_effectivedate      varchar2(17);
  v_discontinuedate    varchar2(17);
  v_firsttraveldate    varchar2(17);
  v_lasttraveldate     varchar2(17);
  v_firstticketeddate  varchar2(17);
  v_lastticketeddate   varchar2(17);
  v_travelcompletedate varchar2(17);
  v_ruleid             varchar2(100);
  v_location           varchar2(4);
  v_fare_rec_no        number;
  v_sub_fare_rec_no    number;
begin
  execute immediate 'alter session set nls_date_language = ''american''';
  v_sqlstring := 'select TRIM(t1.ori_code), TRIM(t1.dest_code),TRIM(T1.journey_type),
                TRIM(t1.fare_basis), t1.booking_class, t1.booking_class_2,
                t1.amount,t1.infant_discount_amount, t1.child_discount_amount,
                TO_CHAR(t1.effective_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.discontinue_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.first_travel_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.last_travel_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.first_ticketed_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.last_ticketed_date, ''DDMONYY/HH24:MI''),
                TO_CHAR(t1.travel_complete_date, ''DDMONYY/HH24:MI''),
                trim(t1.rule_id), trim(t1.location_code),t1.fare_rec_no,t1.sub_fare_rec_no
                from fare t1
                where TRIM(t1.ref_no) = :ref_no';

  if (p_location is not null) then
    v_sqlstring := v_sqlstring ||
                   ' and trim(T1.LOCATION_CODE) = :location_code';
  end if;

  if (p_fare_rec_no is not null) then
    v_sqlstring := v_sqlstring || ' and T1.fare_rec_no = :fare_rec_no';
  end if;

  if (p_sub_fare_rec_no is not null) then
    v_sqlstring := v_sqlstring ||
                   ' and T1.sub_fare_rec_no = :sub_fare_rec_no';
  end if;
  --dbms_output.put_line(v_sqlstring);
  v_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(v_cursor, v_sqlstring, dbms_sql.native);
  dbms_sql.bind_variable(v_cursor, ':ref_no', TRIM(p_ref_no));

  if (p_location is not null) then
    dbms_sql.bind_variable(v_cursor, ':location_code', TRIM(p_location));
  end if;

  if (p_fare_rec_no is not null) then
    dbms_sql.bind_variable(v_cursor, ':fare_rec_no', p_fare_rec_no);
  end if;

  if (p_sub_fare_rec_no is not null) then
    dbms_sql.bind_variable(v_cursor, ':sub_fare_rec_no', p_sub_fare_rec_no);
  end if;

  dbms_sql.define_column(v_cursor, 1, v_oricity, 4);
  dbms_sql.define_column(v_cursor, 2, v_descity, 4);
  dbms_sql.define_column(v_cursor, 3, v_jouneytype, 3);
  dbms_sql.define_column(v_cursor, 4, v_farebasis, 40);
  dbms_sql.define_column(v_cursor, 5, v_class, 2);
  dbms_sql.define_column(v_cursor, 6, v_class2, 2);
  dbms_sql.define_column(v_cursor, 7, v_amount);
  dbms_sql.define_column(v_cursor, 8, v_infantamount);
  dbms_sql.define_column(v_cursor, 9, v_childamount);
  dbms_sql.define_column(v_cursor, 10, v_effectivedate, 17);
  dbms_sql.define_column(v_cursor, 11, v_discontinuedate, 17);
  dbms_sql.define_column(v_cursor, 12, v_firsttraveldate, 17);
  dbms_sql.define_column(v_cursor, 13, v_lasttraveldate, 17);
  dbms_sql.define_column(v_cursor, 14, v_firstticketeddate, 17);
  dbms_sql.define_column(v_cursor, 15, v_lastticketeddate, 17);
  dbms_sql.define_column(v_cursor, 16, v_travelcompletedate, 17);
  dbms_sql.define_column(v_cursor, 17, v_ruleid, 100);
  dbms_sql.define_column(v_cursor, 18, v_location, 4);
  dbms_sql.define_column(v_cursor, 19, v_fare_rec_no);
  dbms_sql.define_column(v_cursor, 20, v_sub_fare_rec_no);
  v_stat := dbms_sql.execute(v_cursor);
  v_rows := 0;
  loop
    EXIT WHEN dbms_sql.fetch_rows(v_cursor) <= 0;
    v_rows := v_rows + 1;
    if (v_rows > 1) then
      dbms_output.put_line('FARE���ж���˼�!!!');
      exit;
    end if;

    dbms_sql.column_value(v_cursor, 1, v_oricity);
    dbms_sql.column_value(v_cursor, 2, v_descity);
    dbms_sql.column_value(v_cursor, 3, v_jouneytype);
    dbms_sql.column_value(v_cursor, 4, v_farebasis);
    dbms_sql.column_value(v_cursor, 5, v_class);
    dbms_sql.column_value(v_cursor, 6, v_class2);
    dbms_sql.column_value(v_cursor, 7, v_amount);
    dbms_sql.column_value(v_cursor, 8, v_infantamount);
    dbms_sql.column_value(v_cursor, 9, v_childamount);
    dbms_sql.column_value(v_cursor, 10, v_effectivedate);
    dbms_sql.column_value(v_cursor, 11, v_discontinuedate);
    dbms_sql.column_value(v_cursor, 12, v_firsttraveldate);
    dbms_sql.column_value(v_cursor, 13, v_lasttraveldate);
    dbms_sql.column_value(v_cursor, 14, v_firstticketeddate);
    dbms_sql.column_value(v_cursor, 15, v_lastticketeddate);
    dbms_sql.column_value(v_cursor, 16, v_travelcompletedate);
    dbms_sql.column_value(v_cursor, 17, v_ruleid);
    dbms_sql.column_value(v_cursor, 18, v_location);
    dbms_sql.column_value(v_cursor, 19, v_fare_rec_no);
    dbms_sql.column_value(v_cursor, 20, v_sub_fare_rec_no);

    p_location        := v_location;
    p_fare_rec_no     := v_fare_rec_no;
    p_sub_fare_rec_no := v_sub_fare_rec_no;

    dbms_output.put_line('RefNo:       ' || p_ref_no);
    dbms_output.put_line('Location:    ' || v_location);
    dbms_output.put_line('FareRecNo:   ' || v_fare_rec_no);
    dbms_output.put_line('SubFareRecNo:' || v_sub_fare_rec_no);
    dbms_output.put_line('RuleID:      ' || v_ruleid);
    dbms_output.put_line('Fb:          ' || v_farebasis);

    if (v_amount != -2) then
      dbms_output.put_line('Amount:      ' || v_amount);
    end if;
    if (v_childamount != -2) then
      dbms_output.put_line('Child:       ' || v_childamount);
    end if;
    if (v_infantamount != -2) then
      dbms_output.put_line('Infant:      ' || v_infantamount);
    end if;
    dbms_output.put_line('');

    dbms_output.put_line(v_oricity || ' --> ' || v_descity || '         ' ||
                         v_jouneytype);
    dbms_output.put_line('Cabin:              ' || TRIM(v_class) || ' ' ||
                         v_class2);
    dbms_output.put_line('effective:          ' || v_effectivedate ||
                         ' --> ' || v_discontinuedate);
    dbms_output.put_line('firsttravel:        ' || v_firsttraveldate ||
                         ' --> ' || v_lasttraveldate);
    dbms_output.put_line('firstticketed:      ' || v_firstticketeddate ||
                         ' --> ' || v_lastticketeddate);
    if (v_travelcompletedate != '01JAN22/00:00') then
      dbms_output.put_line('travelcompletedate: ' || v_travelcompletedate);
    end if;

    PrintAgreement(v_location,  p_ref_no);

    dbms_output.put_line('');
    PrintRouting(v_location, p_ref_no, v_fare_rec_no, v_sub_fare_rec_no);
    dbms_output.put_line('');
    Printrule(v_location, v_ruleid);
    dbms_output.put_line('');
    PrintSeason(v_location, v_ruleid);
    PrintTime(v_location, v_ruleid);
    PrintFlightNumber(v_location, v_ruleid);
    PrintCombineRule(v_location, v_ruleid);
  end loop;
  if (v_rows = 0) then
    dbms_output.put_line('FARE����û�и��˼�!!!');
  end if;
  dbms_sql.close_cursor(v_cursor);

end PrintFare;
/

prompt
prompt Creating procedure PROC_SCHEMAUSER
prompt ==================================
prompt
create or replace procedure nfs_ca.proc_schemaUser(carr in varchar2) Authid Current_User is
    trisql varchar2(10000);
begin
    trisql := 'CREATE USER NFS_' || carr || ' IDENTIFIED BY NFS_' || carr ||
              ' DEFAULT TABLESPACE air_dat TEMPORARY TABLESPACE temp  QUOTA UNLIMITED  ON air_dat QUOTA UNLIMITED ON air_idx';
    execute immediate trisql;
    trisql := 'GRANT CONNECT TO NFS_' || carr || '';
    execute immediate trisql;
    trisql := 'GRANT CREATE PROCEDURE TO NFS_' || carr || '';
    execute immediate trisql;
    trisql := 'GRANT RESOURCE TO NFS_' || carr || '';
    execute immediate trisql;
    trisql := 'GRANT temprole TO NFS_' || carr || '';
    execute immediate trisql;
end;
/


spool off
