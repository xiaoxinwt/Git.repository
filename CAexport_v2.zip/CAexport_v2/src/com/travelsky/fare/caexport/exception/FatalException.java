package com.travelsky.fare.caexport.exception;

public class FatalException extends Exception {

	public FatalException() {
		super();
	}

	public FatalException(String msg, Throwable e) {
		super(msg, e);
	}

	public FatalException(String msg) {
		super(msg);
	}

	public FatalException(Throwable e) {
		super(e);
	}
	
	
     
}
