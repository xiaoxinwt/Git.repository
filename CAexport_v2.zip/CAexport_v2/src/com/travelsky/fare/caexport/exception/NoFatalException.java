package com.travelsky.fare.caexport.exception;

public class NoFatalException extends Exception {

}
