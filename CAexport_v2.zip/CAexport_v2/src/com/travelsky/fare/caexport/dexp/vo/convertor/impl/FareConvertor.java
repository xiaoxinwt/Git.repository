package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRoute;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRule;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.IFareConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.FareRouteConvertor;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.FareRuleConvertor;
import com.travelsky.fare.caexport.dexp.vo.fare.XFare;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRoute;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRule;
import com.travelsky.fare.caexport.util.StringUtil;

public class FareConvertor implements IConvert<Fare, XFare>,IFareConvert<Fare, XFare>{
	
	private IConvert<FareRoute,XFareRoute> routeconvertor = new FareRouteConvertor();
	private IConvert<FareRule,XFareRule> ruleconvertor = new FareRuleConvertor();

	@Override
	public List<XFare> convert(List<Fare> list) {
		List<XFare> fares = null;
		if(list!=null && list.size()>0){
			fares = new ArrayList<XFare>();
			for (Fare fare : list) {
				fares.add( convert(fare) );
			}
		}
		
		return fares;
	}

	@Override
	public XFare convert(Fare fare) {
		XFare xfare = null;
		if( fare!=null ){
			
			if( StringUtil.isNullOrEmpty(fare.getRefNo()) ) return null;
			
			xfare = new XFare();
			xfare.setFareRecNo(fare.getRecNo());

//			xfare.setPnFareNo( fare.getPk().getPnFareNo() );
//			xfare.setPnRptFileNo( fare.getPk().getPnRptFileNo() );
//			xfare.setPnFareNo( StringUtil.getValue( fare.getPk().getPnFareNo() , "" ) );
//			xfare.setPnRptFileNo( StringUtil.getValue( fare.getPk().getPnRptFileNo() ,"" ) );
			xfare.setStopoverFlag( fare.getStopoverFlag() );
			xfare.setClassofservice( fare.getClassOfService() );
			
			xfare.setOricodetype( fare.getOri().getOriCodeType() );
			xfare.setOricode( fare.getOri().getOriCode() );
			xfare.setOricitycode( fare.getOri().getOriCityCode() );
			xfare.setDestcodetype( fare.getDest().getDestCodeType() );
			xfare.setDestcode( fare.getDest().getDestCode() );
			xfare.setDestcitycode( fare.getDest().getDestCityCode() );
			xfare.setJourneytype( fare.getJourneyType() );
			xfare.setFarebasis( fare.getBasis() );
			xfare.setBookingclass( fare.getBookingClass() );
			xfare.setAmount( fare.getAmount() );

			xfare.setGlobaldirection( fare.getGlobalDirection() );
			xfare.setValuecode( fare.getValueCode() );
			xfare.setEffectivedate( fare.getFromto().getEffectiveDate() );
			xfare.setDiscontinuedate( fare.getFromto().getDiscontinueDate() );
			xfare.setFirsttraveldate( fare.getTravel().getFirstTravelDate() );
			xfare.setLasttraveldate( fare.getTravel().getLastTravelDate() );
			xfare.setFirstticketeddate( fare.getTicket().getFirstTicketedDate() );
			xfare.setLastticketeddate( fare.getTicket().getLastTicketedDate() );
			xfare.setRuleid( fare.getRuleId() );
			xfare.setInfantdiscountamount( fare.getInfant().getInfantDiscountAmount() );
			xfare.setChilddiscountamount( fare.getChild().getChildDiscountAmount() );
			xfare.setFaretype( fare.getType() );
			xfare.setBookingclass2( fare.getBookingClass2() );
			xfare.setChildvaluecode( fare.getChild().getChildValueCode() );
			xfare.setInfantvaluecode( fare.getInfant().getInfantValueCode() );
			xfare.setTourcode( fare.getTourCode() );
			xfare.setChildtourcode( fare.getChild().getChildTourCode() );
			xfare.setInfanttourcode( fare.getInfant().getInfantTourCode() );
			xfare.setEndorsementrestriction( fare.getEndorsementRestriction() );
			xfare.setPublishedfarebasiscode( fare.getPublishedFareBasisCode() );
			xfare.setOutboundpermitted( fare.getBound().getOutboundPermitted() );
			xfare.setInboundpermitted( fare.getBound().getInboundPermitted() );
			xfare.setAdultrsfamt( fare.getAdult().getAdultRsfAmt() );
			xfare.setChildrsfamt( fare.getChild().getChildRsfAmt() );
			xfare.setInfantrsfamt( fare.getInfant().getInfantRsfAmt() );
			xfare.setDiscountcode( fare.getDiscountCode() );
			xfare.setChildpublishedfbc( fare.getChild().getChildPublishedFbc() );
			xfare.setInfantpublishedfbc( fare.getInfant().getInfantPublishedFbc() );
			xfare.setTravelcompletedate( fare.getTravel().getTravelCompleteDate() );
			xfare.setBaggageallowance( fare.getBaggageAllowance() );
			xfare.setChildbaggageallowance( fare.getChild().getChildBaggageAllowance() );
			xfare.setInfantbaggageallowance( fare.getInfant().getInfantBaggageAllowance() );
			xfare.setUnit( fare.getUnit() );
			xfare.setBasecommissionamt( fare.getComm().getBaseCommissionAmt() );
			xfare.setBasecommissionpct( fare.getComm().getBaseCommissionPct() );
			xfare.setAddtcommissionamt( fare.getComm().getAddtCommissionAmt() );
			xfare.setAddtcommissionpct( fare.getComm().getAddtCommissionPct() );
			xfare.setTickettype( fare.getTicket().getTicketType() );
			xfare.setFareroute( routeconvertor.convert(fare.getFareRoutes() ) );

			XFareRule xrule = fare.getFarerule()!=null ? ruleconvertor.convert( fare.getFarerule() ): new XFareRule();
			xfare.setFarerule( xrule );
		}
		return xfare;
	}

	@Override
	public Map<RefPK, List<XFare>> convertToMapByPK(List<Fare> list,String carrier) {

		Map<RefPK,List<XFare>> faremap = new HashMap<RefPK,List<XFare>>();
		if(list==null || list.size()==0) return faremap;

		XFare xfare = null;
		RefPK pk = null;
		//������ carrCode + LocationCode + refNo
		for (Fare fare : list) {
			pk = new RefPK(carrier, fare.getLocationCode(), fare.getRefNo());
			if( !faremap.containsKey( pk ) ){
				faremap.put( pk, new ArrayList<XFare>() );
			}else{
				xfare = convert(fare);
				faremap.get( pk ).add( xfare );
			}
		}
		return faremap;
	}

}
