package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "application",
    "eligibility",
    "reservations",
    "combination",
    "grouprequirements",
    "paymentsticketing",
    "cancellationnrefunds",
    "rebookingnrerouting",
    "extensionofvalidity",
    "otherconditions"
})
@XmlRootElement(name = "RULE_TEXTUAL")
public class XRuleTextual {
    @XmlElement(name = "APPLICATION", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String application;
    @XmlElement(name = "ELIGIBILITY", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String eligibility;
    @XmlElement(name = "RESERVATIONS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String reservations;
    @XmlElement(name = "COMBINATION", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String combination;
    @XmlElement(name = "GROUP_REQUIREMENTS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String grouprequirements;
    @XmlElement(name = "PAYMENTS_TICKETING", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String paymentsticketing;
    @XmlElement(name = "CANCELLATION_N_REFUNDS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String cancellationnrefunds;
    @XmlElement(name = "REBOOKING_N_REROUTING", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String rebookingnrerouting;
    @XmlElement(name = "EXTENSION_OF_VALIDITY", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String extensionofvalidity;
    @XmlElement(name = "OTHER_CONDITIONS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String otherconditions;

    public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getEligibility() {
		return eligibility;
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	public String getReservations() {
		return reservations;
	}
	public void setReservations(String reservations) {
		this.reservations = reservations;
	}
	public String getCombination() {
		return combination;
	}
	public void setCombination(String combination) {
		this.combination = combination;
	}
	public String getGrouprequirements() {
		return grouprequirements;
	}
	public void setGrouprequirements(String grouprequirements) {
		this.grouprequirements = grouprequirements;
	}
	public String getPaymentsticketing() {
		return paymentsticketing;
	}
	public void setPaymentsticketing(String paymentsticketing) {
		this.paymentsticketing = paymentsticketing;
	}
	public String getCancellationnrefunds() {
		return cancellationnrefunds;
	}
	public void setCancellationnrefunds(String cancellationnrefunds) {
		this.cancellationnrefunds = cancellationnrefunds;
	}
	public String getRebookingnrerouting() {
		return rebookingnrerouting;
	}
	public void setRebookingnrerouting(String rebookingnrerouting) {
		this.rebookingnrerouting = rebookingnrerouting;
	}
	public String getExtensionofvalidity() {
		return extensionofvalidity;
	}
	public void setExtensionofvalidity(String extensionofvalidity) {
		this.extensionofvalidity = extensionofvalidity;
	}
	public String getOtherconditions() {
		return otherconditions;
	}
	public void setOtherconditions(String otherconditions) {
		this.otherconditions = otherconditions;
	}
}
