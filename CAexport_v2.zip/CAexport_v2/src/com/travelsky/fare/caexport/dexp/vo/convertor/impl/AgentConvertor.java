package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.group.GroupEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.group.XAgent;
import com.travelsky.fare.caexport.util.StringUtil;

public class AgentConvertor implements IConvert<GroupEntry, XAgent> {

	@Override
	public List<XAgent> convert(List<GroupEntry> list) {
		List<XAgent> xagents = null;
		if(list!=null && list.size()>0){
			xagents = new ArrayList<XAgent>();
			for (GroupEntry gentry : list) {
				xagents.add( convert(gentry) );
			}
		}
		return xagents;
	}

	@Override
	public XAgent convert(GroupEntry gentry) {
		XAgent xagent = null;
		if(gentry!=null){
			xagent = new XAgent();
			//�������Ҳ���Ϊnull-1
			xagent.setAgencyidpcc( gentry.getAgencyIdPcc() );
			//�����ҿ�Ϊnull-3
			//AGENCY_ID_IATA��ֵ����Ϊ�ַ���null������xsd�޷�ƥ�䣬
			xagent.setAgencyidiata( gentry.getAgencyIdIata() );
			xagent.setDisname( gentry.getDisName() );
			xagent.setSyscode( gentry.getSysCode() );
		}
		return xagent;
	}

}
