package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.common.refund.Refund;
import com.travelsky.fare.caexport.db.model.common.refund.RefundEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefund;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefundEntry;
import com.travelsky.fare.caexport.util.StringUtil;

public class RefundConvertor implements IConvert<Refund,XRefund> {
	
	private IConvert<RefundEntry, XRefundEntry> entconvertor = new RefundEntryConvertor();

	@Override
	public List<XRefund> convert(List<Refund> list) {
		List<XRefund> xfunds = null;
		if(list!=null && list.size()>0){
			xfunds = new ArrayList<XRefund>();
			for (Refund refund : list) {
				xfunds.add( convert(refund) );
			}
		}
		return xfunds;
	}

	@Override
	public XRefund convert(Refund refund) {
		XRefund xfund = null;
		if(refund!=null){
			xfund = new XRefund();
			//�����ֶ�
			xfund.setLocationCode( StringUtil.isNullOrEmpty(refund.getLocationCode())?"":refund.getLocationCode() );
			xfund.setRefundid( StringUtil.isNullOrEmpty( refund.getRefundRuleId() )?"" : refund.getRefundRuleId() );
			xfund.setRefundType( refund.getRefundType()!=null?refund.getRefundType():0 );
			xfund.setVoluntaryTxt( StringUtil.isNullOrEmpty(refund.getVoluntaryTxt())?"" : refund.getVoluntaryTxt() );
			
			xfund.setInVoluntaryTxt( refund.getInvoluntaryTxt() );
			xfund.setYqtaxallowed( refund.getRefundYqtaxAllowed() );
			xfund.setRefundEntries( entconvertor.convert( refund.getEntries() ) );
		}
		return xfund;
	}

}
