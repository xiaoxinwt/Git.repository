package com.travelsky.fare.caexport.dexp.vo.Adapter;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import com.travelsky.fare.caexport.util.StringUtil;

public class StringToTrimAdapter extends XmlAdapter<String,String> {

	@Override
	public String marshal(String str) throws Exception {
		return StringUtil.isNullOrEmpty(str)?null:str.trim();
	}

	@Override
	public String unmarshal(String str) throws Exception {
		return str;
	}


}
