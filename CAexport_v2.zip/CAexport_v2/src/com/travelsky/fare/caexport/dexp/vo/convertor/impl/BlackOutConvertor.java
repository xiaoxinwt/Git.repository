package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.BlackoutPeriod;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XBlackoutOut;

public class BlackOutConvertor implements IConvert<BlackoutPeriod, XBlackoutOut> {

	@Override
	public List<XBlackoutOut> convert(List<BlackoutPeriod> list) {
		
		List<XBlackoutOut> xbouts = null;
		if(list!=null && list.size()>0){
			xbouts = new ArrayList<XBlackoutOut>();
			for (BlackoutPeriod bout : list) {
				xbouts.add( convert(bout) );
			}
		}
		return xbouts;
	}

	@Override
	public XBlackoutOut convert(BlackoutPeriod bout) {
		XBlackoutOut xbout = null;
		if(bout!=null){
			xbout = new XBlackoutOut();
			xbout.setBlackoutfromdateout( bout.getBlackoutFromDate() );
			xbout.setBlackouttodateout( bout.getBlackoutToDate() );
		}
		return xbout;
	}

}
