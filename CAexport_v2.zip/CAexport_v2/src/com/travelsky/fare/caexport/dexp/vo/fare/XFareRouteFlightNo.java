package com.travelsky.fare.caexport.dexp.vo.fare;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "flightentryno",
    "carriercode",
    "apfromno",
    "aptono",
    "exfromno",
    "extono",
    "bookingclass",
    "bookingclass2",
    "farebasiscode",
    "farebasiscode2"
})
@XmlRootElement(name = "FARE_ROUTE_FLIGHT_NO")
public class XFareRouteFlightNo {
    @XmlElement(name = "FLIGHT_ENTRY_NO", required = true)
    protected Integer flightentryno;
    @XmlElement(name = "CARRIER_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String carriercode;
    @XmlElement(name = "AP_FROM_NO", required = true, nillable = true)
    protected Integer apfromno;
    @XmlElement(name = "AP_TO_NO", required = true, nillable = true)
    protected Integer aptono;
    @XmlElement(name = "EX_FROM_NO", required = true, nillable = true)
    protected Integer exfromno;
    @XmlElement(name = "EX_TO_NO", required = true, nillable = true)
    protected Integer extono;
    @XmlElement(name = "BOOKING_CLASS", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String bookingclass;
    @XmlElement(name = "BOOKING_CLASS2", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String bookingclass2;
    @XmlElement(name = "FARE_BASIS_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String farebasiscode;
    @XmlElement(name = "FARE_BASIS_CODE2", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String farebasiscode2;
	
    public Integer getFlightentryno() {
		return flightentryno;
	}
	public void setFlightentryno(Integer flightentryno) {
		this.flightentryno = flightentryno;
	}
	public String getCarriercode() {
		return carriercode;
	}
	public void setCarriercode(String carriercode) {
		this.carriercode = carriercode;
	}
	public Integer getApfromno() {
		return apfromno;
	}
	public void setApfromno(Integer apfromno) {
		this.apfromno = apfromno;
	}
	public Integer getAptono() {
		return aptono;
	}
	public void setAptono(Integer aptono) {
		this.aptono = aptono;
	}
	public Integer getExfromno() {
		return exfromno;
	}
	public void setExfromno(Integer exfromno) {
		this.exfromno = exfromno;
	}
	public Integer getExtono() {
		return extono;
	}
	public void setExtono(Integer extono) {
		this.extono = extono;
	}
	public String getBookingclass() {
		return bookingclass;
	}
	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}
	public String getBookingclass2() {
		return bookingclass2;
	}
	public void setBookingclass2(String bookingclass2) {
		this.bookingclass2 = bookingclass2;
	}
	public String getFarebasiscode() {
		return farebasiscode;
	}
	public void setFarebasiscode(String farebasiscode) {
		this.farebasiscode = farebasiscode;
	}
	public String getFarebasiscode2() {
		return farebasiscode2;
	}
	public void setFarebasiscode2(String farebasiscode2) {
		this.farebasiscode2 = farebasiscode2;
	}
}
