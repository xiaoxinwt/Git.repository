package com.travelsky.fare.caexport.dexp.vo.reissue;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "passengertype",
    "journeytype",
    "bookingclass",
    "farebasis",
    "ticketusedtag",
    "lowervalue",
    "lowerrelate",
    "uppervalue",
    "upperrelate",
    "otherticketcarrierlist",
    "firstticketedtime",
    "lastticketedtime",
    "ticketedtimeunit",
    "departruetimetype",
    "firstdepartruetime",
    "lastdepartruetime",
    "departruetimeunit",
    "reissueallowedtag",
    "freechangetimes",
    "chargetype",
    "chargeunit",
    "discountcalculatetype",
    "discountpercent",
    "discountbookingclass",
    "carryunit",
    "roundtype",
    "chargeamount",
    "chargeminamount",
    "reissuechargetag",
    "firstflighttag",
    "sameflighttag",
    "flightdatetag",
    "flightdatenum",
    "flightdateunit",
    "otherflightcarrierlist",
    "processtag",
    "datechangedtag",
    "upgradetag",
    "notpermitcabinlist",
    "modclassnewfareallowlowtag",
    "upgradefeetag",
    "faredisplaytag",
    "endorsmenttag",
    "endorsmentprefix",
    "endorsmentsuffix",
    "newendorsment"
})
@XmlRootElement(name = "RULE_REISSUE_ENTRY")
public class XReissueEntry {
    @XmlElement(name = "PASSENGER_TYPE")
    protected String passengertype;
    @XmlElement(name = "JOURNEY_TYPE")
    protected String journeytype;
    @XmlElement(name = "BOOKING_CLASS")
    protected String bookingclass;
    @XmlElement(name = "FARE_BASIS")
    protected String farebasis;
    @XmlElement(name = "TICKET_USED_TAG")
    protected Integer ticketusedtag;
    @XmlElement(name = "LOWER_VALUE")
    protected Integer lowervalue;
    @XmlElement(name = "LOWER_RELATE", required = true)
    protected Integer lowerrelate;
    @XmlElement(name = "UPPER_VALUE")
    protected Integer uppervalue;
    @XmlElement(name = "UPPER_RELATE", required = true)
    protected Integer upperrelate;
    @XmlElement(name = "OTHER_TICKET_CARRIER_LIST")
    protected String otherticketcarrierlist;
    @XmlElement(name = "FIRST_TICKETED_TIME")
    protected Integer firstticketedtime;
    @XmlElement(name = "LAST_TICKETED_TIME")
    protected Integer lastticketedtime;
    @XmlElement(name = "TICKETED_TIME_UNIT", required = true)
    protected String ticketedtimeunit;
    @XmlElement(name = "DEPARTRUE_TIME_TYPE", required = true)
    protected Integer departruetimetype;
    @XmlElement(name = "FIRST_DEPARTRUE_TIME")
    protected Integer firstdepartruetime;
    @XmlElement(name = "LAST_DEPARTRUE_TIME")
    protected Integer lastdepartruetime;
    @XmlElement(name = "DEPARTRUE_TIME_UNIT", required = true)
    protected String departruetimeunit;
    @XmlElement(name = "REISSUE_ALLOWED_TAG")
    protected Integer reissueallowedtag;
    @XmlElement(name = "FREE_CHANGE_TIMES", required = true)
    protected String freechangetimes;
    @XmlElement(name = "CHARGE_TYPE")
    protected Integer chargetype;
    @XmlElement(name = "CHARGE_UNIT")
    protected Integer chargeunit;
    @XmlElement(name = "DISCOUNT_CALCULATE_TYPE")
    protected Integer discountcalculatetype;
    @XmlElement(name = "DISCOUNT_PERCENT")
    protected Integer discountpercent;
    @XmlElement(name = "DISCOUNT_BOOKING_CLASS")
    protected String discountbookingclass;
    @XmlElement(name = "CARRY_UNIT")
    protected Integer carryunit;
    @XmlElement(name = "ROUND_TYPE")
    protected Integer roundtype;
    @XmlElement(name = "CHARGE_AMOUNT")
    protected Integer chargeamount;
    @XmlElement(name = "CHARGE_MIN_AMOUNT")
    protected Integer chargeminamount;
    @XmlElement(name = "REISSUE_CHARGE_TAG", required = true)
    protected Integer reissuechargetag;
    @XmlElement(name = "FIRST_FLIGHT_TAG", required = true)
    protected Integer firstflighttag;
    @XmlElement(name = "SAME_FLIGHT_TAG", required = true)
    protected Integer sameflighttag;
    @XmlElement(name = "FLIGHT_DATE_TAG")
    protected String flightdatetag;
    @XmlElement(name = "FLIGHT_DATE_NUM")
    protected Integer flightdatenum;
    @XmlElement(name = "FLIGHT_DATE_UNIT")
    protected String flightdateunit;
    @XmlElement(name = "OTHER_FLIGHT_CARRIER_LIST")
    protected String otherflightcarrierlist;
    @XmlElement(name = "PROCESS_TAG", required = true)
    protected Integer processtag;
    @XmlElement(name = "DATE_CHANGED_TAG", required = true)
    protected Integer datechangedtag;
    @XmlElement(name = "UPGRADE_TAG", required = true)
    protected Integer upgradetag;
    @XmlElement(name = "NOT_PERMIT_CABIN_LIST")
    protected String notpermitcabinlist;
    @XmlElement(name = "MODCLASS_NEWFARE_ALLOWLOW_TAG")
    protected Integer modclassnewfareallowlowtag;
    @XmlElement(name = "UPGRADE_FEE_TAG")
    protected Integer upgradefeetag;
    @XmlElement(name = "FARE_DISPLAY_TAG", required = true)
    protected Integer faredisplaytag;
    @XmlElement(name = "ENDORSMENT_TAG", required = true)
    protected Integer endorsmenttag;
    @XmlElement(name = "ENDORSMENT_PREFIX")
    protected String endorsmentprefix;
    @XmlElement(name = "ENDORSMENT_SUFFIX")
    protected String endorsmentsuffix;
    @XmlElement(name = "NEW_ENDORSMENT")
    protected String newendorsment;
	
    public String getPassengertype() {
		return passengertype;
	}
	public String getJourneytype() {
		return journeytype;
	}
	public String getBookingclass() {
		return bookingclass;
	}
	public String getFarebasis() {
		return farebasis;
	}
	public Integer getTicketusedtag() {
		return ticketusedtag;
	}
	public Integer getLowervalue() {
		return lowervalue;
	}
	public Integer getLowerrelate() {
		return lowerrelate;
	}
	public Integer getUppervalue() {
		return uppervalue;
	}
	public Integer getUpperrelate() {
		return upperrelate;
	}
	public String getOtherticketcarrierlist() {
		return otherticketcarrierlist;
	}
	public Integer getFirstticketedtime() {
		return firstticketedtime;
	}
	public Integer getLastticketedtime() {
		return lastticketedtime;
	}
	public String getTicketedtimeunit() {
		return ticketedtimeunit;
	}
	public Integer getDepartruetimetype() {
		return departruetimetype;
	}
	public Integer getFirstdepartruetime() {
		return firstdepartruetime;
	}
	public Integer getLastdepartruetime() {
		return lastdepartruetime;
	}
	public String getDepartruetimeunit() {
		return departruetimeunit;
	}
	public Integer getReissueallowedtag() {
		return reissueallowedtag;
	}
	public String getFreechangetimes() {
		return freechangetimes;
	}
	public Integer getChargetype() {
		return chargetype;
	}
	public Integer getChargeunit() {
		return chargeunit;
	}
	public Integer getDiscountcalculatetype() {
		return discountcalculatetype;
	}
	public Integer getDiscountpercent() {
		return discountpercent;
	}
	public String getDiscountbookingclass() {
		return discountbookingclass;
	}
	public Integer getCarryunit() {
		return carryunit;
	}
	public Integer getRoundtype() {
		return roundtype;
	}
	public Integer getChargeamount() {
		return chargeamount;
	}
	public Integer getChargeminamount() {
		return chargeminamount;
	}
	public Integer getReissuechargetag() {
		return reissuechargetag;
	}
	public Integer getFirstflighttag() {
		return firstflighttag;
	}
	public Integer getSameflighttag() {
		return sameflighttag;
	}
	public String getFlightdatetag() {
		return flightdatetag;
	}
	public Integer getFlightdatenum() {
		return flightdatenum;
	}
	public String getFlightdateunit() {
		return flightdateunit;
	}
	public String getOtherflightcarrierlist() {
		return otherflightcarrierlist;
	}
	public Integer getProcesstag() {
		return processtag;
	}
	public Integer getDatechangedtag() {
		return datechangedtag;
	}
	public Integer getUpgradetag() {
		return upgradetag;
	}
	public String getNotpermitcabinlist() {
		return notpermitcabinlist;
	}
	public Integer getModclassnewfareallowlowtag() {
		return modclassnewfareallowlowtag;
	}
	public Integer getUpgradefeetag() {
		return upgradefeetag;
	}
	public Integer getFaredisplaytag() {
		return faredisplaytag;
	}
	public Integer getEndorsmenttag() {
		return endorsmenttag;
	}
	public String getEndorsmentprefix() {
		return endorsmentprefix;
	}
	public String getEndorsmentsuffix() {
		return endorsmentsuffix;
	}
	public String getNewendorsment() {
		return newendorsment;
	}
	public void setPassengertype(String passengertype) {
		this.passengertype = passengertype;
	}
	public void setJourneytype(String journeytype) {
		this.journeytype = journeytype;
	}
	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}
	public void setFarebasis(String farebasis) {
		this.farebasis = farebasis;
	}
	public void setTicketusedtag(Integer ticketusedtag) {
		this.ticketusedtag = ticketusedtag;
	}
	public void setLowervalue(Integer lowervalue) {
		this.lowervalue = lowervalue;
	}
	public void setLowerrelate(Integer lowerrelate) {
		this.lowerrelate = lowerrelate;
	}
	public void setUppervalue(Integer uppervalue) {
		this.uppervalue = uppervalue;
	}
	public void setUpperrelate(Integer upperrelate) {
		this.upperrelate = upperrelate;
	}
	public void setOtherticketcarrierlist(String otherticketcarrierlist) {
		this.otherticketcarrierlist = otherticketcarrierlist;
	}
	public void setFirstticketedtime(Integer firstticketedtime) {
		this.firstticketedtime = firstticketedtime;
	}
	public void setLastticketedtime(Integer lastticketedtime) {
		this.lastticketedtime = lastticketedtime;
	}
	public void setTicketedtimeunit(String ticketedtimeunit) {
		this.ticketedtimeunit = ticketedtimeunit;
	}
	public void setDepartruetimetype(Integer departruetimetype) {
		this.departruetimetype = departruetimetype;
	}
	public void setFirstdepartruetime(Integer firstdepartruetime) {
		this.firstdepartruetime = firstdepartruetime;
	}
	public void setLastdepartruetime(Integer lastdepartruetime) {
		this.lastdepartruetime = lastdepartruetime;
	}
	public void setDepartruetimeunit(String departruetimeunit) {
		this.departruetimeunit = departruetimeunit;
	}
	public void setReissueallowedtag(Integer reissueallowedtag) {
		this.reissueallowedtag = reissueallowedtag;
	}
	public void setFreechangetimes(String freechangetimes) {
		this.freechangetimes = freechangetimes;
	}
	public void setChargetype(Integer chargetype) {
		this.chargetype = chargetype;
	}
	public void setChargeunit(Integer chargeunit) {
		this.chargeunit = chargeunit;
	}
	public void setDiscountcalculatetype(Integer discountcalculatetype) {
		this.discountcalculatetype = discountcalculatetype;
	}
	public void setDiscountpercent(Integer discountpercent) {
		this.discountpercent = discountpercent;
	}
	public void setDiscountbookingclass(String discountbookingclass) {
		this.discountbookingclass = discountbookingclass;
	}
	public void setCarryunit(Integer carryunit) {
		this.carryunit = carryunit;
	}
	public void setRoundtype(Integer roundtype) {
		this.roundtype = roundtype;
	}
	public void setChargeamount(Integer chargeamount) {
		this.chargeamount = chargeamount;
	}
	public void setChargeminamount(Integer chargeminamount) {
		this.chargeminamount = chargeminamount;
	}
	public void setReissuechargetag(Integer reissuechargetag) {
		this.reissuechargetag = reissuechargetag;
	}
	public void setFirstflighttag(Integer firstflighttag) {
		this.firstflighttag = firstflighttag;
	}
	public void setSameflighttag(Integer sameflighttag) {
		this.sameflighttag = sameflighttag;
	}
	public void setFlightdatetag(String flightdatetag) {
		this.flightdatetag = flightdatetag;
	}
	public void setFlightdatenum(Integer flightdatenum) {
		this.flightdatenum = flightdatenum;
	}
	public void setFlightdateunit(String flightdateunit) {
		this.flightdateunit = flightdateunit;
	}
	public void setOtherflightcarrierlist(String otherflightcarrierlist) {
		this.otherflightcarrierlist = otherflightcarrierlist;
	}
	public void setProcesstag(Integer processtag) {
		this.processtag = processtag;
	}
	public void setDatechangedtag(Integer datechangedtag) {
		this.datechangedtag = datechangedtag;
	}
	public void setUpgradetag(Integer upgradetag) {
		this.upgradetag = upgradetag;
	}
	public void setNotpermitcabinlist(String notpermitcabinlist) {
		this.notpermitcabinlist = notpermitcabinlist;
	}
	public void setModclassnewfareallowlowtag(Integer modclassnewfareallowlowtag) {
		this.modclassnewfareallowlowtag = modclassnewfareallowlowtag;
	}
	public void setUpgradefeetag(Integer upgradefeetag) {
		this.upgradefeetag = upgradefeetag;
	}
	public void setFaredisplaytag(Integer faredisplaytag) {
		this.faredisplaytag = faredisplaytag;
	}
	public void setEndorsmenttag(Integer endorsmenttag) {
		this.endorsmenttag = endorsmenttag;
	}
	public void setEndorsmentprefix(String endorsmentprefix) {
		this.endorsmentprefix = endorsmentprefix;
	}
	public void setEndorsmentsuffix(String endorsmentsuffix) {
		this.endorsmentsuffix = endorsmentsuffix;
	}
	public void setNewendorsment(String newendorsment) {
		this.newendorsment = newendorsment;
	}
}
