package com.travelsky.fare.caexport.dexp.vo.rule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;
import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleBlackoutPeriod;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleCombination;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleFlightNoRestriction;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleHourRestriction;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleSeasonality;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleTextual;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "carrCode","locationCode",
    "ruleid",
    "ruleSeqId","effectiveDate","discontinueDate",
    "ruledesc",
    "advancepurchase",
    "dayofweekrestriction",
    "dayofweekrestrictionin",
    "faresgroupsflag",
    "minimumgroup",
    "maximumgroup",
    "farescombinationflag",
    "separatesaletype",
    "rulerefund",
    "rulereissue",
//    "combineversion",
    "combineopenjawflag",
    "combineroundtripflag",
    "maxadvancedpurchars",
    "maxadvancedpurcharsunit",
    "minadvancedpurcharsunit",
    "openjawflag",
    "candidateflag",
    "ruleendorsementrestriction",
    "codeshare",
    "appcxrcodeshare",
    "sectorrangelower",
    "sectorrangeupper",
    "forbiddenjourneyflag",
    "positionlimittype",
    "positionlimitspec",
    "charterflightflag",
    "tickettimelimitvalue",
    "tickettimelimitunit",
    "ticketcarrlimit",
    "flightnotype",
    "flightnotypein",
    "ruleseasonality",
    "ruleblackoutperiod",
    "rulehourrestriction",
    "ruleflightnorestriction",
    "ruletextual",
    "rulecombination"
})
@XmlRootElement(name = "RULE")
public class XRule {
    @XmlElement(name = "Action_Code", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String actionCode;		//[insert|update]
    @XmlElement(name = "CARR_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    private String carrCode;			//[^a-z]{1,2}
    @XmlElement(name = "LOCATION_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    private String locationCode;		//[^a-z]{1,3}
    @XmlElement(name = "RULE_ID", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String ruleid;			//[^a-z]{1,13}
    @XmlElement(name = "RULE_SEQ_ID", required = true)
    protected BigDecimal ruleSeqId;
    @XmlElement(name = "EFFECTIVE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date effectiveDate;		//\p{Nd}{4}-\p{Nd}{2}-\p{Nd}{2}T\p{Nd}{2}:\p{Nd}{2}:\p{Nd}{2} yyyy-MM-ddTHH:mm:ss
    @XmlElement(name = "DISCONTINUE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date discontinueDate;		//\p{Nd}{4}-\p{Nd}{2}-\p{Nd}{2}T\p{Nd}{2}:\p{Nd}{2}:\p{Nd}{2} yyyy-MM-ddTHH:mm:ss
    @XmlElement(name = "RULE_DESC")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String ruledesc;
    @XmlElement(name = "ADVANCE_PURCHASE")
    protected Integer advancepurchase;
    @XmlElement(name = "DAY_OF_WEEK_RESTRICTION", required = true, nillable = true)
    protected Integer dayofweekrestriction;
    @XmlElement(name = "DAY_OF_WEEK_RESTRICTION_IN", required = true, nillable = true)
    protected Integer dayofweekrestrictionin;
    @XmlElement(name = "FARES_GROUPS_FLAG", required = true, nillable = true)
    protected Integer faresgroupsflag;
    @XmlElement(name = "MINIMUM_GROUP", required = true, nillable = true)
    protected Integer minimumgroup;
    @XmlElement(name = "MAXIMUM_GROUP", required = true, nillable = true)
    protected Integer maximumgroup;
    @XmlElement(name = "FARES_COMBINATION_FLAG", required = true, nillable = true)
    protected Integer farescombinationflag;
    @XmlElement(name = "SEPARATE_SALE_TYPE", required = true, nillable = true)
    protected Integer separatesaletype;
    @XmlElement(name = "RULE_REFUND")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String rulerefund;
    @XmlElement(name = "RULE_REISSUE")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String rulereissue;
//    @XmlElement(name = "COMBINE_VERSION", defaultValue = "0")
    @XmlTransient
    protected Integer combineversion;
    @XmlElement(name = "COMBINE_OPEN_JAW_FLAG")
    protected Integer combineopenjawflag;
    @XmlElement(name = "COMBINE_ROUND_TRIP_FLAG")
    protected Integer combineroundtripflag;
    @XmlElement(name = "MAX_ADVANCED_PURCHARS")
    protected Integer maxadvancedpurchars;
    @XmlElement(name = "MAX_ADVANCED_PURCHARS_UNIT")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String maxadvancedpurcharsunit;
    @XmlElement(name = "MIN_ADVANCED_PURCHARS_UNIT")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String minadvancedpurcharsunit;
    @XmlElement(name = "OPEN_JAW_FLAG")
    protected Integer openjawflag;
    @XmlElement(name = "CANDIDATE_FLAG")
    protected Integer candidateflag;
    @XmlElement(name = "RULE_ENDORSEMENT_RESTRICTION")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String ruleendorsementrestriction;
    @XmlElement(name = "CODE_SHARE")
    protected Integer codeshare;
//    @XmlElementRef(name = "APPCXR_CODE_SHARE", type = RuleJAXBElement.class )
    @XmlElement(name = "APPCXR_CODE_SHARE")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String appcxrcodeshare;
    @XmlElement(name = "SECTOR_RANGE_LOWER")
    protected Integer sectorrangelower;
    @XmlElement(name = "SECTOR_RANGE_UPPER")
    protected Integer sectorrangeupper;
    @XmlElement(name = "FORBIDDEN_JOURNEY_FLAG", defaultValue = "0")
    protected Integer forbiddenjourneyflag;
    @XmlElement(name = "POSITION_LIMIT_TYPE", defaultValue = "0")
    protected Integer positionlimittype;
    @XmlElement(name = "POSITION_LIMIT_SPEC")
    protected Integer positionlimitspec;
    @XmlElement(name = "CHARTER_FLIGHT_FLAG")
    protected Integer charterflightflag;
    @XmlElement(name = "TICKET_TIME_LIMIT_VALUE")
    protected BigDecimal tickettimelimitvalue;
    @XmlElement(name = "TICKET_TIME_LIMIT_UNIT", defaultValue = "0")
    protected Integer tickettimelimitunit;
    @XmlElement(name = "TICKET_CARR_LIMIT", defaultValue = "0")
    protected Integer ticketcarrlimit;
    @XmlElement(name = "FLIGHTNO_TYPE", defaultValue = "0")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String flightnotype;
    @XmlElement(name = "FLIGHTNO_TYPE_IN", defaultValue = "0")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String flightnotypein;
    
    @XmlElement(name = "RULE_SEASONALITY")
    protected XRuleSeasonality ruleseasonality;
    @XmlElement(name = "RULE_BLACKOUT_PERIOD")
    protected XRuleBlackoutPeriod ruleblackoutperiod;
    @XmlElement(name = "RULE_HOUR_RESTRICTION", required = true)
    protected XRuleHourRestriction rulehourrestriction;
    @XmlElement(name = "RULE_FLIGHT_NO_RESTRICTION", required = true)
    protected XRuleFlightNoRestriction ruleflightnorestriction;
    @XmlElement(name = "RULE_TEXTUAL", required = true)
    protected List<XRuleTextual> ruletextual;
    @XmlElement(name = "RULE_COMBINATION")
    protected List<XRuleCombination> rulecombination;
    
    @XmlTransient
//    private 
   
    public List<XRuleCombination> getRulecombination() {
        if (rulecombination == null) {
            rulecombination = new ArrayList<XRuleCombination>();
        }
        return this.rulecombination;
    }
    
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getRuleid() {
		return ruleid;
	}
	public void setRuleid(String ruleid) {
		this.ruleid = ruleid;
	}
	public String getRuledesc() {
		return ruledesc;
	}
	public void setRuledesc(String ruledesc) {
		this.ruledesc = ruledesc;
	}
	public Integer getAdvancepurchase() {
		return advancepurchase;
	}
	public void setAdvancepurchase(Integer advancepurchase) {
		this.advancepurchase = advancepurchase;
	}
	public Integer getDayofweekrestriction() {
		return dayofweekrestriction;
	}
	public void setDayofweekrestriction(Integer dayofweekrestriction) {
		this.dayofweekrestriction = dayofweekrestriction;
	}
	public Integer getDayofweekrestrictionin() {
		return dayofweekrestrictionin;
	}
	public void setDayofweekrestrictionin(Integer dayofweekrestrictionin) {
		this.dayofweekrestrictionin = dayofweekrestrictionin;
	}
	public Integer getFaresgroupsflag() {
		return faresgroupsflag;
	}
	public void setFaresgroupsflag(Integer faresgroupsflag) {
		this.faresgroupsflag = faresgroupsflag;
	}
	public Integer getMinimumgroup() {
		return minimumgroup;
	}
	public void setMinimumgroup(Integer minimumgroup) {
		this.minimumgroup = minimumgroup;
	}
	public Integer getMaximumgroup() {
		return maximumgroup;
	}
	public void setMaximumgroup(Integer maximumgroup) {
		this.maximumgroup = maximumgroup;
	}
	public Integer getFarescombinationflag() {
		return farescombinationflag;
	}
	public void setFarescombinationflag(Integer farescombinationflag) {
		this.farescombinationflag = farescombinationflag;
	}
	public Integer getSeparatesaletype() {
		return separatesaletype;
	}
	public void setSeparatesaletype(Integer separatesaletype) {
		this.separatesaletype = separatesaletype;
	}
	public String getRulerefund() {
		return rulerefund;
	}
	public void setRulerefund(String rulerefund) {
		this.rulerefund = rulerefund;
	}
	public String getRulereissue() {
		return rulereissue;
	}
	public void setRulereissue(String rulereissue) {
		this.rulereissue = rulereissue;
	}
	public Integer getCombineversion() {
		return combineversion;
	}
	public void setCombineversion(Integer combineversion) {
		this.combineversion = combineversion;
	}
	public Integer getCombineopenjawflag() {
		return combineopenjawflag;
	}
	public void setCombineopenjawflag(Integer combineopenjawflag) {
		this.combineopenjawflag = combineopenjawflag;
	}
	public Integer getCombineroundtripflag() {
		return combineroundtripflag;
	}
	public void setCombineroundtripflag(Integer combineroundtripflag) {
		this.combineroundtripflag = combineroundtripflag;
	}
	public Integer getMaxadvancedpurchars() {
		return maxadvancedpurchars;
	}
	public void setMaxadvancedpurchars(Integer maxadvancedpurchars) {
		this.maxadvancedpurchars = maxadvancedpurchars;
	}
	public String getMaxadvancedpurcharsunit() {
		return maxadvancedpurcharsunit;
	}
	public void setMaxadvancedpurcharsunit(String maxadvancedpurcharsunit) {
		this.maxadvancedpurcharsunit = maxadvancedpurcharsunit;
	}
	public String getMinadvancedpurcharsunit() {
		return minadvancedpurcharsunit;
	}
	public void setMinadvancedpurcharsunit(String minadvancedpurcharsunit) {
		this.minadvancedpurcharsunit = minadvancedpurcharsunit;
	}
	public Integer getOpenjawflag() {
		return openjawflag;
	}
	public void setOpenjawflag(Integer openjawflag) {
		this.openjawflag = openjawflag;
	}
	public Integer getCandidateflag() {
		return candidateflag;
	}
	public void setCandidateflag(Integer candidateflag) {
		this.candidateflag = candidateflag;
	}
	public String getRuleendorsementrestriction() {
		return ruleendorsementrestriction;
	}
	public void setRuleendorsementrestriction(String ruleendorsementrestriction) {
		this.ruleendorsementrestriction = ruleendorsementrestriction;
	}
	public Integer getCodeshare() {
		return codeshare;
	}
	public void setCodeshare(Integer codeshare) {
		this.codeshare = codeshare;
	}
	public String getAppcxrcodeshare() {
		return appcxrcodeshare;
	}
	public void setAppcxrcodeshare(String appcxrcodeshare) {
		this.appcxrcodeshare = appcxrcodeshare;
	}
	public Integer getSectorrangelower() {
		return sectorrangelower;
	}
	public void setSectorrangelower(Integer sectorrangelower) {
		this.sectorrangelower = sectorrangelower;
	}
	public Integer getSectorrangeupper() {
		return sectorrangeupper;
	}
	public void setSectorrangeupper(Integer sectorrangeupper) {
		this.sectorrangeupper = sectorrangeupper;
	}
	public Integer getForbiddenjourneyflag() {
		return forbiddenjourneyflag;
	}
	public void setForbiddenjourneyflag(Integer forbiddenjourneyflag) {
		this.forbiddenjourneyflag = forbiddenjourneyflag;
	}
	public Integer getPositionlimittype() {
		return positionlimittype;
	}
	public void setPositionlimittype(Integer positionlimittype) {
		this.positionlimittype = positionlimittype;
	}
	public Integer getPositionlimitspec() {
		return positionlimitspec;
	}
	public void setPositionlimitspec(Integer positionlimitspec) {
		this.positionlimitspec = positionlimitspec;
	}
	public Integer getCharterflightflag() {
		return charterflightflag;
	}
	public void setCharterflightflag(Integer charterflightflag) {
		this.charterflightflag = charterflightflag;
	}
	public BigDecimal getTickettimelimitvalue() {
		return tickettimelimitvalue;
	}
	public void setTickettimelimitvalue(BigDecimal tickettimelimitvalue) {
		this.tickettimelimitvalue = tickettimelimitvalue;
	}
	public Integer getTickettimelimitunit() {
		return tickettimelimitunit;
	}
	public void setTickettimelimitunit(Integer tickettimelimitunit) {
		this.tickettimelimitunit = tickettimelimitunit;
	}
	public Integer getTicketcarrlimit() {
		return ticketcarrlimit;
	}
	public void setTicketcarrlimit(Integer ticketcarrlimit) {
		this.ticketcarrlimit = ticketcarrlimit;
	}
	public String getFlightnotype() {
		return flightnotype;
	}
	public void setFlightnotype(String flightnotype) {
		this.flightnotype = flightnotype;
	}
	public String getFlightnotypein() {
		return flightnotypein;
	}
	public void setFlightnotypein(String flightnotypein) {
		this.flightnotypein = flightnotypein;
	}
	public XRuleSeasonality getRuleseasonality() {
		return ruleseasonality;
	}
	public void setRuleseasonality(XRuleSeasonality ruleseasonality) {
		this.ruleseasonality = ruleseasonality;
	}
	public XRuleBlackoutPeriod getRuleblackoutperiod() {
		return ruleblackoutperiod;
	}
	public void setRuleblackoutperiod(XRuleBlackoutPeriod ruleblackoutperiod) {
		this.ruleblackoutperiod = ruleblackoutperiod;
	}
	public XRuleHourRestriction getRulehourrestriction() {
		return rulehourrestriction;
	}
	public void setRulehourrestriction(XRuleHourRestriction rulehourrestriction) {
		this.rulehourrestriction = rulehourrestriction;
	}
	public XRuleFlightNoRestriction getRuleflightnorestriction() {
		return ruleflightnorestriction;
	}
	public void setRuleflightnorestriction(
			XRuleFlightNoRestriction ruleflightnorestriction) {
		this.ruleflightnorestriction = ruleflightnorestriction;
	}
	public List<XRuleTextual> getRuletextual() {
		return ruletextual;
	}
	public void setRuletextual(List<XRuleTextual> ruletextual) {
		this.ruletextual = ruletextual;
	}
	public void setRulecombination(List<XRuleCombination> rulecombination) {
		this.rulecombination = rulecombination;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public BigDecimal getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(BigDecimal ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getDiscontinueDate() {
		return discontinueDate;
	}
	public void setDiscontinueDate(Date discontinueDate) {
		this.discontinueDate = discontinueDate;
	}
	
	
	public static void main(String[] args) {
		
	}
	
}
