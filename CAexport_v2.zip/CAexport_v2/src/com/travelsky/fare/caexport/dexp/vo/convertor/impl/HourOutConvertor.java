package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.HourRestriction;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XHourRestrictionOut;

public class HourOutConvertor implements IConvert<HourRestriction, XHourRestrictionOut> {

	@Override
	public List<XHourRestrictionOut> convert(List<HourRestriction> list) {
		List<XHourRestrictionOut> xhouts = null;
		if(list!=null && list.size()>0){
			xhouts = new ArrayList<XHourRestrictionOut>();
			for (HourRestriction hout : list) {
				xhouts.add( convert(hout) );
			}
		}
		return xhouts;
	}

	@Override
	public XHourRestrictionOut convert(HourRestriction hout) {
		XHourRestrictionOut xhout = null;
		if(hout!=null){
			xhout = new XHourRestrictionOut();
			//�������ҿ�Ϊnull
			xhout.setFromnoout( hout.getFromNo() );
			xhout.setTonoout( hout.getToNo() );
		}
		return xhout;
	}

}
