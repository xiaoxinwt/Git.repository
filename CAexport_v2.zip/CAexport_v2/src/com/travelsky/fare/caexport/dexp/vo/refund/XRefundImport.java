package com.travelsky.fare.caexport.dexp.vo.refund;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "refund"
})
@XmlRootElement(name = "RULE_REFUND_IMPORT")
public class XRefundImport{

    @XmlElement(name = "RULE_REFUND")
    protected List<XRefund> refund;

    public List<XRefund> getRefund() {
        if (refund == null) {
            refund = new ArrayList<XRefund>();
        }
        return this.refund;
    }
    public void setRefund(List<XRefund> refundlist){
    	this.refund = refundlist;
    }

}
