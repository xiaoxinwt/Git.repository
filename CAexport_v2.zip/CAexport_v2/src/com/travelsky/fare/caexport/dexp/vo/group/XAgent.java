package com.travelsky.fare.caexport.dexp.vo.group;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agencyidpcc",
    "agencyidiata",
    "disname",
    "syscode"
})
@XmlRootElement(name = "AGENT")
public class XAgent {
    @XmlElement(name = "AGENCY_ID_PCC", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String agencyidpcc;	//[^a-z]{2,9}
    @XmlElement(name = "AGENCY_ID_IATA", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String agencyidiata;	//[^a-z]{0,7}
    @XmlElement(name = "DIS_NAME", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String disname;		//[^a-z]{0,10}
    @XmlElement(name = "SYS_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String syscode;		//[ICS|CRS]
	
    public String getAgencyidpcc() {
		return agencyidpcc;
	}
	public void setAgencyidpcc(String agencyidpcc) {
		this.agencyidpcc = agencyidpcc;
	}
	public String getDisname() {
		return disname;
	}
	public void setDisname(String disname) {
		this.disname = disname;
	}
	public String getAgencyidiata() {
		return agencyidiata;
	}
	public void setAgencyidiata(String agencyidiata) {
		this.agencyidiata = agencyidiata;
	}
	public String getSyscode() {
		return syscode;
	}
	public void setSyscode(String syscode) {
		this.syscode = syscode;
	}
}
