package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

public class FundHandler {

	public static int getLowerUpperRelate(String relate) {
//		System.out.println( relate );
		if( "<".equals(relate) ){
			return 0;
		}else if( "<=".equals(relate) ){
			return 1;
		}
		return 0;
	}

}
