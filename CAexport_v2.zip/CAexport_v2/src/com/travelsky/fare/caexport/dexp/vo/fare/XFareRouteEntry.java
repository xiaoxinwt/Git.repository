package com.travelsky.fare.caexport.dexp.vo.fare;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "entryno",
    "fromcode",
    "fromcodetype",
    "tocode",
    "tocodetype",
    "stopoverortransfer",
    "qchargeamt",
    "farerouteflightno",
    "minstay",
    "maxstay"
})

@XmlRootElement(name = "FARE_ROUTE_ENTRY")
public class XFareRouteEntry {
    @XmlElement(name = "ENTRY_NO", required = true)
    protected Integer entryno;
    @XmlElement(name = "FROM_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String fromcode;
    @XmlElement(name = "FROM_CODE_TYPE", required = true)
    protected Integer fromcodetype;
    @XmlElement(name = "TO_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String tocode;
    @XmlElement(name = "TO_CODE_TYPE", required = true)
    protected Integer tocodetype;
    @XmlElement(name = "STOPOVER_OR_TRANSFER", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String stopoverortransfer;
    @XmlElement(name = "Q_CHARGE_AMT", required = true, nillable = true)
    protected Integer qchargeamt;
    @XmlElement(name = "FARE_ROUTE_FLIGHT_NO", required = true)
    protected List<XFareRouteFlightNo> farerouteflightno;
    @XmlElement(name = "MIN_STAY")
    protected Integer minstay;
    @XmlElement(name = "MAX_STAY")
    protected Integer maxstay;
	
    public Integer getEntryno() {
		return entryno;
	}
	public void setEntryno(Integer entryno) {
		this.entryno = entryno;
	}
	public String getFromcode() {
		return fromcode;
	}
	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}
	public Integer getFromcodetype() {
		return fromcodetype;
	}
	public void setFromcodetype(Integer fromcodetype) {
		this.fromcodetype = fromcodetype;
	}
	public String getTocode() {
		return tocode;
	}
	public void setTocode(String tocode) {
		this.tocode = tocode;
	}
	public Integer getTocodetype() {
		return tocodetype;
	}
	public void setTocodetype(Integer tocodetype) {
		this.tocodetype = tocodetype;
	}
	public String getStopoverortransfer() {
		return stopoverortransfer;
	}
	public void setStopoverortransfer(String stopoverortransfer) {
		this.stopoverortransfer = stopoverortransfer;
	}
	public Integer getQchargeamt() {
		return qchargeamt;
	}
	public void setQchargeamt(Integer qchargeamt) {
		this.qchargeamt = qchargeamt;
	}
	public List<XFareRouteFlightNo> getFarerouteflightno() {
		if( farerouteflightno==null) farerouteflightno=new ArrayList<XFareRouteFlightNo>();
		return farerouteflightno;
	}
	public void setFarerouteflightno(List<XFareRouteFlightNo> farerouteflightno) {
		this.farerouteflightno = farerouteflightno;
	}
	public Integer getMinstay() {
		return minstay;
	}
	public void setMinstay(Integer minstay) {
		this.minstay = minstay;
	}
	public Integer getMaxstay() {
		return maxstay;
	}
	public void setMaxstay(Integer maxstay) {
		this.maxstay = maxstay;
	}
}
