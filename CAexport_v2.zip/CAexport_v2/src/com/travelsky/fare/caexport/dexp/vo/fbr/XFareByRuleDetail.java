package com.travelsky.fare.caexport.dexp.vo.fbr;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
	"actioncode",
    "fbrdtlid",
    "fbrdtlprior",
    "saleeffdate",
    "salediscdate",
    "firsttraveldate",
    "lasttraveldate",
    "distributionstatus",
    "remark",
    "oricodetype",
    "oricode",
    "destcodetype",
    "destcode",
    "journeytype",
    "bookingclass",
    "subclassflag",
    "ifonlydirectfare",
    "basefaretype",
    "accountcodeflag",
    "accountcode",
    "discountcode",
    "exceptroute",
    "basefare",
    "rstfcaculatetype",
    "rstfpercent",
    "rstfamt",
    "pricechoose",
    "roundrule",
    "rstfthresholdcaltype",
    "rstfthresholdcalpercent",
    "rstfdisplayifsamebasefare",
    "rstfdisplay",
    "ifsamebasefarerule",
    "ruleno",
    "ifuseotherrulerestriction",
    "rulerestriction",
    "ifsamebasefaregroup",
    "groupid"
})
@XmlRootElement(name = "FAREBYRULE_DETAIL")
public class XFareByRuleDetail {
	@XmlElement(name = "ACTION_CODE", required = true)
    protected String actioncode;
    @XmlElement(name = "FBR_DTL_ID")
    protected String fbrdtlid;
    @XmlElement(name = "FBR_DTL_PRIOR", required = true)
    protected Integer fbrdtlprior;
    @XmlElement(name = "SALE_EFF_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date saleeffdate;
    @XmlElement(name = "SALE_DISC_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date salediscdate;
    @XmlElement(name = "FIRST_TRAVEL_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date firsttraveldate;
    @XmlElement(name = "LAST_TRAVEL_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date lasttraveldate;
    @XmlElement(name = "DISTRIBUTION_STATUS", required = true)
    protected Integer distributionstatus;
    @XmlElement(name = "REMARK")
    protected String remark;
    @XmlElement(name = "ORI_CODE_TYPE", required = true)
    protected Integer oricodetype;
    @XmlElement(name = "ORI_CODE", required = true)
    protected String oricode;
    @XmlElement(name = "DEST_CODE_TYPE", required = true)
    protected Integer destcodetype;
    @XmlElement(name = "DEST_CODE", required = true)
    protected String destcode;
    @XmlElement(name = "JOURNEY_TYPE", required = true)
    protected String journeytype;
    @XmlElement(name = "BOOKING_CLASS", required = true, nillable = true)
    protected String bookingclass;
    @XmlElement(name = "SUB_CLASS_FLAG")
    protected Integer subclassflag;
    @XmlElement(name = "IF_ONLY_DIRECT_FARE", required = true)
    protected Integer ifonlydirectfare;
    @XmlElement(name = "BASEFARE_TYPE", required = true)
    protected Integer basefaretype;
    @XmlElement(name = "ACCOUNT_CODE_FLAG", defaultValue = "1")
    protected Integer accountcodeflag;
    @XmlElement(name = "ACCOUNT_CODE", required = true, nillable = true)
    protected String accountcode;
    @XmlElement(name = "DISCOUNT_CODE", required = true, nillable = true)
    protected String discountcode;
    @XmlElement(name = "RSTF_CACULATE_TYPE", required = true)
    protected Integer rstfcaculatetype;
    @XmlElement(name = "RSTF_PERCENT", required = true, nillable = true)
    protected Integer rstfpercent;
    @XmlElement(name = "RSTF_AMT", required = true, nillable = true)
    protected Integer rstfamt;
    @XmlElement(name = "PRICE_CHOOSE", required = true)
    protected Integer pricechoose;
    @XmlElement(name = "ROUND_RULE", required = true)
    protected Integer roundrule;
    @XmlElement(name = "RSTF_THRESHOLD_CAL_TYPE")
    protected String rstfthresholdcaltype;
    @XmlElement(name = "RSTF_THRESHOLD_CAL_PERCENT")
    protected Integer rstfthresholdcalpercent;
    @XmlElement(name = "RSTF_DISPLAY_IF_SAME_BASEFARE", required = true)
    protected Integer rstfdisplayifsamebasefare;
    @XmlElement(name = "RSTF_DISPLAY")
    protected XFareByRuleDetail.RSTFDISPLAY rstfdisplay;
    @XmlElement(name = "IF_SAME_BASEFARE_RULE", required = true)
    protected Integer ifsamebasefarerule;
    @XmlElement(name = "IF_SAME_BASEFARE_GROUP", required = true)
    protected Integer ifsamebasefaregroup;
    @XmlElement(name = "IF_USE_OTHER_RULE_RESTRICTION", required = true)
    protected Integer ifuseotherrulerestriction;
    @XmlElement(name = "RULE_NO")
    protected String ruleno;
    @XmlElement(name = "RULE_RESTRICTION")
    protected XFareByRuleDetail.RULERESTRICTION rulerestriction;
    @XmlElement(name = "EXCEPT_ROUTE")
    protected List<XExceptRoute> exceptroute;
    @XmlElement(name = "BASE_FARE", required = true)
    protected List<XBaseFare> basefare;
    @XmlElement(name = "GROUP_ID")
    protected List<String> groupid;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "rstfdisplayfarebasis",
        "rstfdisplaytourcode",
        "rstfdisplaybasecmnamt",
        "rstfdisplayadtcmnamt",
        "rstfdisplaybasecmnpct",
        "rstfdisplayadtcmnpct",
        "baggageallowance",
        "baggageunit",
        "rstfdisplayiffreeyq",
        "rstfdisplayendorsment"
    })
    public static class RSTFDISPLAY {
        @XmlElement(name = "RSTF_DISPLAY_FARE_BASIS", required = true, nillable = true)
        protected String rstfdisplayfarebasis;
        @XmlElement(name = "RSTF_DISPLAY_TOURCODE", required = true, nillable = true)
        protected String rstfdisplaytourcode;
        @XmlElement(name = "RSTF_DISPLAY_BASE_CMN_AMT", required = true, nillable = true)
        protected Integer rstfdisplaybasecmnamt;
        @XmlElement(name = "RSTF_DISPLAY_ADT_CMN_AMT", required = true, nillable = true)
        protected Integer rstfdisplayadtcmnamt;
        @XmlElement(name = "RSTF_DISPLAY_BASE_CMN_PCT", required = true, nillable = true)
        protected Integer rstfdisplaybasecmnpct;
        @XmlElement(name = "RSTF_DISPLAY_ADT_CMN_PCT", required = true, nillable = true)
        protected Integer rstfdisplayadtcmnpct;
        @XmlElement(name = "BAGGAGE_ALLOWANCE", required = true, nillable = true)
        protected Integer baggageallowance;
        @XmlElement(name = "BAGGAGE_UNIT", required = true)
        protected Integer baggageunit;
        @XmlElement(name = "RSTF_DISPLAY_IF_FREE_YQ", required = true)
        protected Integer rstfdisplayiffreeyq;
        @XmlElement(name = "RSTF_DISPLAY_ENDORSMENT", required = true, nillable = true)
        protected String rstfdisplayendorsment;
		
        public String getRstfdisplayfarebasis() {
			return rstfdisplayfarebasis;
		}
		public void setRstfdisplayfarebasis(String rstfdisplayfarebasis) {
			this.rstfdisplayfarebasis = rstfdisplayfarebasis;
		}
		public String getRstfdisplaytourcode() {
			return rstfdisplaytourcode;
		}
		public void setRstfdisplaytourcode(String rstfdisplaytourcode) {
			this.rstfdisplaytourcode = rstfdisplaytourcode;
		}
		public Integer getRstfdisplaybasecmnamt() {
			return rstfdisplaybasecmnamt;
		}
		public void setRstfdisplaybasecmnamt(Integer rstfdisplaybasecmnamt) {
			this.rstfdisplaybasecmnamt = rstfdisplaybasecmnamt;
		}
		public Integer getRstfdisplayadtcmnamt() {
			return rstfdisplayadtcmnamt;
		}
		public void setRstfdisplayadtcmnamt(Integer rstfdisplayadtcmnamt) {
			this.rstfdisplayadtcmnamt = rstfdisplayadtcmnamt;
		}
		public Integer getRstfdisplaybasecmnpct() {
			return rstfdisplaybasecmnpct;
		}
		public void setRstfdisplaybasecmnpct(Integer rstfdisplaybasecmnpct) {
			this.rstfdisplaybasecmnpct = rstfdisplaybasecmnpct;
		}
		public Integer getRstfdisplayadtcmnpct() {
			return rstfdisplayadtcmnpct;
		}
		public void setRstfdisplayadtcmnpct(Integer rstfdisplayadtcmnpct) {
			this.rstfdisplayadtcmnpct = rstfdisplayadtcmnpct;
		}
		public Integer getBaggageallowance() {
			return baggageallowance;
		}
		public void setBaggageallowance(Integer baggageallowance) {
			this.baggageallowance = baggageallowance;
		}
		public Integer getBaggageunit() {
			return baggageunit;
		}
		public void setBaggageunit(Integer baggageunit) {
			this.baggageunit = baggageunit;
		}
		public Integer getRstfdisplayiffreeyq() {
			return rstfdisplayiffreeyq;
		}
		public void setRstfdisplayiffreeyq(Integer rstfdisplayiffreeyq) {
			this.rstfdisplayiffreeyq = rstfdisplayiffreeyq;
		}
		public String getRstfdisplayendorsment() {
			return rstfdisplayendorsment;
		}
		public void setRstfdisplayendorsment(String rstfdisplayendorsment) {
			this.rstfdisplayendorsment = rstfdisplayendorsment;
		}
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "outboundpermitted",
        "inboundpermitted",
        "minimum",
        "maximum"
    })
    public static class RULERESTRICTION {
        @XmlElement(name = "OUTBOUND_PERMITTED", required = true)
        protected Integer outboundpermitted;
        @XmlElement(name = "INBOUND_PERMITTED", required = true)
        protected Integer inboundpermitted;
        @XmlElement(name = "MINIMUM", required = true)
        protected XFareByRuleDetail.RULERESTRICTION.MINIMUM minimum;
        @XmlElement(name = "MAXIMUM", required = true)
        protected XFareByRuleDetail.RULERESTRICTION.MAXIMUM maximum;
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "maximumstay",
            "maximumstayunit"
        })
        public static class MAXIMUM {
            @XmlElement(name = "MAXIMUM_STAY", required = true)
            protected Integer maximumstay;
            @XmlElement(name = "MAXIMUM_STAY_UNIT", required = true)
            protected String maximumstayunit;
			
            public Integer getMaximumstay() {
				return maximumstay;
			}
			public void setMaximumstay(Integer maximumstay) {
				this.maximumstay = maximumstay;
			}
			public String getMaximumstayunit() {
				return maximumstayunit;
			}
			public void setMaximumstayunit(String maximumstayunit) {
				this.maximumstayunit = maximumstayunit;
			}
        }
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "minimumstay",
            "minimumstayunit"
        })
        public static class MINIMUM {
            @XmlElement(name = "MINIMUM_STAY", required = true)
            protected Integer minimumstay;
            @XmlElement(name = "MINIMUM_STAY_UNIT", required = true)
            protected String minimumstayunit;
			public Integer getMinimumstay() {
				return minimumstay;
			}
			public void setMinimumstay(Integer minimumstay) {
				this.minimumstay = minimumstay;
			}
			public String getMinimumstayunit() {
				return minimumstayunit;
			}
			public void setMinimumstayunit(String minimumstayunit) {
				this.minimumstayunit = minimumstayunit;
			}
        }
		
        public Integer getOutboundpermitted() {
			return outboundpermitted;
		}
		public void setOutboundpermitted(Integer outboundpermitted) {
			this.outboundpermitted = outboundpermitted;
		}
		public Integer getInboundpermitted() {
			return inboundpermitted;
		}
		public void setInboundpermitted(Integer inboundpermitted) {
			this.inboundpermitted = inboundpermitted;
		}
		public XFareByRuleDetail.RULERESTRICTION.MINIMUM getMinimum() {
			return minimum;
		}
		public void setMinimum(XFareByRuleDetail.RULERESTRICTION.MINIMUM minimum) {
			this.minimum = minimum;
		}
		public XFareByRuleDetail.RULERESTRICTION.MAXIMUM getMaximum() {
			return maximum;
		}
		public void setMaximum(XFareByRuleDetail.RULERESTRICTION.MAXIMUM maximum) {
			this.maximum = maximum;
		}
    }

	
    
    public String getActioncode() {
		return actioncode;
	}

	public void setActioncode(String actioncode) {
		this.actioncode = actioncode;
	}

	public String getFbrdtlid() {
		return fbrdtlid;
	}

	public void setFbrdtlid(String fbrdtlid) {
		this.fbrdtlid = fbrdtlid;
	}

	public Integer getFbrdtlprior() {
		return fbrdtlprior;
	}

	public void setFbrdtlprior(Integer fbrdtlprior) {
		this.fbrdtlprior = fbrdtlprior;
	}

	public Date getSaleeffdate() {
		return saleeffdate;
	}

	public void setSaleeffdate(Date saleeffdate) {
		this.saleeffdate = saleeffdate;
	}

	public Date getSalediscdate() {
		return salediscdate;
	}

	public void setSalediscdate(Date salediscdate) {
		this.salediscdate = salediscdate;
	}

	public Date getFirsttraveldate() {
		return firsttraveldate;
	}

	public void setFirsttraveldate(Date firsttraveldate) {
		this.firsttraveldate = firsttraveldate;
	}

	public Date getLasttraveldate() {
		return lasttraveldate;
	}

	public void setLasttraveldate(Date lasttraveldate) {
		this.lasttraveldate = lasttraveldate;
	}

	public Integer getDistributionstatus() {
		return distributionstatus;
	}

	public void setDistributionstatus(Integer distributionstatus) {
		this.distributionstatus = distributionstatus;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getOricodetype() {
		return oricodetype;
	}

	public void setOricodetype(Integer oricodetype) {
		this.oricodetype = oricodetype;
	}

	public String getOricode() {
		return oricode;
	}

	public void setOricode(String oricode) {
		this.oricode = oricode;
	}

	public Integer getDestcodetype() {
		return destcodetype;
	}

	public void setDestcodetype(Integer destcodetype) {
		this.destcodetype = destcodetype;
	}

	public String getDestcode() {
		return destcode;
	}

	public void setDestcode(String destcode) {
		this.destcode = destcode;
	}

	public String getJourneytype() {
		return journeytype;
	}

	public void setJourneytype(String journeytype) {
		this.journeytype = journeytype;
	}

	public String getBookingclass() {
		return bookingclass;
	}

	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}

	public Integer getSubclassflag() {
		return subclassflag;
	}

	public void setSubclassflag(Integer subclassflag) {
		this.subclassflag = subclassflag;
	}

	public Integer getIfonlydirectfare() {
		return ifonlydirectfare;
	}

	public void setIfonlydirectfare(Integer ifonlydirectfare) {
		this.ifonlydirectfare = ifonlydirectfare;
	}

	public Integer getBasefaretype() {
		return basefaretype;
	}

	public void setBasefaretype(Integer basefaretype) {
		this.basefaretype = basefaretype;
	}

	public Integer getAccountcodeflag() {
		return accountcodeflag;
	}

	public void setAccountcodeflag(Integer accountcodeflag) {
		this.accountcodeflag = accountcodeflag;
	}

	public String getAccountcode() {
		return accountcode;
	}

	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}

	public String getDiscountcode() {
		return discountcode;
	}

	public void setDiscountcode(String discountcode) {
		this.discountcode = discountcode;
	}

	public List<XExceptRoute> getExceptroute() {
		if(exceptroute==null) exceptroute=new ArrayList<XExceptRoute>();
		return exceptroute;
	}

	public void setExceptroute(List<XExceptRoute> exceptroute) {
		this.exceptroute = exceptroute;
	}

	public List<XBaseFare> getBasefare() {
		if(basefare==null) basefare=new ArrayList<XBaseFare>();
		return basefare;
	}

	public void setBasefare(List<XBaseFare> basefare) {
		this.basefare = basefare;
	}

	public Integer getRstfcaculatetype() {
		return rstfcaculatetype;
	}

	public void setRstfcaculatetype(Integer rstfcaculatetype) {
		this.rstfcaculatetype = rstfcaculatetype;
	}

	public Integer getRstfpercent() {
		return rstfpercent;
	}

	public void setRstfpercent(Integer rstfpercent) {
		this.rstfpercent = rstfpercent;
	}

	public Integer getRstfamt() {
		return rstfamt;
	}

	public void setRstfamt(Integer rstfamt) {
		this.rstfamt = rstfamt;
	}

	public Integer getPricechoose() {
		return pricechoose;
	}

	public void setPricechoose(Integer pricechoose) {
		this.pricechoose = pricechoose;
	}

	public Integer getRoundrule() {
		return roundrule;
	}

	public void setRoundrule(Integer roundrule) {
		this.roundrule = roundrule;
	}

	public String getRstfthresholdcaltype() {
		return rstfthresholdcaltype;
	}

	public void setRstfthresholdcaltype(String rstfthresholdcaltype) {
		this.rstfthresholdcaltype = rstfthresholdcaltype;
	}

	public Integer getRstfthresholdcalpercent() {
		return rstfthresholdcalpercent;
	}

	public void setRstfthresholdcalpercent(Integer rstfthresholdcalpercent) {
		this.rstfthresholdcalpercent = rstfthresholdcalpercent;
	}

	public Integer getRstfdisplayifsamebasefare() {
		return rstfdisplayifsamebasefare;
	}

	public void setRstfdisplayifsamebasefare(Integer rstfdisplayifsamebasefare) {
		this.rstfdisplayifsamebasefare = rstfdisplayifsamebasefare;
	}

	public XFareByRuleDetail.RSTFDISPLAY getRstfdisplay() {
		return rstfdisplay;
	}

	public void setRstfdisplay(XFareByRuleDetail.RSTFDISPLAY rstfdisplay) {
		this.rstfdisplay = rstfdisplay;
	}

	public XFareByRuleDetail.RULERESTRICTION getRulerestriction() {
		return rulerestriction;
	}

	public void setRulerestriction(XFareByRuleDetail.RULERESTRICTION rulerestriction) {
		this.rulerestriction = rulerestriction;
	}

	public Integer getIfsamebasefarerule() {
		return ifsamebasefarerule;
	}

	public void setIfsamebasefarerule(Integer ifsamebasefarerule) {
		this.ifsamebasefarerule = ifsamebasefarerule;
	}

	public Integer getIfuseotherrulerestriction() {
		return ifuseotherrulerestriction;
	}

	public void setIfuseotherrulerestriction(Integer ifuseotherrulerestriction) {
		this.ifuseotherrulerestriction = ifuseotherrulerestriction;
	}

	public String getRuleno() {
		return ruleno;
	}

	public void setRuleno(String ruleno) {
		this.ruleno = ruleno;
	}

	public Integer getIfsamebasefaregroup() {
		return ifsamebasefaregroup;
	}

	public void setIfsamebasefaregroup(Integer ifsamebasefaregroup) {
		this.ifsamebasefaregroup = ifsamebasefaregroup;
	}

	public List<String> getGroupid() {
		if(groupid==null) groupid=new ArrayList<String>();
		return groupid;
	}

	public void setGroupid(List<String> groupid) {
		this.groupid = groupid;
	}

    
}
