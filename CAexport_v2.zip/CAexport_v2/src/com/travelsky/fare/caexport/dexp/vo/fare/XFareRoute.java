package com.travelsky.fare.caexport.dexp.vo.fare;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "routeno",
    "farerouteentry"
})
@XmlRootElement(name = "FARE_ROUTE")
public class XFareRoute {
    @XmlElement(name = "ROUTE_NO", required = true)
    protected Integer routeno;
    @XmlElement(name = "FARE_ROUTE_ENTRY", required = true)
    protected List<XFareRouteEntry> farerouteentry;
	
    public Integer getRouteno() {
		return routeno;
	}
	public void setRouteno(Integer routeno) {
		this.routeno = routeno;
	}
	public List<XFareRouteEntry> getFarerouteentry() {
		if( farerouteentry==null) farerouteentry=new ArrayList<XFareRouteEntry>();
		return farerouteentry;
	}
	public void setFarerouteentry(List<XFareRouteEntry> farerouteentry) {
		this.farerouteentry = farerouteentry;
	}
}
