package com.travelsky.fare.caexport.dexp.vo.refund;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "carrCode","locationCode",
    "refundid",
    "refundType",
    "yqtaxallowed",
    "voluntaryTxt",
    "inVoluntaryTxt",
    "refundEntries"
})
@XmlRootElement(name = "RULE_REFUND")
public class XRefund{
	@XmlElement(name = "Action_Code", required = true)
	protected String actionCode;
    @XmlElement(name = "CARR_CODE", required = true)
    private String carrCode;
    @XmlElement(name = "LOCATION_CODE", required = true)
    private String locationCode;
	@XmlElement(name = "RULE_REFUND_ID", required = true)
	protected String refundid;
	@XmlElement(name = "REFUND_TYPE", required = true)
	protected Integer refundType;
	@XmlElement(name = "REFUND_YQTAX_ALLOWED")
	protected Integer yqtaxallowed;
	@XmlElement(name = "VOLUNTARY_TXT", required = true)
	protected String voluntaryTxt;
	@XmlElement(name = "INVOLUNTARY_TXT")
	protected String inVoluntaryTxt;
	@XmlElement(name = "RULE_REFUND_ENTRY")
	protected List<XRefundEntry> refundEntries;
	

	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public List<XRefundEntry> getRefundEntries() {
		if (refundEntries == null) {
			refundEntries = new ArrayList<XRefundEntry>();
		}
		return this.refundEntries;
	}
	public void setRefundEntries(List<XRefundEntry> refundEntries) {
		this.refundEntries = refundEntries;
	}
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getRefundid() {
		return refundid;
	}
	public void setRefundid(String refundid) {
		this.refundid = refundid;
	}
	public Integer getRefundType() {
		return refundType;
	}
	public void setRefundType(Integer refundType) {
		this.refundType = refundType;
	}
	public Integer isYqtaxallowed() {
		return yqtaxallowed;
	}
	public void setYqtaxallowed(Integer yqtaxallowed) {
		this.yqtaxallowed = yqtaxallowed;
	}
	public String getVoluntaryTxt() {
		return voluntaryTxt;
	}
	public void setVoluntaryTxt(String voluntaryTxt) {
		this.voluntaryTxt = voluntaryTxt;
	}
	public String getInVoluntaryTxt() {
		return inVoluntaryTxt;
	}
	public void setInVoluntaryTxt(String inVoluntaryTxt) {
		this.inVoluntaryTxt = inVoluntaryTxt;
	}
	public Integer getYqtaxallowed() {
		return yqtaxallowed;
	}
}
