package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.common.reissue.Reissue;
import com.travelsky.fare.caexport.db.model.common.reissue.ReissueDetail;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.reissue.XReissue;
import com.travelsky.fare.caexport.dexp.vo.reissue.XReissueEntry;
import com.travelsky.fare.caexport.util.StringUtil;

public class ReissueConvertor implements IConvert<Reissue, XReissue> {

	private IConvert<ReissueDetail, XReissueEntry> detailconvertor = new ReissueDetailConvertor();
	
	@Override
	public List<XReissue> convert(List<Reissue> list) {
		List<XReissue> xisses = new ArrayList<XReissue>();
		for (Reissue iss : list) {
			xisses.add(convert(iss));
		}
		return xisses;
	}

	@Override
	public XReissue convert(Reissue iss) {
		XReissue xiss = null;
		if(iss!=null){
			xiss = new XReissue();
			//����
			xiss.setLocationCode( iss.getLocationCode() );
			xiss.setRulereissueid( StringUtil.isNullOrEmpty( iss.getReissueId() )? "" : iss.getReissueId() );
			xiss.setChangetag( StringUtil.isNullOrEmpty( iss.getChangeTag() )? null : iss.getChangeTag() );
			xiss.setVoluntarychangedtext( StringUtil.isNullOrEmpty( iss.getVoluntaryChangedText() )? "" : iss.getVoluntaryChangedText() );
			
			xiss.setInvoluntarychangedtext( iss.getInvoluntaryChangedText() );
			xiss.setReissueentries( detailconvertor.convert( iss.getDetails() ) );
		}
		return xiss;
	}

}
