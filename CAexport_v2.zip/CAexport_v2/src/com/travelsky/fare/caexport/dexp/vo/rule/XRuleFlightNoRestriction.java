package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "exflightnoout",
    "exflightnoin",
    "flightnoout",
    "flightnoin"
})
@XmlRootElement(name = "RULE_FLIGHT_NO_RESTRICTION")
public class XRuleFlightNoRestriction {

    @XmlElement(name = "EX_FLIGHT_NO_OUT")
    protected List<XExFlightNoOut> exflightnoout;
    @XmlElement(name = "EX_FLIGHT_NO_IN")
    protected List<XExFlightNoIn> exflightnoin;
    @XmlElement(name = "FLIGHT_NO_OUT", required = true)
    protected List<XFlightNoOut> flightnoout;
    @XmlElement(name = "FLIGHT_NO_IN", required = true)
    protected List<XFlightNoIn> flightnoin;
    
	public List<XExFlightNoOut> getExflightnoout() {
        if (exflightnoout == null) {
            exflightnoout = new ArrayList<XExFlightNoOut>();
        }
		return exflightnoout;
	}
	public void setExflightnoout(List<XExFlightNoOut> exflightnoout) {
		this.exflightnoout = exflightnoout;
	}
	public List<XExFlightNoIn> getExflightnoin() {
        if (exflightnoin == null) {
            exflightnoin = new ArrayList<XExFlightNoIn>();
        }
		return exflightnoin;
	}
	public void setExflightnoin(List<XExFlightNoIn> exflightnoin) {
		this.exflightnoin = exflightnoin;
	}
	public List<XFlightNoOut> getFlightnoout() {
        if (flightnoout == null) {
            flightnoout = new ArrayList<XFlightNoOut>();
        }
		return flightnoout;
	}
	public void setFlightnoout(List<XFlightNoOut> flightnoout) {
		this.flightnoout = flightnoout;
	}
	public List<XFlightNoIn> getFlightnoin() {
        if (flightnoin == null) {
            flightnoin = new ArrayList<XFlightNoIn>();
        }
		return flightnoin;
	}
	public void setFlightnoin(List<XFlightNoIn> flightnoin) {
		this.flightnoin = flightnoin;
	}
}
