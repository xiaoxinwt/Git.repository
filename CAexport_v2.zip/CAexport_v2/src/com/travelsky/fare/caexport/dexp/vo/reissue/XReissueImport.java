package com.travelsky.fare.caexport.dexp.vo.reissue;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "rulereissue"
})
@XmlRootElement(name = "RULE_REISSUE_IMPORT")
public class XReissueImport{

    @XmlElement(name = "RULE_REISSUE")
    protected List<XReissue> rulereissue;

	public List<XReissue> getRulereissue() {
		return rulereissue;
	}
	public void setRulereissue(List<XReissue> rulereissue) {
		this.rulereissue = rulereissue;
	}
}
