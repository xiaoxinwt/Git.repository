package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromnoout",
    "tonoout"
})
@XmlRootElement(name = "HOUR_RESTRICTION_OUT")
public class XHourRestrictionOut {
    @XmlElement(name = "FROM_NO_OUT", required = true, nillable = true)
    protected Integer fromnoout;
    @XmlElement(name = "TO_NO_OUT", required = true, nillable = true)
    protected Integer tonoout;
    public Integer getFromnoout() {
		return fromnoout;
	}
	public void setFromnoout(Integer fromnoout) {
		this.fromnoout = fromnoout;
	}
	public Integer getTonoout() {
		return tonoout;
	}
	public void setTonoout(Integer tonoout) {
		this.tonoout = tonoout;
	}
}
