package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.travelsky.fare.caexport.db.dao.common.AgreementDaoImpl;
import com.travelsky.fare.caexport.db.model.airtis_fare.NewFare;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Agreement;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.dexp.vo.convertor.IFareConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.NewFareConvertor;
import com.travelsky.fare.caexport.dexp.vo.fare.XAgreement;
import com.travelsky.fare.caexport.dexp.vo.fare.XFare;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

/**
 * ���ڽ�Airtis�е�NewFareתΪXFareImport����
 * ��������RefPK��ÿһ��ͬһ������fareװ���һ��Agreement����
 * �������յ�Agreement�б�װ��ɵ����ļ�XFareImport
 */
public class AirtisFareImportor implements IImportor<NewFare,XFareImport>{
	
	//���ڽ� NewFare����תΪXFare����
	IFareConvert<NewFare,XFare> newfareconvertor = new NewFareConvertor();
	private long count = -1;

	@Override
	public XFareImport getImport(List<NewFare> list, String carrier, CAType catype ,ActionType actype){
		
		count = 0;
		XFareImport xfareimp = new XFareImport();
		
		Map<RefPK, List<XFare>> xfaremap = newfareconvertor.convertToMapByPK( list,carrier );
		if( xfaremap==null || xfaremap.size()==0) return xfareimp;
		
		//��xfaremap�������������װΪXAgreement����
		List<XAgreement> xagreelist = new ArrayList<XAgreement>();
		XAgreement xagree = null;
		List<XFare> xfarelist = null;
		for (RefPK pk : xfaremap.keySet()) {
			
			xfarelist = xfaremap.get(pk);
			if( xfarelist==null || xfarelist.size()==0 ) continue;
			
			xagree = new XAgreement();
			xagree.setCarrCode( pk.getCarrier() );
			xagree.setLocationCode( pk.getLocationCode() );
			xagree.setRefno( pk.getRefNo() );
			
			xagree.setAgreementdesc("null");
			xagree.setEffectivedate( DateUtil.getDate("9999-12-31") );
			xagree.setDiscontinuedate( DateUtil.getDate("9999-12-31") );
			xagree.setGroupid(null);
			xagree.setMode( null );
			
			count+=xfarelist.size();
			xagree.setFares( xfarelist );
			xagreelist.add( xagree );
		}
		
		xfareimp.setAgreements( xagreelist );
		return xfareimp;
	}

	@Override
	public long getCount() {
		return count;
	}
	
}
