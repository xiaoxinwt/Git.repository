package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.List;

import com.travelsky.fare.caexport.db.model.common.group.Group;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.GroupConvertor;
import com.travelsky.fare.caexport.dexp.vo.group.XGroup;
import com.travelsky.fare.caexport.dexp.vo.group.XGroupImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.util.Const;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public class GroupImportor implements IImportor<Group, XGroupImport> {

	private IConvert<Group,XGroup> groupconvertor = new GroupConvertor();
	private long count = -1;
	
	@Override
	public XGroupImport getImport(List<Group> list,String carrier,CAType catype, ActionType actype) {
		
		count = 0;
		XGroupImport xgroupimp = new XGroupImport();
		if( list==null || list.size()==0 ) return xgroupimp;
		
		List<XGroup> xgrouplist = groupconvertor.convert(list);
		if( xgrouplist==null || xgrouplist.size()==0 ) return xgroupimp;
		
		boolean isAirtis = catype.equals( CAType.Airtis );
		for (XGroup xgroup : xgrouplist) {
			xgroup.setActionCode( actype.code );
			xgroup.setCarrCode( carrier );
			if( isAirtis ){
				xgroup.setLocationCode( Const.AIRTIS_LOCATION_CODE );
			}
		}
		
		count += xgrouplist.size();
		xgroupimp.setGroups( xgrouplist );
		
		return xgroupimp;
	}

	@Override
	public long getCount() {
		return count;
	}

}
