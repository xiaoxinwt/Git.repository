package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBR;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.FBRConvertor;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRuleImport;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRule;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRuleDetail;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public class FBRImportor implements IImportor<FBR, XFareByRuleImport> {
	
	private IConvert<FBR,XFareByRule> fbrconvertor = new FBRConvertor();
	private long count = -1;
	
	@Override
	public XFareByRuleImport getImport(List<FBR> list,String carrier,CAType catype, ActionType actype) {
		
		count = 0;
		XFareByRuleImport xfbrimp = new XFareByRuleImport();
		if( list==null || list.size()==0 ) return xfbrimp;
		
		List<XFareByRule> xfbrlist = fbrconvertor.convert(list);
		if( xfbrlist==null || xfbrlist.size()==0 ) return xfbrimp;
		
		for (XFareByRule xfbr : xfbrlist) {
			for (XFareByRuleDetail xdetail : xfbr.getFarebyruledetails()) {
				xdetail.setActioncode( actype.code );
			}
		}
		count += xfbrlist.size();
		xfbrimp.setFarebyrule( xfbrlist );
		
		return xfbrimp;
	}

	@Override
	public long getCount() {
		return count;
	}
	

}
