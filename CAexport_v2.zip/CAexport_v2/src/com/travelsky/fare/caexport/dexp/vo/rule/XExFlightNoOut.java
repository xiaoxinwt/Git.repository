package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "exfromnoout",
    "extonoout",
    "exnosuffixout"
})
@XmlRootElement(name = "EX_FLIGHT_NO_OUT")
public class XExFlightNoOut {
    @XmlElement(name = "EX_FROM_NO_OUT", required = true)
    protected Integer exfromnoout;
    @XmlElement(name = "EX_TO_NO_OUT", required = true)
    protected Integer extonoout;
    @XmlElement(name = "EX_NO_SUFFIX_OUT", defaultValue = "")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String exnosuffixout;
	
    public Integer getExfromnoout() {
		return exfromnoout;
	}
	public void setExfromnoout(Integer exfromnoout) {
		this.exfromnoout = exfromnoout;
	}
	public Integer getExtonoout() {
		return extonoout;
	}
	public void setExtonoout(Integer extonoout) {
		this.extonoout = extonoout;
	}
	public String getExnosuffixout() {
		return exnosuffixout;
	}
	public void setExnosuffixout(String exnosuffixout) {
		this.exnosuffixout = exnosuffixout;
	}
}
