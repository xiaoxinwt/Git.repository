package com.travelsky.fare.caexport.dexp.vo.rule;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "exfromnoin",
    "extonoin",
    "exnosuffixin"
})
@XmlRootElement(name = "EX_FLIGHT_NO_IN")
public class XExFlightNoIn {
    @XmlElement(name = "EX_FROM_NO_IN", required = true)
    protected Integer exfromnoin;
    @XmlElement(name = "EX_TO_NO_IN", required = true)
    protected Integer extonoin;
    @XmlElement(name = "EX_NO_SUFFIX_IN", defaultValue = "")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String exnosuffixin;
	
    public Integer getExfromnoin() {
		return exfromnoin;
	}
	public void setExfromnoin(Integer exfromnoin) {
		this.exfromnoin = exfromnoin;
	}
	public Integer getExtonoin() {
		return extonoin;
	}
	public void setExtonoin(Integer extonoin) {
		this.extonoin = extonoin;
	}
	public String getExnosuffixin() {
		return exnosuffixin;
	}
	public void setExnosuffixin(String exnosuffixin) {
		this.exnosuffixin = exnosuffixin;
	}
}
