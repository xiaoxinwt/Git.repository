package com.travelsky.fare.caexport.dexp.vo.refund;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
//	"seqId",
    "passengerType",
    "journeyType",
    "bookingClass",
    "fareBasis",
    "ticketUseType",
    "lowerValue",
    "lowerRelate",
    "upperValue",
    "upperRelate",
    "firstTicketedTime",
    "lastTicketedTime",
    "ticketedTimeUnit",
    "departrueTimeType",
    "firstDepartrueTime",
    "lastDepartrueTime",
    "departrueTimeUnit",
    "refundAllowedTag",
    "refundYqtaxAllowed",
    "calUsedSectorType",
    "calBookingClass",
    "calUnusedSectorType",
    "percent",
    "minAmount",
    "fixedAmount",
    "specRbd",
    "calUnusedPfarePercent",
    "taxRefundType"
})
@XmlRootElement(name = "RULE_REFUND_ENTRY")
public class XRefundEntry {
	
	@XmlTransient
	private String refundId;
	@XmlTransient
//	@XmlElement(name="SEQ_ID" ,required=true)
	private Integer seqId;
	@XmlElement(name = "PASSENGER_TYPE")
    protected String passengerType;
    @XmlElement(name = "JOURNEY_TYPE")
//    @XmlJavaTypeAdapter(JourneyTypeConvertToIntAdapter.class)
    protected String journeyType;
    @XmlElement(name = "BOOKING_CLASS")
    protected String bookingClass;
    @XmlElement(name = "FARE_BASIS")
    protected String fareBasis;
    @XmlElement(name = "TICKET_USE_TYPE", required = true)
    protected Integer ticketUseType;
    @XmlElement(name = "LOWER_VALUE")
    protected Integer lowerValue;
    @XmlElement(name = "LOWER_RELATE", required = true)
    protected Integer lowerRelate;
    @XmlElement(name = "UPPER_VALUE")
    protected Integer upperValue;
    @XmlElement(name = "UPPER_RELATE", required = true)
    protected Integer upperRelate;
    @XmlElement(name = "FIRST_TICKETED_TIME")
    protected Integer firstTicketedTime;
    @XmlElement(name = "LAST_TICKETED_TIME")
    protected Integer lastTicketedTime;
    @XmlElement(name = "TICKETED_TIME_UNIT", required = true)
    protected String ticketedTimeUnit;
    @XmlElement(name = "DEPARTRUE_TIME_TYPE", required = true)
    protected Integer departrueTimeType;
    @XmlElement(name = "FIRST_DEPARTRUE_TIME")
    protected Integer firstDepartrueTime;
    @XmlElement(name = "LAST_DEPARTRUE_TIME")
    protected Integer lastDepartrueTime;
    @XmlElement(name = "DEPARTRUE_TIME_UNIT", required = true)
    protected String departrueTimeUnit;
    @XmlElement(name = "REFUND_ALLOWED_TAG")
    protected Integer refundAllowedTag;
    @XmlElement(name = "REFUND_YQTAX_ALLOWED")
    protected Integer refundYqtaxAllowed;
    @XmlElement(name = "CAL_USED_SECTOR_TYPE")
    protected Integer calUsedSectorType;
    @XmlElement(name = "CAL_BOOKING_CLASS")
    protected String calBookingClass;
    @XmlElement(name = "CAL_UNUSED_SECTOR_TYPE", required = true)
    protected Integer calUnusedSectorType;
    @XmlElement(name = "PERCENT")
    protected Integer percent;
    @XmlElement(name = "MINIMUM_AMOUNT")
    protected Integer minAmount;
    @XmlElement(name = "FIXED_AMOUNT")
    protected Integer fixedAmount;
    @XmlElement(name = "SPEC_RBD")
    protected String specRbd;
    @XmlElement(name = "CAL_UNUSED_PFARE_PERCENT")
    protected Integer calUnusedPfarePercent;
    @XmlElement(name = "TAX_REFUND_TYPE", required = true)
    protected Integer taxRefundType;
	
    public String getRefundId() {
		return refundId;
	}
	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}
	public Integer getSeqId() {
		return seqId;
	}
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}
	public String getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public Integer getTicketUseType() {
		return ticketUseType;
	}
	public void setTicketUseType(Integer ticketUseType) {
		this.ticketUseType = ticketUseType;
	}
	public Integer getLowerValue() {
		return lowerValue;
	}
	public void setLowerValue(Integer lowerValue) {
		this.lowerValue = lowerValue;
	}
	public Integer getLowerRelate() {
		return lowerRelate;
	}
	public void setLowerRelate(Integer lowerRelate) {
		this.lowerRelate = lowerRelate;
	}
	public Integer getUpperValue() {
		return upperValue;
	}
	public void setUpperValue(Integer upperValue) {
		this.upperValue = upperValue;
	}
	public Integer getUpperRelate() {
		return upperRelate;
	}
	public void setUpperRelate(Integer upperRelate) {
		this.upperRelate = upperRelate;
	}
	public Integer getFirstTicketedTime() {
		return firstTicketedTime;
	}
	public void setFirstTicketedTime(Integer firstTicketedTime) {
		this.firstTicketedTime = firstTicketedTime;
	}
	public Integer getLastTicketedTime() {
		return lastTicketedTime;
	}
	public void setLastTicketedTime(Integer lastTicketedTime) {
		this.lastTicketedTime = lastTicketedTime;
	}
	public String getTicketedTimeUnit() {
		return ticketedTimeUnit;
	}
	public void setTicketedTimeUnit(String ticketedTimeUnit) {
		this.ticketedTimeUnit = ticketedTimeUnit;
	}
	public Integer getDepartrueTimeType() {
		return departrueTimeType;
	}
	public void setDepartrueTimeType(Integer departrueTimeType) {
		this.departrueTimeType = departrueTimeType;
	}
	public Integer getFirstDepartrueTime() {
		return firstDepartrueTime;
	}
	public void setFirstDepartrueTime(Integer firstDepartrueTime) {
		this.firstDepartrueTime = firstDepartrueTime;
	}
	public Integer getLastDepartrueTime() {
		return lastDepartrueTime;
	}
	public void setLastDepartrueTime(Integer lastDepartrueTime) {
		this.lastDepartrueTime = lastDepartrueTime;
	}
	public String getDepartrueTimeUnit() {
		return departrueTimeUnit;
	}
	public void setDepartrueTimeUnit(String departrueTimeUnit) {
		this.departrueTimeUnit = departrueTimeUnit;
	}
	public Integer getRefundAllowedTag() {
		return refundAllowedTag;
	}
	public void setRefundAllowedTag(Integer refundAllowedTag) {
		this.refundAllowedTag = refundAllowedTag;
	}
	public Integer getRefundYqtaxAllowed() {
		return refundYqtaxAllowed;
	}
	public void setRefundYqtaxAllowed(Integer refundYqtaxAllowed) {
		this.refundYqtaxAllowed = refundYqtaxAllowed;
	}
	public Integer getCalUsedSectorType() {
		return calUsedSectorType;
	}
	public void setCalUsedSectorType(Integer calUsedSectorType) {
		this.calUsedSectorType = calUsedSectorType;
	}
	public String getCalBookingClass() {
		return calBookingClass;
	}
	public void setCalBookingClass(String calBookingClass) {
		this.calBookingClass = calBookingClass;
	}
	public Integer getCalUnusedSectorType() {
		return calUnusedSectorType;
	}
	public void setCalUnusedSectorType(Integer calUnusedSectorType) {
		this.calUnusedSectorType = calUnusedSectorType;
	}
	public Integer getPercent() {
		return percent;
	}
	public void setPercent(Integer percent) {
		this.percent = percent;
	}
	public Integer getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(Integer minAmount) {
		this.minAmount = minAmount;
	}
	public Integer getFixedAmount() {
		return fixedAmount;
	}
	public void setFixedAmount(Integer fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
	public String getSpecRbd() {
		return specRbd;
	}
	public void setSpecRbd(String specRbd) {
		this.specRbd = specRbd;
	}
	public Integer getCalUnusedPFarePercent() {
		return calUnusedPfarePercent;
	}
	public void setCalUnusedPfarePercent(Integer calUnusedPfarePercent) {
		this.calUnusedPfarePercent = calUnusedPfarePercent;
	}
	public Integer getTaxRefundType() {
		return taxRefundType;
	}
	public void setTaxRefundType(Integer taxRefundType) {
		this.taxRefundType = taxRefundType;
	}
}
