package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "blackoutfromdatein",
    "blackouttodatein"
})
@XmlRootElement(name = "BLACKOUT_IN")
public class XBlackoutIn {
    @XmlElement(name = "BLACKOUT_FROM_DATE_IN", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date blackoutfromdatein;
    @XmlElement(name = "BLACKOUT_TO_DATE_IN", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date blackouttodatein;
	
    public Date getBlackoutfromdatein() {
		return blackoutfromdatein;
	}
	public void setBlackoutfromdatein(Date blackoutfromdatein) {
		this.blackoutfromdatein = blackoutfromdatein;
	}
	public Date getBlackouttodatein() {
		return blackouttodatein;
	}
	public void setBlackouttodatein(Date blackouttodatein) {
		this.blackouttodatein = blackouttodatein;
	}
}
