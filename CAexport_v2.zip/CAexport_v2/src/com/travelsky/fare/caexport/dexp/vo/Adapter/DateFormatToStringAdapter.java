package com.travelsky.fare.caexport.dexp.vo.Adapter;

import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import com.travelsky.fare.caexport.util.DateUtil;

public class DateFormatToStringAdapter extends XmlAdapter<String,Date> {

	@Override
	public String marshal(Date date) throws Exception {
		return DateUtil.getDateStr(date, "yyyy-MM-dd'T'HH:mm:ss");
	}

	@Override
	public Date unmarshal(String datestr) throws Exception {
		return DateUtil.getDate( datestr );
	}

}
