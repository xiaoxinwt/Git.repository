package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.Rule;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.RuleConvertor;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.rule.XRule;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleImport;
import com.travelsky.fare.caexport.util.Const;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public class RuleImportor implements IImportor<Rule, XRuleImport> {

	private IConvert<Rule,XRule> ruleconvertor = new RuleConvertor();
	private long count = -1;
	
	@Override
	public XRuleImport getImport( List<Rule> list, String carrier,CAType catype ,ActionType actype) {
		count=0;
		XRuleImport xruleimp = new XRuleImport();
		
		if(list==null || list.size()==0 ) return xruleimp;
		
		List<XRule> xrulelist = ruleconvertor.convert( list );
		if( xrulelist==null || xrulelist.size()==0 ) return xruleimp;
		
		boolean isAirtis = catype.equals( CAType.Airtis );
		for (XRule xrule : xrulelist) {
			xrule.setActionCode( actype.code );
			xrule.setCarrCode( carrier );
			if( isAirtis ){
				xrule.setLocationCode( Const.AIRTIS_LOCATION_CODE );
			}
		}
		
		count += xrulelist.size();
		xruleimp.setRule( xrulelist );
		
		return xruleimp;
	}

	@Override
	public long getCount() {
		return count;
	}

}
