package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBRBasefare;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fbr.XBaseFare;

public class FBRBaseFareConvertor implements IConvert<FBRBasefare, XBaseFare> {

	@Override
	public List<XBaseFare> convert(List<FBRBasefare> list) {
		List<XBaseFare> xbases = null;
		if(list!=null && list.size()>0){
			xbases = new ArrayList<XBaseFare>();
			for( FBRBasefare basefare : list){
				xbases.add( convert(basefare) );
			}
		}
		return null;
	}

	@Override
	public XBaseFare convert(FBRBasefare basefare) {
		XBaseFare xbase = null;
		if( basefare!=null ){
			xbase = new XBaseFare();
			
			//�����Ҳ�Ϊnull
			xbase.setOricodetype( basefare.getOriCodeType()!=null?basefare.getOriCodeType():0 );
			xbase.setOricode( basefare.getOriCode()!=null?basefare.getOriCode():"" );
			xbase.setDestcodetype( basefare.getDestCodeType()!=null?basefare.getDestCodeType():0 );
			xbase.setDestcode( basefare.getDestCode()!=null?basefare.getDestCode():"" );
			xbase.setJourneytype( basefare.getJourneyType()!=null?basefare.getJourneyType():"" );
			
			//�����ҿ�Ϊnull
			xbase.setBookingclass( basefare.getBookingClass() );
			xbase.setFarebasis( basefare.getFareBasis() );
			
			//�Ǳ���
			xbase.setDistributiontype( basefare.getDistributionType() );
			xbase.setAgencyid( basefare.getAgencyId() );
			xbase.setIfdrbdopenseq( basefare.getIfDRbdOpenSeq() );
			xbase.setDrbdopenseq( basefare.getdRbdOpenSeq() );
		}
		return xbase;
	}

}
