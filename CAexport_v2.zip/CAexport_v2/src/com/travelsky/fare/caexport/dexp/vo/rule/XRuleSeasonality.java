package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "seasonalityout",
    "seasonalityin"
})
@XmlRootElement(name = "RULE_SEASONALITY")
public class XRuleSeasonality {

    @XmlElement(name = "SEASONALITY_OUT")
    protected List<XSeasonalityOut> seasonalityout;
    @XmlElement(name = "SEASONALITY_IN")
    protected List<XSeasonalityIn> seasonalityin;

	public List<XSeasonalityOut> getSeasonalityout() {
		if (seasonalityout == null) {
			seasonalityout = new ArrayList<XSeasonalityOut>();
		}
		return seasonalityout;
	}
	public void setSeasonalityout(List<XSeasonalityOut> seasonalityout) {
		this.seasonalityout = seasonalityout;
	}
	public List<XSeasonalityIn> getSeasonalityin() {
		if (seasonalityin == null) {
			seasonalityin = new ArrayList<XSeasonalityIn>();
		}
		return seasonalityin;
	}
	public void setSeasonalityin(List<XSeasonalityIn> seasonalityin) {
		this.seasonalityin = seasonalityin;
	}
}
