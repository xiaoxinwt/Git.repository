package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromnoin",
    "tonoin"
})
@XmlRootElement(name = "HOUR_RESTRICTION_IN")
public class XHourRestrictionIn {
    @XmlElement(name = "FROM_NO_IN", required = true, nillable = true)
    protected Integer fromnoin;
    @XmlElement(name = "TO_NO_IN", required = true, nillable = true)
    protected Integer tonoin;
	
    public Integer getFromnoin() {
		return fromnoin;
	}
	public void setFromnoin(Integer fromnoin) {
		this.fromnoin = fromnoin;
	}
	public Integer getTonoin() {
		return tonoin;
	}
	public void setTonoin(Integer tonoin) {
		this.tonoin = tonoin;
	}
    
}
