package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.github.pagehelper.StringUtil;
import com.travelsky.fare.caexport.db.dao.common.AgreementDaoImpl;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Agreement;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.dexp.vo.convertor.IFareConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.FareConvertor;
import com.travelsky.fare.caexport.dexp.vo.fare.XAgreement;
import com.travelsky.fare.caexport.dexp.vo.fare.XFare;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

/**
 * ����EasyFare�� ��FareתΪXFareImport����
 * XfareImport��ΪXAgreement����
 * XAgreement���ϵĻ��ֹ���ͬһ��FareNo��NewFare���Ϸ�װ��һ��XAgreement����
 */
public class EasyfareFareImportor implements IImportor<Fare,XFareImport>{

	private IFareConvert<Fare,XFare> fareconvertor = new FareConvertor();
	AgreementDaoImpl agreedao = new AgreementDaoImpl();
	private long count = -1;
	
	@Override
	public XFareImport getImport(List<Fare> list, String carrier,CAType catype ,ActionType actype) {
		
		count=0;
		XFareImport xfareimp = new XFareImport();
		if( list==null || list.size()==0 ) return xfareimp;
		
		//�Ƚ�Fare����תΪ������Ϊkey��map����
		Map<RefPK, List<XFare>> xfaremap = fareconvertor.convertToMapByPK( list , carrier);
		List<XAgreement> xagreelist = null;
		XAgreement xagree = null;
		if( xfaremap!=null && xfaremap.size()>0 ){
			xagreelist = new ArrayList<XAgreement>();
			List<XFare> xfarelist = null;
			Agreement agree = null;
			for ( RefPK pk : xfaremap.keySet() ) {
				xfarelist = xfaremap.get( pk );
				xagree = new XAgreement();
				xagree.setCarrCode( pk.getCarrier() );
				xagree.setLocationCode( pk.getLocationCode() );
				xagree.setRefno( pk.getRefNo() );
				
				agree = agreedao.queryAgreementByRefPK(pk);
				if( agree!=null ){
					xagree.setAgreementdesc( agree.getDesc() );
					xagree.setGroupid( agree.getGroupIds() );
					xagree.setEffectivedate( agree.getFromto().getEffectiveDate() );
					xagree.setDiscontinuedate( agree.getFromto().getDiscontinueDate() );
					xagree.setMode( null );
				}
				
				if( xfarelist!=null && xfarelist.size()>0 ){
					for (XFare xfare : xfarelist) {
						xfare.setActionCode( actype.code );
					}
					count += xfarelist.size();
				}
				xagree.setFares(xfarelist);
				xagreelist.add( xagree );
			}
			
			xfareimp.setAgreements( xagreelist );
		}
		return xfareimp;
	}

	@Override
	public long getCount() {
		return count;
	}

}
