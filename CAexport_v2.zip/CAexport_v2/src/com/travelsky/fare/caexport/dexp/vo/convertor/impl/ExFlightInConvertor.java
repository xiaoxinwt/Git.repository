package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.ExFlightNoIn;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XExFlightNoIn;

public class ExFlightInConvertor implements IConvert<ExFlightNoIn, XExFlightNoIn> {

	@Override
	public List<XExFlightNoIn> convert(List<ExFlightNoIn> list) {
		List<XExFlightNoIn> xeins = null;
		if(list!=null && list.size()>0){
			xeins = new ArrayList<XExFlightNoIn>();
			for (ExFlightNoIn ein : list) {
				xeins.add( convert(ein) );
			}
		}
		return xeins;
	}

	@Override
	public XExFlightNoIn convert(ExFlightNoIn ein) {
		XExFlightNoIn xein = null;
		if( ein!=null ){
			xein = new XExFlightNoIn();
			xein.setExfromnoin( ein.getFromNo() );
			xein.setExtonoin( ein.getToNo() );
			xein.setExnosuffixin( ein.getFlightnoSuffix() );
		}
		return xein;
	}

}
