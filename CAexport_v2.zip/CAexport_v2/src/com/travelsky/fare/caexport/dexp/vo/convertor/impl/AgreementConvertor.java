package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Agreement;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XAgreement;
import com.travelsky.fare.caexport.dexp.vo.fare.XFare;

public class AgreementConvertor implements IConvert<Agreement, XAgreement> {
	
	private IConvert<Fare, XFare> fareconvertor = new FareConvertor();

	@Override
	public List<XAgreement> convert(List<Agreement> list) {
		List<XAgreement> xagrees = null;
		if( list!=null ){
			xagrees = new ArrayList<XAgreement>();
			for(Agreement agree : list){
				xagrees.add( convert(agree) );
			}
		}
		return xagrees;
	}

	@Override
	public XAgreement convert(Agreement agree) {
		XAgreement xagree = null;
		if(agree!=null){
			xagree = new XAgreement();
			
			xagree.setRefno( agree.getRefNo() );
			xagree.setAgreementdesc( agree.getDesc() );
			xagree.setEffectivedate( agree.getFromto().getEffectiveDate() );
			xagree.setDiscontinuedate( agree.getFromto().getDiscontinueDate() );
//			xagree.setMode( agree );
			xagree.setGroupid( GroupsHelper.getGroupid(agree.getDistributes() ) );
			xagree.setFares( fareconvertor.convert(agree.getFares()) );
		}
		return xagree;
	}

}
