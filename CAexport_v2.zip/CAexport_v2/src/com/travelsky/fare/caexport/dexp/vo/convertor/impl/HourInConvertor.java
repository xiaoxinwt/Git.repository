package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.HourRestrictionIn;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XHourRestrictionIn;

public class HourInConvertor implements IConvert<HourRestrictionIn, XHourRestrictionIn> {

	@Override
	public List<XHourRestrictionIn> convert(List<HourRestrictionIn> list) {
		List<XHourRestrictionIn> xhins = null;
		if(list!=null && list.size()>0){
			xhins = new ArrayList<XHourRestrictionIn>();
			for (HourRestrictionIn hin : list) {
				xhins.add( convert(hin) );
			}
		}
		return xhins;
	}

	@Override
	public XHourRestrictionIn convert(HourRestrictionIn hin) {
		XHourRestrictionIn xhin = null;
		if(hin!=null){
			xhin = new XHourRestrictionIn();
			//�������ҿ�Ϊnull
			xhin.setFromnoin( hin.getFromNo() );
			xhin.setTonoin( hin.getToNo() );
		}
		return xhin;
	}

}
