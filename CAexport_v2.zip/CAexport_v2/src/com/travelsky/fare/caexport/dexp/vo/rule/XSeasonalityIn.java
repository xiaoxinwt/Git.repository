package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromdatein",
    "todatein"
})
@XmlRootElement(name = "SEASONALITY_IN")
public class XSeasonalityIn {
    @XmlElement(name = "FROM_DATE_IN", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date fromdatein;
    @XmlElement(name = "TO_DATE_IN", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date todatein;
	
    public Date getFromdatein() {
		return fromdatein;
	}
	public void setFromdatein(Date fromdatein) {
		this.fromdatein = fromdatein;
	}
	public Date getTodatein() {
		return todatein;
	}
	public void setTodatein(Date todatein) {
		this.todatein = todatein;
	}
}
