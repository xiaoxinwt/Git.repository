package com.travelsky.fare.caexport.dexp.vo.group;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "groups"
})
@XmlRootElement(name = "GROUPS_IMPORT")
public class XGroupImport{
    @XmlElement(name = "GROUPS")
    protected List<XGroup> groups;

    public List<XGroup> getGroups() {
		if (groups == null) {
			groups = new ArrayList<XGroup>();
		}
		return groups;
	}
	public void setGroups(List<XGroup> groups) {
		this.groups = groups;
	}
}
