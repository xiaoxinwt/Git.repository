package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRouteEntry;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRouteFlightNo;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRouteEntry;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRouteFlightNo;

public class FareRouteEntryConvertor implements IConvert<FareRouteEntry, XFareRouteEntry> {

	private IConvert<FareRouteFlightNo, XFareRouteFlightNo> flightnoconvertor = new FareRouteFlightNoConvertor();
	
	@Override
	public List<XFareRouteEntry> convert(List<FareRouteEntry> list) {
		List<XFareRouteEntry> xentrys = null;
		if(list!=null && list.size()>0){
			xentrys = new ArrayList<XFareRouteEntry>();
			for(FareRouteEntry entry : list){
				xentrys.add( convert(entry) );
			}
		}
		return xentrys;
	}

	@Override
	public XFareRouteEntry convert(FareRouteEntry entry) {
		XFareRouteEntry xentry = null;
		if( entry!=null ){
			xentry = new XFareRouteEntry();

			xentry.setEntryno( entry.getEntryNo() );
			xentry.setFromcode( entry.getFromCode() );
			xentry.setFromcodetype( entry.getFromCodeType() );
			xentry.setTocode( entry.getToCode() );
			xentry.setTocodetype( entry.getToCodeType() );
			xentry.setStopoverortransfer( entry.getStopoverOrTransfer() );
			xentry.setQchargeamt( entry.getqChargeAmt() );
			xentry.setMinstay( entry.getMinStay() );
			xentry.setMaxstay( entry.getMaxStay() );
			xentry.setFarerouteflightno( flightnoconvertor.convert(entry.getFlightNoes()) );
		}
		return xentry;
	}

}
