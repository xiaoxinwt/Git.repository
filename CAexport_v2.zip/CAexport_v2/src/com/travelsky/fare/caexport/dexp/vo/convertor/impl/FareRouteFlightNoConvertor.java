package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRouteFlightNo;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRouteFlightNo;

public class FareRouteFlightNoConvertor implements IConvert<FareRouteFlightNo, XFareRouteFlightNo> {

	@Override
	public List<XFareRouteFlightNo> convert(List<FareRouteFlightNo> list) {
		List<XFareRouteFlightNo> xflightnos = null;
		if(list!=null && list.size()>0){
			xflightnos = new ArrayList<XFareRouteFlightNo>();
			for(FareRouteFlightNo flightno : list){
				xflightnos.add( convert(flightno) );
			}
		}
		return xflightnos;
	}

	@Override
	public XFareRouteFlightNo convert(FareRouteFlightNo flightno) {
		XFareRouteFlightNo xflightno = null;
		if( flightno!=null ){
			xflightno = new XFareRouteFlightNo();

			xflightno.setFlightentryno( flightno.getFlightEntryNo() );
			xflightno.setCarriercode( flightno.getCarrierCode() );
			xflightno.setApfromno( flightno.getApFromNo() );
			xflightno.setAptono( flightno.getApToNo() );
			xflightno.setExfromno( flightno.getExFromNo() );
			xflightno.setExtono( flightno.getExToNo() );
			xflightno.setBookingclass( flightno.getBookingClass() );
			xflightno.setBookingclass2( flightno.getBookingClass2() );
			xflightno.setFarebasiscode( flightno.getFareBasisCode() );
			xflightno.setFarebasiscode2( flightno.getFareBasisCode2() );
		}
		return xflightno;
	}

}
