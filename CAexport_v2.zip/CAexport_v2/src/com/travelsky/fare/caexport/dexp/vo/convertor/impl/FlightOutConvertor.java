package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.FlightNoRestriction;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XFlightNoOut;

public class FlightOutConvertor implements IConvert<FlightNoRestriction,XFlightNoOut> {

	@Override
	public List<XFlightNoOut> convert(List<FlightNoRestriction> list) {
		List<XFlightNoOut> xfouts = null;
		if(list!=null && list.size()>0){
			xfouts = new ArrayList<XFlightNoOut>();
			for (FlightNoRestriction fout : list) {
				xfouts.add( convert(fout) );
			}
		}
		return xfouts;
	}

	@Override
	public XFlightNoOut convert(FlightNoRestriction fout) {
		XFlightNoOut xfout = null;
		if( fout!=null ){
			xfout = new XFlightNoOut();
			xfout.setFromnoout( fout.getFromNo() );
			xfout.setTonoout( fout.getToNo() );
			xfout.setNosuffixout( fout.getFlightnoSuffix() );
		}
		return xfout;
	}

}
