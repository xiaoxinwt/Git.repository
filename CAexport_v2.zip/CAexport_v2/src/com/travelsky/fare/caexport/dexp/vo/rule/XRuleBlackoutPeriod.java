package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "blackoutout",
    "blackoutin"
})
@XmlRootElement(name = "RULE_BLACKOUT_PERIOD")
public class XRuleBlackoutPeriod {
	
	@XmlElement(name = "BLACKOUT_OUT")
	protected List<XBlackoutOut> blackoutout;
	@XmlElement(name = "BLACKOUT_IN")
	protected List<XBlackoutIn> blackoutin;

	public List<XBlackoutOut> getBlackoutout() {
		if (blackoutout == null) {
			blackoutout = new ArrayList<XBlackoutOut>();
		}
		return blackoutout;
	}
	public void setBlackoutout(List<XBlackoutOut> blackoutout) {
		this.blackoutout = blackoutout;
	}
	public List<XBlackoutIn> getBlackoutin() {
		if (blackoutin == null) {
			blackoutin = new ArrayList<XBlackoutIn>();
		}
		return blackoutin;
	}
	public void setBlackoutin(List<XBlackoutIn> blackoutin) {
		this.blackoutin = blackoutin;
	}
}
