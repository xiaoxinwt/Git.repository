package com.travelsky.fare.caexport.dexp.vo.rule;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "seqid",
    "combineruleid",
    "farebasis",
    "bookingclass",
    "carriercode",
    "ischeckallsectors",
    "sectorcombinetype",
    "staytype",
    "minimumstay",
    "minimumstayunit",
    "maximumstay",
    "maximumstayunit"
})
@XmlRootElement(name = "RULE_COMBINATION")
public class XRuleCombination {
    
	@XmlElement(name = "CARRIER_CODE")
	@XmlJavaTypeAdapter(StringToTrimAdapter.class)
	protected String carriercode;
	@XmlElement(name = "SEQ_ID", required = true)
    protected BigDecimal seqid;
    @XmlElement(name = "COMBINE_RULE_ID", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String combineruleid;
    @XmlElement(name = "FARE_BASIS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String farebasis;
    @XmlElement(name = "BOOKING_CLASS", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String bookingclass;
    @XmlElement(name = "IS_CHECK_ALL_SECTORS")
    protected BigDecimal ischeckallsectors;
    @XmlElement(name = "SECTOR_COMBINE_TYPE")
    protected BigDecimal sectorcombinetype;
    @XmlElement(name = "STAY_TYPE")
    protected BigDecimal staytype;
    @XmlElement(name = "MINIMUM_STAY")
    protected BigDecimal minimumstay;
    @XmlElement(name = "MINIMUM_STAY_UNIT")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String minimumstayunit;
    @XmlElement(name = "MAXIMUM_STAY")
    protected BigDecimal maximumstay;
    @XmlElement(name = "MAXIMUM_STAY_UNIT")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String maximumstayunit;
	
    
    public BigDecimal getSeqid() {
		return seqid;
	}
	public void setSeqid(BigDecimal seqid) {
		this.seqid = seqid;
	}
	public String getCombineruleid() {
		return combineruleid;
	}
	public void setCombineruleid(String combineruleid) {
		this.combineruleid = combineruleid;
	}
	public String getFarebasis() {
		return farebasis;
	}
	public void setFarebasis(String farebasis) {
		this.farebasis = farebasis;
	}
	public String getBookingclass() {
		return bookingclass;
	}
	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}
	public String getCarriercode() {
		return carriercode;
	}
	public void setCarriercode(String carriercode) {
		this.carriercode = carriercode;
	}
	public BigDecimal getIscheckallsectors() {
		return ischeckallsectors;
	}
	public void setIscheckallsectors(BigDecimal ischeckallsectors) {
		this.ischeckallsectors = ischeckallsectors;
	}
	public BigDecimal getSectorcombinetype() {
		return sectorcombinetype;
	}
	public void setSectorcombinetype(BigDecimal sectorcombinetype) {
		this.sectorcombinetype = sectorcombinetype;
	}
	public BigDecimal getStaytype() {
		return staytype;
	}
	public void setStaytype(BigDecimal staytype) {
		this.staytype = staytype;
	}
	public BigDecimal getMinimumstay() {
		return minimumstay;
	}
	public void setMinimumstay(BigDecimal minimumstay) {
		this.minimumstay = minimumstay;
	}
	public String getMinimumstayunit() {
		return minimumstayunit;
	}
	public void setMinimumstayunit(String minimumstayunit) {
		this.minimumstayunit = minimumstayunit;
	}
	public BigDecimal getMaximumstay() {
		return maximumstay;
	}
	public void setMaximumstay(BigDecimal maximumstay) {
		this.maximumstay = maximumstay;
	}
	public String getMaximumstayunit() {
		return maximumstayunit;
	}
	public void setMaximumstayunit(String maximumstayunit) {
		this.maximumstayunit = maximumstayunit;
	}
}
