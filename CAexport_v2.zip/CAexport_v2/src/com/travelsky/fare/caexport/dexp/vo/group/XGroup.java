package com.travelsky.fare.caexport.dexp.vo.group;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "carrCode","locationCode",
    "groupid",
    "groupdesc",
    "agent"
})
@XmlRootElement(name = "GROUPS")
public class XGroup {

    @XmlElement(name = "Action_Code", required = true)
    protected String actionCode;
    @XmlElement(name = "CARR_CODE", required = true)
    private String carrCode;
    @XmlElement(name = "LOCATION_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    private String locationCode;
    @XmlElement(name = "GROUP_ID", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String groupid;
    @XmlElement(name = "GROUP_DESC", required = true, nillable = true)
    protected String groupdesc;
    @XmlElement(name = "AGENT", required = true)
    protected List<XAgent> agent;
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getGroupid() {
		return groupid;
	}
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	public String getGroupdesc() {
		return groupdesc;
	}
	public void setGroupdesc(String groupdesc) {
		this.groupdesc = groupdesc;
	}
	public List<XAgent> getAgent() {
		if (agent == null) {
			agent = new ArrayList<XAgent>();
		}
		return agent;
	}
	public void setAgent(List<XAgent> agent) {
		this.agent = agent;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
}
