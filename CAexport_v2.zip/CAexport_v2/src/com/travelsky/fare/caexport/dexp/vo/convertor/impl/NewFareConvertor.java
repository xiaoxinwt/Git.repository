package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.travelsky.fare.caexport.db.model.airtis_fare.NewFare;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRule;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.IFareConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XFare;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRule;
import com.travelsky.fare.caexport.util.Const;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.FareUtil;
import com.travelsky.fare.caexport.util.StringUtil;

/**
 * ��List<NewPSFare> תΪ List<XFare>
 * �Ƚ� List<NewPSFare> תΪ List<Fare>
 * Airtis���������͵�locationCode����"PUB"
 * @author xiaoxinwt
 */
public class NewFareConvertor implements IConvert<NewFare,XFare>,IFareConvert<NewFare,XFare>{
	
	private IConvert<FareRule, XFareRule> fruleconvertor = new FareRuleConvertor();

	@Override
	public Map<RefPK,List<XFare>> convertToMapByPK(List<NewFare> list, String carrier) {
		Map<RefPK,List<XFare>> fmap = new HashMap<RefPK,List<XFare>>();
		if(list==null || list.size()==0) return fmap;

		XFare xfare = null;
		RefPK pk = null;
		//Airtis���������͵�locationCode����"PUB"
		for (NewFare nfare : list) {
			pk = new RefPK(carrier, Const.AIRTIS_LOCATION_CODE, nfare.getRefNo());
			if( !fmap.containsKey( pk ) ){
				fmap.put( pk, new ArrayList<XFare>() );
			}else{
				xfare = convert(nfare);
				fmap.get( pk ).add( xfare );
			}
		}
		return fmap;
	}

	
	public List<XFare> convert( List<NewFare> nfarelist){
		List<XFare> xfarelist = null;
		if( nfarelist!=null && nfarelist.size()>0){
			xfarelist = new ArrayList<XFare>();
			for ( NewFare nfare : nfarelist) {
				xfarelist.add( convert(nfare) );
			}
		}
		return xfarelist;
	}

	public XFare convert( NewFare nfare ){
		XFare xfare = null;
		if( nfare!=null ){
			
			if( StringUtil.isNullOrEmpty(nfare.getRefNo()) ) return null;
			xfare = new XFare();
			xfare.setFareRecNo( String.valueOf(nfare.getFareRecNo()) );
			
			xfare.setActionCode( nfare.getActiontype().code );
			xfare.setPnFareNo( String.valueOf(nfare.getPnFareNo()) );
			xfare.setPnRptFileNo( nfare.getPnRptFileNo() );
			
			String destCityCode = nfare.getDest().getDestCityCode();
			if(StringUtil.isNullOrEmpty(destCityCode) || destCityCode.trim().equalsIgnoreCase("null")){
				destCityCode = null;
			}
			xfare.setDestcitycode( destCityCode );

			String oriCityCode = nfare.getOri().getOriCityCode();
			if(StringUtil.isNullOrEmpty(oriCityCode) || oriCityCode.trim().equalsIgnoreCase("null")){
				oriCityCode = null;
			}
			xfare.setOricitycode( oriCityCode );
			
			xfare.setDestcode( nfare.getDest().getDestCode() );
			xfare.setDestcodetype( nfare.getDest().getDestCodeType() );
			xfare.setOricode( nfare.getOri().getOriCode());
			xfare.setOricodetype( nfare.getOri().getOriCodeType() );
			
			xfare.setFarebasis( nfare.getFareBasis() );
			xfare.setBookingclass( nfare.getClsCode() );
			xfare.setFaretype( nfare.getFareType() );


			//����ֵ
//			xfare.setAmount( FareUtil.getAmount(nfare) );
			xfare.setAmount( nfare.getMoney().getValue() );
			
			xfare.setClassofservice( nfare.getServiceClass() );
			xfare.setFirstticketeddate( nfare.getFirstSaleDate() );
			xfare.setFirsttraveldate( nfare.getEffDate() );
			xfare.setDiscountcode( nfare.getFareType() );
			xfare.setEffectivedate( nfare.getFirstSaleDate() );
			xfare.setJourneytype( FareUtil.getJourneyType( nfare ) );
			xfare.setRuleid( FareUtil.getRuleId(nfare) );
			
			//Ĭ��ֵ
			xfare.setGlobaldirection( "EH" );
			xfare.setInboundpermitted( new Integer("1") );
			xfare.setInfantdiscountamount( new BigDecimal(-2.000) );
			xfare.setChilddiscountamount( new BigDecimal(-2.000) );
			xfare.setTickettype( new Integer("0") );
			xfare.setDiscontinuedate( DateUtil.endDate( nfare.getLastSaleDate(),DateUtil.parseDate("22220101") ) );
			xfare.setLastticketeddate( DateUtil.endDate( nfare.getLastSaleDate(),DateUtil.parseDate("22220101") ) );
			xfare.setLasttraveldate( DateUtil.endDate(nfare.getDiscDate(),DateUtil.parseDate("22220101") ) );
			xfare.setOutboundpermitted( new Integer("1") );
			xfare.setTravelcompletedate( DateUtil.parseDate("22220101") );
			xfare.setUnit( new Integer("0") );
			xfare.setStopoverFlag( null );
			
			
			//û��ֵ��֮���Ӧ
//			xfare.setAddtcommissionamt( nfare );
//			xfare.setAddtcommissionpct( nfare );
//			xfare.setBasecommissionamt( nfare );
//			xfare.setBasecommissionpct( nfare );
//
//			xfare.setAdultrsfamt( nfare );
//			xfare.setBaggageallowance( nfare );
//			xfare.setBookingclass2( nfare );
//			xfare.setChildbaggageallowance( nfare );
//			xfare.setChildpublishedfbc( nfare );
//			xfare.setChildrsfamt( nfare );
//			xfare.setChildtourcode( nfare );
//			xfare.setChildvaluecode( nfare );	//fare���У�nfare��û��
//			xfare.setEndorsementrestriction( nfare );
//			xfare.setInfantbaggageallowance( nfare );
//			xfare.setInfantpublishedfbc( nfare );
//			xfare.setInfantrsfamt( nfare );
//			xfare.setInfanttourcode( nfare );
//			xfare.setInfantvaluecode( nfare );
//			xfare.setPublishedfarebasiscode( nfare );
//			xfare.setStopoverFlag( nfare );
//			xfare.setTourcode( nfare );
//			xfare.setValuecode( nfare );
			
			//�б�
			//Airtis��Fare��û��FareRoute,����XML�й涨����FareRoute���֣������ӽڵ�Route_No��Fare_Route_Entry������֣����ԣ��˴�����FareRoute��
//			xfare.setFareroute( frouteconvertor.convert( nfare.getRoutes() ) );
			xfare.setFareroute( null );
			
			List<XFareRule> xlist = fruleconvertor.convert( nfare.getRules() );
			xfare.setFarerule( (xlist!=null && xlist.size()>0)?xlist.get(0):new XFareRule() );

/*			//�̶�ֵ
			fare.setLocationCode("PUB");
			fare.getUpdate().setWhoLastUpdate("1E");
			fare.getUpdate().setWhereLastUpdate("PUB");
			
			//Ĭ��ֵ
			fare.setCategory( Integer.valueOf("1") );
			fare.getInfant().setInfantDiscountPercent( new Integer("0") );
			fare.getInfant().setInfantAbsoluteAmtEntered( new Integer("1") );
			fare.getChild().setChildDiscountPercent( new Integer("0") );
			fare.getChild().setChildAbsoluteAmtEntered( new Integer("1") );
//			fare.getFree().setFreeStopoverOutbound( new Integer("0") );
//			fare.getFree().setFreeStopoverInbound( new Integer("0") );
//			fare.getFree().setFreeStopoverTotal( new Integer("0") );
			fare.getCharge().setChargeableStopoverOutbound( new Integer("0") );
			fare.getCharge().setChargeableStopoverInbound( new Integer("0") );
			fare.getCharge().setChargeableStopoverTotal( new Integer("0") );
			fare.setStopoverLastnum( new Integer("0") );
			fare.setIsCombinedFare( new Integer("0") );
			fare.getBound().setOutboundPermitted( new Integer("1") );
			fare.getBound().setInboundPermitted( new Integer("1") );
			fare.setThruFare( new Integer("0") );
//			fare.setModifiedFlag( new Integer("0") );
			fare.setRouteLastnum( new Integer("0") );*/
		}
		return xfare;
	}

}
