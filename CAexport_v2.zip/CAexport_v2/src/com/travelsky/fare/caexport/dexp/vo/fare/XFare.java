package com.travelsky.fare.caexport.dexp.vo.fare;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;
import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "fareRecNo",
    "pnRptFileNo","pnFareNo",
    "oricodetype",
    "oricode",
    "oricitycode",
    "destcodetype",
    "destcode",
    "destcitycode",
    "journeytype",
    "farebasis",
    "bookingclass",
    "globaldirection",
    "amount",
    "valuecode",
    "effectivedate",
    "discontinuedate",
    "firsttraveldate",
    "lasttraveldate",
    "firstticketeddate",
    "lastticketeddate",
    "ruleid",
    "infantdiscountamount",
    "childdiscountamount",
    "faretype",
    "stopoverFlag",
    "bookingclass2",
    "childvaluecode",
    "infantvaluecode",
    "classofservice",
    "tourcode",
    "childtourcode",
    "infanttourcode",
    "endorsementrestriction",
    "publishedfarebasiscode",
    "outboundpermitted",
    "inboundpermitted",
    "adultrsfamt",
    "childrsfamt",
    "infantrsfamt",
    "discountcode",
    "childpublishedfbc",
    "infantpublishedfbc",
    "travelcompletedate",
    "baggageallowance",
    "childbaggageallowance",
    "infantbaggageallowance",
    "unit",
    "basecommissionamt",
    "basecommissionpct",
    "addtcommissionamt",
    "addtcommissionpct",
    "tickettype",
    "fareroute",
    "farerule"
})
@XmlRootElement(name = "FARE")
public class XFare {
    @XmlElement(name = "Action_Code", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String actionCode;
    @XmlElement(name = "FARE_REC_NO", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String fareRecNo;
    
    @XmlElement(name = "PN_RPT_FILE_NO", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String pnRptFileNo;	//len : 30
    @XmlElement(name = "PN_FARE_NO", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String pnFareNo;		//len : 10
    
    @XmlElement(name = "ORI_CODE_TYPE", required = true)
    protected Integer oricodetype;
    @XmlElement(name = "ORI_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String oricode;
    @XmlElement(name = "ORI_CITY_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String oricitycode;
    @XmlElement(name = "DEST_CODE_TYPE", required = true)
    protected Integer destcodetype;
    @XmlElement(name = "DEST_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String destcode;
    @XmlElement(name = "DEST_CITY_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String destcitycode;
    @XmlElement(name = "JOURNEY_TYPE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String journeytype;		//[OR|OW|RT]
    @XmlElement(name = "FARE_BASIS", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String farebasis;
    @XmlElement(name = "BOOKING_CLASS", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String bookingclass;
    @XmlElement(name = "GLOBAL_DIRECTION", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String globaldirection;
    @XmlElement(name = "AMOUNT", required = true, nillable = true)
    protected BigDecimal amount;
    @XmlElement(name = "VALUE_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String valuecode;
    @XmlElement(name = "EFFECTIVE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date effectivedate;
    @XmlElement(name = "DISCONTINUE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date discontinuedate;
    @XmlElement(name = "FIRST_TRAVEL_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date firsttraveldate;
    @XmlElement(name = "LAST_TRAVEL_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date lasttraveldate;
    @XmlElement(name = "FIRST_TICKETED_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date firstticketeddate;
    @XmlElement(name = "LAST_TICKETED_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date lastticketeddate;
    @XmlElement(name = "RULE_ID", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String ruleid;
    @XmlElement(name = "INFANT_DISCOUNT_AMOUNT", required = true, nillable = true)
    protected BigDecimal infantdiscountamount;
    @XmlElement(name = "CHILD_DISCOUNT_AMOUNT", required = true, nillable = true)
    protected BigDecimal childdiscountamount;
    @XmlElement(name = "FARE_TYPE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String faretype;
    @XmlElement(name = "STOPOVER_FLAG", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String stopoverFlag;
    @XmlElement(name = "BOOKING_CLASS_2", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String bookingclass2;
    @XmlElement(name = "CHILD_VALUE_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String childvaluecode;
    @XmlElement(name = "INFANT_VALUE_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String infantvaluecode;
    @XmlElement(name = "CLASS_OF_SERVICE", required = true)
    protected Integer classofservice;
    @XmlElement(name = "TOUR_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String tourcode;
    @XmlElement(name = "CHILD_TOUR_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String childtourcode;
    @XmlElement(name = "INFANT_TOUR_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String infanttourcode;
    @XmlElement(name = "ENDORSEMENT_RESTRICTION", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String endorsementrestriction;
    @XmlElement(name = "PUBLISHED_FARE_BASIS_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String publishedfarebasiscode;
    @XmlElement(name = "OUTBOUND_PERMITTED", required = true)
    protected Integer outboundpermitted;
    @XmlElement(name = "INBOUND_PERMITTED", required = true)
    protected Integer inboundpermitted;
    @XmlElement(name = "ADULT_RSF_AMT", required = true, nillable = true)
    protected Integer adultrsfamt;
    @XmlElement(name = "CHILD_RSF_AMT", required = true, nillable = true)
    protected Integer childrsfamt;
    @XmlElement(name = "INFANT_RSF_AMT", required = true, nillable = true)
    protected Integer infantrsfamt;
    @XmlElement(name = "DISCOUNT_CODE", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String discountcode;
    @XmlElement(name = "CHILD_PUBLISHED_FBC", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String childpublishedfbc;
    @XmlElement(name = "INFANT_PUBLISHED_FBC", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String infantpublishedfbc;
    @XmlElement(name = "TRAVEL_COMPLETE_DATE", required = true, nillable = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date travelcompletedate;
    @XmlElement(name = "BAGGAGE_ALLOWANCE", required = true, nillable = true)
    protected Integer baggageallowance;
    @XmlElement(name = "CHILD_BAGGAGE_ALLOWANCE", required = true, nillable = true)
    protected Integer childbaggageallowance;
    @XmlElement(name = "INFANT_BAGGAGE_ALLOWANCE", required = true, nillable = true)
    protected Integer infantbaggageallowance;
    @XmlElement(name = "UNIT", required = true, nillable = true)
    protected Integer unit;
    @XmlElement(name = "BASE_COMMISSION_AMT", required = true, nillable = true)
    protected Integer basecommissionamt;
    @XmlElement(name = "BASE_COMMISSION_PCT", required = true, nillable = true)
    protected Integer basecommissionpct;
    @XmlElement(name = "ADDT_COMMISSION_AMT", required = true, nillable = true)
    protected Integer addtcommissionamt;
    @XmlElement(name = "ADDT_COMMISSION_PCT", required = true, nillable = true)
    protected Integer addtcommissionpct;
    @XmlElement(name = "TICKET_TYPE", required = true)
    protected Integer tickettype;
    @XmlElement(name = "FARE_ROUTE")
    protected List<XFareRoute> fareroute;
    @XmlElement(name = "FARE_RULE", required = true)
    protected XFareRule farerule = new XFareRule();
	
    public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(String fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public String getPnRptFileNo() {
		return pnRptFileNo;
	}
	public void setPnRptFileNo(String pnRptFileNo) {
		this.pnRptFileNo = pnRptFileNo;
	}
	public String getPnFareNo() {
		return pnFareNo;
	}
	public void setPnFareNo(String pnFareNo) {
		this.pnFareNo = pnFareNo;
	}
	public Integer getOricodetype() {
		return oricodetype;
	}
	public void setOricodetype(Integer oricodetype) {
		this.oricodetype = oricodetype;
	}
	public String getOricode() {
		return oricode;
	}
	public void setOricode(String oricode) {
		this.oricode = oricode;
	}
	public String getOricitycode() {
		return oricitycode;
	}
	public void setOricitycode(String oricitycode) {
		this.oricitycode = oricitycode;
	}
	public Integer getDestcodetype() {
		return destcodetype;
	}
	public void setDestcodetype(Integer destcodetype) {
		this.destcodetype = destcodetype;
	}
	public String getDestcode() {
		return destcode;
	}
	public void setDestcode(String destcode) {
		this.destcode = destcode;
	}
	public String getDestcitycode() {
		return destcitycode;
	}
	public void setDestcitycode(String destcitycode) {
		this.destcitycode = destcitycode;
	}
	public String getJourneytype() {
		return journeytype;
	}
	public void setJourneytype(String journeytype) {
		this.journeytype = journeytype;
	}
	public String getFarebasis() {
		return farebasis;
	}
	public void setFarebasis(String farebasis) {
		this.farebasis = farebasis;
	}
	public String getBookingclass() {
		return bookingclass;
	}
	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}
	public String getGlobaldirection() {
		return globaldirection;
	}
	public void setGlobaldirection(String globaldirection) {
		this.globaldirection = globaldirection;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getValuecode() {
		return valuecode;
	}
	public void setValuecode(String valuecode) {
		this.valuecode = valuecode;
	}
	public Date getEffectivedate() {
		return effectivedate;
	}
	public void setEffectivedate(Date effectivedate) {
		this.effectivedate = effectivedate;
	}
	public Date getDiscontinuedate() {
		return discontinuedate;
	}
	public void setDiscontinuedate(Date discontinuedate) {
		this.discontinuedate = discontinuedate;
	}
	public Date getFirsttraveldate() {
		return firsttraveldate;
	}
	public void setFirsttraveldate(Date firsttraveldate) {
		this.firsttraveldate = firsttraveldate;
	}
	public Date getLasttraveldate() {
		return lasttraveldate;
	}
	public void setLasttraveldate(Date lasttraveldate) {
		this.lasttraveldate = lasttraveldate;
	}
	public Date getFirstticketeddate() {
		return firstticketeddate;
	}
	public void setFirstticketeddate(Date firstticketeddate) {
		this.firstticketeddate = firstticketeddate;
	}
	public Date getLastticketeddate() {
		return lastticketeddate;
	}
	public void setLastticketeddate(Date lastticketeddate) {
		this.lastticketeddate = lastticketeddate;
	}
	public String getRuleid() {
		return ruleid;
	}
	public void setRuleid(String ruleid) {
		this.ruleid = ruleid;
	}
	public BigDecimal getInfantdiscountamount() {
		return infantdiscountamount;
	}
	public void setInfantdiscountamount(BigDecimal infantdiscountamount) {
		this.infantdiscountamount = infantdiscountamount;
	}
	public BigDecimal getChilddiscountamount() {
		return childdiscountamount;
	}
	public void setChilddiscountamount(BigDecimal childdiscountamount) {
		this.childdiscountamount = childdiscountamount;
	}
	public String getFaretype() {
		return faretype;
	}
	public void setFaretype(String faretype) {
		this.faretype = faretype;
	}
	public String getStopoverFlag() {
		return stopoverFlag;
	}
	public void setStopoverFlag(String stopoverFlag) {
		this.stopoverFlag = stopoverFlag;
	}
	public String getBookingclass2() {
		return bookingclass2;
	}
	public void setBookingclass2(String bookingclass2) {
		this.bookingclass2 = bookingclass2;
	}
	public String getChildvaluecode() {
		return childvaluecode;
	}
	public void setChildvaluecode(String childvaluecode) {
		this.childvaluecode = childvaluecode;
	}
	public String getInfantvaluecode() {
		return infantvaluecode;
	}
	public void setInfantvaluecode(String infantvaluecode) {
		this.infantvaluecode = infantvaluecode;
	}
	public Integer getClassofservice() {
		return classofservice;
	}
	public void setClassofservice(Integer classofservice) {
		this.classofservice = classofservice;
	}
	public String getTourcode() {
		return tourcode;
	}
	public void setTourcode(String tourcode) {
		this.tourcode = tourcode;
	}
	public String getChildtourcode() {
		return childtourcode;
	}
	public void setChildtourcode(String childtourcode) {
		this.childtourcode = childtourcode;
	}
	public String getInfanttourcode() {
		return infanttourcode;
	}
	public void setInfanttourcode(String infanttourcode) {
		this.infanttourcode = infanttourcode;
	}
	public String getEndorsementrestriction() {
		return endorsementrestriction;
	}
	public void setEndorsementrestriction(String endorsementrestriction) {
		this.endorsementrestriction = endorsementrestriction;
	}
	public String getPublishedfarebasiscode() {
		return publishedfarebasiscode;
	}
	public void setPublishedfarebasiscode(String publishedfarebasiscode) {
		this.publishedfarebasiscode = publishedfarebasiscode;
	}
	public Integer getOutboundpermitted() {
		return outboundpermitted;
	}
	public void setOutboundpermitted(Integer outboundpermitted) {
		this.outboundpermitted = outboundpermitted;
	}
	public Integer getInboundpermitted() {
		return inboundpermitted;
	}
	public void setInboundpermitted(Integer inboundpermitted) {
		this.inboundpermitted = inboundpermitted;
	}
	public Integer getAdultrsfamt() {
		return adultrsfamt;
	}
	public void setAdultrsfamt(Integer adultrsfamt) {
		this.adultrsfamt = adultrsfamt;
	}
	public Integer getChildrsfamt() {
		return childrsfamt;
	}
	public void setChildrsfamt(Integer childrsfamt) {
		this.childrsfamt = childrsfamt;
	}
	public Integer getInfantrsfamt() {
		return infantrsfamt;
	}
	public void setInfantrsfamt(Integer infantrsfamt) {
		this.infantrsfamt = infantrsfamt;
	}
	public String getDiscountcode() {
		return discountcode;
	}
	public void setDiscountcode(String discountcode) {
		this.discountcode = discountcode;
	}
	public String getChildpublishedfbc() {
		return childpublishedfbc;
	}
	public void setChildpublishedfbc(String childpublishedfbc) {
		this.childpublishedfbc = childpublishedfbc;
	}
	public String getInfantpublishedfbc() {
		return infantpublishedfbc;
	}
	public void setInfantpublishedfbc(String infantpublishedfbc) {
		this.infantpublishedfbc = infantpublishedfbc;
	}
	public Date getTravelcompletedate() {
		return travelcompletedate;
	}
	public void setTravelcompletedate(Date travelcompletedate) {
		this.travelcompletedate = travelcompletedate;
	}
	public Integer getBaggageallowance() {
		return baggageallowance;
	}
	public void setBaggageallowance(Integer baggageallowance) {
		this.baggageallowance = baggageallowance;
	}
	public Integer getChildbaggageallowance() {
		return childbaggageallowance;
	}
	public void setChildbaggageallowance(Integer childbaggageallowance) {
		this.childbaggageallowance = childbaggageallowance;
	}
	public Integer getInfantbaggageallowance() {
		return infantbaggageallowance;
	}
	public void setInfantbaggageallowance(Integer infantbaggageallowance) {
		this.infantbaggageallowance = infantbaggageallowance;
	}
	public Integer getUnit() {
		return unit;
	}
	public void setUnit(Integer unit) {
		this.unit = unit;
	}
	public Integer getBasecommissionamt() {
		return basecommissionamt;
	}
	public void setBasecommissionamt(Integer basecommissionamt) {
		this.basecommissionamt = basecommissionamt;
	}
	public Integer getBasecommissionpct() {
		return basecommissionpct;
	}
	public void setBasecommissionpct(Integer basecommissionpct) {
		this.basecommissionpct = basecommissionpct;
	}
	public Integer getAddtcommissionamt() {
		return addtcommissionamt;
	}
	public void setAddtcommissionamt(Integer addtcommissionamt) {
		this.addtcommissionamt = addtcommissionamt;
	}
	public Integer getAddtcommissionpct() {
		return addtcommissionpct;
	}
	public void setAddtcommissionpct(Integer addtcommissionpct) {
		this.addtcommissionpct = addtcommissionpct;
	}
	public Integer getTickettype() {
		return tickettype;
	}
	public void setTickettype(Integer tickettype) {
		this.tickettype = tickettype;
	}
	public List<XFareRoute> getFareroute() {
		if(fareroute==null) fareroute=new ArrayList<XFareRoute>();
		return fareroute;
	}
	public void setFareroute(List<XFareRoute> fareroute) {
		this.fareroute = fareroute;
	}
	public XFareRule getFarerule() {
		return farerule;
	}
	public void setFarerule(XFareRule farerule) {
		this.farerule = farerule;
	}
}
