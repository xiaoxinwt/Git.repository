package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.common.refund.RefundEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefundEntry;
import com.travelsky.fare.caexport.util.StringUtil;

public class RefundEntryConvertor implements IConvert<RefundEntry, XRefundEntry> {

	@Override
	public List<XRefundEntry> convert(List<RefundEntry> list) {
		List<XRefundEntry> xentrys = null;
		if( list!=null && list.size()>0){
			xentrys = new ArrayList<XRefundEntry>();
			for (RefundEntry ent : list) {
				xentrys.add( convert(ent) );
			}
		}
		return xentrys;
	}

	@Override
	public XRefundEntry convert(RefundEntry ent) {
		XRefundEntry xent = null;
		if(ent!=null){
			xent = new XRefundEntry();
			xent.setBookingClass( ent.getBookingClass() );
			xent.setCalBookingClass( ent.getCal().getCalBookingClass() );
			xent.setCalUnusedPfarePercent( ent.getCal().getCalUnusedPfarePercent() );
			xent.setCalUsedSectorType( ent.getCal().getCalUsedSectorType() );
			xent.setFareBasis( ent.getFareBasis() );
			xent.setFirstDepartrueTime( ent.getDepart().getFirstDepartrueTime() );
			xent.setFirstTicketedTime( ent.getTicket().getFirstTicketedTime() );
			xent.setFixedAmount( ent.getAmount().getFixedAmount() );
			xent.setJourneyType( ent.getJourneyType() );
			xent.setLastDepartrueTime( ent.getDepart().getLastDepartrueTime() );
			xent.setLastTicketedTime( ent.getTicket().getLastTicketedTime() );
			xent.setLowerValue( ent.getLowup().getLowerValue() );
			xent.setMinAmount( ent.getAmount().getMinimumAmount() );
			xent.setPassengerType( ent.getPassengerType() );
			xent.setPercent( ent.getPercent() );
			xent.setRefundAllowedTag( ent.getRefundAllowedTag() );
			xent.setRefundId( ent.getRefundRuleId() );
			xent.setRefundYqtaxAllowed( ent.getRefundYqtaxAllowed() );
			xent.setSeqId( ent.getSeqId() );
			xent.setSpecRbd( ent.getSpecRbd() );
			xent.setUpperValue( ent.getLowup().getUpperValue() );
			
			//����
			xent.setTicketUseType( ent.getTicket().getTicketUseType()!=null? ent.getTicket().getTicketUseType() :0 );
			xent.setLowerRelate( FundHandler.getLowerUpperRelate( ent.getLowup().getLowerRelate() ) );
			xent.setUpperRelate( FundHandler.getLowerUpperRelate( ent.getLowup().getUpperRelate() ) );
			xent.setTicketedTimeUnit( StringUtil.isNullOrEmpty( ent.getTicket().getTicketedTimeUnit() )? "" :ent.getTicket().getTicketedTimeUnit() );
			xent.setDepartrueTimeType( ent.getDepart().getDepartrueTimeType()!=null? ent.getDepart().getDepartrueTimeType() :0 );
			xent.setDepartrueTimeUnit( StringUtil.isNullOrEmpty( ent.getDepart().getDepartrueTimeUnit() )?"": ent.getDepart().getDepartrueTimeUnit() );
			xent.setCalUnusedSectorType( ent.getCal().getCalUnusedSectorType()!=null? ent.getCal().getCalUnusedSectorType() :0 );
			xent.setTaxRefundType( ent.getTaxRefundType()!=null? ent.getTaxRefundType() :0 );
			
		}
		return xent;
	}

}
