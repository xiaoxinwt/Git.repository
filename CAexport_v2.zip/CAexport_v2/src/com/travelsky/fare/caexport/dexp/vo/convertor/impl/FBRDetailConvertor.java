package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBRBasefare;
import com.travelsky.fare.caexport.db.model.common.fbr.FBRDetail;
import com.travelsky.fare.caexport.db.model.common.fbr.FBRDtlExroute;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fbr.XBaseFare;
import com.travelsky.fare.caexport.dexp.vo.fbr.XExceptRoute;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRuleDetail;
import com.travelsky.fare.caexport.util.DateUtil;

public class FBRDetailConvertor implements IConvert<FBRDetail, XFareByRuleDetail> {
	
	private IConvert<FBRBasefare, XBaseFare> fbrbfareconvertor = new FBRBaseFareConvertor();
	private IConvert<FBRDtlExroute, XExceptRoute> fbrexrouteconvertor = new FBRExRouteConvertor();

	@Override
	public List<XFareByRuleDetail> convert(List<FBRDetail> list) {
		List<XFareByRuleDetail> xfbrds = null;
		if(list!=null && list.size()>0){
			xfbrds = new ArrayList<XFareByRuleDetail>();
			for(FBRDetail fbrd : list){
				xfbrds.add( convert(fbrd) );
			}
		}
		return xfbrds;
	}

	@Override
	public XFareByRuleDetail convert(FBRDetail fbrd) {
		XFareByRuleDetail xfbrd = null;
		if( fbrd!=null ){
			xfbrd = new XFareByRuleDetail();
			
			//�����Ҳ�Ϊnull
//			xfbrd.setActioncode(  );//��impt�л�Ϊ�����ֵ
			xfbrd.setFbrdtlprior( fbrd.getFbrDtlPrior()!=null?fbrd.getFbrDtlPrior():0 );
			xfbrd.setSaleeffdate( fbrd.getSaleEffDate()!=null?fbrd.getSaleEffDate():DateUtil.getDate("9999-12-31") );
			xfbrd.setSalediscdate( fbrd.getSaleDiscDate()!=null?fbrd.getSaleDiscDate():DateUtil.getDate("9999-12-31") );
			xfbrd.setFirsttraveldate( fbrd.getFirstTravelDate()!=null?fbrd.getFirstTravelDate():DateUtil.getDate("9999-12-31") );
			xfbrd.setLasttraveldate( fbrd.getLastTravelDate()!=null?fbrd.getLastTravelDate():DateUtil.getDate("9999-12-31") );
			xfbrd.setDistributionstatus( fbrd.getDistributionStatus()!=null?fbrd.getDistributionStatus():0 );
			xfbrd.setOricodetype( fbrd.getOriCodeType()!=null?fbrd.getOriCodeType():0 );
			xfbrd.setOricode( fbrd.getOriCode()!=null?fbrd.getOriCode():"" );
			xfbrd.setDestcodetype( fbrd.getDestCodeType()!=null?fbrd.getDestCodeType():0 );
			xfbrd.setDestcode( fbrd.getDestCode()!=null?fbrd.getDestCode():"" );
			xfbrd.setJourneytype( fbrd.getJourneyType()!=null?fbrd.getJourneyType():"" );
			xfbrd.setIfonlydirectfare( fbrd.getIfOnlyDirectFare()!=null?fbrd.getIfOnlyDirectFare():0 );
			xfbrd.setBasefaretype( fbrd.getBasefareType()!=null?fbrd.getBasefareType():0 );
			xfbrd.setRstfcaculatetype( fbrd.getRstfCaculateType()!=null?fbrd.getRstfCaculateType():0 );
			xfbrd.setPricechoose( fbrd.getPriceChoose()!=null?fbrd.getPriceChoose():0 );
			xfbrd.setRoundrule( fbrd.getRoundRule()!=null?fbrd.getRoundRule():0 );
			xfbrd.setRstfdisplayifsamebasefare( fbrd.getRstfDisplayIfSameBasefare()!=null?fbrd.getRstfDisplayIfSameBasefare():0 );
			xfbrd.setIfsamebasefarerule( fbrd.getIfSameBasefareRule()!=null?fbrd.getIfSameBasefareRule():0 );
			xfbrd.setIfuseotherrulerestriction( fbrd.getIfUseOtherRuleRestriction()!=null?fbrd.getIfUseOtherRuleRestriction():0 );
			
			XFareByRuleDetail.RULERESTRICTION.MINIMUM xmin = new XFareByRuleDetail.RULERESTRICTION.MINIMUM();
			xmin.setMinimumstay( fbrd.getMinimumStay()!=null?fbrd.getMinimumStay():0 );
			String minunit = "";
			if( fbrd.getMinimumStayUnit()!=null ){
				minunit = fbrd.getMinimumStayUnit().toUpperCase();
				if( !minunit.endsWith("S") ){
					minunit += "S";
				}
			}
			xmin.setMinimumstayunit( minunit );

			XFareByRuleDetail.RULERESTRICTION.MAXIMUM xmax = new XFareByRuleDetail.RULERESTRICTION.MAXIMUM();
			xmax.setMaximumstay( fbrd.getMaximumStay()!=null?fbrd.getMaximumStay():0 );
			String maxunit = "";
			if( fbrd.getMaximumStayUnit()!=null ){
				maxunit = fbrd.getMaximumStayUnit().toUpperCase();
				if( !maxunit.endsWith("S") ){
					maxunit+="S";
				}
			}
			xmax.setMaximumstayunit( maxunit );

			XFareByRuleDetail.RULERESTRICTION xrestrict = new XFareByRuleDetail.RULERESTRICTION();
			xrestrict.setOutboundpermitted( fbrd.getOutboundPermitted()!=null?fbrd.getOutboundPermitted():0 );
			xrestrict.setInboundpermitted( fbrd.getInboundPermitted()!=null?fbrd.getInboundPermitted():0 );
			xrestrict.setMinimum( xmin );
			xrestrict.setMaximum( xmax );
			xfbrd.setRulerestriction( xrestrict );
			
			List<XBaseFare> basefarelist = fbrbfareconvertor.convert(fbrd.getBasefares() );
			if( basefarelist ==null || basefarelist.size()==0 ){
				basefarelist = new ArrayList<XBaseFare>();
				XBaseFare xbasefare = new XBaseFare();
				xbasefare.setOricode("");
				xbasefare.setOricodetype(0);
				xbasefare.setDestcode("");
				xbasefare.setDestcodetype(0);
				xbasefare.setJourneytype("");
				xbasefare.setBookingclass( null );
				xbasefare.setFarebasis( null );
				basefarelist.add( xbasefare );
			}
			xfbrd.setBasefare( basefarelist );
			
			//�����ҿ�Ϊnull
			xfbrd.setBookingclass( fbrd.getBookingClass() );
			xfbrd.setAccountcode( fbrd.getAccountCode() );
			xfbrd.setDiscountcode( fbrd.getDiscountCode() );
			xfbrd.setRstfpercent( fbrd.getRstfPercent() );
			xfbrd.setRstfamt( fbrd.getRstfAmt() );
			
			//�Ǳ����ҿ�Ϊnull
			xfbrd.setFbrdtlid( fbrd.getFareByRuleDtlId() );
			xfbrd.setRemark( fbrd.getRemark() );
			xfbrd.setSubclassflag( fbrd.getSubClassFlag() );
			xfbrd.setRstfthresholdcaltype( fbrd.getRstfThresholdCalType()!=null? String.valueOf(fbrd.getRstfThresholdCalType()) : null );
			xfbrd.setRstfthresholdcalpercent( fbrd.getRstfThresholdCalPercent() );
			xfbrd.setRuleno( fbrd.getRuleNo() );
			xfbrd.setIfsamebasefaregroup( fbrd.getIfSameBasefareGroup() );

			XFareByRuleDetail.RSTFDISPLAY xdisplay = new XFareByRuleDetail.RSTFDISPLAY();
			//�����Ҳ���Ϊnull
			xdisplay.setBaggageunit( fbrd.getBaggageUnit()!=null?fbrd.getBaggageUnit():0 );
			xdisplay.setRstfdisplayiffreeyq( fbrd.getRstfDisplayIfFreeYq()!=null?fbrd.getRstfDisplayIfFreeYq():0 );
			//�����ҿ�Ϊnull
			xdisplay.setRstfdisplayfarebasis( fbrd.getRstfDisplayFareBasis() );
			xdisplay.setRstfdisplaytourcode( fbrd.getRstfDisplayTourcode() );
			xdisplay.setRstfdisplaybasecmnamt( fbrd.getRstfDisplayBaseCmnPct() );
			xdisplay.setRstfdisplayadtcmnamt( fbrd.getRstfDisplayAdtCmnAmt() );
			xdisplay.setRstfdisplaybasecmnpct( fbrd.getRstfDisplayBaseCmnPct() );
			xdisplay.setRstfdisplayadtcmnpct( fbrd.getRstfDisplayAdtCmnPct() );
			xdisplay.setBaggageallowance( fbrd.getBaggageAllowance() );
			xdisplay.setRstfdisplayendorsment( fbrd.getRstfDisplayEndorsment() );
			xfbrd.setRstfdisplay( xdisplay );

			xfbrd.setExceptroute( fbrexrouteconvertor.convert(fbrd.getFbrDetailRoutes()) );
			xfbrd.setGroupid( fbrd.getGroupids() );
			
			//��Ĭ��ֵ��
			xfbrd.setAccountcodeflag( fbrd.getAccountCodeFlag()!=null?fbrd.getAccountCodeFlag():1 );
		}
		return xfbrd;
	}

}
