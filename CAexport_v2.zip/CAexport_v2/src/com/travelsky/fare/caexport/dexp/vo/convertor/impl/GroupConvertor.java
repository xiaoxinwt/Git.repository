package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.group.Group;
import com.travelsky.fare.caexport.db.model.common.group.GroupEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.group.XAgent;
import com.travelsky.fare.caexport.dexp.vo.group.XGroup;
import com.travelsky.fare.caexport.util.StringUtil;

public class GroupConvertor implements IConvert<Group, XGroup>{
	
	private IConvert<GroupEntry, XAgent> agentconvertor = new AgentConvertor();

	@Override
	public List<XGroup> convert(List<Group> list) {
		List<XGroup> xgroups = null;
		if(list!=null && list.size()>0){
			xgroups = new ArrayList<XGroup>();
			for (Group group : list) {
				xgroups.add( convert(group) );
			}
		}
		return xgroups;
	}

	@Override
	public XGroup convert(Group group) {
		XGroup xgroup = null;
		if( group!=null ){
			xgroup = new XGroup();
			
			//�������Ҳ���Ϊnull
			xgroup.setCarrCode( StringUtil.isNullOrEmpty(group.getCarrCode())?"":group.getCarrCode() );
			xgroup.setLocationCode( StringUtil.isNullOrEmpty(group.getLocationCode())?"":group.getLocationCode() );
			xgroup.setGroupid( StringUtil.isNullOrEmpty(group.getGroupId())?"":group.getGroupId() );
			List<XAgent> xagentlist = new ArrayList<XAgent>();
			if( group.getGentrys()!=null && group.getGentrys().size()>0 ){
				xagentlist = agentconvertor.convert( group.getGentrys() );
			}
			xgroup.setAgent( xagentlist );
			
			//�����ҿ�Ϊnull
			xgroup.setGroupdesc( group.getGroupDesc() );
		}
		return xgroup;
	}

}
