package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "hourrestrictionout",
    "hourrestrictionin"
})
@XmlRootElement(name = "RULE_HOUR_RESTRICTION")
public class XRuleHourRestriction {

    @XmlElement(name = "HOUR_RESTRICTION_OUT", required = true)
    protected List<XHourRestrictionOut> hourrestrictionout;
    @XmlElement(name = "HOUR_RESTRICTION_IN", required = true)
    protected List<XHourRestrictionIn> hourrestrictionin;

	public List<XHourRestrictionOut> getHourrestrictionout() {
        if (hourrestrictionout == null) {
            hourrestrictionout = new ArrayList<XHourRestrictionOut>();
        }
        return this.hourrestrictionout;
	}
	public void setHourrestrictionout(List<XHourRestrictionOut> hourrestrictionout) {
		this.hourrestrictionout = hourrestrictionout;
	}
	public List<XHourRestrictionIn> getHourrestrictionin() {
        if (hourrestrictionin == null) {
            hourrestrictionin = new ArrayList<XHourRestrictionIn>();
        }
        return this.hourrestrictionin;
	}
	public void setHourrestrictionin(List<XHourRestrictionIn> hourrestrictionin) {
		this.hourrestrictionin = hourrestrictionin;
	}
}
