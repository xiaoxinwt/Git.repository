package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromnoout",
    "tonoout",
    "nosuffixout"
})
@XmlRootElement(name = "FLIGHT_NO_OUT")
public class XFlightNoOut {
    @XmlElement(name = "FROM_NO_OUT", required = true, nillable = true)
    protected Integer fromnoout;
    @XmlElement(name = "TO_NO_OUT", required = true, nillable = true)
    protected Integer tonoout;
    @XmlElement(name = "NO_SUFFIX_OUT", defaultValue = "")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String nosuffixout;
	
    public Integer getFromnoout() {
		return fromnoout;
	}
	public void setFromnoout(Integer fromnoout) {
		this.fromnoout = fromnoout;
	}
	public Integer getTonoout() {
		return tonoout;
	}
	public void setTonoout(Integer tonoout) {
		this.tonoout = tonoout;
	}
	public String getNosuffixout() {
		return nosuffixout;
	}
	public void setNosuffixout(String nosuffixout) {
		this.nosuffixout = nosuffixout;
	}
}
