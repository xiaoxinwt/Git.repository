package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.ExFlightNo;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XExFlightNoOut;

public class ExFlightOutConvertor implements IConvert<ExFlightNo,XExFlightNoOut> {

	@Override
	public List<XExFlightNoOut> convert(List<ExFlightNo> list) {
		
		List<XExFlightNoOut> xeouts = null;
		if(list!=null && list.size()>0){
			xeouts = new ArrayList<XExFlightNoOut>();
			for (ExFlightNo eout : list) {
				xeouts.add( convert(eout) );
			}
		}
		
		return xeouts;
	}

	@Override
	public XExFlightNoOut convert(ExFlightNo eout) {
		XExFlightNoOut xeout = null;
		if( eout!=null ){
			xeout = new XExFlightNoOut();
			xeout.setExfromnoout( eout.getFromNo() );
			xeout.setExtonoout( eout.getToNo() );
			xeout.setExnosuffixout( eout.getFlightnoSuffix() );
		}
		return xeout;
	}

}
