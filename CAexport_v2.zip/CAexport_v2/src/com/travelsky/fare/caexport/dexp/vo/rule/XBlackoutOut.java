package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "blackoutfromdateout",
    "blackouttodateout"
})
@XmlRootElement(name = "BLACKOUT_OUT")
public class XBlackoutOut {
    @XmlElement(name = "BLACKOUT_FROM_DATE_OUT", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date blackoutfromdateout;
    @XmlElement(name = "BLACKOUT_TO_DATE_OUT", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date blackouttodateout;
	
    public Date getBlackoutfromdateout() {
		return blackoutfromdateout;
	}
	public void setBlackoutfromdateout(Date blackoutfromdateout) {
		this.blackoutfromdateout = blackoutfromdateout;
	}
	public Date getBlackouttodateout() {
		return blackouttodateout;
	}
	public void setBlackouttodateout(Date blackouttodateout) {
		this.blackouttodateout = blackouttodateout;
	}
}
