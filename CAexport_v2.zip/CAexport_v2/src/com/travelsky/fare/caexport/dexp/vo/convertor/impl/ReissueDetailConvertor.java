package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.reissue.ReissueDetail;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.reissue.XReissueEntry;
import com.travelsky.fare.caexport.util.StringUtil;

public class ReissueDetailConvertor implements IConvert<ReissueDetail, XReissueEntry> {

	@Override
	public List<XReissueEntry> convert(List<ReissueDetail> list) {
		List<XReissueEntry> xdetails = null;
		if( list!=null && list.size()>0 ){
			xdetails = new ArrayList<XReissueEntry>();
			for (ReissueDetail detail : list) {
				xdetails.add( convert(detail) );
			}			
		}
		return xdetails;
	}

	@Override
	public XReissueEntry convert(ReissueDetail detail) {
		XReissueEntry xdetail = null;
		if(detail!=null){
			xdetail = new XReissueEntry();
			
			xdetail.setPassengertype( detail.getPassengerType() );
			xdetail.setJourneytype( detail.getJourneyType() );
			xdetail.setBookingclass( detail.getBookingClass() );
			xdetail.setFarebasis( detail.getFareBasis() );
			xdetail.setTicketusedtag( detail.getTicket().getTicketUsedTag() );
			xdetail.setLowervalue( detail.getLowup().getLowerValue() );
			xdetail.setUppervalue( detail.getLowup().getUpperValue() );
			xdetail.setFirstticketedtime( detail.getTicket().getFirstTicketedTime() );
			xdetail.setLastticketedtime( detail.getTicket().getLastTicketedTime() );
			xdetail.setFirstdepartruetime( detail.getDepart().getFirstDepartrueTime() );
			xdetail.setLastdepartruetime( detail.getDepart().getLastDepartrueTime() );
			xdetail.setReissueallowedtag( detail.getReissueAllowedTag() );
			xdetail.setChargetype( detail.getCharge().getChargeType() );
			xdetail.setChargeunit( detail.getCharge().getChargeUnit() );
			xdetail.setDiscountcalculatetype( detail.getDis().getDiscountCalculateType() );
			xdetail.setDiscountpercent( detail.getDis().getDiscountPercent() );
			xdetail.setDiscountbookingclass( detail.getDis().getDiscountBookingClass() );
			xdetail.setCarryunit( detail.getCarryUnit() );
			xdetail.setRoundtype( detail.getRoundType() );
			xdetail.setChargeamount( detail.getAmount().getChargeAmount() );
			xdetail.setChargeminamount( detail.getCharge().getChargeMinAmount() );
			xdetail.setEndorsmentprefix( detail.getEndorsmentPrefix() );
			xdetail.setEndorsmentsuffix( detail.getEndorsmentSuffix() );
			xdetail.setOtherflightcarrierlist( detail.getOtherReissueCarrierList() );
			xdetail.setUpgradefeetag( detail.getUpgradeFeeTag() );
			xdetail.setNewendorsment( detail.getNewEndorsment() );
			
			//��ֵ��
			xdetail.setFlightdatetag( null );
			xdetail.setFlightdatenum( null );
			xdetail.setFlightdateunit( null );
			xdetail.setNotpermitcabinlist( null );
			xdetail.setOtherticketcarrierlist( null );
			xdetail.setModclassnewfareallowlowtag( null );

			//�����ֶ�
			xdetail.setLowerrelate( FundHandler.getLowerUpperRelate( detail.getLowup().getLowerRelate() ) );
			xdetail.setUpperrelate( FundHandler.getLowerUpperRelate( detail.getLowup().getUpperRelate() ) );
//			xdetail.setTicketedtimeunit( null );
//			xdetail.setTicketedtimeunit( "" );
			xdetail.setTicketedtimeunit( StringUtil.isNullOrEmpty( detail.getTicket().getTicketedTimeUnit() )?"":detail.getTicket().getTicketedTimeUnit() );
			xdetail.setDepartruetimetype( detail.getDepart().getDepartrueTimeType()!=null?detail.getDepart().getDepartrueTimeType():0 );
			xdetail.setDepartruetimeunit( StringUtil.isNullOrEmpty( detail.getDepart().getDepartrueTimeUnit() )?"":detail.getDepart().getDepartrueTimeUnit() );
			xdetail.setFreechangetimes( StringUtil.isNullOrEmpty( detail.getFreeChangeTimes() )?"":detail.getFreeChangeTimes() );
			xdetail.setReissuechargetag( detail.getReissueChargeTag()!=null? detail.getReissueChargeTag() :0 );
			xdetail.setFirstflighttag( detail.getFirstFlightTag()!=null? detail.getFirstFlightTag() :0 );
			xdetail.setSameflighttag( detail.getSameFlightTag()!=null? detail.getSameFlightTag() :0 );
			xdetail.setProcesstag( detail.getProcessTag()!=null ? detail.getProcessTag() : 0 );
			xdetail.setDatechangedtag( detail.getDateChangedTag()!=null ? detail.getDateChangedTag() : 0 );
			xdetail.setUpgradetag( detail.getUpgradeTag()!=null ? detail.getUpgradeTag() : 0 );
			xdetail.setFaredisplaytag( detail.getFareDisplayTag()!=null ? detail.getFareDisplayTag() : 0 );
			xdetail.setEndorsmenttag( detail.getEndorsmentTag()!=null ? detail.getEndorsmentTag() : 0 );
			
		}
		return xdetail;
	}

}
