package com.travelsky.fare.caexport.dexp.vo.fbr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "entryno",
    "fromcode",
    "tocode"
})
@XmlRootElement(name = "EXCEPT_ROUTE_ENTRY")
public class XExceptRouteEntry {
    @XmlElement(name = "ENTRY_NO", required = true)
    protected Integer entryno;
    @XmlElement(name = "FROM_CODE", required = true)
    protected String fromcode;
    @XmlElement(name = "TO_CODE", required = true)
    protected String tocode;
	
    public Integer getEntryno() {
		return entryno;
	}
	public void setEntryno(Integer entryno) {
		this.entryno = entryno;
	}
	public String getFromcode() {
		return fromcode;
	}
	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}
	public String getTocode() {
		return tocode;
	}
	public void setTocode(String tocode) {
		this.tocode = tocode;
	}
}
