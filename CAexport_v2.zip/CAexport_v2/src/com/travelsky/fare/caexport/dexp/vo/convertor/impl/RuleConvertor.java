package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.BlackoutPeriod;
import com.travelsky.fare.caexport.db.model.common.rule.BlackoutPeriodIn;
import com.travelsky.fare.caexport.db.model.common.rule.CombinationEntry;
import com.travelsky.fare.caexport.db.model.common.rule.ExFlightNo;
import com.travelsky.fare.caexport.db.model.common.rule.ExFlightNoIn;
import com.travelsky.fare.caexport.db.model.common.rule.FlightNoRestriction;
import com.travelsky.fare.caexport.db.model.common.rule.FlightNoRestrictionIn;
import com.travelsky.fare.caexport.db.model.common.rule.HourRestriction;
import com.travelsky.fare.caexport.db.model.common.rule.HourRestrictionIn;
import com.travelsky.fare.caexport.db.model.common.rule.Rule;
import com.travelsky.fare.caexport.db.model.common.rule.Seasonality;
import com.travelsky.fare.caexport.db.model.common.rule.SeasonalityIn;
import com.travelsky.fare.caexport.db.model.common.rule.Textual;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XBlackoutIn;
import com.travelsky.fare.caexport.dexp.vo.rule.XBlackoutOut;
import com.travelsky.fare.caexport.dexp.vo.rule.XExFlightNoIn;
import com.travelsky.fare.caexport.dexp.vo.rule.XExFlightNoOut;
import com.travelsky.fare.caexport.dexp.vo.rule.XFlightNoIn;
import com.travelsky.fare.caexport.dexp.vo.rule.XFlightNoOut;
import com.travelsky.fare.caexport.dexp.vo.rule.XHourRestrictionIn;
import com.travelsky.fare.caexport.dexp.vo.rule.XHourRestrictionOut;
import com.travelsky.fare.caexport.dexp.vo.rule.XRule;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleBlackoutPeriod;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleCombination;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleFlightNoRestriction;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleHourRestriction;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleSeasonality;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleTextual;
import com.travelsky.fare.caexport.dexp.vo.rule.XSeasonalityIn;
import com.travelsky.fare.caexport.dexp.vo.rule.XSeasonalityOut;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.StringUtil;

public class RuleConvertor implements IConvert<Rule, XRule>{
	
	private IConvert<Seasonality,XSeasonalityOut> soconvert = new SeasonOutConvertor();
	private IConvert<SeasonalityIn, XSeasonalityIn> siconvert = new SeasonInConvertor();
	private IConvert<BlackoutPeriod, XBlackoutOut> boconvert = new BlackOutConvertor();
	private IConvert<BlackoutPeriodIn, XBlackoutIn> biconvert = new BlackInConvertor();
	private IConvert<HourRestriction, XHourRestrictionOut> hoconvert = new HourOutConvertor();
	private IConvert<HourRestrictionIn, XHourRestrictionIn> hiconvert = new HourInConvertor();
	private IConvert<FlightNoRestriction,XFlightNoOut> foconvert = new FlightOutConvertor();
	private IConvert<FlightNoRestrictionIn,XFlightNoIn> ficonvert = new FlightInConvertor();
	private IConvert<ExFlightNo,XExFlightNoOut> eoconvert = new ExFlightOutConvertor();
	private IConvert<ExFlightNoIn, XExFlightNoIn> eiconvert = new ExFlightInConvertor();
	private IConvert<Textual,XRuleTextual> tconvert = new TextualConvertor();
	private IConvert<CombinationEntry, XRuleCombination> cconvert = new CombinConvertor();
	
	List<XRule> xrules = null;
	private XRule xrule = null;

	@Override
	public List<XRule> convert(List<Rule> list) {
		if(list!=null && list.size()>0){
			xrules = new ArrayList<XRule>();
			for (Rule rule : list) {
				xrules.add( convert(rule) );
			}			
		}
		return xrules;
	}

	@Override
	public XRule convert(Rule rule) {
		if(rule!=null){
			xrule = new XRule();
			XRuleSeasonality xseason = null;
			XRuleBlackoutPeriod xblack = null;
			XRuleHourRestriction xhour = null;
			XRuleFlightNoRestriction xflight = null;
			List<XRuleCombination> xcombs = null;
			
			//������
//			xrule.setCarrCode( );	//��Importor���ֻ�����
//			xrule.setActionCode( );	//��Importor���ֻ�����
			xrule.setLocationCode( StringUtil.isNullOrEmpty(rule.getLocationCode())?"":rule.getLocationCode() );
			xrule.setRuleid( StringUtil.isNullOrEmpty(rule.getRuleId())?"":rule.getRuleId() );
			xrule.setRuleSeqId( rule.getRuleSeqId()!=null?rule.getRuleSeqId():new BigDecimal(0) );
			xrule.setEffectiveDate( rule.getEffectiveDate()!=null?rule.getEffectiveDate():DateUtil.getDate("9999-12-31") );
			xrule.setDiscontinueDate( rule.getDiscontinueDate()!=null?rule.getDiscontinueDate():DateUtil.getDate("9999-12-31") );
			xrule.setMinimumgroup( rule.getGroupFrom() );
			xrule.setMaximumgroup( rule.getGroupTo() );
			xrule.setFarescombinationflag( rule.getFaresCombinationFlag() );
			xrule.setSeparatesaletype( rule.getSeparateSaleType() );
			
			//�����ҿ�Ϊnull
			xrule.setDayofweekrestriction( rule.getDayOfWeekRestriction() );
			xrule.setDayofweekrestrictionin( rule.getDayOfWeekRestrictionIn() );
			xrule.setFaresgroupsflag( rule.getGroupFlag() );
			
			//��Ĭ��ֵ
			xrule.setForbiddenjourneyflag( rule.getForbiddenJourneyFlag()!=null?rule.getForbiddenJourneyFlag():0 );
			xrule.setPositionlimittype( rule.getPositionLimitType()!=null?rule.getPositionLimitType():0 );
			xrule.setTickettimelimitunit( rule.getTicketTimeLimitUnit()!=null?rule.getTicketTimeLimitUnit():0 );
			xrule.setTicketcarrlimit( rule.getTicketCarrLimit()!=null?rule.getTicketCarrLimit():0 );
			xrule.setFlightnotype( StringUtil.isNullOrEmpty(rule.getFlightnoType())?"0":rule.getFlightnoType() );
			xrule.setFlightnotypein( StringUtil.isNullOrEmpty(rule.getFlightnoTypeIn())?"0":rule.getFlightnoTypeIn() );
			
			//��Ϊ��
			xrule.setRuledesc( rule.getRuleDesc() );
			xrule.setAdvancepurchase( rule.getAdvancePurchase() );
			xrule.setRulerefund( rule.getRefundRuleId() );
			xrule.setRulereissue( rule.getReissueId() );
			xrule.setCombineopenjawflag( rule.getCombineOpenJawFlag() );
			xrule.setCombineroundtripflag( rule.getCombineRoundTripFlag() );
			xrule.setMaxadvancedpurchars( rule.getMaxAdvancedPurchase() );
			xrule.setMaxadvancedpurcharsunit( rule.getMaxAdvancedPurchaseUnit() );
			xrule.setMinadvancedpurcharsunit( rule.getMinAdvancedPurchaseUnit() );
			xrule.setOpenjawflag( rule.getOpenJawFlag() );
			xrule.setCandidateflag( rule.getCandidateFlag() );
//			System.out.println( rule.getRestrictionDesc() );
			xrule.setRuleendorsementrestriction( StringUtil.listToString( rule.getRestrictionDesc() ) );
			xrule.setCodeshare( rule.getCodeShare() );
			xrule.setAppcxrcodeshare( rule.getAppcxrCodeShare() );
			xrule.setSectorrangelower( rule.getSectorRangeLower() );
			xrule.setSectorrangeupper( rule.getSectorRangeUpper() );
			xrule.setPositionlimitspec( rule.getPositionLimitSpec() );
			xrule.setCharterflightflag( rule.getCharterFlightFlag() );
			xrule.setTickettimelimitvalue( new BigDecimal(rule.getTicketTimeLimitValue()!=null? rule.getTicketTimeLimitValue():0.00) );
			xcombs = cconvert.convert( rule.getCombinas());
			xrule.setRulecombination( xcombs );

			//û��ֵ��֮���Ӧ
			xrule.setCombineversion( null );
			
			//���Ӷ���
			//�Ǳ����Ϊnull
			xrule.setRuleseasonality( xseason );
			if( (rule.getSeasonins()==null || rule.getSeasonins().size()==0) && (rule.getSeasonouts()==null || rule.getSeasonouts().size()==0) ){
				xrule.setRuleseasonality( null );
			}else{
				xseason = new XRuleSeasonality();
				xseason.setSeasonalityout( soconvert.convert(rule.getSeasonouts() ));
				xseason.setSeasonalityin( siconvert.convert(rule.getSeasonins() ));
			}
			
			if( (rule.getBlackouts()==null || rule.getBlackouts().size()==0) && (rule.getBlackins()==null || rule.getBlackins().size()==0) ){
				xrule.setRuleblackoutperiod( null );
			}else{
				xblack = new XRuleBlackoutPeriod();
				xblack.setBlackoutout( boconvert.convert(rule.getBlackouts() ));
				xblack.setBlackoutin( biconvert.convert(rule.getBlackins() ));
				xrule.setRuleblackoutperiod( xblack );
			}
			
			//�������Ϊnull - ��Ҫ����Ĭ��ֵ
			xhour = new XRuleHourRestriction();
			//������ֵ��Ҫ���Ǳ������Ҳ���Ϊnull
			List<XHourRestrictionIn> xHourInList = new ArrayList<XHourRestrictionIn>();
			if( rule.getHourins()!=null && rule.getHourins().size()>0 ){
				xHourInList = hiconvert.convert( rule.getHourins() );
			}
			List<XHourRestrictionOut> xHourOutList = new ArrayList<XHourRestrictionOut>();
			if( rule.getHourouts()!=null && rule.getHourouts().size()>0 ){
				xHourOutList = hoconvert.convert( rule.getHourouts() );
			}
			xhour.setHourrestrictionin(xHourInList);
			xhour.setHourrestrictionout(xHourOutList);
			xrule.setRulehourrestriction(xhour);
			
			//�������Ϊnull - ��Ҫ����Ĭ��ֵ
			xflight = new XRuleFlightNoRestriction();
			//�������� �������Ҳ���Ϊnull
			xflight.setFlightnoin( (rule.getFlightins()!=null && rule.getFlightins().size()>0 )? ficonvert.convert( rule.getFlightins() ) : new ArrayList<XFlightNoIn>() );
			xflight.setFlightnoout( ( rule.getFlightouts()!=null && rule.getFlightouts().size()>0 )? foconvert.convert( rule.getFlightouts() ) : new ArrayList<XFlightNoOut>() );
			//�������� �Ǳ����Ϊnull����
			xflight.setExflightnoin( (rule.getExins()!=null && rule.getExins().size()>0)? eiconvert.convert( rule.getExins() ) : null );
			xflight.setExflightnoout( (rule.getExouts()!=null && rule.getExouts().size()>0)? eoconvert.convert( rule.getExouts() ) : null );
			xrule.setRuleflightnorestriction( xflight );
			
			//�������Ϊnull - ��Ҫ����Ĭ��ֵ
			List<XRuleTextual> xtexts = new ArrayList<XRuleTextual>();
			if( rule.getTexts()!=null && rule.getTexts().size()>0 ){
				xtexts = tconvert.convert( rule.getTexts() );
			}
			xrule.setRuletextual( xtexts );
		}
		return xrule;
	}

}
