package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBRDetail;
import com.travelsky.fare.caexport.db.model.common.fbr.FBR;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRule;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRuleDetail;

public class FBRConvertor implements IConvert<FBR, XFareByRule> {

	private IConvert<FBRDetail, XFareByRuleDetail> fbrdetailconvertor = new FBRDetailConvertor();
	
	@Override
	public List<XFareByRule> convert(List<FBR> list) {
		List<XFareByRule> xfbrs = null;
		if( list!=null && list.size()>0 ){
			xfbrs = new ArrayList<XFareByRule>();
			for(FBR fbr : list){
				xfbrs.add( convert(fbr) );
			}
		}
		return xfbrs;
	}

	@Override
	public XFareByRule convert(FBR fbr) {
		XFareByRule xfbr = null;
		if( fbr!=null ){
			xfbr = new XFareByRule();
			//�������Ҳ�Ϊnull
			xfbr.setFarebyruleid( fbr.getFareByRuleId() );
			xfbr.setFbrdesc( fbr.getFbrDesc() );
			xfbr.setCarrCode( fbr.getCarrCode() );
			xfbr.setLocationCode( fbr.getLocationCode() );
			xfbr.setFarebyruledetails( fbrdetailconvertor.convert(fbr.getFbrDetails()) );
			
			//�Ǳ����� -- ����֮��Ӧ��ֵ
			xfbr.setMode( null );
			xfbr.setTopbottom( null );
		}
		return xfbr;
	}

}
