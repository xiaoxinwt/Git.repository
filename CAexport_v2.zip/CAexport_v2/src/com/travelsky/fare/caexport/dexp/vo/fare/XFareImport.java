package com.travelsky.fare.caexport.dexp.vo.fare;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agreements"
})
@XmlRootElement(name = "AGREEMENT_IMPORT")
public class XFareImport{
    @XmlElement(name = "AGREEMENT")
    protected List<XAgreement> agreements;

	public List<XAgreement> getAgreements() {
		if( agreements==null ) agreements=new ArrayList<XAgreement>();
		return agreements;
	}
	public void setAgreements(List<XAgreement> agreements) {
		this.agreements = agreements;
	}
}
