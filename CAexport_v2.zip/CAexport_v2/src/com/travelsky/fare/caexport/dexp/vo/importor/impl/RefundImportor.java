package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.List;

import com.travelsky.fare.caexport.db.model.common.refund.Refund;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.RefundConvertor;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefund;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefundImport;
import com.travelsky.fare.caexport.util.Const;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public class RefundImportor implements IImportor<Refund, XRefundImport> {

	private IConvert<Refund,XRefund> refundconvertor = new RefundConvertor();
	private long count = -1;
	
	@Override
	public XRefundImport getImport(List<Refund> list,String carrier,CAType catype,ActionType actype) {
		count = 0;
		XRefundImport xrefundimp = new XRefundImport();
		if( list==null || list.size()==0 ) return xrefundimp;
		
		List<XRefund> xrefundlist = refundconvertor.convert( list );
		if( xrefundlist==null || xrefundlist.size()==0 ) return xrefundimp;
		boolean isAirtis = catype.equals( CAType.Airtis );
		for (XRefund xrefund : xrefundlist) {
			xrefund.setActionCode( actype.code );
			xrefund.setCarrCode( carrier );
			if( isAirtis ){
				xrefund.setLocationCode( Const.AIRTIS_LOCATION_CODE );
			}
		}
		
		count += xrefundlist.size();
		xrefundimp.setRefund( xrefundlist );
		
		return xrefundimp;
	}

	@Override
	public long getCount() {
		return count;
	}

}
