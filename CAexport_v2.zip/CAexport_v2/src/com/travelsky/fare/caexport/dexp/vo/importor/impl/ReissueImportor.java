package com.travelsky.fare.caexport.dexp.vo.importor.impl;

import java.util.List;

import com.travelsky.fare.caexport.db.model.common.reissue.Reissue;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.convertor.impl.ReissueConvertor;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.reissue.XReissue;
import com.travelsky.fare.caexport.dexp.vo.reissue.XReissueImport;
import com.travelsky.fare.caexport.util.Const;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public class ReissueImportor implements IImportor<Reissue, XReissueImport> {

	private IConvert<Reissue,XReissue> reissueconvertor = new ReissueConvertor();
	private long count = -1;
	
	@Override
	public XReissueImport getImport(List<Reissue> list,String carrier,CAType catype, ActionType actype) {
		count = 0;
		XReissueImport xreissueimp = new XReissueImport();
		if(list==null || list.size()==0) return xreissueimp;
		
		List<XReissue> xreissuelist = reissueconvertor.convert( list );
		if( xreissuelist==null || xreissuelist.size()==0 ) return xreissueimp;
		
		boolean isAirtis = catype.equals( CAType.Airtis );
		for (XReissue xreissue : xreissuelist) {
			xreissue.setActionCode( actype.code );
			xreissue.setCarrCode( carrier );
			if( isAirtis ){
				xreissue.setLocationCode( Const.AIRTIS_LOCATION_CODE );
			}
		}
		
		count += xreissuelist.size();
		xreissueimp.setRulereissue( xreissuelist );

		return xreissueimp;
	}

	@Override
	public long getCount() {
		return count;
	}

}
