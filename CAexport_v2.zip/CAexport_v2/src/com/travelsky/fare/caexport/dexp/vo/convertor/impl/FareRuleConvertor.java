package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRule;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRule;

public class FareRuleConvertor implements IConvert<FareRule, XFareRule> {

	@Override
	public List<XFareRule> convert(List<FareRule> list) {
		List<XFareRule> xrules = null;
		if( list!=null && list.size()>0){
			xrules = new ArrayList<XFareRule>();
			for(FareRule rule : list){
				if( rule!=null ){
					xrules.add( convert(rule) );					
				}
			}
		}
		return xrules;
	}

	@Override
	public XFareRule convert(FareRule rule) {
		XFareRule xrule = null;
		if( rule!=null ){
			xrule = new XFareRule();
			xrule.setMinimumstay( rule.getMm().getMinimumStay() );
			if( rule.getMm().getMinimumStayUnit()!=null ){
				xrule.setMinimumstayunit( rule.getMm().getMinimumStayUnit().toLowerCase() );				
			}
			xrule.setMaximumstay( rule.getMm().getMaximumStay() );
			if( rule.getMm().getMaximumStayUnit()!=null ){
				xrule.setMaximumstayunit( rule.getMm().getMaximumStayUnit().toLowerCase() );				
			}
		}
		
		return xrule;
	}

}
