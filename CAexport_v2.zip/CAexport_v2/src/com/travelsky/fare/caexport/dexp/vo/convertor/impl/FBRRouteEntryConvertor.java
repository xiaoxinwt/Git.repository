package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBRDtlExrouteEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fbr.XExceptRouteEntry;

public class FBRRouteEntryConvertor implements IConvert<FBRDtlExrouteEntry, XExceptRouteEntry> {

	@Override
	public List<XExceptRouteEntry> convert( List<FBRDtlExrouteEntry> list) {
		List<XExceptRouteEntry> xentrys = null;
		if( list!=null && list.size()>0 ){
			xentrys = new ArrayList<XExceptRouteEntry>();
			for(FBRDtlExrouteEntry entry : list){
				xentrys.add( convert(entry) );
			}
		}
		
		return xentrys;
	}

	@Override
	public XExceptRouteEntry convert(FBRDtlExrouteEntry entry) {
		XExceptRouteEntry xentry = null;
		if(entry!=null){
			xentry = new XExceptRouteEntry();
			xentry = new XExceptRouteEntry();

			xentry.setEntryno( entry.getEntryNo() );
			xentry.setFromcode( entry.getFromCode() );
			xentry.setTocode( entry.getToCode() );
		}
		
		return xentry;
	}

}
