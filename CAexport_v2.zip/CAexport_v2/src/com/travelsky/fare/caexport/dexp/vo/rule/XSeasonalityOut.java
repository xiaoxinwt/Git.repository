package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromdateout",
    "todateout"
})
@XmlRootElement(name = "SEASONALITY_OUT")
public class XSeasonalityOut {
    @XmlElement(name = "FROM_DATE_OUT", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date fromdateout;
    @XmlElement(name = "TO_DATE_OUT", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date todateout;
    
	public Date getFromdateout() {
		return fromdateout;
	}
	public void setFromdateout(Date fromdateout) {
		this.fromdateout = fromdateout;
	}
	public Date getTodateout() {
		return todateout;
	}
	public void setTodateout(Date todateout) {
		this.todateout = todateout;
	}
}
