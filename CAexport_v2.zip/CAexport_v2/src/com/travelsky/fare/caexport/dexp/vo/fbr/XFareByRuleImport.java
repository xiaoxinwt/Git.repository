package com.travelsky.fare.caexport.dexp.vo.fbr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "farebyrule"
})
@XmlRootElement(name = "FBR_IMPORT")
public class XFareByRuleImport{
    @XmlElement(name = "FAREBYRULE")
    protected List<XFareByRule> farebyrule;

	public List<XFareByRule> getFarebyrule() {
		if(farebyrule==null) farebyrule=new ArrayList<XFareByRule>();
		return farebyrule;
	}
	public void setFarebyrule(List<XFareByRule> farebyrule) {
		this.farebyrule = farebyrule;
	}
}
