package com.travelsky.fare.caexport.dexp.vo.rule;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "rule"
})
@XmlRootElement(name = "RULES_IMPORT")
public class XRuleImport{

    @XmlElement(name = "RULE")
    protected List<XRule> rule;

	public List<XRule> getRule() {
		if( rule==null ) rule = new ArrayList<XRule>();
		return rule;
	}
	public void setRule(List<XRule> rule) {
		this.rule = rule;
	}
}
