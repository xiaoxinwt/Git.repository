package com.travelsky.fare.caexport.dexp.vo.fare;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "minimumstay",
    "minimumstayunit",
    "maximumstay",
    "maximumstayunit"
})

@XmlRootElement(name = "FARE_RULE")
public class XFareRule {
    @XmlElement(name = "MINIMUM_STAY", required = true, nillable = true)
    protected Integer minimumstay;
    @XmlElement(name = "MINIMUM_STAY_UNIT", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String minimumstayunit;
    @XmlElement(name = "MAXIMUM_STAY", required = true, nillable = true)
    protected Integer maximumstay;
    @XmlElement(name = "MAXIMUM_STAY_UNIT", required = true, nillable = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String maximumstayunit;
	
    public Integer getMinimumstay() {
		return minimumstay;
	}
	public void setMinimumstay(Integer minimumstay) {
		this.minimumstay = minimumstay;
	}
	public String getMinimumstayunit() {
		return minimumstayunit;
	}
	public void setMinimumstayunit(String minimumstayunit) {
		this.minimumstayunit = minimumstayunit;
	}
	public Integer getMaximumstay() {
		return maximumstay;
	}
	public void setMaximumstay(Integer maximumstay) {
		this.maximumstay = maximumstay;
	}
	public String getMaximumstayunit() {
		return maximumstayunit;
	}
	public void setMaximumstayunit(String maximumstayunit) {
		this.maximumstayunit = maximumstayunit;
	}
}
