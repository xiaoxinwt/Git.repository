package com.travelsky.fare.caexport.dexp.vo.fbr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
	"farebyruleid",
    "fbrdesc",
    "carrCode",
    "locationCode",
    "mode",
    "topbottom",
    "farebyruledetails"
})

@XmlRootElement(name = "FAREBYRULE")
public class XFareByRule {
    @XmlElement(name = "CARR_CODE", required = true)
    private String carrCode;
    @XmlElement(name = "LOCATION_CODE", required = true)
    private String locationCode;
	@XmlElement(name = "FAREBYRULE_ID", required = true)
    protected String farebyruleid;
    @XmlElement(name = "FBR_DESC", required = true)
    protected String fbrdesc;
    @XmlElement(name = "MODE")
    protected Integer mode;
    @XmlElement(name = "TOPBOTTOM")
    protected Integer topbottom;
    @XmlElement(name = "FAREBYRULE_DETAIL", required = true)
    protected List<XFareByRuleDetail> farebyruledetails;
	
    public String getCarrCode() {
    	return carrCode;
    }
    public void setCarrCode(String carrCode) {
    	this.carrCode = carrCode;
    }
    public String getLocationCode() {
    	return locationCode;
    }
    public void setLocationCode(String locationCode) {
    	this.locationCode = locationCode;
    }
    public String getFarebyruleid() {
		return farebyruleid;
	}
	public void setFarebyruleid(String farebyruleid) {
		this.farebyruleid = farebyruleid;
	}
	public String getFbrdesc() {
		return fbrdesc;
	}
	public void setFbrdesc(String fbrdesc) {
		this.fbrdesc = fbrdesc;
	}
	public Integer getMode() {
		return mode;
	}
	public void setMode(Integer mode) {
		this.mode = mode;
	}
	public Integer getTopbottom() {
		return topbottom;
	}
	public void setTopbottom(Integer topbottom) {
		this.topbottom = topbottom;
	}
	public List<XFareByRuleDetail> getFarebyruledetails() {
		if(farebyruledetails==null) farebyruledetails=new ArrayList<XFareByRuleDetail>();
		return farebyruledetails;
	}
	public void setFarebyruledetails(List<XFareByRuleDetail> farebyruledetails) {
		this.farebyruledetails = farebyruledetails;
	}
}
