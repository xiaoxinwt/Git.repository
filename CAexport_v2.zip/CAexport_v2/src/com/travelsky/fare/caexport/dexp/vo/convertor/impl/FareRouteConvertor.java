package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRoute;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRouteEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRoute;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareRouteEntry;

public class FareRouteConvertor implements IConvert<FareRoute, XFareRoute> {

	private IConvert<FareRouteEntry, XFareRouteEntry> routeentryconvertor = new FareRouteEntryConvertor();
	
	@Override
	public List<XFareRoute> convert(List<FareRoute> list) {
		List<XFareRoute> xroutes = null;
		if(list!=null && list.size()>0){
			xroutes = new ArrayList<XFareRoute>();
			for (FareRoute route : list) {
				xroutes.add( convert(route) );
			}
		}
		
		return xroutes;
	}

	@Override
	public XFareRoute convert(FareRoute route) {
		XFareRoute xroute = null;
		if(route!=null){
			xroute = new XFareRoute();
			xroute.setRouteno( route.getRouteNo() );
			xroute.setFarerouteentry( routeentryconvertor.convert(route.getRouteEntries() ) );
		}
		return xroute;
	}

}
