package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.Seasonality;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XSeasonalityOut;

public class SeasonOutConvertor implements IConvert<Seasonality,XSeasonalityOut> {

	@Override
	public List<XSeasonalityOut> convert( List<Seasonality> list){
		
		List<XSeasonalityOut> xsouts = null;
		if( list!=null && list.size()>0 ){
			xsouts = new ArrayList<XSeasonalityOut>();
			for (Seasonality sout : list) {
				xsouts.add(convert(sout));
			}
		}
		return xsouts;
	}

	@Override
	public XSeasonalityOut convert(Seasonality obj) {
		XSeasonalityOut xsout = null;
		if(obj!=null){
			xsout = new XSeasonalityOut();
			xsout.setFromdateout( obj.getFromDate() );
			xsout.setTodateout( obj.getToDate() );
		}
		return xsout;
	}
	
}
