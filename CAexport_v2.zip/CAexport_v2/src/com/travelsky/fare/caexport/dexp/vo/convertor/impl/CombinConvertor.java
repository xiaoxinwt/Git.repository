package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import com.travelsky.fare.caexport.db.model.common.rule.CombinationEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleCombination;

public class CombinConvertor implements IConvert<CombinationEntry, XRuleCombination> {

	@Override
	public List<XRuleCombination> convert(List<CombinationEntry> list) {
		List<XRuleCombination> xcombs = null;
		if(list!=null && list.size()>0){
			xcombs = new ArrayList<XRuleCombination>();
			for (CombinationEntry combin : list) {
				xcombs.add( convert(combin) );
			}
		}
		return xcombs;
	}

	@Override
	public XRuleCombination convert(CombinationEntry comb) {
		XRuleCombination xcomb = null;
		if(comb!=null){
			xcomb = new XRuleCombination();

			xcomb.setBookingclass( comb.getBookingClass() );
			xcomb.setCarriercode( comb.getCarrierCode() );
			xcomb.setCombineruleid( comb.getCombineRuleId() );
			xcomb.setFarebasis( comb.getFareBasis() );
			xcomb.setIscheckallsectors( new BigDecimal( comb.getIsCheckAllSectors()!=null? comb.getIsCheckAllSectors() : 0 ) );
			xcomb.setMaximumstay( new BigDecimal( comb.getMaximumStay()!=null? comb.getMaximumStay() : 0) );
			xcomb.setMaximumstayunit( comb.getMaximumStayUnit() );
			xcomb.setMinimumstay( new BigDecimal( comb.getMinimumStay()!=null? comb.getMinimumStay() : 0) );
			xcomb.setMinimumstayunit( comb.getMinimumStayUnit() );
			xcomb.setSectorcombinetype( new BigDecimal( comb.getSectorCombineType()!=null? comb.getSectorCombineType() : 0) );
			xcomb.setSeqid( new BigDecimal( comb.getSeqId()!=null ? comb.getSeqId() : 0) );
			xcomb.setStaytype( new BigDecimal( comb.getStayType()!=null? comb.getStayType() : 0) );
		}
		return xcomb;
	}

}
