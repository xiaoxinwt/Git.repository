package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.SeasonalityIn;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XSeasonalityIn;

public class SeasonInConvertor implements IConvert<SeasonalityIn, XSeasonalityIn> {

	@Override
	public List<XSeasonalityIn> convert(List<SeasonalityIn> list) {
		List<XSeasonalityIn> xins = null;
		if( list!=null && list.size()>0 ){
			xins = new ArrayList<XSeasonalityIn>();
			for (SeasonalityIn sin : list) {
				xins.add( convert(sin) );
			}
		}
		return xins;
	}

	@Override
	public XSeasonalityIn convert(SeasonalityIn obj) {
		XSeasonalityIn xin = null;
		if(obj!=null){
			xin = new XSeasonalityIn();
			xin.setFromdatein( obj.getFromDate() );
			xin.setTodatein( obj.getToDate() );
		}
		return xin;
	}

}
