package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.fbr.FBRDtlExroute;
import com.travelsky.fare.caexport.db.model.common.fbr.FBRDtlExrouteEntry;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.fbr.XExceptRoute;
import com.travelsky.fare.caexport.dexp.vo.fbr.XExceptRouteEntry;

public class FBRExRouteConvertor implements IConvert<FBRDtlExroute, XExceptRoute> {

	private IConvert<FBRDtlExrouteEntry, XExceptRouteEntry> fbrfentryconvertor = new FBRRouteEntryConvertor();
	
	@Override
	public List<XExceptRoute> convert(List<FBRDtlExroute> list) {
		List<XExceptRoute> xroutes = null;
		if( list!=null && list.size()>0 ){
			xroutes = new ArrayList<XExceptRoute>();
			for( FBRDtlExroute route : list){
				xroutes.add( convert(route) );				
			}
		}
		return xroutes;
	}

	@Override
	public XExceptRoute convert(FBRDtlExroute route) {
		XExceptRoute xroute = null;
		if( route!=null ){
			xroute = new XExceptRoute();

			xroute.setRouteno( route.getExrouteNo() );
			xroute.setExceptrouteentrys( fbrfentryconvertor.convert(route.getRouteEntries()) );
		}
		return xroute;
	}

}
