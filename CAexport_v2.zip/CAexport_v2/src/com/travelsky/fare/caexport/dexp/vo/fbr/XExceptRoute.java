package com.travelsky.fare.caexport.dexp.vo.fbr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "routeno",
    "exceptrouteentrys"
})
@XmlRootElement(name = "EXCEPT_ROUTE")
public class XExceptRoute {
    @XmlElement(name = "ROUTE_NO", required = true)
    protected Integer routeno;
    @XmlElement(name = "EXCEPT_ROUTE_ENTRY", required = true)
    protected List<XExceptRouteEntry> exceptrouteentrys;
	public Integer getRouteno() {
		return routeno;
	}
	public void setRouteno(Integer routeno) {
		this.routeno = routeno;
	}
	public List<XExceptRouteEntry> getExceptrouteentrys() {
		if(exceptrouteentrys==null) exceptrouteentrys=new ArrayList<XExceptRouteEntry>();
		return exceptrouteentrys;
	}
	public void setExceptrouteentrys(List<XExceptRouteEntry> exceptrouteentrys) {
		this.exceptrouteentrys = exceptrouteentrys;
	}
}
