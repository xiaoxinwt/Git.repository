package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.BlackoutPeriodIn;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XBlackoutIn;

public class BlackInConvertor implements IConvert<BlackoutPeriodIn, XBlackoutIn> {

	@Override
	public List<XBlackoutIn> convert(List<BlackoutPeriodIn> list) {
		List<XBlackoutIn> xbins = null;
		if(list!=null && list.size()>0){
			xbins = new ArrayList<XBlackoutIn>();
			for (BlackoutPeriodIn bin : list) {
				xbins.add(convert(bin) );
			}
		}
		return xbins;
	}

	@Override
	public XBlackoutIn convert(BlackoutPeriodIn obj) {
		XBlackoutIn xbin = null;
		if(obj!=null){
			xbin = new XBlackoutIn();
			xbin.setBlackoutfromdatein( obj.getBlackoutFromDate() );
			xbin.setBlackouttodatein( obj.getBlackoutToDate() );
		}
		return xbin;
	}

}
