package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.Textual;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleTextual;

public class TextualConvertor implements IConvert<Textual,XRuleTextual> {

	@Override
	public List<XRuleTextual> convert(List<Textual> list) {
		List<XRuleTextual> xts = null;
		if(list!=null && list.size()>0){
			xts = new ArrayList<XRuleTextual>();
			for (Textual t : list) {
				xts.add( convert(t) );
			}
		}
		return xts;
	}

	@Override
	public XRuleTextual convert(Textual obj) {
		XRuleTextual xt = null;
		if(obj!=null){
			xt = new XRuleTextual();
			xt.setApplication( obj.getApplication() );
			xt.setCancellationnrefunds( obj.getCancellationNRefunds() );
			xt.setCombination( null );
			xt.setEligibility( obj.getEligibility() );
			xt.setExtensionofvalidity( obj.getExtensionOfValidity() );
			xt.setGrouprequirements( null );
			xt.setOtherconditions( obj.getOtherConditions() );
			xt.setPaymentsticketing( obj.getPayment() );
			xt.setRebookingnrerouting( obj.getRebookingNRerouting() );
			xt.setReservations( null );
		}
		return xt;
	}

}
