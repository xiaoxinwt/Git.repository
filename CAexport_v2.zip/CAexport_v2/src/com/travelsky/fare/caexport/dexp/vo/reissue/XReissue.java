package com.travelsky.fare.caexport.dexp.vo.reissue;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "carrCode","locationCode",
    "rulereissueid",
    "changetag",
    "voluntarychangedtext",
    "involuntarychangedtext",
    "reissueentries"
})
@XmlRootElement(name = "RULE_REISSUE")
public class XReissue{
    @XmlElement(name = "Action_Code", required = true)
    protected String actionCode;
	@XmlElement(name = "CARR_CODE", required = true)
	private String carrCode;
	@XmlElement(name = "LOCATION_CODE", required = true)
	private String locationCode;
    @XmlElement(name = "RULE_REISSUE_ID", required = true)
    protected String rulereissueid;
    @XmlElement(name = "CHANGE_TAG", required = true, nillable = true)
    protected String changetag;
    @XmlElement(name = "VOLUNTARY_CHANGED_TEXT", required = true)
    protected String voluntarychangedtext;
    @XmlElement(name = "INVOLUNTARY_CHANGED_TEXT")
    protected String involuntarychangedtext;
    @XmlElement(name = "RULE_REISSUE_ENTRY")
    protected List<XReissueEntry> reissueentries;

    public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getRulereissueid() {
		return rulereissueid;
	}
	public void setRulereissueid(String rulereissueid) {
		this.rulereissueid = rulereissueid;
	}
	public String getChangetag() {
		return changetag;
	}
	public void setChangetag(String changetag) {
		this.changetag = changetag;
	}
	public String getVoluntarychangedtext() {
		return voluntarychangedtext;
	}
	public void setVoluntarychangedtext(String voluntarychangedtext) {
		this.voluntarychangedtext = voluntarychangedtext;
	}
	public String getInvoluntarychangedtext() {
		return involuntarychangedtext;
	}
	public void setInvoluntarychangedtext(String involuntarychangedtext) {
		this.involuntarychangedtext = involuntarychangedtext;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public List<XReissueEntry> getReissueentries() {
        if (reissueentries == null) {
            reissueentries = new ArrayList<XReissueEntry>();
        }
		return reissueentries;
	}
	public void setReissueentries(List<XReissueEntry> reissueentries) {
		this.reissueentries = reissueentries;
	}
}
