package com.travelsky.fare.caexport.dexp.vo.convertor;

import java.util.List;
import java.util.Map;
import com.travelsky.fare.caexport.db.model.po.RefPK;

public interface IFareConvert<T, U> {
	public Map<RefPK,List<U>> convertToMapByPK(List<T> list,String carrier);
}
