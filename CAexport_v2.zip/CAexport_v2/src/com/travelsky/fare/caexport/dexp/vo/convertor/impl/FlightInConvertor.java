package com.travelsky.fare.caexport.dexp.vo.convertor.impl;

import java.util.ArrayList;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.rule.FlightNoRestrictionIn;
import com.travelsky.fare.caexport.dexp.vo.convertor.IConvert;
import com.travelsky.fare.caexport.dexp.vo.rule.XFlightNoIn;

public class FlightInConvertor implements IConvert<FlightNoRestrictionIn,XFlightNoIn> {

	@Override
	public List<XFlightNoIn> convert(List<FlightNoRestrictionIn> list) {
		List<XFlightNoIn> xfins = null;
		if(list!=null && list.size()>0){
			xfins = new ArrayList<XFlightNoIn>();
			for(FlightNoRestrictionIn fin : list){
				xfins.add( convert(fin) );
			}
		}
		return xfins;
	}

	@Override
	public XFlightNoIn convert(FlightNoRestrictionIn fin) {
		XFlightNoIn xfin = null;
		if( fin!=null ){
			xfin = new XFlightNoIn();
			xfin.setFromnoin( fin.getFromNo() );
			xfin.setTonoin( fin.getToNo() );
			xfin.setNosuffixin( fin.getFlightnoSuffix() );
		}
		return xfin;
	}

}
