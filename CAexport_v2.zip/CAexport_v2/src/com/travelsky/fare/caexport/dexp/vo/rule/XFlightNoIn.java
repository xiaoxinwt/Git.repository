package com.travelsky.fare.caexport.dexp.vo.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fromnoin",
    "tonoin",
    "nosuffixin"
})
@XmlRootElement(name = "FLIGHT_NO_IN")
public class XFlightNoIn {
    @XmlElement(name = "FROM_NO_IN", required = true, nillable = true)
    protected Integer fromnoin;
    @XmlElement(name = "TO_NO_IN", required = true, nillable = true)
    protected Integer tonoin;
    @XmlElement(name = "NO_SUFFIX_IN", defaultValue = "")
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String nosuffixin;
	
    public Integer getFromnoin() {
		return fromnoin;
	}
	public void setFromnoin(Integer fromnoin) {
		this.fromnoin = fromnoin;
	}
	public Integer getTonoin() {
		return tonoin;
	}
	public void setTonoin(Integer tonoin) {
		this.tonoin = tonoin;
	}
	public String getNosuffixin() {
		return nosuffixin;
	}
	public void setNosuffixin(String nosuffixin) {
		this.nosuffixin = nosuffixin;
	}
}
