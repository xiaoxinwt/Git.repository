package com.travelsky.fare.caexport.dexp.vo.importor;

import java.util.List;

import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAType;

public interface IImportor<T,V> {
	public V getImport( List<T> list, String carrier ,CAType catype, ActionType actype);
	public long getCount();
}
