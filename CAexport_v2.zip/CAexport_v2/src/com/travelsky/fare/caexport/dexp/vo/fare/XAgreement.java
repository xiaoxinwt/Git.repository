package com.travelsky.fare.caexport.dexp.vo.fare;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.travelsky.fare.caexport.dexp.vo.Adapter.DateFormatToStringAdapter;
import com.travelsky.fare.caexport.dexp.vo.Adapter.StringToTrimAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
	"carrCode","locationCode",
	"refno",
    "agreementdesc",
    "effectivedate",
    "discontinuedate",
    "groupid",
//    "mode",
    "fares"
})

@XmlRootElement(name = "AGREEMENT")
public class XAgreement {
    @XmlElement(name = "CARR_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    private String carrCode;
    @XmlElement(name = "LOCATION_CODE", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    private String locationCode;
	@XmlElement(name = "REF_NO", required = true)
	@XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String refno;
    @XmlElement(name = "AGREEMENT_DESC", required = true)
    @XmlJavaTypeAdapter(StringToTrimAdapter.class)
    protected String agreementdesc;
    @XmlElement(name = "EFFECTIVE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date effectivedate;
    @XmlElement(name = "DISCONTINUE_DATE", required = true)
    @XmlJavaTypeAdapter(DateFormatToStringAdapter.class)
    protected Date discontinuedate;
    @XmlElement(name = "GROUP_ID")
    protected List<String> groupid;
//    @XmlElement(name = "MODE")
    @XmlTransient
    protected Integer mode;
    @XmlElement(name = "FARE", required = true)
    protected List<XFare> fares;
	
    public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getAgreementdesc() {
		return agreementdesc;
	}
	public void setAgreementdesc(String agreementdesc) {
		this.agreementdesc = agreementdesc;
	}
	public Date getEffectivedate() {
		return effectivedate;
	}
	public void setEffectivedate(Date effectivedate) {
		this.effectivedate = effectivedate;
	}
	public Date getDiscontinuedate() {
		return discontinuedate;
	}
	public void setDiscontinuedate(Date discontinuedate) {
		this.discontinuedate = discontinuedate;
	}
	public List<String> getGroupid() {
		return groupid;
	}
	public void setGroupid(List<String> groupid) {
		this.groupid = groupid;
	}
	public Integer getMode() {
		return mode;
	}
	public void setMode(Integer mode) {
		this.mode = mode;
	}
	public List<XFare> getFares() {
		if( fares==null ) fares = new ArrayList<XFare>();
		return fares;
	}
	public void setFares(List<XFare> fares) {
		this.fares = fares;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
}
