package com.travelsky.fare.caexport.dexp.vo.fbr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "oricodetype",
    "oricode",
    "destcodetype",
    "destcode",
    "journeytype",
    "bookingclass",
    "farebasis",
    "distributiontype",
    "agencyid",
    "ifdrbdopenseq",
    "drbdopenseq"
})

@XmlRootElement(name = "BASE_FARE")
public class XBaseFare {
    @XmlElement(name = "ORI_CODE_TYPE", required = true)
    protected Integer oricodetype;
    @XmlElement(name = "ORI_CODE", required = true)
    protected String oricode;
    @XmlElement(name = "DEST_CODE_TYPE", required = true)
    protected Integer destcodetype;
    @XmlElement(name = "DEST_CODE", required = true)
    protected String destcode;
    @XmlElement(name = "JOURNEY_TYPE", required = true)
    protected String journeytype;
    @XmlElement(name = "BOOKING_CLASS", required = true, nillable = true)
    protected String bookingclass;
    @XmlElement(name = "FARE_BASIS", required = true, nillable = true)
    protected String farebasis;
    @XmlElement(name = "DISTRIBUTION_TYPE")
    protected String distributiontype;
    @XmlElement(name = "AGENCY_ID")
    protected String agencyid;
    @XmlElement(name = "IF_D_RBD_OPEN_SEQ")
    protected Integer ifdrbdopenseq;
    @XmlElement(name = "D_RBD_OPEN_SEQ")
    protected String drbdopenseq;
	
    public Integer getOricodetype() {
		return oricodetype;
	}
	public void setOricodetype(Integer oricodetype) {
		this.oricodetype = oricodetype;
	}
	public String getOricode() {
		return oricode;
	}
	public void setOricode(String oricode) {
		this.oricode = oricode;
	}
	public Integer getDestcodetype() {
		return destcodetype;
	}
	public void setDestcodetype(Integer destcodetype) {
		this.destcodetype = destcodetype;
	}
	public String getDestcode() {
		return destcode;
	}
	public void setDestcode(String destcode) {
		this.destcode = destcode;
	}
	public String getJourneytype() {
		return journeytype;
	}
	public void setJourneytype(String journeytype) {
		this.journeytype = journeytype;
	}
	public String getBookingclass() {
		return bookingclass;
	}
	public void setBookingclass(String bookingclass) {
		this.bookingclass = bookingclass;
	}
	public String getFarebasis() {
		return farebasis;
	}
	public void setFarebasis(String farebasis) {
		this.farebasis = farebasis;
	}
	public String getDistributiontype() {
		return distributiontype;
	}
	public void setDistributiontype(String distributiontype) {
		this.distributiontype = distributiontype;
	}
	public String getAgencyid() {
		return agencyid;
	}
	public void setAgencyid(String agencyid) {
		this.agencyid = agencyid;
	}
	public Integer getIfdrbdopenseq() {
		return ifdrbdopenseq;
	}
	public void setIfdrbdopenseq(Integer ifdrbdopenseq) {
		this.ifdrbdopenseq = ifdrbdopenseq;
	}
	public String getDrbdopenseq() {
		return drbdopenseq;
	}
	public void setDrbdopenseq(String drbdopenseq) {
		this.drbdopenseq = drbdopenseq;
	}
}
