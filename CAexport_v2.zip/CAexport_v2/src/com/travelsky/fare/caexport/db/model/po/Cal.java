package com.travelsky.fare.caexport.db.model.po;

public class Cal {
	//Nullable: true	CAL_USED_SECTOR_TYPE
	private Integer calUsedSectorType;
	//Nullable: true	CAL_BOOKING_CLASS
	private String calBookingClass;
	//Nullable: false	CAL_UNUSED_SECTOR_TYPE
	private Integer calUnusedSectorType;
	//Nullable: true	CAL_UNUSED_PFARE_PERCENT
	private Integer calUnusedPfarePercent;
	public Integer getCalUsedSectorType() {
		return calUsedSectorType;
	}
	public void setCalUsedSectorType(Integer calUsedSectorType) {
		this.calUsedSectorType = calUsedSectorType;
	}
	public String getCalBookingClass() {
		return calBookingClass;
	}
	public void setCalBookingClass(String calBookingClass) {
		this.calBookingClass = calBookingClass;
	}
	public Integer getCalUnusedSectorType() {
		return calUnusedSectorType;
	}
	public void setCalUnusedSectorType(Integer calUnusedSectorType) {
		this.calUnusedSectorType = calUnusedSectorType;
	}
	public Integer getCalUnusedPfarePercent() {
		return calUnusedPfarePercent;
	}
	public void setCalUnusedPfarePercent(Integer calUnusedPfarePercent) {
		this.calUnusedPfarePercent = calUnusedPfarePercent;
	}
}
