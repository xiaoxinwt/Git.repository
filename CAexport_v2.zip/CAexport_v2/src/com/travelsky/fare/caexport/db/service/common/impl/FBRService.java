package com.travelsky.fare.caexport.db.service.common.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.dao.common.impl.FBRDaoImpl;
import com.travelsky.fare.caexport.db.model.common.fbr.FBR;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRule;
import com.travelsky.fare.caexport.dexp.vo.fbr.XFareByRuleImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.FBRImportor;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.PageUtil;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class FBRService implements IExport<FBR> {

	private Log log = LogFactory.getLog( this.getClass() );
	private final int pageSize = 10000;
	private CAType catype = null;
	private CAModule camodule = null;
	
	private IFareDao<FBR> dao = new FBRDaoImpl();
	private IImportor<FBR, XFareByRuleImport> importor = new FBRImportor();

	public FBRService(CAType catype) {
		this.catype = catype;
		this.camodule = CAModule.FBR;
	}
	
	@Override
	public Export exportAll(String carrier) throws NoFatalException, FatalException{
		//����fare���Ͳ�����
		ExpType exptype = ExpType.All;
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setExpdate( new Date() );
		return exp;
	}
	
	@Override
	public Export exportAllOfDate(String carrier, Date saleDate) throws NoFatalException, FatalException {
		List<FBR> fbrlist = null;
		XFareByRuleImport imp = null;
		long total = dao.countAllByDate(carrier, saleDate);
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				fbrlist = dao.queryAllByDateForPage(carrier, saleDate, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(fbrlist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier, imp, catype, camodule, exptype, saleDate, pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			fbrlist = dao.queryAllByDate(carrier, saleDate);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(fbrlist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule,exptype, saleDate);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(DateUtil.getYesterday(saleDate));
		exp.setEndDate(saleDate);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {
		List<FBR> fbrlist = null;
		PairDays days = new PairDays(DateUtil.getYesterday(date),date);
		int xmlIdx = 0;
		
		ExpType exptype = ExpType.Inc;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		
		XFareByRuleImport insertimp = null;
		XFareByRuleImport updateimp = null;

		//����Inc�е���������
		long inserttotal = dao.countInsertByDays(carrier, days);
		if(inserttotal>0 && inserttotal>pageSize){
			int pages = PageUtil.getPageCount(inserttotal, pageSize);
			long querystart = 0L;
			long xmlstart = 0L;
			boolean islast = false;
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				islast = (pageNum==pages);
				querystart = System.currentTimeMillis();
				fbrlist = dao.queryInsertByDaysForPage(carrier, days, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				insertimp = importor.getImport(fbrlist, carrier,this.catype, ActionType.Insert );
				count += importor.getCount();
				
				if(!islast){
					xmlstart = System.currentTimeMillis();
					ExportUtil.ExportToXmlForPage(carrier, insertimp, catype, camodule, exptype, date, ++xmlIdx);
					toxmlcost += (System.currentTimeMillis()-xmlstart);
				}
			}
			//���һҳ�����ݼ��д���
		}
		
		//����Inc�е��޸Ĳ���
		long updatetotal = dao.countUpdateByDays(carrier, days);
		if( updatetotal>0 && updatetotal>pageSize ){
			int pages = PageUtil.getPageCount(updatetotal, pageSize);
			long querystart = 0L;
			long xmlstart = 0L;
			boolean islast = false;
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				islast = (pageNum==pages);
				querystart = System.currentTimeMillis();
				fbrlist = dao.queryUpdateByDaysForPage(carrier, days, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				updateimp = importor.getImport(fbrlist, carrier,this.catype,ActionType.Update);
				count += importor.getCount();
				
				if(!islast){
					xmlstart = System.currentTimeMillis();
					ExportUtil.ExportToXmlForPage(carrier, updateimp, catype, camodule, exptype, date, ++xmlIdx);
					toxmlcost += (System.currentTimeMillis()-xmlstart);
				}
			}
			//���һҳ�����ݣ����д���
		}
		
		//�����������Է�ҳ���Լ�֮ǰ��ҳ�������µ����һҳ������(����������һҳ)�ĺϲ������·�ҳ
		long querystart = 0L;
		if( insertimp==null ){
			querystart = System.currentTimeMillis();
			List<FBR> fbrInsertList = dao.queryInsertByDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			count += importor.getCount();
			insertimp = importor.getImport( fbrInsertList, carrier, catype, ActionType.Insert );
		}
		if( updateimp==null ){
			querystart = System.currentTimeMillis();
			List<FBR> fbrUpdateList = dao.queryUpdateByDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			updateimp = importor.getImport( fbrUpdateList, carrier, catype, ActionType.Update );
			count += importor.getCount();
		}
		
		
		List<XFareByRule> otherList = new ArrayList<XFareByRule>();
		if( insertimp!=null ){
			otherList.addAll( insertimp.getFarebyrule() );
		}
		if( updateimp!=null ){
			otherList.addAll( updateimp.getFarebyrule() );
		}
		
		
		//���·�ҳ
		XFareByRuleImport lastimp = null;
		long xmlstart = 0L;
		if( otherList.size()>pageSize ){
			int pages = PageUtil.getPageCount(otherList.size(), pageSize);
			List<XFareByRule> pagelist = null;
			boolean islast = false;
			xmlstart = System.currentTimeMillis();
			for (int i = 1; i <= pages; i++) {
				islast = (i==pages);
				if(!islast){
					pagelist = otherList.subList((i-1)*pageSize, i*pageSize );
				}else{
					pagelist = otherList.subList((i-1)*pageSize,otherList.size());
				}
				lastimp = new XFareByRuleImport();
				lastimp.setFarebyrule( pagelist );
				ExportUtil.ExportToXmlForPage(carrier, updateimp, catype, camodule, exptype, date, ++xmlIdx);
			}
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}else{
			lastimp = new XFareByRuleImport();
			lastimp.setFarebyrule( otherList );
			xmlstart = System.currentTimeMillis();
			if( xmlIdx>0 ){
				ExportUtil.ExportToXmlForPage(carrier, updateimp, catype, camodule, exptype, date, ++xmlIdx);				
			}else{
				ExportUtil.ExportToXml(carrier, updateimp, catype, camodule, exptype, date);
			}
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate( DateUtil.getYesterday(date) );
		exp.setEndDate( date );
		exp.setExpectTotal( inserttotal+updatetotal );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		long total = 0;
		Export exp = new Export(carrier, catype, camodule ,ExpType.Inc);
		List<Date> dates = DateUtil.getDates(days.getFirstDate(),days.getLastDate());
		//�ֱ��ѯÿһ���ȫ�������ϲ�Ϊ�ܵ�ȫ��
		if(dates!=null && dates.size()>0){
			Export tmpexp = null;
			for(Date date : dates){
				tmpexp = exportIncOfDate(carrier,date);
				querycost += tmpexp.getCount();
				toxmlcost += tmpexp.getToxmlCost();
				total += tmpexp.getExpectTotal();
			}
		}
		exp.setStartDate(days.getFirstDate());
		exp.setEndDate( days.getLastDate() );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		IExport<FBR> exportor = new FBRService( CAType.Easyfare );
		Date date = DateUtil.getDate("2015-01-01");
		Date enddate = DateUtil.getDate("2015-01-06");
		PairDays days = new PairDays( date , enddate);
		String carrier = "MU";

		
		Export exp = null;
//		exp = exportor.exportAll(carrier);
		exp = exportor.exportAllOfDate(carrier, date);
//		exp = exportor.exportIncOfDate(carrier, date);
//		exp = exportor.exportIncOfDays(carrier, days);
		ExportUtil.writeInfo(exp);
		
	}
	
}
