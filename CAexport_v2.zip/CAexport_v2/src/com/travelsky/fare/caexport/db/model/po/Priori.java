package com.travelsky.fare.caexport.db.model.po;

public class Priori {
	//Nullable: true	PRIORITY_TYPE
	private Integer priorityType;
	//Nullable: true	PRIORITY_LIST
	private String priorityList;
	public Integer getPriorityType() {
		return priorityType;
	}
	public void setPriorityType(Integer priorityType) {
		this.priorityType = priorityType;
	}
	public String getPriorityList() {
		return priorityList;
	}
	public void setPriorityList(String priorityList) {
		this.priorityList = priorityList;
	}

}
