package com.travelsky.fare.caexport.db.model.common.rule;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class RuleEndorsemtRestriction implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: false	RESTRICTION_ID
	private Integer restrictionId;
	//Nullable: false	RULE_SEQ_ID
	private Integer ruleSeqId;
	private EndorsemtRestriction endorsemtRestriction;	//һ��һ
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public Integer getRestrictionId() {
		return restrictionId;
	}
	public void setRestrictionId(Integer restrictionId) {
		this.restrictionId = restrictionId;
	}
	public Integer getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(Integer ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public EndorsemtRestriction getEndorsemtRestriction() {
		return endorsemtRestriction;
	}
	public void setEndorsemtRestriction(EndorsemtRestriction endorsemtRestriction) {
		this.endorsemtRestriction = endorsemtRestriction;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "RuleEndorsemtRestriction [locationCode=" + locationCode
				+ ", ruleId=" + ruleId + ", restrictionId=" + restrictionId
				+ ", ruleSeqId=" + ruleSeqId + ", endorsemtRestriction="
				+ endorsemtRestriction + "]";
	}
}