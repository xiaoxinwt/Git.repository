package com.travelsky.fare.caexport.db.model.po;

public class YCabin {

	//Nullable: true	Y_CABIN_PRICE_CHOOSE_IF
	private Integer yCabinPriceChooseIf;
	//Nullable: true	MIN_Y_CABIN_PRICE
	private Integer minYCabinPrice;
	//Nullable: true	MAX_Y_CABIN_PRICE
	private Integer maxYCabinPrice;
	public Integer getyCabinPriceChooseIf() {
		return yCabinPriceChooseIf;
	}
	public void setyCabinPriceChooseIf(Integer yCabinPriceChooseIf) {
		this.yCabinPriceChooseIf = yCabinPriceChooseIf;
	}
	public Integer getMinYCabinPrice() {
		return minYCabinPrice;
	}
	public void setMinYCabinPrice(Integer minYCabinPrice) {
		this.minYCabinPrice = minYCabinPrice;
	}
	public Integer getMaxYCabinPrice() {
		return maxYCabinPrice;
	}
	public void setMaxYCabinPrice(Integer maxYCabinPrice) {
		this.maxYCabinPrice = maxYCabinPrice;
	}

}
