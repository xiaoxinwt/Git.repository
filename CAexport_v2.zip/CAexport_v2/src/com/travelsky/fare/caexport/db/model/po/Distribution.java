package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

public class Distribution {

	//Nullable: true	DISTRIBUTION_TYPE
	private String distributionType;
	//Nullable: true	DISTRIBUTION_STATUS
	private Integer distributionStatus;
	//Nullable: true	DISTRIBUTION_DATE
	private Date distributionDate;
	public Integer getDistributionStatus() {
		return distributionStatus;
	}
	public void setDistributionStatus(Integer distributionStatus) {
		this.distributionStatus = distributionStatus;
	}
	public String getDistributionType() {
		return distributionType;
	}
	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}
	public Date getDistributionDate() {
		return distributionDate;
	}
	public void setDistributionDate(Date distributionDate) {
		this.distributionDate = distributionDate;
	}

}
