package com.travelsky.fare.caexport.db.model.airtis_fare;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class PNFare extends AbstractPxFare implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	XBG_RATE
	private Integer xbgRate;
	
	public Integer getXbgRate() {
		return xbgRate;
	}
	public void setXbgRate(Integer xbgRate) {
		this.xbgRate = xbgRate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "PNFare [xbgRate=" + xbgRate + ", getCarrCode()="
				+ getCarrCode() + ", getFileNo()=" + getFileNo()
				+ ", getArchvInd()=" + getArchvInd() + ", getRptFileNo()="
				+ getRptFileNo() + ", getRptFrom()=" + getRptFrom()
				+ ", getRptDate()=" + getRptDate() + ", getFare()=" + getFare()
				+ ", getFareNo()=" + getFareNo() + ", getEffDate()="
				+ getEffDate() + ", getDiscDate()=" + getDiscDate()
				+ ", getFirstSaleDate()=" + getFirstSaleDate()
				+ ", getLastSaleDate()=" + getLastSaleDate() + ", getMoney()="
				+ getMoney() + ", getOri()=" + getOri() + ", getDest()="
				+ getDest() + ", getTravelType()=" + getTravelType()
				+ ", getAprvDate()=" + getAprvDate() + ", getAprvInd()="
				+ getAprvInd() + ", getAttribute1()=" + getAttribute1()
				+ ", getCsActivateDate()=" + getCsActivateDate()
				+ ", getCsSourceFarePk()=" + getCsSourceFarePk()
				+ ", getCreateDate()=" + getCreateDate() + ", getCreateBy()="
				+ getCreateBy() + ", getLastUpdateDate()="
				+ getLastUpdateDate() + ", getLastUpdateBy()="
				+ getLastUpdateBy() + ", getFlag()=" + getFlag()
				+ ", getFareBasis()=" + getFareBasis() + ", getFareType()="
				+ getFareType() + ", getAttribute2()=" + getAttribute2()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
}