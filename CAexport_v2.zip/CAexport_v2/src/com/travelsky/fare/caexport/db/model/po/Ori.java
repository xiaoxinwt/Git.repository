package com.travelsky.fare.caexport.db.model.po;

public class Ori {
	//Nullable: true	ORI_CODE_TYPE
	private Integer oriCodeType;
	//Nullable: true	ORI_CODE
	private String oriCode;
	//Nullable: true	ORI_CITY_CODE
	private String oriCityCode;
	public Integer getOriCodeType() {
		return oriCodeType;
	}
	public void setOriCodeType(Integer oriCodeType) {
		this.oriCodeType = oriCodeType;
	}
	public String getOriCode() {
		return oriCode;
	}
	public void setOriCode(String oriCode) {
		this.oriCode = oriCode;
	}
	public String getOriCityCode() {
		return oriCityCode;
	}
	public void setOriCityCode(String oriCityCode) {
		this.oriCityCode = oriCityCode;
	}
}
