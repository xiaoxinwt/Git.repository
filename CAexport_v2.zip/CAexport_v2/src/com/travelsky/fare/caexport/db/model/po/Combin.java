package com.travelsky.fare.caexport.db.model.po;

public class Combin {
	//Nullable: true	COMBINE_OPEN_JAW_FLAG
	private Integer combineOpenJawFlag;
	//Nullable: true	COMBINE_ROUND_TRIP_FLAG
	private Integer combineRoundTripFlag;
	private Integer seqId;
	public Combin(Integer openJawFlag, Integer roundTripFlag,Integer seqId) {
		this.combineOpenJawFlag = openJawFlag;
		this.combineRoundTripFlag = roundTripFlag;
		this.seqId = seqId;
	}
	public Combin() {
	}
	public Integer getCombineOpenJawFlag() {
		return combineOpenJawFlag;
	}
	public void setCombineOpenJawFlag(Integer combineOpenJawFlag) {
		this.combineOpenJawFlag = combineOpenJawFlag;
	}
	public Integer getCombineRoundTripFlag() {
		return combineRoundTripFlag;
	}
	public void setCombineRoundTripFlag(Integer combineRoundTripFlag) {
		this.combineRoundTripFlag = combineRoundTripFlag;
	}
	public Integer getSeqId() {
		return seqId;
	}
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}
}
