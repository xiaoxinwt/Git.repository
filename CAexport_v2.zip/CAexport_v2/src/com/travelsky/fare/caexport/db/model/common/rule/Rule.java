package com.travelsky.fare.caexport.db.model.common.rule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.travelsky.fare.caexport.db.model.common.refund.Refund;
import com.travelsky.fare.caexport.db.model.common.reissue.Reissue;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class Rule implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: true	MINIMUM_STAY
	private Integer minimumStay;
	//Nullable: true	MINIMUM_STAY_UNIT
	private String minimumStayUnit;
	//Nullable: true	MAXIMUM_STAY
	private Integer maximumStay;
	//Nullable: true	MAXIMUM_STAY_UNIT
	private String maximumStayUnit;
	//Nullable: true	CONSTRUCTION_ADDONS
	private Integer constructionAddons;
	//Nullable: true	DAY_OF_WEEK_RESTRICTION
	private Integer dayOfWeekRestriction;
	//Nullable: true	ADVANCE_PURCHASE
	private Integer advancePurchase;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: false	RULE_TYPE
	private Integer ruleType;
	//Nullable: true	STATUS
	private Integer status;
	//Nullable: true	DAY_OF_WEEK_RESTRICTION_IN
	private Integer dayOfWeekRestrictionIn;
	//Nullable: true	FARES_COMBINATION_FLAG
	private Integer faresCombinationFlag;
	//Nullable: false	GROUP_FLAG
	private Integer groupFlag;
	//Nullable: true	GROUP_FROM
	private Integer groupFrom;
	//Nullable: true	GROUP_TO
	private Integer groupTo;
	//Nullable: true	SEPARATE_SALE_TYPE
	private Integer separateSaleType;
	//Nullable: true	REFUND_RULE_ID
	private String refundRuleId;
	//Nullable: true	REISSUE_ID
	private String reissueId;
	//Nullable: true	COMBINE_OPEN_JAW_FLAG
	private Integer combineOpenJawFlag;
	//Nullable: true	COMBINE_ROUND_TRIP_FLAG
	private Integer combineRoundTripFlag;
	//Nullable: true	MAX_ADVANCED_PURCHASE
	private Integer maxAdvancedPurchase;
	//Nullable: false	MAX_ADVANCED_PURCHASE_UNIT
	private String maxAdvancedPurchaseUnit;
	//Nullable: false	MIN_ADVANCED_PURCHASE_UNIT
	private String minAdvancedPurchaseUnit;
	//Nullable: false	OPEN_JAW_FLAG
	private Integer openJawFlag;
	//Nullable: false	CANDIDATE_FLAG
	private Integer candidateFlag;
	//Nullable: true	CODE_SHARE
	private Integer codeShare;
	//Nullable: true	APPCXR_CODE_SHARE
	private String appcxrCodeShare;
	//Nullable: true	TRAVEL_COMPLETE_DAYS_RESTR
	private Integer travelCompleteDaysRestr;
	//Nullable: true	RULE_ID_NO
	private String ruleIdNo;
	//Nullable: true	SECTOR_RANGE_LOWER
	private Integer sectorRangeLower;
	//Nullable: true	SECTOR_RANGE_UPPER
	private Integer sectorRangeUpper;
	//Nullable: true	FORBIDDEN_JOURNEY_FLAG
	private Integer forbiddenJourneyFlag;
	//Nullable: true	POSITION_LIMIT_TYPE
	private Integer positionLimitType;
	//Nullable: true	POSITION_LIMIT_SPEC
	private Integer positionLimitSpec;
	//Nullable: true	CHARTER_FLIGHT_FLAG
	private Integer charterFlightFlag;
	//Nullable: true	RULE_DESC
	private String ruleDesc;
	//Nullable: false	RULE_SEQ_ID
	private BigDecimal ruleSeqId;
	//Nullable: false	EFFECTIVE_DATE
	private Date effectiveDate;
	//Nullable: false	DISCONTINUE_DATE
	private Date discontinueDate;
	//Nullable: true	XML_IMPORT_FLAG
	private Integer xmlImportFlag;
	//Nullable: true	WHEN_CREATE
	private Date whenCreate;
	//Nullable: true	WHO_CREATE
	private String whoCreate;
	//Nullable: true	WHERE_CREATE
	private String whereCreate;
	//Nullable: true	TICKET_TIME_LIMIT_VALUE
	private Integer ticketTimeLimitValue;
	//Nullable: true	TICKET_TIME_LIMIT_UNIT
	private Integer ticketTimeLimitUnit;
	//Nullable: true	TICKET_CARR_LIMIT
	private Integer ticketCarrLimit;
	//Nullable: true	FLIGHTNO_TYPE
	private String flightnoType;
	//Nullable: true	FLIGHTNO_TYPE_IN
	private String flightnoTypeIn;
	private List<BlackoutPeriod> blackouts = new ArrayList<BlackoutPeriod>();
	private List<BlackoutPeriodIn> blackins = new ArrayList<BlackoutPeriodIn>();
	private List<ExFlightNo> exouts = new ArrayList<ExFlightNo>();
	private List<ExFlightNoIn> exins = new ArrayList<ExFlightNoIn>();
	private List<FlightNoRestriction> flightouts = new ArrayList<FlightNoRestriction>();
	private List<FlightNoRestrictionIn> flightins = new ArrayList<FlightNoRestrictionIn>();
	private List<HourRestriction> hourouts = new ArrayList<HourRestriction>();
	private List<HourRestrictionIn> hourins = new ArrayList<HourRestrictionIn>();
	private List<Seasonality> seasonouts = new ArrayList<Seasonality>();
	private List<SeasonalityIn> seasonins = new ArrayList<SeasonalityIn>();
	private List<Textual> texts = new ArrayList<Textual>();
	private List<CombinationEntry> combinas = new ArrayList<CombinationEntry>();
	private List<Refund> refunds = new ArrayList<Refund>();
	private List<Reissue> reissues = new ArrayList<Reissue>();
	private List<String> restrictionDesc = new ArrayList<String>();
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String id) {
		this.ruleId = id;
	}
	public Integer getMinimumStay() {
		return minimumStay;
	}
	public void setMinimumStay(Integer minimumStay) {
		this.minimumStay = minimumStay;
	}
	public String getMinimumStayUnit() {
		return minimumStayUnit;
	}
	public void setMinimumStayUnit(String minimumStayUnit) {
		this.minimumStayUnit = minimumStayUnit;
	}
	public Integer getMaximumStay() {
		return maximumStay;
	}
	public void setMaximumStay(Integer maximumStay) {
		this.maximumStay = maximumStay;
	}
	public String getMaximumStayUnit() {
		return maximumStayUnit;
	}
	public void setMaximumStayUnit(String maximumStayUnit) {
		this.maximumStayUnit = maximumStayUnit;
	}
	public Integer getConstructionAddons() {
		return constructionAddons;
	}
	public void setConstructionAddons(Integer constructionAddons) {
		this.constructionAddons = constructionAddons;
	}
	public Integer getDayOfWeekRestriction() {
		return dayOfWeekRestriction;
	}
	public void setDayOfWeekRestriction(Integer dayOfWeekRestriction) {
		this.dayOfWeekRestriction = dayOfWeekRestriction;
	}
	public Integer getAdvancePurchase() {
		return advancePurchase;
	}
	public void setAdvancePurchase(Integer advancePurchase) {
		this.advancePurchase = advancePurchase;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer type) {
		this.ruleType = type;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getDayOfWeekRestrictionIn() {
		return dayOfWeekRestrictionIn;
	}
	public void setDayOfWeekRestrictionIn(Integer dayOfWeekRestrictionIn) {
		this.dayOfWeekRestrictionIn = dayOfWeekRestrictionIn;
	}
	public Integer getFaresCombinationFlag() {
		return faresCombinationFlag;
	}
	public void setFaresCombinationFlag(Integer faresCombinationFlag) {
		this.faresCombinationFlag = faresCombinationFlag;
	}
	public Integer getGroupFlag() {
		return groupFlag;
	}
	public void setGroupFlag(Integer groupFlag) {
		this.groupFlag = groupFlag;
	}
	public Integer getGroupFrom() {
		return groupFrom;
	}
	public void setGroupFrom(Integer groupFrom) {
		this.groupFrom = groupFrom;
	}
	public Integer getGroupTo() {
		return groupTo;
	}
	public void setGroupTo(Integer groupTo) {
		this.groupTo = groupTo;
	}
	public Integer getSeparateSaleType() {
		return separateSaleType;
	}
	public void setSeparateSaleType(Integer separateSaleType) {
		this.separateSaleType = separateSaleType;
	}
	public String getRefundRuleId() {
		return refundRuleId;
	}
	public void setRefundRuleId(String refundRuleId) {
		this.refundRuleId = refundRuleId;
	}
	public String getReissueId() {
		return reissueId;
	}
	public void setReissueId(String reissueId) {
		this.reissueId = reissueId;
	}
	public Integer getCombineOpenJawFlag() {
		return combineOpenJawFlag;
	}
	public void setCombineOpenJawFlag(Integer combineOpenJawFlag) {
		this.combineOpenJawFlag = combineOpenJawFlag;
	}
	public Integer getCombineRoundTripFlag() {
		return combineRoundTripFlag;
	}
	public void setCombineRoundTripFlag(Integer combineRoundTripFlag) {
		this.combineRoundTripFlag = combineRoundTripFlag;
	}
	public Integer getMaxAdvancedPurchase() {
		return maxAdvancedPurchase;
	}
	public void setMaxAdvancedPurchase(Integer maxAdvancedPurchase) {
		this.maxAdvancedPurchase = maxAdvancedPurchase;
	}
	public String getMaxAdvancedPurchaseUnit() {
		return maxAdvancedPurchaseUnit;
	}
	public void setMaxAdvancedPurchaseUnit(String maxAdvancedPurchaseUnit) {
		this.maxAdvancedPurchaseUnit = maxAdvancedPurchaseUnit;
	}
	public String getMinAdvancedPurchaseUnit() {
		return minAdvancedPurchaseUnit;
	}
	public void setMinAdvancedPurchaseUnit(String minAdvancedPurchaseUnit) {
		this.minAdvancedPurchaseUnit = minAdvancedPurchaseUnit;
	}
	public Integer getOpenJawFlag() {
		return openJawFlag;
	}
	public void setOpenJawFlag(Integer openJawFlag) {
		this.openJawFlag = openJawFlag;
	}
	public Integer getCandidateFlag() {
		return candidateFlag;
	}
	public void setCandidateFlag(Integer candidateFlag) {
		this.candidateFlag = candidateFlag;
	}
	public Integer getCodeShare() {
		return codeShare;
	}
	public void setCodeShare(Integer codeShare) {
		this.codeShare = codeShare;
	}
	public String getAppcxrCodeShare() {
		return appcxrCodeShare;
	}
	public void setAppcxrCodeShare(String appcxrCodeShare) {
		this.appcxrCodeShare = appcxrCodeShare;
	}
	public Integer getTravelCompleteDaysRestr() {
		return travelCompleteDaysRestr;
	}
	public void setTravelCompleteDaysRestr(Integer travelCompleteDaysRestr) {
		this.travelCompleteDaysRestr = travelCompleteDaysRestr;
	}
	public String getRuleIdNo() {
		return ruleIdNo;
	}
	public void setRuleIdNo(String idNo) {
		this.ruleIdNo = idNo;
	}
	public Integer getSectorRangeLower() {
		return sectorRangeLower;
	}
	public void setSectorRangeLower(Integer sectorRangeLower) {
		this.sectorRangeLower = sectorRangeLower;
	}
	public Integer getSectorRangeUpper() {
		return sectorRangeUpper;
	}
	public void setSectorRangeUpper(Integer sectorRangeUpper) {
		this.sectorRangeUpper = sectorRangeUpper;
	}
	public Integer getForbiddenJourneyFlag() {
		return forbiddenJourneyFlag;
	}
	public void setForbiddenJourneyFlag(Integer forbiddenJourneyFlag) {
		this.forbiddenJourneyFlag = forbiddenJourneyFlag;
	}
	public Integer getPositionLimitType() {
		return positionLimitType;
	}
	public void setPositionLimitType(Integer positionLimitType) {
		this.positionLimitType = positionLimitType;
	}
	public Integer getPositionLimitSpec() {
		return positionLimitSpec;
	}
	public void setPositionLimitSpec(Integer positionLimitSpec) {
		this.positionLimitSpec = positionLimitSpec;
	}
	public Integer getCharterFlightFlag() {
		return charterFlightFlag;
	}
	public void setCharterFlightFlag(Integer charterFlightFlag) {
		this.charterFlightFlag = charterFlightFlag;
	}
	public String getRuleDesc() {
		return ruleDesc;
	}
	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}
	public BigDecimal getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(BigDecimal ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getDiscontinueDate() {
		return discontinueDate;
	}
	public void setDiscontinueDate(Date discontinueDate) {
		this.discontinueDate = discontinueDate;
	}
	public Integer getXmlImportFlag() {
		return xmlImportFlag;
	}
	public void setXmlImportFlag(Integer xmlImportFlag) {
		this.xmlImportFlag = xmlImportFlag;
	}
	public Date getWhenCreate() {
		return whenCreate;
	}
	public void setWhenCreate(Date whenCreate) {
		this.whenCreate = whenCreate;
	}
	public String getWhoCreate() {
		return whoCreate;
	}
	public void setWhoCreate(String whoCreate) {
		this.whoCreate = whoCreate;
	}
	public String getWhereCreate() {
		return whereCreate;
	}
	public void setWhereCreate(String whereCreate) {
		this.whereCreate = whereCreate;
	}
	public Integer getTicketTimeLimitValue() {
		return ticketTimeLimitValue;
	}
	public void setTicketTimeLimitValue(Integer ticketTimeLimitValue) {
		this.ticketTimeLimitValue = ticketTimeLimitValue;
	}
	public Integer getTicketTimeLimitUnit() {
		return ticketTimeLimitUnit;
	}
	public void setTicketTimeLimitUnit(Integer ticketTimeLimitUnit) {
		this.ticketTimeLimitUnit = ticketTimeLimitUnit;
	}
	public Integer getTicketCarrLimit() {
		return ticketCarrLimit;
	}
	public void setTicketCarrLimit(Integer ticketCarrLimit) {
		this.ticketCarrLimit = ticketCarrLimit;
	}
	public String getFlightnoType() {
		return flightnoType;
	}
	public void setFlightnoType(String flightnoType) {
		this.flightnoType = flightnoType;
	}
	public String getFlightnoTypeIn() {
		return flightnoTypeIn;
	}
	public void setFlightnoTypeIn(String flightnoTypeIn) {
		this.flightnoTypeIn = flightnoTypeIn;
	}
	public List<Textual> getTexts() {
		return texts;
	}
	public void setTexts(List<Textual> texts) {
		this.texts = texts;
	}
	public List<BlackoutPeriod> getBlackouts() {
		return blackouts;
	}
	public void setBlackouts(List<BlackoutPeriod> blackouts) {
		this.blackouts = blackouts;
	}
	public List<BlackoutPeriodIn> getBlackins() {
		return blackins;
	}
	public void setBlackins(List<BlackoutPeriodIn> blackins) {
		this.blackins = blackins;
	}
	public List<ExFlightNo> getExouts() {
		return exouts;
	}
	public void setExouts(List<ExFlightNo> exouts) {
		this.exouts = exouts;
	}
	public List<ExFlightNoIn> getExins() {
		return exins;
	}
	public void setExins(List<ExFlightNoIn> exins) {
		this.exins = exins;
	}
	public List<FlightNoRestriction> getFlightouts() {
		return flightouts;
	}
	public void setFlightouts(List<FlightNoRestriction> flightouts) {
		this.flightouts = flightouts;
	}
	public List<FlightNoRestrictionIn> getFlightins() {
		return flightins;
	}
	public void setFlightins(List<FlightNoRestrictionIn> flightins) {
		this.flightins = flightins;
	}
	public List<HourRestriction> getHourouts() {
		return hourouts;
	}
	public void setHourouts(List<HourRestriction> hourouts) {
		this.hourouts = hourouts;
	}
	public List<HourRestrictionIn> getHourins() {
		return hourins;
	}
	public void setHourins(List<HourRestrictionIn> hourins) {
		this.hourins = hourins;
	}
	public List<Seasonality> getSeasonouts() {
		return seasonouts;
	}
	public void setSeasonouts(List<Seasonality> seasonouts) {
		this.seasonouts = seasonouts;
	}
	public List<SeasonalityIn> getSeasonins() {
		return seasonins;
	}
	public void setSeasonins(List<SeasonalityIn> seasonins) {
		this.seasonins = seasonins;
	}
	public List<Refund> getRefunds() {
		return refunds;
	}
	public void setRefunds(List<Refund> refunds) {
		this.refunds = refunds;
	}
	public List<Reissue> getReissues() {
		return reissues;
	}
	public void setReissues(List<Reissue> reissues) {
		this.reissues = reissues;
	}
	public List<String> getRestrictionDesc() {
		return restrictionDesc;
	}
	public void setRestrictionDesc(List<String> restrictionDesc) {
		this.restrictionDesc = restrictionDesc;
	}
	public List<CombinationEntry> getCombinas() {
		return combinas;
	}
	public void setCombinas(List<CombinationEntry> combinas) {
		this.combinas = combinas;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}