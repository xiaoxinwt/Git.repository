package com.travelsky.fare.caexport.db.model.po;

public class Dest {
	//Nullable: true	DEST_CODE_TYPE
	private Integer destCodeType;
	//Nullable: true	DEST_CODE
	private String destCode;
	//Nullable: true	DEST_CITY_CODE
	private String destCityCode;
	
	public Integer getDestCodeType() {
		return destCodeType;
	}
	public void setDestCodeType(Integer destCodeType) {
		this.destCodeType = destCodeType;
	}
	public String getDestCode() {
		return destCode;
	}
	public void setDestCode(String destCode) {
		this.destCode = destCode;
	}
	public String getDestCityCode() {
		return destCityCode;
	}
	public void setDestCityCode(String destCityCode) {
		this.destCityCode = destCityCode;
	}
}
