package com.travelsky.fare.caexport.db.model.po;

public class Commission {
	//Nullable: true	BASE_COMMISSION_AMT
	private Integer baseCommissionAmt;
	//Nullable: true	BASE_COMMISSION_PCT
	private Integer baseCommissionPct;
	//Nullable: true	ADDT_COMMISSION_AMT
	private Integer addtCommissionAmt;
	//Nullable: true	ADDT_COMMISSION_PCT
	private Integer addtCommissionPct;
	public Integer getBaseCommissionAmt() {
		return baseCommissionAmt;
	}
	public void setBaseCommissionAmt(Integer baseCommissionAmt) {
		this.baseCommissionAmt = baseCommissionAmt;
	}
	public Integer getBaseCommissionPct() {
		return baseCommissionPct;
	}
	public void setBaseCommissionPct(Integer baseCommissionPct) {
		this.baseCommissionPct = baseCommissionPct;
	}
	public Integer getAddtCommissionAmt() {
		return addtCommissionAmt;
	}
	public void setAddtCommissionAmt(Integer addtCommissionAmt) {
		this.addtCommissionAmt = addtCommissionAmt;
	}
	public Integer getAddtCommissionPct() {
		return addtCommissionPct;
	}
	public void setAddtCommissionPct(Integer addtCommissionPct) {
		this.addtCommissionPct = addtCommissionPct;
	}
}
