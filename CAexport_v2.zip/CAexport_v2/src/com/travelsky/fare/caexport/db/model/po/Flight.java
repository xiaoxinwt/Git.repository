package com.travelsky.fare.caexport.db.model.po;

public class Flight {
	//Nullable: true	FLIGHT_LAUNCH_TAG
	private String flightLaunchTag;
	//Nullable: true	FLIGHT_LAUNCH_UNIT
	private String flightLaunchUnit;
	//Nullable: true	FLIGHT_LAUNCH_NUMBER
	private Integer flightLaunchNumber;
	public String getFlightLaunchTag() {
		return flightLaunchTag;
	}
	public void setFlightLaunchTag(String flightLaunchTag) {
		this.flightLaunchTag = flightLaunchTag;
	}
	public String getFlightLaunchUnit() {
		return flightLaunchUnit;
	}
	public void setFlightLaunchUnit(String flightLaunchUnit) {
		this.flightLaunchUnit = flightLaunchUnit;
	}
	public Integer getFlightLaunchNumber() {
		return flightLaunchNumber;
	}
	public void setFlightLaunchNumber(Integer flightLaunchNumber) {
		this.flightLaunchNumber = flightLaunchNumber;
	}

}
