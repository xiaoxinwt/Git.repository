package com.travelsky.fare.caexport.db.service.easyfare.impl;

import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.FareDaoImpl;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.EasyfareFareImportor;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.PageUtil;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class EasyfareFareService implements IExport<Fare> {
	
	private Log log = LogFactory.getLog( this.getClass() );
	private final int pageSize = 5000;
	private CAType catype = null;
	private CAModule camodule = null;
	
	private IFareDao<Fare> dao = new FareDaoImpl();
	private IImportor<Fare, XFareImport> importor = new EasyfareFareImportor();

	public EasyfareFareService() {
		this.catype = CAType.Easyfare;
		this.camodule = CAModule.Fare;
	}
	
	@Override
	public Export exportAll(String carrier) throws NoFatalException, FatalException{
		//����fare���Ͳ�����
		return null;
	}
	
	@Override
	public Export exportAllOfDate(String carrier, Date saleDate) throws NoFatalException, FatalException {
		ActionType actype = ActionType.Insert;
		ExpType exptype = ExpType.All;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		
		List<Fare> farelist = null;
		XFareImport imp = null;
		long total = dao.countAllByDate(carrier, saleDate);
		if(total>pageSize){
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				farelist = dao.queryAllByDateForPage(carrier, saleDate, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(farelist, carrier,this.catype, actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier, imp, catype, camodule, exptype, saleDate, pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			farelist = dao.queryAllByDate(carrier, saleDate);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(farelist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype, saleDate);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(DateUtil.getYesterday(saleDate));
		exp.setEndDate(saleDate);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {

		ActionType actype = null;
		ExpType exptype = ExpType.Inc;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		
		List<Fare> farelist = null;
		XFareImport imp = null;
		PairDays days = new PairDays(DateUtil.getYesterday(date),date);
		
		//����Inc�е���������
		long inserttotal = dao.countInsertByDays(carrier, days);
		actype = ActionType.Insert;
		if(inserttotal>pageSize){
			int pages = PageUtil.getPageCount(inserttotal, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				farelist = dao.queryInsertByDaysForPage(carrier, days, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(farelist, carrier,this.catype, actype );
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier, imp, catype, camodule, exptype, date, pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			farelist = dao.queryInsertByDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(farelist, carrier,this.catype, actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype, date);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		
		//����Inc�е��޸Ĳ���
		long updatetotal = dao.countUpdateByDays(carrier, days);
		actype = ActionType.Update;
		if(updatetotal>pageSize){
			int pages = PageUtil.getPageCount(updatetotal, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				farelist = dao.queryUpdateByDaysForPage(carrier, days, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(farelist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier, imp, catype, camodule, exptype, date, pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			farelist = dao.queryUpdateByDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(farelist, carrier,this.catype, actype );
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype, date);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate( DateUtil.getYesterday(date) );
		exp.setEndDate( date );
		exp.setExpectTotal( inserttotal+updatetotal );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		Export exp = new Export(carrier, catype, camodule ,ExpType.Inc);
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		long total = 0;
		List<Date> dates = DateUtil.getDates(days.getFirstDate(),days.getLastDate());
		//�ֱ��ѯÿһ���ȫ�������ϲ�Ϊ�ܵ�ȫ��
		if(dates!=null && dates.size()>0){
			Export tmpexp = null;
			for(Date date : dates){
				tmpexp = exportIncOfDate(carrier,date);
				querycost += tmpexp.getCount();
				toxmlcost += tmpexp.getToxmlCost();
				total += tmpexp.getExpectTotal();
			}
		}
		exp.setStartDate(days.getFirstDate());
		exp.setEndDate( days.getLastDate() );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		String carrier = "CA";
		IExport<Fare> export = new EasyfareFareService();
		Date date = DateUtil.getDate("2015-01-01");
		Date enddate = DateUtil.getDate("2015-01-06");
		PairDays days = new PairDays( date , enddate);

//		export.exportAll(carrier);
//		export.exportAllOfDate(carrier, enddate);
		export.exportIncOfDate(carrier, enddate);
//		export.exportIncOfDays(carrier, days);
		
	}

}
