package com.travelsky.fare.caexport.db.model.easyfare_fare;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class FareRouteFlightNo implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: false	FARE_REC_NO
	private Integer fareRecNo;
	//Nullable: false	ROUTE_NO
	private Integer routeNo;
	//Nullable: false	ENTRY_NO
	private Integer entryNo;
	//Nullable: false	FLIGHT_ENTRY_NO
	private Integer flightEntryNo;
	//Nullable: false	CARRIER_CODE
	private String carrierCode;
	//Nullable: true	AP_FROM_NO
	private Integer apFromNo;
	//Nullable: true	AP_TO_NO
	private Integer apToNo;
	//Nullable: true	EX_FROM_NO
	private Integer exFromNo;
	//Nullable: true	EX_TO_NO
	private Integer exToNo;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: true	BOOKING_CLASS2
	private String bookingClass2;
	//Nullable: true	FARE_BASIS_CODE
	private String fareBasisCode;
	//Nullable: true	FARE_BASIS_CODE2
	private String fareBasisCode2;
	//Nullable: false	SUB_FARE_REC_NO
	private Integer subFareRecNo;
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Integer getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(Integer fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public Integer getRouteNo() {
		return routeNo;
	}
	public void setRouteNo(Integer routeNo) {
		this.routeNo = routeNo;
	}
	public Integer getEntryNo() {
		return entryNo;
	}
	public void setEntryNo(Integer entryNo) {
		this.entryNo = entryNo;
	}
	public Integer getFlightEntryNo() {
		return flightEntryNo;
	}
	public void setFlightEntryNo(Integer flightEntryNo) {
		this.flightEntryNo = flightEntryNo;
	}
	public String getCarrierCode() {
		return carrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}
	public Integer getApFromNo() {
		return apFromNo;
	}
	public void setApFromNo(Integer apFromNo) {
		this.apFromNo = apFromNo;
	}
	public Integer getApToNo() {
		return apToNo;
	}
	public void setApToNo(Integer apToNo) {
		this.apToNo = apToNo;
	}
	public Integer getExFromNo() {
		return exFromNo;
	}
	public void setExFromNo(Integer exFromNo) {
		this.exFromNo = exFromNo;
	}
	public Integer getExToNo() {
		return exToNo;
	}
	public void setExToNo(Integer exToNo) {
		this.exToNo = exToNo;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getBookingClass2() {
		return bookingClass2;
	}
	public void setBookingClass2(String bookingClass2) {
		this.bookingClass2 = bookingClass2;
	}
	public String getFareBasisCode() {
		return fareBasisCode;
	}
	public void setFareBasisCode(String fareBasisCode) {
		this.fareBasisCode = fareBasisCode;
	}
	public String getFareBasisCode2() {
		return fareBasisCode2;
	}
	public void setFareBasisCode2(String fareBasisCode2) {
		this.fareBasisCode2 = fareBasisCode2;
	}
	public Integer getSubFareRecNo() {
		return subFareRecNo;
	}
	public void setSubFareRecNo(Integer subFareRecNo) {
		this.subFareRecNo = subFareRecNo;
	}
	
	@Override
	public String toString() {
		return "FareRouteFlightNo [locationCode=" + locationCode + ", refNo="
				+ refNo + ", fareRecNo=" + fareRecNo + ", routeNo=" + routeNo
				+ ", entryNo=" + entryNo + ", flightEntryNo=" + flightEntryNo
				+ ", carrierCode=" + carrierCode + ", apFromNo=" + apFromNo
				+ ", apToNo=" + apToNo + ", exFromNo=" + exFromNo + ", exToNo="
				+ exToNo + ", bookingClass=" + bookingClass
				+ ", bookingClass2=" + bookingClass2 + ", fareBasisCode="
				+ fareBasisCode + ", fareBasisCode2=" + fareBasisCode2
				+ ", subFareRecNo=" + subFareRecNo + "]";
	}
}