package com.travelsky.fare.caexport.db.model.airtis_fare;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRoute;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRule;
import com.travelsky.fare.caexport.db.model.po.FromTo;
import com.travelsky.fare.caexport.db.model.po.Money;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.StringUtil;
import com.travelsky.fare.caexport.util.enums.ActionType;

public class NewFare extends PSFare implements Comparable {
	private static final long serialVersionUID = 1L;
	private BigDecimal fareNo;
	private String rptFileNo;
	private BigDecimal pnFareNo;
	private String pnRptFileNo;
	private String refNo;
	private BigDecimal fareRecNo;
	
	//Nullable: true	FIRST_TRAVEL_DATE
	private Date firstTravelDate;
	//Nullable: false	LAST_TRAVEL_DATE
	private Date lastTravelDate;
	private List<FareRoute> routes;
	private List<FareRule> rules;
	//��������
	private ActionType actiontype;

	public NewFare(PSFare ps) {
		this(ps,null);
	}
	public NewFare(PSFare ps,PNFare pn){
		
		if(ps!=null){
			
			this.setFareNo( new BigDecimal(ps.getFareNo().doubleValue()) );
			this.setRptFileNo( ps.getRptFileNo() );
			this.setRefNo( ps.getRptFileNo() );
			this.setFareRecNo( new BigDecimal(ps.getFareNo().doubleValue()) );
			
			if(pn!=null){
				this.setPnFareNo( pn.getFareNo() );
				this.setPnRptFileNo( pn.getRptFileNo() );
			}
			
			this.setFileNo( ps.getFileNo() );
			this.setTravelType( ps.getTravelType() );
			this.setRuleId( ps.getRuleId() );		//��Ӧ��RuleId
			this.setFlag( ps.getFlag() );
			this.setCarrCode( ps.getCarrCode() );
			this.setEffDate( ps.getEffDate() );
			this.setDiscDate( ps.getDiscDate() );
			this.setDiscPer( ps.getDiscPer() );
			this.setClsCode( ps.getClsCode() );
			this.setServiceClass( ps.getServiceClass() );
			this.setFareBasis( ps.getFareBasis() );
			this.setRuleIdNo( ps.getRuleIdNo() );
			this.setRouteflag( ps.getRouteflag() );
			this.setArchvInd( ps.getArchvInd() );
			this.setRptDate( ps.getRptDate() );
			this.setRptFrom( ps.getRptFrom() );
			this.setFare( ps.getFare() );
			this.setOri( ps.getOri() );
			this.setDest( ps.getDest() );
			this.setAprvDate( ps.getAprvDate() );
			this.setAprvInd( ps.getAprvInd() );
			this.setAttribute1( ps.getAttribute1() );
			this.setAttribute2( ps.getAttribute2() );
			this.setCsActivateDate( ps.getCsActivateDate() );
			this.setCsSourceFarePk( ps.getCsSourceFarePk() );
			this.setCreateDate( ps.getCreateDate() );
			this.setCreateBy( ps.getCreateBy() );
			this.setLastUpdateDate( ps.getLastUpdateDate() );
			this.setLastUpdateBy( ps.getLastUpdateBy() );
			this.setRoutes( ps.getRoutes() );
			this.setRules( ps.getRules() );

			if( ps!=null && pn!=null ){
				//����������ֹ����
				this.setFirstTravelDate( DateUtil.getLater(ps.getEffDate(), pn.getEffDate()) );
				this.setLastTravelDate( DateUtil.getEarlier(ps.getDiscDate(), pn.getDiscDate()) );
				//����������ֹ����
				this.setFirstSaleDate( DateUtil.getLater(ps.getFirstSaleDate(), pn.getFirstSaleDate()) );
				this.setLastSaleDate( DateUtil.getEarlier(ps.getLastSaleDate(), pn.getLastSaleDate()) );
				
				//�Խ�����ת��
				double monval = 0;
				int rate = 1;
				if( "2".equals( ps.getTravelType() ) ){
					rate = 2;
				}
				monval = Math.round( pn.getMoney().getValue().doubleValue() * ps.getDiscPer().doubleValue() / 1000 ) * 10 * rate;
				this.setMoney( new Money(new BigDecimal(monval)) );
			}else{
				this.setFirstTravelDate( ps.getEffDate() );
				this.setLastTravelDate( ps.getDiscDate() );
				this.setFirstSaleDate( ps.getFirstSaleDate() );
				this.setLastSaleDate( ps.getLastSaleDate() );
				this.setMoney( ps.getMoney() );
			}
		}
		
	}

	public boolean accord(String carrier, FromTo fromto, PairDays travelday, String journeyType, String bookingClass, String fareBasis) {
		if( !StringUtil.isNullOrEmptyOrEqualsTargetStr(carrier,this.getCarrCode()) ) {
			return false;
		}
		
		if (travelday != null) {
			Date effDate = travelday.getFirstDate();
			Date discDate = travelday.getLastDate();
			if ( DateUtil.laterThan(this.getEffDate(), discDate) || DateUtil.earlierThan(this.getDiscDate(), effDate) ) {
				return false;
			}
		}

		if (fromto != null) {
			String oriCode = fromto.getOriCode();
			String destCode = fromto.getDesCode();
			if (oriCode != null && !oriCode.equals("") && !oriCode.equals("***") && !oriCode.equals(this.getOri().getOriCode())) {
				return false;
			}
			if (destCode != null && !destCode.equals("") && !destCode.equals("***") && !destCode.equals(this.getDest().getDestCode())) {
				return false;
			}
		}
		if (bookingClass != null && !bookingClass.equals("") && !bookingClass.equals(this.getClsCode())) {
			return false;
		}
		if (fareBasis != null && !fareBasis.equals("") && !fareBasis.equals(this.getFareBasis())) {
			return false;
		}
		if (journeyType != null && !journeyType.equals("") && !journeyType.equals("All") && !"0".equals(this.getTravelType()) && !journeyType.equals(this.getTravelType())) {
			return false;
		}

		return true;
	}
	
	public Date getFirstTravelDate() {
		return firstTravelDate;
	}
	public void setFirstTravelDate(Date firstTravelDate) {
		this.firstTravelDate = firstTravelDate;
	}
	public Date getLastTravelDate() {
		return lastTravelDate;
	}
	public void setLastTravelDate(Date lastTravelDate) {
		this.lastTravelDate = lastTravelDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<FareRoute> getRoutes() {
		return routes;
	}
	public void setRoutes(List<FareRoute> routes) {
		this.routes = routes;
	}
	public List<FareRule> getRules() {
		return rules;
	}
	public void setRules(List<FareRule> rules) {
		this.rules = rules;
	}
	public BigDecimal getFareNo() {
		return fareNo;
	}
	public void setFareNo(BigDecimal fareNo) {
		this.fareNo = fareNo;
	}
	public String getRptFileNo() {
		return rptFileNo;
	}
	public void setRptFileNo(String rptFileNo) {
		this.rptFileNo = rptFileNo;
	}
	public BigDecimal getPnFareNo() {
		return pnFareNo;
	}
	public void setPnFareNo(BigDecimal pnFareNo) {
		this.pnFareNo = pnFareNo;
	}
	public String getPnRptFileNo() {
		return pnRptFileNo;
	}
	public void setPnRptFileNo(String pnRptFileNo) {
		this.pnRptFileNo = pnRptFileNo;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public BigDecimal getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(BigDecimal fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public ActionType getActiontype() {
		return actiontype;
	}
	public void setActiontype(ActionType actiontype) {
		this.actiontype = actiontype;
	}
	@Override
	public int compareTo(Object o) {
		if(o instanceof NewFare){
			NewFare f = (NewFare) o;
			if( this.hashCode()==f.hashCode() )return 0;
			else return -1;
		}else{
			return 0;
		}
	}
}
