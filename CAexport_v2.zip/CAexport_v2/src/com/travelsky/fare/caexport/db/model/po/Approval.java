package com.travelsky.fare.caexport.db.model.po;

public class Approval {
	//Nullable: true	APPROVING_OFFICE
	private Integer approvingOffice;
	//Nullable: true	APPROVAL_TYPE
	private Integer approvalType;
	public Integer getApprovingOffice() {
		return approvingOffice;
	}
	public void setApprovingOffice(Integer approvingOffice) {
		this.approvingOffice = approvingOffice;
	}
	public Integer getApprovalType() {
		return approvalType;
	}
	public void setApprovalType(Integer approvalType) {
		this.approvalType = approvalType;
	}

}
