package com.travelsky.fare.caexport.db.model.airtis_fare;

import java.math.BigDecimal;
import java.util.Date;
import com.travelsky.fare.caexport.db.model.po.Dest;
import com.travelsky.fare.caexport.db.model.po.Money;
import com.travelsky.fare.caexport.db.model.po.Ori;

public class AbstractPxFare {
	//Nullable: false	CARR_CODE
	private String carrCode;
	private String fileNo;
	//Nullable: false	ARCHV_IND
	private String archvInd;
	//Nullable: false	RPT_FILE_NO
	private String rptFileNo;	//��Ӧ��fare�е�REF_NO
	//Nullable: false	RPT_FROM
	private String rptFrom;
	//Nullable: false	RPT_DATE
	private Date rptDate;
	//Nullable: false	FARE
	private BigDecimal fare;
	//Nullable: false	FARE_NO
	private BigDecimal fareNo;
	//Nullable: false	FARE_BASIS
	private String fareBasis;
	//Nullable: false	FARE_TYPE
	private String fareType;
	//Nullable: false	EFF_DATE
	private Date effDate;
	//Nullable: false	DISC_DATE
	private Date discDate;
	//Nullable: false	FIRST_SALE_DATE
	private Date firstSaleDate;
	//Nullable: false	LAST_SALE_DATE
	private Date lastSaleDate;
	private Money money = new Money(new BigDecimal("0.000"));
	private Ori ori = new Ori();
	private Dest dest = new Dest();
	//Nullable: false	TRAVEL_TYPE
	private String travelType;
	//Nullable: false	APRV_DATE
	private Date aprvDate;
	//Nullable: false	APRV_IND
	private String aprvInd;
	//Nullable: false	ATTRIBUTE1
	private String attribute1;
	//Nullable: false	ATTRIBUTE2
	private String attribute2;
	//Nullable: false	CS_ACTIVATE_DATE
	private Date csActivateDate;
	//Nullable: false	CS_SOURCE_FARE_PK
	private String csSourceFarePk;
	//Nullable: false	CREATE_DATE
	private Date createDate;
	//Nullable: false	CREATE_BY
	private String createBy;
	//Nullable: false	LAST_UPDATE_DATE
	private Date lastUpdateDate;
	//Nullable: false	LAST_UPDATE_BY
	private String lastUpdateBy;
	private String flag;	//��Ϊ��Ҫ������ʱ�ӵ� ʵ�� PS���ж�PN��û��
	
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getFileNo() {
		return fileNo;
	}
	public void setFileNo(String fileNo) {
		this.fileNo = fileNo;
	}
	public String getArchvInd() {
		return archvInd;
	}
	public void setArchvInd(String archvInd) {
		this.archvInd = archvInd;
	}
	public String getRptFileNo() {
		return rptFileNo;
	}
	public void setRptFileNo(String rptFileNo) {
		this.rptFileNo = rptFileNo;
	}
	public String getRptFrom() {
		return rptFrom;
	}
	public void setRptFrom(String rptFrom) {
		this.rptFrom = rptFrom;
	}
	public Date getRptDate() {
		return rptDate;
	}
	public void setRptDate(Date rptDate) {
		this.rptDate = rptDate;
	}
	public BigDecimal getFare() {
		return fare;
	}
	public void setFare(BigDecimal fare) {
		this.fare = fare;
	}
	public BigDecimal getFareNo() {
		return fareNo;
	}
	public void setFareNo(BigDecimal fareNo) {
		this.fareNo = fareNo;
	}
	public Date getEffDate() {
		return effDate;
	}
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}
	public Date getDiscDate() {
		return discDate;
	}
	public void setDiscDate(Date discDate) {
		this.discDate = discDate;
	}
	public Date getFirstSaleDate() {
		return firstSaleDate;
	}
	public void setFirstSaleDate(Date firstSaleDate) {
		this.firstSaleDate = firstSaleDate;
	}
	public Date getLastSaleDate() {
		return lastSaleDate;
	}
	public void setLastSaleDate(Date lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
	}
	public Money getMoney() {
		return money;
	}
	public void setMoney(Money money) {
		this.money = money;
	}
	public Ori getOri() {
		return ori;
	}
	public void setOri(Ori ori) {
		this.ori = ori;
	}
	public Dest getDest() {
		return dest;
	}
	public void setDest(Dest dest) {
		this.dest = dest;
	}
	public String getTravelType() {
		return travelType;
	}
	public void setTravelType(String travelType) {
		this.travelType = travelType;
	}
	public Date getAprvDate() {
		return aprvDate;
	}
	public void setAprvDate(Date aprvDate) {
		this.aprvDate = aprvDate;
	}
	public String getAprvInd() {
		return aprvInd;
	}
	public void setAprvInd(String aprvInd) {
		this.aprvInd = aprvInd;
	}
	public String getAttribute1() {
		return attribute1;
	}
	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}
	public Date getCsActivateDate() {
		return csActivateDate;
	}
	public void setCsActivateDate(Date csActivateDate) {
		this.csActivateDate = csActivateDate;
	}
	public String getCsSourceFarePk() {
		return csSourceFarePk;
	}
	public void setCsSourceFarePk(String csSourceFarePk) {
		this.csSourceFarePk = csSourceFarePk;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getLastUpdateBy() {
		return lastUpdateBy;
	}
	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public String getFareType() {
		return fareType;
	}
	public void setFareType(String fareType) {
		this.fareType = fareType;
	}
	public String getAttribute2() {
		return attribute2;
	}
	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}
}
