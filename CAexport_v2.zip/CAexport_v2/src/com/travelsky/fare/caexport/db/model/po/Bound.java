package com.travelsky.fare.caexport.db.model.po;

public class Bound {

	//Nullable: true	OUTBOUND_PERMITTED
	private Integer outboundPermitted;
	//Nullable: true	INBOUND_PERMITTED
	private Integer inboundPermitted;
	public Integer getOutboundPermitted() {
		return outboundPermitted;
	}
	public void setOutboundPermitted(Integer outboundPermitted) {
		this.outboundPermitted = outboundPermitted;
	}
	public Integer getInboundPermitted() {
		return inboundPermitted;
	}
	public void setInboundPermitted(Integer inboundPermitted) {
		this.inboundPermitted = inboundPermitted;
	}

}
