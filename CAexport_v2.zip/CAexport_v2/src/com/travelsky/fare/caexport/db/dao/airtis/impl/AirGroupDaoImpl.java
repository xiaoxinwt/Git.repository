package com.travelsky.fare.caexport.db.dao.airtis.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.ICommonDao;
import com.travelsky.fare.caexport.db.model.common.group.Group;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class AirGroupDaoImpl extends CommonDaoImpl implements ICommonDao<Group> {

	@Override
	public List<Group> queryAll(String carrier) throws NoFatalException,FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		return (List<Group>) queryForList(Group.class,"Tis_SelectAll",param);
	}
	
	@Override
	public List<Group> queryAllFrom(String carrier, Date startdate) throws NoFatalException,FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start", startdate);
		return (List<Group>) queryForList(Group.class,"Tis_SelectAll",param);
	}
	
	@Override
	public List<Group> queryIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {
		return queryIncOfDays(carrier,new PairDays(DateUtil.getYesterday(date), date));
	}

	@Override
	public List<Group> queryIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start",days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<Group>) queryForList(Group.class,"Tis_SelectInc",param);
	}

	public static void main(String[] args) throws NoFatalException, FatalException {
		AirGroupDaoImpl dao = new AirGroupDaoImpl();
		String carrier = "CA";
		PairDays days = new PairDays( "2015-01-01","2015-05-30" );
		Date date = DateUtil.getDate("2015-01-01");
		
		int pageNum = 1;
		int pageSize = 10;
		
		long total = 0;
		List<Group> list = new ArrayList<Group>();
		List<Group> page = new ArrayList<Group>();
		total = dao.countAll(carrier);
		list = dao.queryAll(carrier);
		page = dao.queryAllForPage(carrier, pageNum, pageSize);
		System.out.println( total );
		System.out.println( list.size() );
		System.out.println( page.size() );
		total = dao.countAllFrom(carrier, date);
		list = dao.queryAllFrom(carrier, date);
		page = dao.queryAllFromForPage(carrier, date, pageNum, pageSize);
		System.out.println( total );
		System.out.println( list.size() );
		System.out.println( page.size() );
		total = dao.countIncOfDate(carrier, date);
		list = dao.queryIncOfDate(carrier, date);
		page = dao.queryIncOfDateForPage(carrier, date, pageNum, pageSize);
		System.out.println( total );
		System.out.println( list.size() );
		System.out.println( page.size() );
		total = dao.countIncOfDays(carrier, days);
		list = dao.queryIncOfDays(carrier,days);
		page = dao.queryIncOfDaysForPage(carrier, days, pageNum, pageSize);
		System.out.println( total );
		System.out.println( list.size() );
		System.out.println( page.size() );
	}

	@Override
	public long countAll(String carrier) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryAll(carrier);
		return page.getTotal();
	}

	@Override
	public long countAllFrom(String carrier, Date startDate) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryAllFrom(carrier, startDate);
		return page.getTotal();
	}

	@Override
	public long countIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryIncOfDate(carrier, date);
		return page.getTotal();
	}

	@Override
	public long countIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryIncOfDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	public List<Group> queryAllForPage(String carrier,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryAll(carrier);
	}
	
	@Override
	public List<Group> queryAllFromForPage(String carrier,Date startDate,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryAllFrom(carrier, startDate);
	}
	
	@Override
	public List<Group> queryIncOfDateForPage(String carrier,Date date,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryIncOfDate(carrier, date);
	}
	
	@Override
	public List<Group> queryIncOfDaysForPage(String carrier,PairDays days,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryIncOfDays(carrier, days);
	}

}
