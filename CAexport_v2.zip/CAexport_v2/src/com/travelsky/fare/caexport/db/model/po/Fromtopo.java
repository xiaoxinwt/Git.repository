package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

import com.travelsky.fare.caexport.util.Tools;

public class Fromtopo {
	//Nullable: true	FROM_CODE
	private String fromCode;
	//Nullable: true	TO_CODE
	private String toCode;
	//Nullable: false	EFFECTIVE_DATE
	private Date effectiveDate;
	//Nullable: false	DISCONTINUE_DATE
	private Date discontinueDate;
	//Nullable: false	EFF_DATE
	private Date effDate;
	//Nullable: false	DISC_DATE
	private Date discDate;
	private String firstDate;
	private String lastDate;
	
	public String getFromCode() {
		return fromCode;
	}
	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}
	public String getToCode() {
		return toCode;
	}
	public void setToCode(String toCode) {
		this.toCode = toCode;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
		this.firstDate = Tools.getStringDate( effectiveDate );
	}
	public Date getDiscontinueDate() {
		return discontinueDate;
	}
	public void setDiscontinueDate(Date discontinueDate) {
		this.discontinueDate = discontinueDate;
		this.lastDate = Tools.getStringDate(discontinueDate);
	}
	public Date getEffDate() {
		return effDate;
	}
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
		this.firstDate = Tools.getStringDate( effDate );
	}
	public Date getDiscDate() {
		return discDate;
	}
	public void setDiscDate(Date discDate) {
		this.discDate = discDate;
		this.lastDate = Tools.getStringDate( discDate );
	}
	public String getFirstDate() {
		return firstDate;
	}
	public void setFirstDate(String firstDate) {
		this.firstDate = firstDate;
	}
	public String getLastDate() {
		return lastDate;
	}
	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}
}
