package com.travelsky.fare.caexport.db.model.po;

public class Position {
	//Nullable: true	POSITION_LIMIT_TYPE
	private Integer positionLimitType;
	//Nullable: true	POSITION_LIMIT_SPEC
	private Integer positionLimitSpec;
	public Integer getPositionLimitType() {
		return positionLimitType;
	}
	public void setPositionLimitType(Integer positionLimitType) {
		this.positionLimitType = positionLimitType;
	}
	public Integer getPositionLimitSpec() {
		return positionLimitSpec;
	}
	public void setPositionLimitSpec(Integer positionLimitSpec) {
		this.positionLimitSpec = positionLimitSpec;
	}
}
