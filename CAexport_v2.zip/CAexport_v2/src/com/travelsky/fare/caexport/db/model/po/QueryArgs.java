package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

/**
 * Export�����еĲ�ѯ��������
 * @author xiaoxinwt
 *
 */
public class QueryArgs {
	
	private String carrier;		//
	private Date date;			//�����
	private PairDays days;		//�����ڷ�Χ��
	
	public QueryArgs(String carrier) {
		this.carrier = carrier;
	}
	public QueryArgs(String carrier, Date date){
		this.carrier = carrier;
		this.date = date;
	}
	public QueryArgs(String carrier, PairDays days){
		this.carrier = carrier;
		this.days = days;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public PairDays getDays() {
		return days;
	}
	public void setDays(PairDays days) {
		this.days = days;
	}
}
