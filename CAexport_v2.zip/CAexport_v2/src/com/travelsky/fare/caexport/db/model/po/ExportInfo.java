package com.travelsky.fare.caexport.db.model.po;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class ExportInfo {
	private String flag="";
	private String dataType = "";
	private ExpType exportType;
	private Long count;
	private Long total;
	private Date startDate;
	private Date endDate;
	private String md5;
	private Double queryCost;
	private Double toXMLCost;
	public ExportInfo() {}
	
	@Override
	public String toString() {
		String datePatern = "";
		if(flag.equals("airtis")){
			datePatern = "yyyy-MM-dd";
		}else{
			datePatern = "yyyy-MM-dd HH:mm:ss";
		}
		SimpleDateFormat format = new SimpleDateFormat(datePatern);
		String result = StringUtils.EMPTY;
		result +="DATATYPE="+ dataType+"\n";
		result +="EXPORT_TYPE="+ exportType+"\n";
		
		result +="Expect_TOTAL=" + total + "\n";
		result +="Actual_COUNT=" + count + "\n";
		
		if( exportType.equals(ExpType.All )){
			result +="ALL_START="+ ( startDate ==null?"":format.format( startDate ))+"\n";
		}else if( exportType.equals( ExpType.Inc )){
			result +="INC_START="+ (startDate==null?"":format.format(startDate))+"\n";
			result +="INC_END="+ (endDate==null?"":format.format(endDate))+"\n";
		}
		
		result +="QUERY_COST="+ (queryCost!=null?queryCost:"")+"s\n";
		result +="ToXML_COST="+ (toXMLCost!=null?toXMLCost:"")+"s\n";
		result +="MD5="+ md5+"\n\n";
		return result;
	}
	
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getMd5() {
		return md5;
	}
	public void setMd5(String md5) {
		this.md5 = md5;
	}
	public Double getQueryCost() {
		return queryCost;
	}
	public void setQueryCost(Double queryCost) {
		this.queryCost = queryCost;
	}
	public Double getToXMLCost() {
		return toXMLCost;
	}
	public void setToXMLCost(Double toXMLCost) {
		this.toXMLCost = toXMLCost;
	}
	public ExpType getExportType() {
		return exportType;
	}
	public void setExportType(ExpType exportType) {
		this.exportType = exportType;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
