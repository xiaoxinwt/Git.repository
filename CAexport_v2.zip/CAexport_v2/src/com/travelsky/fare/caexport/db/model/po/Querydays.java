package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

public class Querydays {
	private Date firstdate;
    private Date lastdate;
	private String firststr;
	private String laststr;

	public Querydays(Date firstdate, Date lastdate) {
		this.firstdate = firstdate;
		this.lastdate = lastdate;
	}
	public Querydays(String firststr, String laststr){
		this.firststr = firststr;
		this.laststr = laststr;		
	}
	
	public Date getFirstdate() {
		return firstdate;
	}
	public void setFirstdate(Date firstdate) {
		this.firstdate = firstdate;
	}
	public Date getLastdate() {
		return lastdate;
	}
	public void setLastdate(Date lastdate) {
		this.lastdate = lastdate;
	}
	public String getFirststr() {
		return firststr;
	}
	public void setFirststr(String firststr) {
		this.firststr = firststr;
	}
	public String getLaststr() {
		return laststr;
	}
	public void setLaststr(String laststr) {
		this.laststr = laststr;
	}
}
