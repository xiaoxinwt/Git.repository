package com.travelsky.fare.caexport.db.model.common.group;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class Agent implements Entity {
    
	private static final long serialVersionUID = 1L;
	protected String agencyidpcc;
    protected String disname;
	
    public String getAgencyidpcc() {
		return agencyidpcc;
	}
	public void setAgencyidpcc(String agencyidpcc) {
		this.agencyidpcc = agencyidpcc;
	}
	public String getDisname() {
		return disname;
	}
	public void setDisname(String disname) {
		this.disname = disname;
	}
}
