package com.travelsky.fare.caexport.db.model.po;

public class Rstf {
	
	//Nullable: true	RSTF_CACULATE_TYPE
	private Integer rstfCaculateType;
	//Nullable: true	RSTF_AMT
	private Integer rstfAmt;
	//Nullable: true	RSTF_CURRENCY_CODE
	private String rstfCurrencyCode;
	//Nullable: true	RSTF_PERCENT
	private Integer rstfPercent;
	//Nullable: true	RSTF_DISPLAY_IF_SAME_BASEFARE
	private Integer rstfDisplayIfSameBasefare;
	//Nullable: true	RSTF_DISPLAY_FARE_BASIS
	private String rstfDisplayFareBasis;
	//Nullable: true	RSTF_DISPLAY_ADT_CMN_AMT
	private Integer rstfDisplayAdtCmnAmt;
	//Nullable: true	RSTF_DISPLAY_BASE_CMN_AMT
	private Integer rstfDisplayBaseCmnAmt;
	//Nullable: true	RSTF_DISPLAY_ADT_CMN_PCT
	private Integer rstfDisplayAdtCmnPct;
	//Nullable: true	RSTF_DISPLAY_BASE_CMN_PCT
	private Integer rstfDisplayBaseCmnPct;
	//Nullable: true	RSTF_DISPLAY_TOURCODE
	private String rstfDisplayTourcode;
	//Nullable: true	RSTF_DISPLAY_ENDORSMENT
	private String rstfDisplayEndorsment;
	//Nullable: true	RSTF_DISPLAY_IF_FREE_YQ
	private Integer rstfDisplayIfFreeYq;
	//Nullable: true	RSTF_THRESHOLD_CAL_TYPE
	private Integer rstfThresholdCalType;
	//Nullable: true	RSTF_THRESHOLD_CAL_PERCENT
	private Integer rstfThresholdCalPercent;
	public Integer getRstfThresholdCalType() {
		return rstfThresholdCalType;
	}
	public void setRstfThresholdCalType(Integer rstfThresholdCalType) {
		this.rstfThresholdCalType = rstfThresholdCalType;
	}
	public Integer getRstfThresholdCalPercent() {
		return rstfThresholdCalPercent;
	}
	public void setRstfThresholdCalPercent(Integer rstfThresholdCalPercent) {
		this.rstfThresholdCalPercent = rstfThresholdCalPercent;
	}
	public Integer getRstfCaculateType() {
		return rstfCaculateType;
	}
	public void setRstfCaculateType(Integer rstfCaculateType) {
		this.rstfCaculateType = rstfCaculateType;
	}
	public Integer getRstfAmt() {
		return rstfAmt;
	}
	public void setRstfAmt(Integer rstfAmt) {
		this.rstfAmt = rstfAmt;
	}
	public String getRstfCurrencyCode() {
		return rstfCurrencyCode;
	}
	public void setRstfCurrencyCode(String rstfCurrencyCode) {
		this.rstfCurrencyCode = rstfCurrencyCode;
	}
	public Integer getRstfPercent() {
		return rstfPercent;
	}
	public void setRstfPercent(Integer rstfPercent) {
		this.rstfPercent = rstfPercent;
	}
	public Integer getRstfDisplayIfSameBasefare() {
		return rstfDisplayIfSameBasefare;
	}
	public void setRstfDisplayIfSameBasefare(Integer rstfDisplayIfSameBasefare) {
		this.rstfDisplayIfSameBasefare = rstfDisplayIfSameBasefare;
	}
	public String getRstfDisplayFareBasis() {
		return rstfDisplayFareBasis;
	}
	public void setRstfDisplayFareBasis(String rstfDisplayFareBasis) {
		this.rstfDisplayFareBasis = rstfDisplayFareBasis;
	}
	public Integer getRstfDisplayAdtCmnAmt() {
		return rstfDisplayAdtCmnAmt;
	}
	public void setRstfDisplayAdtCmnAmt(Integer rstfDisplayAdtCmnAmt) {
		this.rstfDisplayAdtCmnAmt = rstfDisplayAdtCmnAmt;
	}
	public Integer getRstfDisplayBaseCmnAmt() {
		return rstfDisplayBaseCmnAmt;
	}
	public void setRstfDisplayBaseCmnAmt(Integer rstfDisplayBaseCmnAmt) {
		this.rstfDisplayBaseCmnAmt = rstfDisplayBaseCmnAmt;
	}
	public Integer getRstfDisplayAdtCmnPct() {
		return rstfDisplayAdtCmnPct;
	}
	public void setRstfDisplayAdtCmnPct(Integer rstfDisplayAdtCmnPct) {
		this.rstfDisplayAdtCmnPct = rstfDisplayAdtCmnPct;
	}
	public Integer getRstfDisplayBaseCmnPct() {
		return rstfDisplayBaseCmnPct;
	}
	public void setRstfDisplayBaseCmnPct(Integer rstfDisplayBaseCmnPct) {
		this.rstfDisplayBaseCmnPct = rstfDisplayBaseCmnPct;
	}
	public String getRstfDisplayTourcode() {
		return rstfDisplayTourcode;
	}
	public void setRstfDisplayTourcode(String rstfDisplayTourcode) {
		this.rstfDisplayTourcode = rstfDisplayTourcode;
	}
	public String getRstfDisplayEndorsment() {
		return rstfDisplayEndorsment;
	}
	public void setRstfDisplayEndorsment(String rstfDisplayEndorsment) {
		this.rstfDisplayEndorsment = rstfDisplayEndorsment;
	}
	public Integer getRstfDisplayIfFreeYq() {
		return rstfDisplayIfFreeYq;
	}
	public void setRstfDisplayIfFreeYq(Integer rstfDisplayIfFreeYq) {
		this.rstfDisplayIfFreeYq = rstfDisplayIfFreeYq;
	}
}
