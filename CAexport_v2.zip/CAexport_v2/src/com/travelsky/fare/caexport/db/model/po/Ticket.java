package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

public class Ticket {
	//Nullable: true	FIRST_TICKETED_DATE
	private Date firstTicketedDate;
	//Nullable: false	LAST_TICKETED_DATE
	private Date lastTicketedDate;
	//Nullable: true	TICKET_USED_TAG
	private Integer ticketUsedTag;
	//Nullable: false	TICKET_USE_TYPE
	private Integer ticketUseType;
	//Nullable: true	FIRST_TICKETED_TIME
	private Integer firstTicketedTime;
	//Nullable: true	LAST_TICKETED_TIME
	private Integer lastTicketedTime;
	//Nullable: true	TICKETED_TIME_UNIT
	private String ticketedTimeUnit;
	//Nullable: false	TICKET_TYPE
	private Integer ticketType;
	public Date getFirstTicketedDate() {
		return firstTicketedDate;
	}
	public void setFirstTicketedDate(Date firstTicketedDate) {
		this.firstTicketedDate = firstTicketedDate;
	}
	public Date getLastTicketedDate() {
		return lastTicketedDate;
	}
	public void setLastTicketedDate(Date lastTicketedDate) {
		this.lastTicketedDate = lastTicketedDate;
	}
	public Integer getTicketUsedTag() {
		return ticketUsedTag;
	}
	public void setTicketUsedTag(Integer ticketUsedTag) {
		this.ticketUsedTag = ticketUsedTag;
	}
	public Integer getTicketUseType() {
		return ticketUseType;
	}
	public void setTicketUseType(Integer ticketUseType) {
		this.ticketUseType = ticketUseType;
	}
	public Integer getFirstTicketedTime() {
		return firstTicketedTime;
	}
	public void setFirstTicketedTime(Integer firstTicketedTime) {
		this.firstTicketedTime = firstTicketedTime;
	}
	public Integer getLastTicketedTime() {
		return lastTicketedTime;
	}
	public void setLastTicketedTime(Integer lastTicketedTime) {
		this.lastTicketedTime = lastTicketedTime;
	}
	public String getTicketedTimeUnit() {
		return ticketedTimeUnit;
	}
	public void setTicketedTimeUnit(String ticketedTimeUnit) {
		this.ticketedTimeUnit = ticketedTimeUnit;
	}
	public Integer getTicketType() {
		return ticketType;
	}
	public void setTicketType(Integer ticketType) {
		this.ticketType = ticketType;
	}
}
