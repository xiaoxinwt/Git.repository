package com.travelsky.fare.caexport.db.model.po;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.Tools;

public class PairDays {
	
	private Date firstDate;
    private Date lastDate;
	private String firstDateStr;
	private String lastDateStr;
	public PairDays(){}
	public PairDays(Date firstDate, Date lastDate) {
		this.firstDate = firstDate;
		this.lastDate = lastDate;
		this.firstDateStr = Tools.getStringDate( firstDate );
		this.lastDateStr = Tools.getStringDate( lastDate );
	}
	public PairDays(String firstDateStr, String lastDateStr) {
		this.firstDateStr = firstDateStr;
		this.lastDateStr = lastDateStr;
		this.firstDate = DateUtil.getDate(firstDateStr);
		this.lastDate = DateUtil.getDate(lastDateStr);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstDate == null) ? 0 : firstDate.hashCode());
		result = prime * result + ((lastDate == null) ? 0 : lastDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof PairDays)) return false;
		final PairDays other = (PairDays) obj;
		if (firstDate == null) {
			if (other.firstDate != null) return false;
		} else if (!firstDate.equals(other.firstDate)) return false;
		if (lastDate == null) {
			if (other.lastDate != null) return false;
		} else if (!lastDate.equals(other.lastDate)) return false;
		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return new PairDays(firstDate,lastDate);
	}
    
	public PairDays crossDays(PairDays days){
		//������ཻ���򷵻�null
		if(firstDate.after(days.getLastDate())||lastDate.before(days.getLastDate())){
			return null;
		}
		//��������ȡ�м��������ʱ��
		List<Date> temp = new ArrayList<Date>();
		temp.add(firstDate);
		temp.add(lastDate);
		temp.add(days.getFirstDate());
		temp.add(days.getLastDate());
		Collections.sort(temp);
		return new PairDays(temp.get(1),temp.get(2));
	}
	
	public Date getFirstDate() {
		return firstDate;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public String getFirstDateStr() {
		return firstDateStr;
	}
	public String getLastDateStr() {
		return lastDateStr;
	}
	public void setFirstDate(Date firstDate) {
		this.firstDate = firstDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
	public void setFirstDateStr(String firstDateStr) {
		this.firstDateStr = firstDateStr;
	}
	public void setLastDateStr(String lastDateStr) {
		this.lastDateStr = lastDateStr;
	}
	
	@Override
	public String toString() {
		return "��"+getFirstDateStr()+" �� "+getLastDateStr();
	}
}
