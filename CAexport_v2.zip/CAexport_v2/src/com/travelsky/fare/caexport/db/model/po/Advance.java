package com.travelsky.fare.caexport.db.model.po;

public class Advance {
	//Nullable: true	ADVANCE_PURCHASE
	private Integer advancePurchase;
	//Nullable: true	MAX_ADVANCED_PURCHASE
	private Integer maxAdvancedPurchase;
	//Nullable: false	MAX_ADVANCED_PURCHASE_UNIT
	private String maxAdvancedPurchaseUnit;
	//Nullable: false	MIN_ADVANCED_PURCHASE_UNIT
	private String minAdvancedPurchaseUnit;
	public Integer getMaxAdvancedPurchase() {
		return maxAdvancedPurchase;
	}
	public void setMaxAdvancedPurchase(Integer maxAdvancedPurchase) {
		this.maxAdvancedPurchase = maxAdvancedPurchase;
	}
	public String getMaxAdvancedPurchaseUnit() {
		return maxAdvancedPurchaseUnit;
	}
	public void setMaxAdvancedPurchaseUnit(String maxAdvancedPurchaseUnit) {
		this.maxAdvancedPurchaseUnit = maxAdvancedPurchaseUnit;
	}
	public String getMinAdvancedPurchaseUnit() {
		return minAdvancedPurchaseUnit;
	}
	public void setMinAdvancedPurchaseUnit(String minAdvancedPurchaseUnit) {
		this.minAdvancedPurchaseUnit = minAdvancedPurchaseUnit;
	}
	public Integer getAdvancePurchase() {
		return advancePurchase;
	}
	public void setAdvancePurchase(Integer advancePurchase) {
		this.advancePurchase = advancePurchase;
	}
}
