package com.travelsky.fare.caexport.db.model.po;

public class MinMax {

	//Nullable: true	MINIMUM_STAY
	private Integer minimumStay;
	//Nullable: true	MINIMUM_STAY_UNIT
	private String minimumStayUnit;
	//Nullable: true	MAXIMUM_STAY
	private Integer maximumStay;
	//Nullable: true	MAXIMUM_STAY_UNIT
	private String maximumStayUnit;
	public Integer getMinimumStay() {
		return minimumStay;
	}
	public void setMinimumStay(Integer minimumStay) {
		this.minimumStay = minimumStay;
	}
	public String getMinimumStayUnit() {
		return minimumStayUnit;
	}
	public void setMinimumStayUnit(String minimumStayUnit) {
		this.minimumStayUnit = minimumStayUnit;
	}
	public Integer getMaximumStay() {
		return maximumStay;
	}
	public void setMaximumStay(Integer maximumStay) {
		this.maximumStay = maximumStay;
	}
	public String getMaximumStayUnit() {
		return maximumStayUnit;
	}
	public void setMaximumStayUnit(String maximumStayUnit) {
		this.maximumStayUnit = maximumStayUnit;
	}

}
