package com.travelsky.fare.caexport.db.model.po;

public interface Entity extends java.io.Serializable {}
