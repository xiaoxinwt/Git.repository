package com.travelsky.fare.caexport.db.model.po;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public class FromTo implements Entity{
	private static final long serialVersionUID = 1L;
	
	private String oriCode;
    private String oriCityCode;
    private String oriCodeType;
    private String desCode;
    private String desCodeType;
    private String destCityCode;
    
    public FromTo(){}
	public FromTo(String oriCode, String oriCityCode, String oriCodeType, String desCode, String desCodeType, String destCityCode) {
		super();
		this.oriCode = oriCode;
		this.oriCityCode = oriCityCode;
		this.oriCodeType = oriCodeType;
		this.desCode = desCode;
		this.desCodeType = desCodeType;
		this.destCityCode = destCityCode;
	}

	/**
	 * ���oriCode����desCodeΪ***����ת����fromTo�е�ʼ����Ŀ�ĵ�
	 * @param fromTo
	 * @return
	 */
	public FromTo newFromTo(FromTo fromTo){
		String ori = null;
		String des = null;
		String oriC = null;
		String desC = null;
		String oriT = null;
		String desT = null;
		if(StringUtils.equals(oriCode,"***")){
			ori = fromTo.getOriCode();
			oriC = fromTo.getOriCityCode();
			oriT = fromTo.getOriCodeType();
		}
		else{
			ori = oriCode;
			oriC = oriCityCode;
			oriT = oriCodeType;
		}
		
		if(StringUtils.equals(desCode, "***")){
			des = fromTo.getDesCode();
			desC = fromTo.getDestCityCode();
			desT = fromTo.getDesCodeType();
		}
		
		else{
			des = desCode;
			desC = destCityCode;
			desT = desCodeType;
		}
		
		return new FromTo(ori,oriC,oriT,des,desT,desC);
	}
	
	/**
	 * ��ΪFromTo�У����������¼�������
	 * CN-CN
	 * CN-XXX
	 * XXX-CN
	 * ***-***
	 * ***-CN
	 * CN-***
	 * XXX-***
	 * ***-XXX
	 * �������������⼸���������Ҫ���ݴ����ʼ���أ�Ŀ�ĵأ�ͨ���ǵ�ǰ��Ч�˼۵����е�ʼ���ء�Ŀ�ĵأ����в��
	 */
	public List<FromTo> abtainAllRoutes(List<FromTo> routes){
		List<FromTo> result = new ArrayList<FromTo>();
		if(routes==null||routes.size()==0){
			return result;
		}
		/**
		 * �����CN-CN���������������ʼ����Ŀ�ĵ�
		 * �����***-***�����ʾ���еĳ��ж�(��������Ӧ�ðѻ���Ҳ���ϣ���Ϊ֮��Ҫ�����еĻ���ת���ɳ���)
		 * ���CN-***����***-CN
		 */
		if(StringUtils.equals(oriCode, "CN")&&StringUtils.equals(desCode, "CN")
		||StringUtils.equals(oriCode, "***")&&StringUtils.equals(desCode, "***")
		||StringUtils.equals(oriCode, "***")&&StringUtils.equals(desCode, "CN")
		||StringUtils.equals(oriCode, "CN")&&StringUtils.equals(desCode, "***")){
			result.addAll(routes);
		}
		/**
		 * �����CN-XXX�����������***-XXX
		 */
		else if((StringUtils.equals(oriCode, "CN")||StringUtils.equals(oriCode, "***"))&&!StringUtils.equals(desCode, "CN")&&!StringUtils.equals(desCode, "***")){
			for(FromTo fromTo:routes){
				if(StringUtils.equals(desCode, fromTo.getDesCode())){
					result.add(fromTo);
				}
			}
		}
		/**
		 * �����XXX-CN���������XXX-***
		 */
		else if((StringUtils.equals(desCode, "CN")||StringUtils.equals(desCode, "***"))&&!StringUtils.equals(oriCode, "CN")&&!StringUtils.equals(oriCode, "***")){
			for(FromTo fromTo:routes){
				if(StringUtils.equals(oriCode, fromTo.getDesCode())){
					result.add(fromTo);
				}
			}
		}
		/**
		 * ��ͨ��***-***�����
		 */
		else{
			result.add(this);
		}
		return result;		
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return new FromTo(oriCode, oriCityCode,oriCodeType,
				desCode,desCodeType,destCityCode);
	}
	
	public String toXML() {
//		XmlUtil xml = new XmlUtil();
//		xml.addElement("ORI_CODE_TYPE", getOriCodeType());
//		xml.addElement("ORI_CODE", getOriCode());
//		xml.addElement("ORI_CITY_CODE", getOriCityCode());
//		xml.addElement("DEST_CODE_TYPE", getDesCodeType());
//		xml.addElement("DEST_CODE", getDesCode());
//		xml.addElement("DEST_CITY_CODE", getDestCityCode());
//		return xml.toString();
		return null;
	}
	
	public String toXMLnoncity() {
//		XmlUtil xml = new XmlUtil();
//		xml.addElement("ORI_CODE_TYPE", getOriCodeType());
//		xml.addElement("ORI_CODE", getOriCode());
//		xml.addElement("DEST_CODE_TYPE", getDesCodeType());
//		xml.addElement("DEST_CODE", getDesCode());
//		return xml.toString();
		return null;
	}
    
	
	
	
	
	
	
	
	
	
	public String getOriCode() {
		return oriCode;
	}
	public String getOriCityCode() {
		return oriCityCode;
	}
	public String getOriCodeType() {
		return oriCodeType;
	}
	public String getDesCode() {
		return desCode;
	}
	public String getDesCodeType() {
		return desCodeType;
	}
	public String getDestCityCode() {
		return destCityCode;
	}
	public void setDesCode(String desCode) {
		this.desCode = desCode;
	}
	public void setDesCodeType(String desCodeType) {
		this.desCodeType = desCodeType;
	}
	public void setDestCityCode(String destCityCode) {
		this.destCityCode = destCityCode;
	}
	public void setOriCityCode(String oriCityCode) {
		this.oriCityCode = oriCityCode;
	}
	public void setOriCode(String oriCode) {
		this.oriCode = oriCode;
	}
	public void setOriCodeType(String oriCodeType) {
		this.oriCodeType = oriCodeType;
	}

}
 