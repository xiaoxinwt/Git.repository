package com.travelsky.fare.caexport.db.dao.common;

import java.util.HashMap;
import java.util.Map;

import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Agreement;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;

public class AgreementDaoImpl extends CommonDaoImpl {

	public Agreement queryAgreementByRefPK(RefPK refpk){
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("carrCode", refpk.getCarrier());
		param.put("locationCode", refpk.getLocationCode());
		param.put("refNo", refpk.getRefNo());
		
		Agreement agree = null;
		try {
			agree = (Agreement) queryForOne(Agreement.class, "selectAgreementByRefPK", param);
		} catch (NoFatalException e) {
			e.printStackTrace();
		} catch (FatalException e) {
			e.printStackTrace();
		}
		return agree;
	}
	
	
	public static void main(String[] args) {
		RefPK pk = new RefPK("CA", "KWE", "IPD6C04_490QL19");
		AgreementDaoImpl dao = new AgreementDaoImpl();
		Agreement agree = dao.queryAgreementByRefPK(pk);
		System.out.println( agree );
	}
	
}
