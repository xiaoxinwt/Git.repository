package com.travelsky.fare.caexport.db.model.easyfare_fare;

import java.math.BigDecimal;
import java.util.List;

import com.travelsky.fare.caexport.db.model.po.Adult;
import com.travelsky.fare.caexport.db.model.po.Bound;
import com.travelsky.fare.caexport.db.model.po.Charge;
import com.travelsky.fare.caexport.db.model.po.Child;
import com.travelsky.fare.caexport.db.model.po.Commission;
import com.travelsky.fare.caexport.db.model.po.Dest;
import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.Free;
import com.travelsky.fare.caexport.db.model.po.Fromtopo;
import com.travelsky.fare.caexport.db.model.po.Infant;
import com.travelsky.fare.caexport.db.model.po.Ori;
import com.travelsky.fare.caexport.db.model.po.Ticket;
import com.travelsky.fare.caexport.db.model.po.Travel;

public class Fare implements Entity {
	private static final long serialVersionUID = 1L;
	private String carrier;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: false	FARE_REC_NO
	private String recNo;
	//Nullable: true	FARE_CATEGORY
	private Integer category;
	private Ori ori = new Ori();
	private Dest dest = new Dest();
	//Nullable: true	JOURNEY_TYPE
	private String journeyType;
	//Nullable: true	FARE_BASIS
	private String basis;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: true	GLOBAL_DIRECTION
	private String globalDirection;
	//Nullable: true	AMOUNT
	private BigDecimal amount;
	//Nullable: true	VALUE_CODE
	private String valueCode;
	private Fromtopo fromto = new Fromtopo();
	private Travel travel = new Travel();
	private Ticket ticket = new Ticket();
	//Nullable: true	RULE_ID
	private String ruleId;
	private Infant infant = new Infant();
	private Child child = new Child();
	private Free free = new Free();
	private Charge charge = new Charge();
	//Nullable: true	ROUTE_LASTNUM
	private Integer routeLastnum;
	//Nullable: true	STOPOVER_LASTNUM
	private Integer stopoverLastnum;
	//Nullable: true	FARE_TYPE
	private String type;
	//Nullable: true	STOPOVER_FLAG
	private String stopoverFlag;
	//Nullable: true	BOOKING_CLASS_2
	private String bookingClass2;
	//Nullable: true	CLASS_OF_SERVICE
	private Integer classOfService;
	//Nullable: true	TOUR_CODE
	private String tourCode;
	//Nullable: true	ENDORSEMENT_RESTRICTION
	private String endorsementRestriction;
	//Nullable: true	FARE_CALCULATION
	private String calculation;
	//Nullable: true	PUBLISHED_FARE_BASIS_CODE
	private String publishedFareBasisCode;
	//Nullable: true	IS_COMBINED_FARE
	private Integer isCombinedFare;
	private Bound bound = new Bound();
	//Nullable: true	THRU_FARE
	private Integer thruFare;
	private Adult adult = new Adult();
	//Nullable: true	DISCOUNT_CODE
	private String discountCode;
	//Nullable: false	SUB_FARE_REC_NO
	private Integer subFareRecNo;
	//Nullable: true	MODIFIED_FLAG
	private Integer modifiedFlag;
	//Nullable: true	VALUE_CODE2
	private String valueCode2;
	//Nullable: true	BAGGAGE_ALLOWANCE
	private Integer baggageAllowance;
	//Nullable: true	UNIT
	private Integer unit;
	private Commission comm = new Commission();
	//Nullable: true	ETERM_ENDORSEMENT_RESTRICTION
	private String etermEndorsementRestriction;
	//Nullable: true	DISC_PER
	private BigDecimal discPer;
	private FareRule farerule;
    private List<String> groupIds;
    private List<FareRoute> fareRoutes;

	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public List<FareRoute> getFareRoutes() {
		return fareRoutes;
	}
	public void setFareRoutes(List<FareRoute> fareRoutes) {
		this.fareRoutes = fareRoutes;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getRecNo() {
		return recNo;
	}
	public void setRecNo(String recNo) {
		this.recNo = recNo;
	}
	public Integer getCategory() {
		return category;
	}
	public void setCategory(Integer category) {
		this.category = category;
	}
	public Ori getOri() {
		return ori;
	}
	public void setOri(Ori ori) {
		this.ori = ori;
	}
	public Dest getDest() {
		return dest;
	}
	public void setDest(Dest dest) {
		this.dest = dest;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBasis() {
		return basis;
	}
	public void setBasis(String basis) {
		this.basis = basis;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getGlobalDirection() {
		return globalDirection;
	}
	public void setGlobalDirection(String globalDirection) {
		this.globalDirection = globalDirection;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getValueCode() {
		return valueCode;
	}
	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}
	public Fromtopo getFromto() {
		return fromto;
	}
	public void setFromto(Fromtopo fromto) {
		this.fromto = fromto;
	}
	public Travel getTravel() {
		return travel;
	}
	public void setTravel(Travel travel) {
		this.travel = travel;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public Infant getInfant() {
		return infant;
	}
	public void setInfant(Infant infant) {
		this.infant = infant;
	}
	public Child getChild() {
		return child;
	}
	public void setChild(Child child) {
		this.child = child;
	}
	public Free getFree() {
		return free;
	}
	public void setFree(Free free) {
		this.free = free;
	}
	public Charge getCharge() {
		return charge;
	}
	public void setCharge(Charge charge) {
		this.charge = charge;
	}
	public Integer getRouteLastnum() {
		return routeLastnum;
	}
	public void setRouteLastnum(Integer routeLastnum) {
		this.routeLastnum = routeLastnum;
	}
	public Integer getStopoverLastnum() {
		return stopoverLastnum;
	}
	public void setStopoverLastnum(Integer stopoverLastnum) {
		this.stopoverLastnum = stopoverLastnum;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStopoverFlag() {
		return stopoverFlag;
	}
	public void setStopoverFlag(String stopoverFlag) {
		this.stopoverFlag = stopoverFlag;
	}
	public String getBookingClass2() {
		return bookingClass2;
	}
	public void setBookingClass2(String bookingClass2) {
		this.bookingClass2 = bookingClass2;
	}
	public Integer getClassOfService() {
		return classOfService;
	}
	public void setClassOfService(Integer classOfService) {
		this.classOfService = classOfService;
	}
	public String getTourCode() {
		return tourCode;
	}
	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}
	public String getEndorsementRestriction() {
		return endorsementRestriction;
	}
	public void setEndorsementRestriction(String endorsementRestriction) {
		this.endorsementRestriction = endorsementRestriction;
	}
	public String getCalculation() {
		return calculation;
	}
	public void setCalculation(String calculation) {
		this.calculation = calculation;
	}
	public String getPublishedFareBasisCode() {
		return publishedFareBasisCode;
	}
	public void setPublishedFareBasisCode(String publishedFareBasisCode) {
		this.publishedFareBasisCode = publishedFareBasisCode;
	}
	public Integer getIsCombinedFare() {
		return isCombinedFare;
	}
	public void setIsCombinedFare(Integer isCombinedFare) {
		this.isCombinedFare = isCombinedFare;
	}
	public Bound getBound() {
		return bound;
	}
	public void setBound(Bound bound) {
		this.bound = bound;
	}
	public Integer getThruFare() {
		return thruFare;
	}
	public void setThruFare(Integer thruFare) {
		this.thruFare = thruFare;
	}
	public Adult getAdult() {
		return adult;
	}
	public void setAdult(Adult adult) {
		this.adult = adult;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Integer getSubFareRecNo() {
		return subFareRecNo;
	}
	public void setSubFareRecNo(Integer subFareRecNo) {
		this.subFareRecNo = subFareRecNo;
	}
	public Integer getModifiedFlag() {
		return modifiedFlag;
	}
	public void setModifiedFlag(Integer modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}
	public String getValueCode2() {
		return valueCode2;
	}
	public void setValueCode2(String valueCode2) {
		this.valueCode2 = valueCode2;
	}
	public Integer getBaggageAllowance() {
		return baggageAllowance;
	}
	public void setBaggageAllowance(Integer baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}
	public Integer getUnit() {
		return unit;
	}
	public void setUnit(Integer unit) {
		this.unit = unit;
	}
	public Commission getComm() {
		return comm;
	}
	public void setComm(Commission comm) {
		this.comm = comm;
	}
	public String getEtermEndorsementRestriction() {
		return etermEndorsementRestriction;
	}
	public void setEtermEndorsementRestriction(String etermEndorsementRestriction) {
		this.etermEndorsementRestriction = etermEndorsementRestriction;
	}
	public BigDecimal getDiscPer() {
		return discPer;
	}
	public void setDiscPer(BigDecimal discPer) {
		this.discPer = discPer;
	}
	public List<String> getGroupIds() {
		return groupIds;
	}
	public void setGroupIds(List<String> groupIds) {
		this.groupIds = groupIds;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public FareRule getFarerule() {
		return farerule;
	}
	public void setFarerule(FareRule farerule) {
		this.farerule = farerule;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
}