package com.travelsky.fare.caexport.db.model.po;

import java.math.BigDecimal;

public class Infant {
	//Nullable: true	INFANT_DISCOUNT_AMOUNT
	private BigDecimal infantDiscountAmount;
	//Nullable: true	INFANT_DISCOUNT_PERCENT
	private Integer infantDiscountPercent;
	//Nullable: true	INFANT_ABSOLUTE_AMT_ENTERED
	private Integer infantAbsoluteAmtEntered;
	//Nullable: true	INFANT_VALUE_CODE
	private String infantValueCode;
	//Nullable: true	INFANT_TOUR_CODE
	private String infantTourCode;
	//Nullable: true	INFANT_RSF_AMT
	private Integer infantRsfAmt;
	//Nullable: true	INFANT_PUBLISHED_FBC
	private String infantPublishedFbc;
	//Nullable: true	INFANT_VALUE_CODE2
	private String infantValueCode2;
	//Nullable: true	INFANT_BAGGAGE_ALLOWANCE
	private Integer infantBaggageAllowance;
	public BigDecimal getInfantDiscountAmount() {
		return infantDiscountAmount;
	}
	public void setInfantDiscountAmount(BigDecimal infantDiscountAmount) {
		this.infantDiscountAmount = infantDiscountAmount;
	}
	public Integer getInfantDiscountPercent() {
		return infantDiscountPercent;
	}
	public void setInfantDiscountPercent(Integer infantDiscountPercent) {
		this.infantDiscountPercent = infantDiscountPercent;
	}
	public Integer getInfantAbsoluteAmtEntered() {
		return infantAbsoluteAmtEntered;
	}
	public void setInfantAbsoluteAmtEntered(Integer infantAbsoluteAmtEntered) {
		this.infantAbsoluteAmtEntered = infantAbsoluteAmtEntered;
	}
	public String getInfantValueCode() {
		return infantValueCode;
	}
	public void setInfantValueCode(String infantValueCode) {
		this.infantValueCode = infantValueCode;
	}
	public String getInfantTourCode() {
		return infantTourCode;
	}
	public void setInfantTourCode(String infantTourCode) {
		this.infantTourCode = infantTourCode;
	}
	public Integer getInfantRsfAmt() {
		return infantRsfAmt;
	}
	public void setInfantRsfAmt(Integer infantRsfAmt) {
		this.infantRsfAmt = infantRsfAmt;
	}
	public String getInfantPublishedFbc() {
		return infantPublishedFbc;
	}
	public void setInfantPublishedFbc(String infantPublishedFbc) {
		this.infantPublishedFbc = infantPublishedFbc;
	}
	public String getInfantValueCode2() {
		return infantValueCode2;
	}
	public void setInfantValueCode2(String infantValueCode2) {
		this.infantValueCode2 = infantValueCode2;
	}
	public Integer getInfantBaggageAllowance() {
		return infantBaggageAllowance;
	}
	public void setInfantBaggageAllowance(Integer infantBaggageAllowance) {
		this.infantBaggageAllowance = infantBaggageAllowance;
	}
}
