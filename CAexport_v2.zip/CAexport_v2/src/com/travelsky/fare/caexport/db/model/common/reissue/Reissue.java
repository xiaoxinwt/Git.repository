package com.travelsky.fare.caexport.db.model.common.reissue;

import java.util.List;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class Reissue implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	REISSUE_ID
	private String reissueId;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: true	CHANGE_TAG
	private String changeTag;
	//Nullable: true	VOLUNTARY_CHANGED_TEXT
	private String voluntaryChangedText;
	//Nullable: true	INVOLUNTARY_CHANGED_TEXT
	private String involuntaryChangedText;
	//Nullable: false	RULE_TYPE
	private Integer ruleType;
	private List<ReissueDetail> details;
//	private ReissueDetail detail;
	
	public Reissue() {}
	public Reissue(String reissueId, String locationCode, String changeTag,
			String voluntaryChangedText, String involuntaryChangedText,
			Integer ruleType, List<ReissueDetail> details) {
		this.reissueId = reissueId;
		this.locationCode = locationCode;
		this.changeTag = changeTag;
		this.voluntaryChangedText = voluntaryChangedText;
		this.involuntaryChangedText = involuntaryChangedText;
		this.ruleType = ruleType;
		this.details = details;
	}
	
	public String getReissueId() {
		return reissueId;
	}
	public void setReissueId(String id) {
		this.reissueId = id;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getChangeTag() {
		return changeTag;
	}
	public void setChangeTag(String changeTag) {
		this.changeTag = changeTag;
	}
	public String getVoluntaryChangedText() {
		return voluntaryChangedText;
	}
	public void setVoluntaryChangedText(String voluntaryChangedText) {
		this.voluntaryChangedText = voluntaryChangedText;
	}
	public String getInvoluntaryChangedText() {
		return involuntaryChangedText;
	}
	public void setInvoluntaryChangedText(String involuntaryChangedText) {
		this.involuntaryChangedText = involuntaryChangedText;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}
//	public ReissueDetail getDetail() {
//		return detail;
//	}
//	public void setDetail(ReissueDetail detail) {
//		this.detail = detail;
//	}
	public List<ReissueDetail> getDetails() {
		return details;
	}
	public void setDetails(List<ReissueDetail> details) {
		this.details = details;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}