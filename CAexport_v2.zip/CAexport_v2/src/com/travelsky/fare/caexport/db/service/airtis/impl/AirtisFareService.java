package com.travelsky.fare.caexport.db.service.airtis.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.dao.airtis.impl.PNDaoImpl;
import com.travelsky.fare.caexport.db.dao.airtis.impl.PSDaoImpl;
import com.travelsky.fare.caexport.db.model.airtis_fare.NewFare;
import com.travelsky.fare.caexport.db.model.airtis_fare.PNFare;
import com.travelsky.fare.caexport.db.model.airtis_fare.PSFare;
import com.travelsky.fare.caexport.db.model.po.Money;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.dexp.vo.fare.XFareImport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.AirtisFareImportor;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ErrorLog;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.FileNameGenerator;
import com.travelsky.fare.caexport.util.IOUtil;
import com.travelsky.fare.caexport.util.JaxbUtil;
import com.travelsky.fare.caexport.util.PageUtil;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;
import com.travelsky.fare.caexport.util.handler.AirtisFareHandler;

public class AirtisFareService implements IExport<NewFare> {
	
	private Log log = LogFactory.getLog( this.getClass() );
	private final int pageSize = 5000;		//����ȫ����ѯ�ķ�ҳ��������ֵ>5000,JAXB�ᷢ���ڲ�����
	private final int querySize = 5000;		//��������������ѯ
	private CAType catype = null;
	private CAModule camodule = null;
	
	private IFareDao<PSFare> psdao = new PSDaoImpl();
	private IFareDao<PNFare> pndao = new PNDaoImpl();
	private IImportor<NewFare, XFareImport> importor = new AirtisFareImportor();

	public AirtisFareService() {
		this.catype = CAType.Airtis;
		this.camodule = CAModule.Fare;
	}
	
	//dao��service��֮������������ڽ�dao��ѯ���PS,PNͨ���߼������ϵת��ΪNewFare���ͣ�����װ��service������Ҫ�������ʽ
//	private AirtisFareHandler handler = new AirtisFareHandler();
	@Override
	public Export exportAll(String carrier) throws NoFatalException, FatalException{
		//����fare���Ͳ�����
		return null;
	}
	
	@Override
	public Export exportAllOfDate(String carrier, Date saleDate) throws NoFatalException, FatalException{
		
		long total = 0;
		long count = 0;
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		
		long pscount = psdao.countAllByDate(carrier, saleDate);
//		long pncount = pndao.countAllByDate(carrier, saleDate);
//		log.info( saleDate.toLocaleString()+"PN������"+pncount );
//		log.info( saleDate.toLocaleString()+"PS������"+pscount );
		
		//PN���٣�PS���󣬲������PN������ҳ��ѯPS��֮����м���
		List<PNFare> pnlist = pndao.queryAllByDate(carrier, saleDate);
		log.info( "PN������"+ pnlist.size() );
		
		List<PSFare> psOfPageList = null;
		List<NewFare> tmplist = null;
		//��ҳ��ѯ
		int pspages = PageUtil.getPageCount(pscount,pageSize);

		long querycost = 0;
		long toxmlcost = 0;
		for(int i=1;i<=pspages;i++){
			
			long querystart = System.currentTimeMillis();
			psOfPageList = psdao.queryAllByDateForPage(carrier, saleDate, i, pageSize);
			querycost += (System.currentTimeMillis()-querystart);
			log.info( "��"+i+"ҳPS��������"+ psOfPageList.size() );
			
			tmplist = createNewFareByPsPn( psOfPageList , pnlist );
			total += tmplist.size();
			
			for (NewFare nfare : tmplist) {
				nfare.setActiontype( actype );
			}
			
			//��ҳ������ΪXML�ļ�
			long xmlstart = System.currentTimeMillis();
			count += exportToXML(tmplist,carrier,exptype,saleDate,i);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		log.info( "NewFareList��������"+total );
		log.info( "ʵ�ʵ���ΪXML��������"+count );
		
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate( saleDate );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDate(String carrier, Date date) throws FatalException, NoFatalException{
		
		long total = 0;
		long count = 0;
		ExpType exptype = ExpType.Inc;
		long querycost = 0;
		long toxmlcost = 0;
		
		PairDays days = new PairDays(DateUtil.getYesterday(date),date);
		long querystart = System.currentTimeMillis();
		List<NewFare> insertlist = getInsertNewFare(carrier ,days );
		querycost += (System.currentTimeMillis()-querystart);
		
		querystart = System.currentTimeMillis();
		List<NewFare> updatelist = getUpdateNewFare(carrier,days );
		querycost += (System.currentTimeMillis()-querystart);
		
		List<NewFare> explist = new ArrayList<NewFare>();
		explist.addAll( insertlist );
		explist.addAll( updatelist );
		log.info("InsertFareList��������"+insertlist.size());
		log.info("UpdateFareList��������"+updatelist.size());
		total += insertlist.size()+updatelist.size();
		
		//��listתΪXML
		long xmlstart = System.currentTimeMillis();
		count += exportToXML(explist,carrier,exptype,date);
		toxmlcost += (System.currentTimeMillis()-xmlstart);
		log.info("������ĵ���������"+ total );
		log.info("ʵ�ʵĵ���������"+ count);
		
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(DateUtil.getYesterday(date));
		exp.setEndDate( date );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}

	@Override
	public Export exportIncOfDays(String carrier, PairDays days) throws FatalException, NoFatalException{
		
		Export exp = new Export(carrier, catype, camodule ,ExpType.Inc);

		long total = 0;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		List<Date> dates = DateUtil.getDates(days.getFirstDate(),days.getLastDate());
		//�ֱ��ѯÿһ���ȫ�������ϲ�Ϊ�ܵ�ȫ��
		if(dates!=null && dates.size()>0){
			Export tmpexp = null;
			for(Date date : dates){
				tmpexp = exportIncOfDate(carrier,date);
			}
			total += tmpexp.getExpectTotal();
			count += tmpexp.getCount();
			querycost += tmpexp.getQueryCost();
			toxmlcost += tmpexp.getToxmlCost();
		}
		
		exp.setStartDate( days.getFirstDate() );
		exp.setEndDate( days.getLastDate() );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public static void main(String[] args) throws NoFatalException, FatalException{
		
		IExport<NewFare> exportor = new AirtisFareService();
		
		String carrier = "MU";
		Date date = DateUtil.getDate("2015-01-01");
		PairDays days = new PairDays("2015-01-01","2015-01-05");
		
		date = DateUtil.getDate("2015-01-01");
		
		Export exp = null;
		//����ĳһ���ȫ��
//		exp = exportor.exportAllOfDate(carrier, date);
		//����ĳһ�������
		exp = exportor.exportIncOfDate(carrier, date);
//		exp = exportor.exportIncOfDays(carrier, days);
		ExportUtil.writeInfo( exp );
	}
	
	private List<NewFare> getInsertNewFare(String carrier , PairDays days) throws FatalException, NoFatalException{
		
		List<NewFare> inclist1 = new ArrayList<NewFare>();
		List<NewFare> inclist2 = new ArrayList<NewFare>();
		List<NewFare> inclist3 = new ArrayList<NewFare>();
		
		List<NewFare> retlist = new ArrayList<NewFare>();
		long psinccount = psdao.countInsertByDays(carrier, days);
		log.info( days.toString()+"��Ч��PS��"+psinccount );
		if(psinccount>0){
			long pnallcount = pndao.countAllByDate(carrier, days.getLastDate());
			log.info( days.toString()+"ȫ����PN��"+pnallcount );

			// ��ѯ��lastDate����������Ч��PN
			List<PNFare> allPnList = pndao.queryAllByDateForPage(carrier, days.getLastDate() ,1,(int) pnallcount);
			inclist1 = getIncFareByIncPsAllPnOfPage(allPnList, psinccount, carrier ,days);
		}
		long pninccount = pndao.countInsertByDays(carrier, days);
		log.info( days.toString()+"��Ч��PN��"+pninccount );
		if(pninccount>0){
			long psallcount = psdao.countAllByDate(carrier, days.getLastDate() );
			log.info( days.toString()+"ȫ����PS��"+psallcount );
			// ��ѯ��lastDate����������Ч��PS -- ��ΪPNFare������������ȫ��
			List<PNFare> incPnList = pndao.queryInsertByDaysForPage(carrier, days ,1, (int) pninccount );
			inclist2 = getIncFareByIncPnAllPsOfPage(incPnList, psallcount, carrier ,days);
			
			if(psinccount>0){
				// ���ݵ������ÿ�ʼ��Ч��PN�͵������ÿ�ʼ��Ч��PS����FbrPsFare
				inclist3 = getIncFareByIncPsIncPnOfPage(incPnList, psinccount,carrier , days);
			}
		}
		
		//������ȥ��
		log.info("ȥ��ǰ��"+(inclist1.size()+inclist2.size()+inclist3.size()) );
		div(inclist1,inclist3);
		div(inclist2,inclist3);
		log.info("ȥ�غ�"+(inclist1.size()+inclist2.size()+inclist3.size()) );
		
		retlist.addAll( inclist1 );
		retlist.addAll( inclist2 );
		retlist.addAll( inclist3 );
		
		if(retlist!=null && retlist.size()>0){
			for (NewFare nfare : retlist) {
				nfare.setActiontype( ActionType.Insert );
			}
		}
		
		return retlist;
	}
	
	//��ҳ��ѯPS������Fare
	private List<NewFare> getIncFareByIncPsIncPnOfPage(List<PNFare> incPnList, long psinccount, String carrier,PairDays days) throws NoFatalException, FatalException {
		List<NewFare> inclist = new ArrayList<NewFare>();
		int queryPages = PageUtil.getPageCount(psinccount, querySize);
		List<PSFare> tmpPsList = new ArrayList<PSFare>();
		List<NewFare> tmplist = new ArrayList<NewFare>();
		for (int i = 1; i <= queryPages; i++) {
			tmpPsList = psdao.queryInsertByDaysForPage(carrier, days,i,querySize);
			tmplist = createNewFareByPsPn( tmpPsList , incPnList );			
			log.info("��"+i+"�β�ѯ��"+tmplist.size() );
			inclist.addAll(tmplist);
		}
		log.info("IncPS,IncPN:"+inclist.size() );
		return inclist;
	}

	//��ҳ��ѯPS������Fare
	private List<NewFare> getIncFareByIncPsAllPnOfPage(List<PNFare> allPnList, long psinccount, String carrier, PairDays days) throws NoFatalException, FatalException {
		List<NewFare> inclist = new ArrayList<NewFare>();
		int queryPages = PageUtil.getPageCount(psinccount, querySize);
		List<PSFare> tmpPsList = new ArrayList<PSFare>();
		List<NewFare> tmplist = new ArrayList<NewFare>();
		for (int i = 1; i <= queryPages; i++) {
			// ��ѯ��ʼ��Ч���ڽ���ʱ���֮���PS.  firstDate< First_sale_day <=lastDate
			tmpPsList = psdao.queryInsertByDaysForPage(carrier, days,i,querySize);
			// ����PS * AllPN����FbrPsFare
			tmplist = createNewFareByPsPn( tmpPsList , allPnList);
			log.info("��"+i+"�β�ѯ��"+tmplist.size() );
			inclist.addAll(tmplist);
		}
		log.info("IncPS,AllPN:"+inclist.size() );
		return inclist;
	}
	//��ҳ��ѯPS������Fare
	private List<NewFare> getIncFareByIncPnAllPsOfPage(List<PNFare> incPnList, long psallcount , String carrier , PairDays days) throws NoFatalException, FatalException{
		List<NewFare> inclist = new ArrayList<NewFare>();
		int queryPages = PageUtil.getPageCount(psallcount,querySize);
		List<PSFare> tmpPsList = new ArrayList<PSFare>();
		List<NewFare> tmplist = new ArrayList<NewFare>();
		for (int i = 1; i <= queryPages; i++) {
			tmpPsList = psdao.queryAllByDateForPage(carrier,  days.getLastDate() ,i, querySize);
			// ��ѯ��ʼ��Ч���ڽ���ʱ���֮���PN. firstDate< First_sale_day <=lastDate
			// ����AllPS * Pn����FbrPsFare
			tmplist = createNewFareByPnPs( incPnList , tmpPsList );
			log.info("��"+i+"�β�ѯ��"+tmplist.size() );
			inclist.addAll(tmplist);
		}
		log.info("AllPS,IncPN:" + inclist.size() );
		return inclist;
	}
	
	
	public List<NewFare> getUpdateNewFare(String carrier, PairDays days) throws FatalException, NoFatalException{

		List<PSFare> updatePsList = new ArrayList<PSFare>();
		List<PNFare> updatePnList = new ArrayList<PNFare>();
		List<NewFare> uplist1 = new ArrayList<NewFare>();
		List<NewFare> uplist2 = new ArrayList<NewFare>();
		List<NewFare> uplist3 = new ArrayList<NewFare>();
		
		List<NewFare> retlist = new ArrayList<NewFare>();
		long psupcount = psdao.countUpdateByDays(carrier, days);
		log.info( days.toString()+"���µ�PS:"+psupcount);
		if(psupcount>0){
			long pnallcount = pndao.countAllByDate(carrier, days.getFirstDate() );
			log.info( days.getFirstDate().toLocaleString()+"��Ч��ȫ��PN��"+pnallcount );
			//��ѯ����޸����ڽ���ʱ���֮���PS.  firstDate<= Last_Update_Date <lastDate����
			//��ѯ��firstDate������Ч������PN
			List<PNFare> allPnList = pndao.queryAllByDateForPage(carrier, days.getFirstDate(), 1, (int) pnallcount);
			//FIRST_SALE_DATE<=firstDate<=LAST_SALE_DATE
			updatePsList = psdao.queryUpdateByDaysForPage(carrier, days,1,(int) psupcount);
			uplist1 = createNewFareByPsPn(updatePsList, allPnList);
			log.info("UpdatePS,AllPN:"+uplist1.size() );
		}
		long pnupcount = pndao.countUpdateByDays(carrier, days);
		log.info( days.toString()+"���µ�PN��"+pnupcount);
		if(pnupcount>0){
			long psallcount = psdao.countAllByDate(carrier, days.getFirstDate() );
			log.info( days.getFirstDate().toLocaleString()+"��Ч��ȫ��PS��"+psallcount );
			//��ѯ����޸����ڽ���ʱ���֮���PN.  firstDate<= Last_Update_Date <lastDate����
			//FIRST_SALE_DATE<=firstDate<=LAST_SALE_DATE
			updatePnList = pndao.queryUpdateByDaysForPage(carrier, days,1,(int) pnupcount );
			uplist2 = getUpdateFareByUpPnAllPsOfPage(updatePnList,psallcount,carrier,days);
			log.info("AllPS,UpdatePN:"+uplist2.size() );
		}
		
		if(pnupcount>0 && psupcount>0){
			uplist3 = createNewFareByPsPn(updatePsList , updatePnList);
			log.info("UpdatePS,UpdatePN:"+uplist3.size() );
		}
		
		log.info("ȥ��ǰ��"+(uplist1.size()+uplist2.size()+uplist3.size()));
		div(uplist1 , uplist3);
		div(uplist2 , uplist3);
		log.info("ȥ�غ�"+(uplist1.size()+uplist2.size()+uplist3.size()));
		
		retlist.addAll( uplist1 );
		retlist.addAll( uplist2 );
		retlist.addAll( uplist3 );
		
		
		if(retlist!=null && retlist.size()>0){
			for (NewFare nfare : retlist) {
				nfare.setActiontype( ActionType.Update );
			}
		}
		
		return retlist;
	}
	
	private List<NewFare> getUpdateFareByUpPnAllPsOfPage(List<PNFare> updatePnList, long psallcount, String carrier,PairDays days) throws NoFatalException, FatalException {
		List<NewFare> flist = new ArrayList<NewFare>();
		int queryPages = PageUtil.getPageCount(psallcount,querySize);
		List<PSFare> tmppslist = new ArrayList<PSFare>();
		List<NewFare> tmpfarelist = new ArrayList<NewFare>();
		//��ѯ��firstDate������Ч������PS
		for (int i = 1; i <=queryPages; i++) {
			tmppslist = psdao.queryAllByDateForPage(carrier, days.getFirstDate(), i, querySize);
			tmpfarelist = createNewFareByPnPs(updatePnList,tmppslist);
			log.info("��"+i+"�β�ѯ��"+tmpfarelist.size() );
			flist.addAll(tmpfarelist);
		}
		return flist;
	}
	
	private long exportToXML(List<NewFare> nfarelist ,String carrier ,ExpType exptype, Date queryDate){
		return exportToXML(nfarelist, carrier, exptype, queryDate,null);
	}
	
	/**
	 * ����ѯ����Fare�б���������ת��ΪAgreement���󣬲���ת�����Agreement���󵼳�Ϊ��Ӧ��XML�ļ�
	 * @param nfarelist
	 * @param carrier
	 * @param exptype
	 * @param actype
	 * @param queryDate
	 * @param xmlIdx
	 * @return
	 */
	private long exportToXML(List<NewFare> nfarelist ,String carrier ,ExpType exptype, Date queryDate,Integer xmlIdx){
		long total = 0;
		
		log.info( "NewFare����:"+ nfarelist.size() );
		long count = 0;
		String xmlpath = null;
		if( xmlIdx!=null ){
			xmlpath = FileNameGenerator.genertXmlPath(carrier,catype,camodule,exptype,queryDate ,xmlIdx);
		}else{
			//��listתΪ��Ҫ������XFareImport�ļ���������XML�ļ���
			xmlpath = FileNameGenerator.genertXmlPath(carrier,catype,camodule,exptype,queryDate);
		}
		XFareImport xfareimp = new XFareImport();
//		int xmlItemNum = Integer.valueOf( PropertiesUtil.getSysProperty( Const.AIRTIS_FARE_XMLNUM ) );
//		List<NewFare> tmplist = new ArrayList<NewFare>();
//		int xmlPages = PageUtil.getPageCount(nfarelist.size(), xmlItemNum);
//		for(int i=1;i<=xmlPages;i++){
//			if(i==xmlPages){
//				tmplist = nfarelist.subList((i-1)*xmlItemNum, nfarelist.size());
//			}else{
//				tmplist = nfarelist.subList((i-1)*xmlItemNum, i*xmlItemNum);					
//			}
//			
//			//��listתΪ��Ҫ������XFareImport�ļ���������XML�ļ���
//			xfareimp.getAgreements().addAll( importor.getImport(tmplist, carrier, catype, actype).getAgreements() );
//			count = importor.getCount();
//			total+=count;
//			log.info("TmpFareList������"+tmplist.size() +" ==> "+count);
//		}
		xfareimp = importor.getImport(nfarelist, carrier, catype, ActionType.Null);
		count = importor.getCount();
		log.info("TmpFareList������"+nfarelist.size() +" ==> "+count);
		total += count;
		
		WriteXML(xfareimp,xmlpath);
		return total;
	}
	
	
	/**
	 * ���Ϊһ���µ�XML�ļ�
	 * @param nfarelist
	 * @param carrier
	 * @param exptype
	 * @param actype
	 * @param queryDate
	 * @param xmlIdx
	 * @return
	 * @throws IOException
	 * @throws Exception
	 */
	private void WriteXML(XFareImport xfareimp,String xmlpath){

		log.info( xmlpath );
		File xmlfile = new File(xmlpath);
		if(xmlfile.exists() ) xmlfile.delete();
		
		OutputStream os = null;
		try {
			os = new FileOutputStream( xmlfile );
			JaxbUtil.convertToXml( xfareimp, "UTF-8", os);
		} catch (Exception e) {
			ErrorLog.log( e );
		} finally{
			IOUtil.close(os);
		}
		
	}
	
	//����Pn-->Ps ������Ӧ�Ĺ����˼�
	private List<NewFare> createNewFareByPnPs(List<PNFare> pnlist,List<PSFare> pslist){
		Map<String, List<PSFare>> psmap = AirtisFareHandler.convertListToMap( pslist );
		List<NewFare> newFareList = new ArrayList<NewFare>();
		for( PNFare pn : pnlist ){
			newFareList.addAll( buildNewPsFare(pn,psmap) );
		}
		return newFareList;
	}
	
	private List<NewFare> buildNewPsFare(PNFare pn,Map<String,List<PSFare>> psmap){
		String key = AirtisFareHandler.getKey( pn );
		List<PSFare> pslist = psmap.get( key );
		if( pslist==null ){
			return new ArrayList<NewFare>();
		}
		
		List<NewFare> retlist = new ArrayList<NewFare>();
		Date pnEDate = pn.getEffDate();
		Date pnDDate = pn.getDiscDate();
		Date pnSFDate = pn.getFirstSaleDate();
		Date pnSLDate = pn.getLastSaleDate();
		for( PSFare ps : pslist ){
			//���PS�۸��ǽ�����������¼��������
			if( "1".equals( ps.getFlag() )){
				continue;
			}
			//�����Ч����֮��û�н�����������������¼������
			if( DateUtil.laterThan(ps.getEffDate() , pnDDate) || DateUtil.earlierThan(ps.getDiscDate(), pnEDate) 
				|| DateUtil.laterThan(ps.getFirstSaleDate(), pnSLDate) 
				|| DateUtil.earlierThan(ps.getLastSaleDate(), pnSFDate) ){
				continue;
			} 
			
			retlist.add( new NewFare(ps,pn) );
		}
		return retlist;
	}
	
	
	//����Ps-->Pn ������Ӧ�Ĺ����˼�
	private List<NewFare> createNewFareByPsPn(List<PSFare> pslist,List<PNFare> pnlist){
		Map<String, List<PNFare>> pnmap = AirtisFareHandler.convertListToMap(pnlist);
		List<NewFare> newFareList = new ArrayList<NewFare>();
		Money money = null;
		for( PSFare ps : pslist){
			// ���PS���ǽ�����Ҫ��PN��
			if("1".equals( ps.getFlag() )){
				money = ps.getMoney();
				double val = Math.round( money.getValue().doubleValue()/10)*10;
				money.setValue( new BigDecimal(val) );
				newFareList.add( buildNewFare(ps) );	//new NewFare(ps)
			}else{
				newFareList.addAll( buildNewFare( ps , pnmap));
			}
		}
		return newFareList;
	}
	
	private NewFare buildNewFare(PSFare ps){
		return new NewFare(ps);
	}
	
	//����һ�������˼ۼ�¼[ps]�Լ������˼�����[pn]��������Ч�Ĺ����˼�
	private List<NewFare> buildNewFare(PSFare ps ,Map<String,List<PNFare>> pnmap){
		
		String key = AirtisFareHandler.getKey( ps );
		List<PNFare> pnlist = pnmap.get(key);
		if( pnlist==null ){
			return new ArrayList<NewFare>();
		}
		
		List<NewFare> retlist = new ArrayList<NewFare>();
		Date psEDate = ps.getEffDate();
		Date psDDate = ps.getDiscDate();
		Date psSFDate = ps.getFirstSaleDate();
		Date psSLDate = ps.getLastSaleDate();
		for( PNFare pn : pnlist ){
			//���˵�����û���ཻ�ļ۸�
			if( DateUtil.laterThan(psEDate, pn.getDiscDate()) || DateUtil.earlierThan(psDDate, pn.getEffDate()) || 
				DateUtil.laterThan(psSFDate, pn.getLastSaleDate()) || DateUtil.earlierThan(psSLDate, pn.getFirstSaleDate()) ){
				continue;
			}
			retlist.add( new NewFare(ps,pn) );
		}
		
		return retlist;
	}
	
	//ȥ������1������ ����1�뼯��2�ظ���Ԫ��
	@Deprecated
	private void divlist(List<NewFare> srclist, List<NewFare> divedlist) {
		List<NewFare> retlist = new ArrayList<NewFare>();
		retlist.addAll( srclist );
		
		for (NewFare divfare : divedlist) {
			BigDecimal fareNo = divfare.getFareNo();
			String rptFileNo = divfare.getRptFileNo();
			BigDecimal pnFareNo = divfare.getPnFareNo();
			String pnRptFileNo = divfare.getPnRptFileNo();
			for ( NewFare sfare : retlist ) {
				BigDecimal tmpFareNo = sfare.getFareNo();
				String tmpRptFileNo = sfare.getRptFileNo();
				BigDecimal tmpPnFareNo = sfare.getPnFareNo();
				String tmpPnRptFileNo = sfare.getPnRptFileNo();
				if (fareNo.equals(tmpFareNo) && rptFileNo.equals(tmpRptFileNo)) {
					if ((pnFareNo == null && pnRptFileNo == null && tmpPnFareNo == null && tmpPnRptFileNo == null)
							|| (pnFareNo.equals(tmpPnFareNo) && pnRptFileNo.equals(tmpPnRptFileNo))) {
						retlist.remove(sfare);
						break;
					}
				}
			}
		}
		
		log.info( "ȥ�غ��srclist:" +retlist.size() );
	}
	
	class PK{
		BigDecimal psFareNo;
		String psRptFileNo;
		BigDecimal pnFareNo;
		String pnRptFileNo;
		
		public PK( BigDecimal psFareNo, String psRptFileNo , BigDecimal pnFareNo , String pnRptFileNo ){
			this.psFareNo = psFareNo;
			this.psRptFileNo = psRptFileNo;
			this.pnFareNo = pnFareNo;
			this.pnRptFileNo = pnRptFileNo;
		}
		
		public PK(NewFare nfare){
			this.psFareNo = nfare.getFareNo();
			this.psRptFileNo = nfare.getRptFileNo();
			this.pnFareNo = nfare.getPnFareNo();
			this.pnRptFileNo = nfare.getPnRptFileNo();
		}
		
		public BigDecimal getPsFareNo() {
			return psFareNo;
		}
		public void setPsFareNo(BigDecimal psFareNo) {
			this.psFareNo = psFareNo;
		}
		public String getPsRptFileNo() {
			return psRptFileNo;
		}
		public void setPsRptFileNo(String psRptFileNo) {
			this.psRptFileNo = psRptFileNo;
		}
		public BigDecimal getPnFareNo() {
			return pnFareNo;
		}
		public void setPnFareNo(BigDecimal pnFareNo) {
			this.pnFareNo = pnFareNo;
		}
		public String getPnRptFileNo() {
			return pnRptFileNo;
		}
		public void setPnRptFileNo(String pnRptFileNo) {
			this.pnRptFileNo = pnRptFileNo;
		}
	}
	
	private static void div(List<NewFare> srclist, List<NewFare> divlist){
		
		AirtisFareService t = new AirtisFareService();

		PK divpk = null,srcpk=null;
		for( NewFare divfare : divlist ){
			divpk = t.new PK(divfare);
			for( NewFare srcfare : srclist ){
				srcpk = t.new PK(srcfare);
				if( isPKEqual( divpk, srcpk ) ){
					srclist.remove( srcfare );
					break;
				}
			}
		}
	}
	
	private static boolean isPKEqual(PK s, PK n){
		
		if ( s.getPsFareNo().equals( n.getPsFareNo() ) && s.getPsRptFileNo().equals( n.getPsRptFileNo() )) {
			if (( s.getPnFareNo() == null && s.getPnRptFileNo() == null && n.getPnFareNo() == null && n.getPnRptFileNo() == null)
					|| ( s.getPnFareNo().equals( n.getPnFareNo() ) && s.getPnRptFileNo().equals( n.getPnRptFileNo() ))) {
				return true;
			}
		}
		return false;
	}

}
