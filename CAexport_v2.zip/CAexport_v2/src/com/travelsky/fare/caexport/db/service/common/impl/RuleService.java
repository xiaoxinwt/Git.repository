package com.travelsky.fare.caexport.db.service.common.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.travelsky.fare.caexport.db.dao.ICommonDao;
import com.travelsky.fare.caexport.db.model.common.rule.Rule;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.RuleImportor;
import com.travelsky.fare.caexport.dexp.vo.rule.XRuleImport;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DaoUtil;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.PageUtil;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class RuleService implements IExport<Rule>{
	
	private final int pageSize = 5000;
	private CAType catype = null;
	private CAModule camodule = null;

	private Log log = LogFactory.getLog( this.getClass() );
	private IImportor<Rule, XRuleImport> importor = new RuleImportor();
	private ICommonDao<Rule> dao;

	public RuleService(CAType catype) {
		this.catype = catype;
		this.camodule = CAModule.Rule;
		dao = (ICommonDao<Rule>) DaoUtil.getDaoImpl( this.catype,this.camodule );
	}
	
	//��������
	public Export exportAll(String carrier) throws NoFatalException, FatalException{
		List<Rule> rulelist = null;
		XRuleImport imp = null;
		long total = dao.countAll(carrier);
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				rulelist = dao.queryAllForPage(carrier, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(rulelist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			rulelist = dao.queryAll(carrier);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(rulelist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier,imp,this.catype,this.camodule,exptype);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportAllOfDate(String carrier , Date startDate) throws NoFatalException, FatalException{
		List<Rule> rulelist = null;
		XRuleImport imp = null;
		long total = dao.countAllFrom(carrier, startDate);
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			int idx = 0;
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				rulelist = dao.queryAllFromForPage(carrier,startDate, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(rulelist, carrier,this.catype,actype);
				count += importor.getCount();
				
				log.info( "page:"+pageNum+" ==> count:"+rulelist.size());
				if(imp!=null){
					idx++;
					long xmlstart = System.currentTimeMillis();
					ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,startDate,idx);
					toxmlcost += (System.currentTimeMillis()-xmlstart);
				}
			}
		}else{
			long querystart = System.currentTimeMillis();
			rulelist = dao.queryAllFrom(carrier, startDate);
			querycost += (System.currentTimeMillis()-querystart);

			imp = importor.getImport(rulelist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype,startDate);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(startDate);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportIncOfDate(String carrier , Date date) throws NoFatalException, FatalException{
		List<Rule> rulelist = null;
		XRuleImport imp = null;
		long total = dao.countIncOfDate(carrier, date);
		ExpType exptype = ExpType.Inc;
		ActionType actype = ActionType.Update;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			int idx = 0;
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				rulelist = dao.queryIncOfDateForPage(carrier,date, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(rulelist, carrier,this.catype,actype);
				count += importor.getCount();
				
				if(imp!=null){
					idx++;
					long xmlstart = System.currentTimeMillis();
					ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,date,idx);
					toxmlcost += (System.currentTimeMillis()-xmlstart);
				}
			}
		}else{
			long querystart = System.currentTimeMillis();
			rulelist = dao.queryIncOfDate(carrier, date);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(rulelist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype,date);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}

		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate( DateUtil.getYesterday(date) );
		exp.setEndDate( date );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException{
		List<Rule> rulelist = null;
		XRuleImport imp = null;
		long total = dao.countIncOfDays(carrier, days);
//			List<Date> dates = DateUtil.getDates(days.getFirstDate(),days.getLastDate());
		ExpType exptype = ExpType.Inc;
		ActionType actype = ActionType.Update;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			int idx = 0;
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				rulelist = dao.queryIncOfDaysForPage(carrier,days,pageNum,pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(rulelist, carrier,this.catype,actype);
				count += importor.getCount();
				
				if(imp!=null){
					idx++;
					long xmlstart = System.currentTimeMillis();
					ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,null,idx);
					toxmlcost += (System.currentTimeMillis()-xmlstart);
				}
			}
		}else{
			long querystart = System.currentTimeMillis();
			rulelist = dao.queryIncOfDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(rulelist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule,exptype);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}

		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(days.getFirstDate());
		exp.setEndDate( days.getLastDate() );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		
		IExport<Rule> exportor = null;
//		exportor = new RuleService(CAType.Airtis);
		exportor = new RuleService(CAType.Easyfare);
		
		String carrier = "MU";
		
		PairDays days = new PairDays("2015-01-01","2015-05-30");
		Date date = DateUtil.getDate("2015-01-01");
		
		Export exp = null;
//		exp = exportor.exportAll(carrier);
//		exp = exportor.exportAllOfDate(carrier, date);
		exp = exportor.exportIncOfDate(carrier, date);
//		exp = exportor.exportIncOfDays(carrier, days);
		ExportUtil.writeInfo(exp);
	}
	
}
