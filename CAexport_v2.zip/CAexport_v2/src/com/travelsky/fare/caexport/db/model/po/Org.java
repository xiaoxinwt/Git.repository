package com.travelsky.fare.caexport.db.model.po;

public class Org {

	//Nullable: false	ORG_STN
	private String orgStn;
	//Nullable: false	ORG_TYPE
	private String orgType;
	//Nullable: false	ORG_CITY
	private String orgCity;
	//Nullable: false	ORG_FLG
	private String orgFlg;

	public String getOrgStn() {
		return orgStn;
	}
	public void setOrgStn(String orgStn) {
		this.orgStn = orgStn;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getOrgCity() {
		return orgCity;
	}
	public void setOrgCity(String orgCity) {
		this.orgCity = orgCity;
	}
	public String getOrgFlg() {
		return orgFlg;
	}
	public void setOrgFlg(String orgFlg) {
		this.orgFlg = orgFlg;
	}
}
