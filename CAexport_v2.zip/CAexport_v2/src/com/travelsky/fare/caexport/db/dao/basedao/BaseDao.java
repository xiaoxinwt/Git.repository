package com.travelsky.fare.caexport.db.dao.basedao;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.MyBatisUtil;

public class BaseDao {
	
	private Log log=LogFactory.getLog("BaseDao");
	
	protected List<?> selectForList(String statementId,Map<String,Object> param) throws NoFatalException, FatalException{
		List<?> result = null;
		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
		try {
			result = session.selectList(statementId,param);
		} catch (Exception e) {
			e.printStackTrace();
			throw new FatalException(e);
		} finally{
			session.close();
		}
		return result;
	}
	
	protected Map selectForObject( String statementId, Map<String,Object> param ,String key) throws NoFatalException, FatalException{
		Map result = null;
		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
		try {
			result = session.selectMap(statementId,param,key);
		} catch (Exception e) {
			throw new FatalException(e);
		} finally{
			session.close();			
		}
		return result;
	}
	
	protected List<?> selectForListByPage( String statementId, Map<String,Object> param,RowBounds rowbounds) throws NoFatalException, FatalException{
		List<?> result = null;
		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
		try {
			result = session.selectList(statementId,param,rowbounds);
		} catch (Exception e) {
			throw new FatalException(e);
		} finally{
			session.close();			
		}
		return result;
	}

	protected Object selectForOne(String statementId,Map<String,Object> param) throws NoFatalException, FatalException{
		Object obj = null;
		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
		try {
			obj = session.selectOne(statementId,param);
		} catch (Exception e) {
			throw new FatalException(e);
		} finally{
			session.close();
		}
		return obj;
	}
	
	protected String getMapper( Class<?> mappercls ){
		String mapperName = mappercls.getSimpleName()+"Mapper";
		return mapperName;
	}
	
	protected void selectByHandler( String statementId, ResultHandler<?> handler,Map<String,Object> params) throws NoFatalException, FatalException{
		
		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
		try {
			session.select(statementId, params, handler);
		} catch (Exception e) {
			throw new FatalException(e);
		} finally{
			session.close();
		}
		
	}
	
}
