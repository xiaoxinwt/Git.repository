package com.travelsky.fare.caexport.db.model.po;

public class Route {
	//Nullable: false	ROUTEFLAG
	private String routeflag;

	public String getRouteflag() {
		return routeflag;
	}
	public void setRouteflag(String routeflag) {
		this.routeflag = routeflag;
	}
}
