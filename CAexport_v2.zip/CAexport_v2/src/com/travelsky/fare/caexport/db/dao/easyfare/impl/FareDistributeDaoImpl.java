package com.travelsky.fare.caexport.db.dao.easyfare.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareDistribution;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class FareDistributeDaoImpl extends CommonDaoImpl {

	private Map<String,Object> param;
	private FareDistResultHandler handler = new FareDistResultHandler();
	
	public Map<RefPK,List<String>> queryAvailByDate(String carrier, Date date) throws FatalException, NoFatalException {
		param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("date", date);
		queryByHandler(Fare.class, "selectAllDisGroup", param,handler);
		return handler.fareDist;
	}

	public Map<RefPK,List<String>> queryIncByDays(String carrier, PairDays days) throws FatalException, NoFatalException {
		param = new HashMap<String,Object>();
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		param.put("carrCode", carrier);
		queryByHandler(Fare.class, "selectIncDisGroup", param,handler);
		return handler.fareDist;
	}

	public Map<RefPK,List<String>> queryUpdateByDays(String carrier, PairDays days) throws FatalException, NoFatalException {
		param = new HashMap<String,Object>();
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		param.put("carrCode", carrier);
		queryByHandler(Fare.class, "selectUpdateDisGroup", param,handler);
		return handler.fareDist;
	}
	
	public static void main(String[] args) throws FatalException, NoFatalException {
		
		FareDistributeDaoImpl dao = new FareDistributeDaoImpl();
		Map<RefPK, List<String>> map = dao.queryAvailByDate("CA", DateUtil.getDate("2015-10-01"));
		for (RefPK key : map.keySet() ) {
			System.out.println( key + " : "+ map.get( key ));
		}
		
	}
	
	//��ѯ�������ӳ����
	class FareDistResultHandler implements ResultHandler<FareDistribution> {

		Map<RefPK, List<String>> fareDist = new HashMap<RefPK, List<String>>();
		
		FareDistribution dis = null;
		@Override
		public void handleResult(ResultContext<? extends FareDistribution> context) {
			
			dis = context.getResultObject();
			if( !fareDist.containsKey(dis.getRefpk()) ){
				fareDist.put( dis.getRefpk(), new ArrayList<String>() );
			}
			fareDist.get( dis.getRefpk() ).add( dis.getGroupId() );
		}
	}
	
}
