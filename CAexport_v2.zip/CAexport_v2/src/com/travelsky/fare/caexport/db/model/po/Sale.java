package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

import com.travelsky.fare.caexport.util.Tools;

public class Sale {
	//Nullable: false	SALE_EFF_DATE
	private Date saleEffDate;
	//Nullable: true	SALE_DISC_DATE
	private Date saleDiscDate;
	//Nullable: false	FIRST_SALE_DATE
	private Date firstSaleDate;
	//Nullable: false	LAST_SALE_DATE
	private Date lastSaleDate;
	//Nullable: false	SALES_EFF_DATE
	private Date salesEffDate;
	//Nullable: false	SALES_DISC_DATE
	private Date salesDiscDate;
	private String firstDate;
	private String lastDate;
	
	public Date getSalesEffDate() {
		return salesEffDate;
	}
	public void setSalesEffDate(Date salesEffDate) {
		this.salesEffDate = salesEffDate;
	}
	public Date getSalesDiscDate() {
		return salesDiscDate;
	}
	public void setSalesDiscDate(Date salesDiscDate) {
		this.salesDiscDate = salesDiscDate;
	}
	public Date getFirstSaleDate() {
		return firstSaleDate;
	}
	public void setFirstSaleDate(Date firstSaleDate) {
		this.firstSaleDate = firstSaleDate;
		this.firstDate = Tools.getStringDate( firstSaleDate );
	}
	public Date getLastSaleDate() {
		return lastSaleDate;
	}
	public void setLastSaleDate(Date lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
		this.lastDate = Tools.getStringDate( lastSaleDate );
	}
	public Date getSaleEffDate() {
		return saleEffDate;
	}
	public void setSaleEffDate(Date saleEffDate) {
		this.saleEffDate = saleEffDate;
	}
	public Date getSaleDiscDate() {
		return saleDiscDate;
	}
	public void setSaleDiscDate(Date saleDiscDate) {
		this.saleDiscDate = saleDiscDate;
	}
	public String getFirstDate() {
		return firstDate;
	}
	public void setFirstDate(String firstDate) {
		this.firstDate = firstDate;
	}
	public String getLastDate() {
		return lastDate;
	}
	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}
}
