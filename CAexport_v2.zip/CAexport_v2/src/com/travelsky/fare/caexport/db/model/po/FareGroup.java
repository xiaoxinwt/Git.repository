package com.travelsky.fare.caexport.db.model.po;

import java.util.List;

public class FareGroup {

	private RefPK refpk;
	private List<String> groupIds;
	
	public RefPK getRefpk() {
		return refpk;
	}
	public void setRefpk(RefPK refpk) {
		this.refpk = refpk;
	}
	public List<String> getGroupIds() {
		return groupIds;
	}
	public void setGroupIds(List<String> groupIds) {
		this.groupIds = groupIds;
	}
}
