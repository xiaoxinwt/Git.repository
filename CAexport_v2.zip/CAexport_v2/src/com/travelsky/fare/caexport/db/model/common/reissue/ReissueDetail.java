package com.travelsky.fare.caexport.db.model.common.reissue;

import com.travelsky.fare.caexport.db.model.po.Amount;
import com.travelsky.fare.caexport.db.model.po.Charge;
import com.travelsky.fare.caexport.db.model.po.Depart;
import com.travelsky.fare.caexport.db.model.po.Discount;
import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.Flight;
import com.travelsky.fare.caexport.db.model.po.LowerUpper;
import com.travelsky.fare.caexport.db.model.po.Priori;
import com.travelsky.fare.caexport.db.model.po.Ticket;

public class ReissueDetail implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	REISSUE_ID
	private String reissueId;
	//Nullable: false	SEQ_NUMBER
	private Integer seqNumber;
	//Nullable: true	PASSENGER_TYPE
	private String passengerType;
	private String fareBasis;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: true	JOURNEY_TYPE
	private String journeyType;
	private Ticket ticket = new Ticket();
	private Flight flight = new Flight();
	//Nullable: true	FREE_CHANGE_TIMES
	private String freeChangeTimes;
	private Charge charge = new Charge();
	private Amount amount = new Amount();
	private Discount dis = new Discount();
	//Nullable: true	CARRY_UNIT
	private Integer carryUnit;
	//Nullable: true	ROUND_TYPE
	private Integer roundType;
	//Nullable: true	REISSUE_CHARGE_TAG
	private Integer reissueChargeTag;
	//Nullable: false	REISSUE_RESTRICTION_ID
	private Integer reissueRestrictionId;
	//Nullable: true	DETAIL_TRANSLATE
	private String detailTranslate;
	private LowerUpper lowup = new LowerUpper();
	//Nullable: true	OTHER_REISSUE_CARRIER_LIST
	private String otherReissueCarrierList;
	//Nullable: false	RULE_TYPE
	private Integer ruleType;
	//Nullable: true	SPECIAL_PRODUCTION_TAG
	private Integer specialProductionTag;
	private Priori pri = new Priori();
	private Depart depart = new Depart();
	//Nullable: true	REISSUE_ALLOWED_TAG
	private Integer reissueAllowedTag;

	private Integer firstFlightTag;
	private Integer sameFlightTag;
	private String flightDateTag;
	private Integer flightDateNum;
	private String flightDateUnit;
	private Integer processTag;
	private Integer dateChangedTag;
	private Integer upgradeTag;
	private Integer upgradeFeeTag;
	private Integer fareDisplayTag;
	private Integer endorsmentTag;
	private String endorsmentPrefix;
	private String endorsmentSuffix;
	private String newEndorsment;
	
	public String getReissueId() {
		return reissueId;
	}
	public void setReissueId(String reissueId) {
		this.reissueId = reissueId;
	}
	public Integer getSeqNumber() {
		return seqNumber;
	}
	public void setSeqNumber(Integer seqNumber) {
		this.seqNumber = seqNumber;
	}
	public String getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public String getFreeChangeTimes() {
		return freeChangeTimes;
	}
	public void setFreeChangeTimes(String freeChangeTimes) {
		this.freeChangeTimes = freeChangeTimes;
	}
	public Charge getCharge() {
		return charge;
	}
	public void setCharge(Charge charge) {
		this.charge = charge;
	}
	public Amount getAmount() {
		return amount;
	}
	public void setAmount(Amount amount) {
		this.amount = amount;
	}
	public Discount getDis() {
		return dis;
	}
	public void setDis(Discount dis) {
		this.dis = dis;
	}
	public Integer getCarryUnit() {
		return carryUnit;
	}
	public void setCarryUnit(Integer carryUnit) {
		this.carryUnit = carryUnit;
	}
	public Integer getRoundType() {
		return roundType;
	}
	public void setRoundType(Integer roundType) {
		this.roundType = roundType;
	}
	public Integer getReissueChargeTag() {
		return reissueChargeTag;
	}
	public void setReissueChargeTag(Integer reissueChargeTag) {
		this.reissueChargeTag = reissueChargeTag;
	}
	public Integer getReissueRestrictionId() {
		return reissueRestrictionId;
	}
	public void setReissueRestrictionId(Integer reissueRestrictionId) {
		this.reissueRestrictionId = reissueRestrictionId;
	}
	public String getDetailTranslate() {
		return detailTranslate;
	}
	public void setDetailTranslate(String detailTranslate) {
		this.detailTranslate = detailTranslate;
	}
	public LowerUpper getLowup() {
		return lowup;
	}
	public void setLowup(LowerUpper lowup) {
		this.lowup = lowup;
	}
	public String getOtherReissueCarrierList() {
		return otherReissueCarrierList;
	}
	public void setOtherReissueCarrierList(String otherReissueCarrierList) {
		this.otherReissueCarrierList = otherReissueCarrierList;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}
	public Integer getSpecialProductionTag() {
		return specialProductionTag;
	}
	public void setSpecialProductionTag(Integer specialProductionTag) {
		this.specialProductionTag = specialProductionTag;
	}
	public Depart getDepart() {
		return depart;
	}
	public void setDepart(Depart depart) {
		this.depart = depart;
	}
	public Integer getReissueAllowedTag() {
		return reissueAllowedTag;
	}
	public void setReissueAllowedTag(Integer reissueAllowedTag) {
		this.reissueAllowedTag = reissueAllowedTag;
	}
	public Priori getPri() {
		return pri;
	}
	public void setPri(Priori pri) {
		this.pri = pri;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public Integer getFirstFlightTag() {
		return firstFlightTag;
	}
	public void setFirstFlightTag(Integer firstFlightTag) {
		this.firstFlightTag = firstFlightTag;
	}
	public Integer getSameFlightTag() {
		return sameFlightTag;
	}
	public void setSameFlightTag(Integer sameFlightTag) {
		this.sameFlightTag = sameFlightTag;
	}
	public String getFlightDateTag() {
		return flightDateTag;
	}
	public void setFlightDateTag(String flightDateTag) {
		this.flightDateTag = flightDateTag;
	}
	public Integer getFlightDateNum() {
		return flightDateNum;
	}
	public void setFlightDateNum(Integer flightDateNum) {
		this.flightDateNum = flightDateNum;
	}
	public String getFlightDateUnit() {
		return flightDateUnit;
	}
	public void setFlightDateUnit(String flightDateUnit) {
		this.flightDateUnit = flightDateUnit;
	}
	public Integer getProcessTag() {
		return processTag;
	}
	public void setProcessTag(Integer processTag) {
		this.processTag = processTag;
	}
	public Integer getDateChangedTag() {
		return dateChangedTag;
	}
	public void setDateChangedTag(Integer dateChangedTag) {
		this.dateChangedTag = dateChangedTag;
	}
	public Integer getUpgradeTag() {
		return upgradeTag;
	}
	public void setUpgradeTag(Integer upgradeTag) {
		this.upgradeTag = upgradeTag;
	}
	public Integer getUpgradeFeeTag() {
		return upgradeFeeTag;
	}
	public void setUpgradeFeeTag(Integer upgradeFeeTag) {
		this.upgradeFeeTag = upgradeFeeTag;
	}
	public Integer getFareDisplayTag() {
		return fareDisplayTag;
	}
	public void setFareDisplayTag(Integer fareDisplayTag) {
		this.fareDisplayTag = fareDisplayTag;
	}
	public Integer getEndorsmentTag() {
		return endorsmentTag;
	}
	public void setEndorsmentTag(Integer endorsmentTag) {
		this.endorsmentTag = endorsmentTag;
	}
	public String getEndorsmentPrefix() {
		return endorsmentPrefix;
	}
	public void setEndorsmentPrefix(String endorsmentPrefix) {
		this.endorsmentPrefix = endorsmentPrefix;
	}
	public String getEndorsmentSuffix() {
		return endorsmentSuffix;
	}
	public void setEndorsmentSuffix(String endorsmentSuffix) {
		this.endorsmentSuffix = endorsmentSuffix;
	}
	public String getNewEndorsment() {
		return newEndorsment;
	}
	public void setNewEndorsment(String newEndorsment) {
		this.newEndorsment = newEndorsment;
	}
}