package com.travelsky.fare.caexport.db.model.po;

public class Flagpo {
	//Nullable: true	CHARTER_FLIGHT_FLAG
	private Integer charterFlightFlag;
	//Nullable: true	FARES_COMBINATION_FLAG
	private Integer faresCombinationFlag;
	//Nullable: false	OPEN_JAW_FLAG
	private Integer openJawFlag;
	//Nullable: false	CANDIDATE_FLAG
	private Integer candidateFlag;
	//Nullable: true	FORBIDDEN_JOURNEY_FLAG
	private Integer forbiddenJourneyFlag;
	//Nullable: true	XML_IMPORT_FLAG
	private Integer xmlImportFlag;
	
	public Integer getFaresCombinationFlag() {
		return faresCombinationFlag;
	}
	public void setFaresCombinationFlag(Integer faresCombinationFlag) {
		this.faresCombinationFlag = faresCombinationFlag;
	}
	public Integer getOpenJawFlag() {
		return openJawFlag;
	}
	public void setOpenJawFlag(Integer openJawFlag) {
		this.openJawFlag = openJawFlag;
	}
	public Integer getCandidateFlag() {
		return candidateFlag;
	}
	public void setCandidateFlag(Integer candidateFlag) {
		this.candidateFlag = candidateFlag;
	}
	public Integer getForbiddenJourneyFlag() {
		return forbiddenJourneyFlag;
	}
	public void setForbiddenJourneyFlag(Integer forbiddenJourneyFlag) {
		this.forbiddenJourneyFlag = forbiddenJourneyFlag;
	}
	public Integer getXmlImportFlag() {
		return xmlImportFlag;
	}
	public void setXmlImportFlag(Integer xmlImportFlag) {
		this.xmlImportFlag = xmlImportFlag;
	}
	public Integer getCharterFlightFlag() {
		return charterFlightFlag;
	}
	public void setCharterFlightFlag(Integer charterFlightFlag) {
		this.charterFlightFlag = charterFlightFlag;
	}
}
