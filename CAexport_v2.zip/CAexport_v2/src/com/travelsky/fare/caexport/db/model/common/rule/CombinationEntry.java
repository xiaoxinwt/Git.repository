package com.travelsky.fare.caexport.db.model.common.rule;

import java.util.Date;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class CombinationEntry implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	SEQ_ID
	private Integer seqId;
	//Nullable: true	COMBINE_RULE_ID
	private String combineRuleId;
	//Nullable: true	FARE_BASIS
	private String fareBasis;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: false	LAST_UPDATE_BY
	private String lastUpdateBy;
	//Nullable: false	LAST_UPDATE_DATE
	private Date lastUpdateDate;
	//Nullable: false	CARRIER_CODE
	private String carrierCode;
	//Nullable: false	IS_CHECK_ALL_SECTORS
	private Integer isCheckAllSectors;
	//Nullable: false	RULE_SEQ_ID
	private Integer ruleSeqId;
	//Nullable: true	STAY_TYPE
	private Integer stayType;
	//Nullable: true	MINIMUM_STAY
	private Integer minimumStay;
	//Nullable: true	MINIMUM_STAY_UNIT
	private String minimumStayUnit;
	//Nullable: true	MAXIMUM_STAY
	private Integer maximumStay;
	//Nullable: true	MAXIMUM_STAY_UNIT
	private String maximumStayUnit;
	//Nullable: true	SECTOR_COMBINE_TYPE
	private Integer sectorCombineType;
	//Nullable: true	ORI_CODE
	private String oriCode;
	//Nullable: true	DEST_CODE
	private String destCode;
	
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public Integer getSeqId() {
		return seqId;
	}
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}
	public String getCombineRuleId() {
		return combineRuleId;
	}
	public void setCombineRuleId(String combineRuleId) {
		this.combineRuleId = combineRuleId;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getLastUpdateBy() {
		return lastUpdateBy;
	}
	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getCarrierCode() {
		return carrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}
	public Integer getIsCheckAllSectors() {
		return isCheckAllSectors;
	}
	public void setIsCheckAllSectors(Integer isCheckAllSectors) {
		this.isCheckAllSectors = isCheckAllSectors;
	}
	public Integer getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(Integer ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public Integer getStayType() {
		return stayType;
	}
	public void setStayType(Integer stayType) {
		this.stayType = stayType;
	}
	public Integer getMinimumStay() {
		return minimumStay;
	}
	public void setMinimumStay(Integer minimumStay) {
		this.minimumStay = minimumStay;
	}
	public String getMinimumStayUnit() {
		return minimumStayUnit;
	}
	public void setMinimumStayUnit(String minimumStayUnit) {
		this.minimumStayUnit = minimumStayUnit;
	}
	public Integer getMaximumStay() {
		return maximumStay;
	}
	public void setMaximumStay(Integer maximumStay) {
		this.maximumStay = maximumStay;
	}
	public String getMaximumStayUnit() {
		return maximumStayUnit;
	}
	public void setMaximumStayUnit(String maximumStayUnit) {
		this.maximumStayUnit = maximumStayUnit;
	}
	public Integer getSectorCombineType() {
		return sectorCombineType;
	}
	public void setSectorCombineType(Integer sectorCombineType) {
		this.sectorCombineType = sectorCombineType;
	}
	public String getOriCode() {
		return oriCode;
	}
	public void setOriCode(String oriCode) {
		this.oriCode = oriCode;
	}
	public String getDestCode() {
		return destCode;
	}
	public void setDestCode(String destCode) {
		this.destCode = destCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}