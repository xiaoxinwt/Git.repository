package com.travelsky.fare.caexport.db.model.po;

public class ZValue {
	//Nullable: true	Z_VALUE_MIN
	private Integer zValueMin;
	//Nullable: true	Z_VALUE_MAX
	private Integer zValueMax;
	//Nullable: true	Z_VALUE_MIN_SYMBOL
	private Integer zValueMinSymbol;
	//Nullable: true	Z_VALUE_MAX_SYMBOL
	private Integer zValueMaxSymbol;
	//Nullable: true	IF_Z_VALUE_CHECK
	private Integer ifZValueCheck;
	
	public Integer getzValueMin() {
		return zValueMin;
	}
	public void setzValueMin(Integer zValueMin) {
		this.zValueMin = zValueMin;
	}
	public Integer getzValueMax() {
		return zValueMax;
	}
	public void setzValueMax(Integer zValueMax) {
		this.zValueMax = zValueMax;
	}
	public Integer getzValueMinSymbol() {
		return zValueMinSymbol;
	}
	public void setzValueMinSymbol(Integer zValueMinSymbol) {
		this.zValueMinSymbol = zValueMinSymbol;
	}
	public Integer getzValueMaxSymbol() {
		return zValueMaxSymbol;
	}
	public void setzValueMaxSymbol(Integer zValueMaxSymbol) {
		this.zValueMaxSymbol = zValueMaxSymbol;
	}
	public Integer getIfZValueCheck() {
		return ifZValueCheck;
	}
	public void setIfZValueCheck(Integer ifZValueCheck) {
		this.ifZValueCheck = ifZValueCheck;
	}
}
