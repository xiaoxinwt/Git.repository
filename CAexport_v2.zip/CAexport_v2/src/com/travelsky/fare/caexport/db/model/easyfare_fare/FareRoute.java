package com.travelsky.fare.caexport.db.model.easyfare_fare;

import java.util.List;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class FareRoute implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: false	FARE_REC_NO
	private Integer fareRecNo;
	//Nullable: false	ROUTE_NO
	private Integer routeNo;
	//Nullable: true	ENTRY_LASTNUM
	private Integer entryLastnum;
	//Nullable: false	SUB_FARE_REC_NO
	private Integer subFareRecNo;

	//Nullable: false	ROUTEFLAG
	private String routeflag;
	private List<FareRouteEntry> routeEntries;
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Integer getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(Integer fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public Integer getRouteNo() {
		return routeNo;
	}
	public void setRouteNo(Integer routeNo) {
		this.routeNo = routeNo;
	}
	public Integer getEntryLastnum() {
		return entryLastnum;
	}
	public void setEntryLastnum(Integer entryLastnum) {
		this.entryLastnum = entryLastnum;
	}
	public Integer getSubFareRecNo() {
		return subFareRecNo;
	}
	public void setSubFareRecNo(Integer subFareRecNo) {
		this.subFareRecNo = subFareRecNo;
	}
	public List<FareRouteEntry> getRouteEntries() {
		return routeEntries;
	}
	public void setRouteEntries(List<FareRouteEntry> routeEntries) {
		this.routeEntries = routeEntries;
	}
	public String getRouteflag() {
		return routeflag;
	}
	public void setRouteflag(String routeflag) {
		this.routeflag = routeflag;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "FareRoute [locationCode=" + locationCode + ", refNo=" + refNo
				+ ", fareRecNo=" + fareRecNo + ", routeNo=" + routeNo
				+ ", entryLastnum=" + entryLastnum + ", subFareRecNo="
				+ subFareRecNo + ", routeflag=" + routeflag + ", routeEntries="
				+ routeEntries + "]";
	}
}