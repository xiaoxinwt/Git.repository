package com.travelsky.fare.caexport.db.model.po;

public class ACPair {
    private String airport;
    private String citycode;
    public ACPair() {
	}
	public ACPair(String airport, String citycode) {
		this.airport = airport;
		this.citycode = citycode;
	}
	/**
	 * @return the airport
	 */
	public String getAirport() {
		return airport;
	}
	/**
	 * @return the citycode
	 */
	public String getCitycode() {
		return citycode;
	}
    
}
