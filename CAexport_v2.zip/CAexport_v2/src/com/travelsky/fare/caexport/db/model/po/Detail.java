package com.travelsky.fare.caexport.db.model.po;

import java.math.BigDecimal;

public class Detail {
	private Categorypo cat;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	SEQ_ID
	private String seqId;
	//Nullable: false	PASSENGER_TYPE
	private String passengerType;
	//Nullable: false	JOURNEY_TYPE
	private String journeyType;
	//Nullable: false	BOOKING_CLASS
	private String bookingClass;
	//Nullable: false	FARE_BASIS
	private String fareBasis;
	//Nullable: false	TICKET_USE_TYPE
	private Integer ticketUseType;
	//Nullable: false	FIRST_TICKETED_TIME
	private Integer firstTicketedTime;
	//Nullable: false	LAST_TICKETED_TIME
	private Integer lastTicketedTime;
	//Nullable: false	DEPARTRUE_TIME_TYPE
	private Integer departrueTimeType;
	//Nullable: false	FIRST_DEPARTRUE_TIME
	private Integer firstDepartrueTime;
	//Nullable: false	LAST_DEPARTRUE_TIME
	private Integer lastDepartrueTime;
	//Nullable: false	CAL_USED_SECTOR_TYPE
	private Integer calUsedSectorType;
	//Nullable: false	CAL_BOOKING_CLASS
	private String calBookingClass;
	//Nullable: false	CAL_UNUSED_SECTOR_TYPE
	private Integer calUnusedSectorType;
	//Nullable: false	PERCENT
	private BigDecimal percent;
	//Nullable: false	MINIMUM_AMOUNT
	private Integer minimumAmount;
	//Nullable: false	FIXED_AMOUNT
	private Integer fixedAmount;
	//Nullable: false	TAX_REFUND_TYPE
	private Integer taxRefundType;
	//Nullable: false	TICKETED_TIME_UNIT
	private String ticketedTimeUnit;
	//Nullable: false	DEPARTRUE_TIME_UNIT
	private String departrueTimeUnit;
	//Nullable: false	CAL_UNUSED_PFARE_PERCENT
	private BigDecimal calUnusedPfarePercent;
	//Nullable: false	SPEC_RBD
	private String specRbd;
	//Nullable: false	REFUND_ALLOWED_TAG
	private BigDecimal refundAllowedTag;
	
	public Categorypo getCat() {
		return cat;
	}
	public void setCat(Categorypo cat) {
		this.cat = cat;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getSeqId() {
		return seqId;
	}
	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}
	public String getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public Integer getTicketUseType() {
		return ticketUseType;
	}
	public void setTicketUseType(Integer ticketUseType) {
		this.ticketUseType = ticketUseType;
	}
	public Integer getFirstTicketedTime() {
		return firstTicketedTime;
	}
	public void setFirstTicketedTime(Integer firstTicketedTime) {
		this.firstTicketedTime = firstTicketedTime;
	}
	public Integer getLastTicketedTime() {
		return lastTicketedTime;
	}
	public void setLastTicketedTime(Integer lastTicketedTime) {
		this.lastTicketedTime = lastTicketedTime;
	}
	public Integer getDepartrueTimeType() {
		return departrueTimeType;
	}
	public void setDepartrueTimeType(Integer departrueTimeType) {
		this.departrueTimeType = departrueTimeType;
	}
	public Integer getFirstDepartrueTime() {
		return firstDepartrueTime;
	}
	public void setFirstDepartrueTime(Integer firstDepartrueTime) {
		this.firstDepartrueTime = firstDepartrueTime;
	}
	public Integer getLastDepartrueTime() {
		return lastDepartrueTime;
	}
	public void setLastDepartrueTime(Integer lastDepartrueTime) {
		this.lastDepartrueTime = lastDepartrueTime;
	}
	public Integer getCalUsedSectorType() {
		return calUsedSectorType;
	}
	public void setCalUsedSectorType(Integer calUsedSectorType) {
		this.calUsedSectorType = calUsedSectorType;
	}
	public String getCalBookingClass() {
		return calBookingClass;
	}
	public void setCalBookingClass(String calBookingClass) {
		this.calBookingClass = calBookingClass;
	}
	public Integer getCalUnusedSectorType() {
		return calUnusedSectorType;
	}
	public void setCalUnusedSectorType(Integer calUnusedSectorType) {
		this.calUnusedSectorType = calUnusedSectorType;
	}
	public BigDecimal getPercent() {
		return percent;
	}
	public void setPercent(BigDecimal percent) {
		this.percent = percent;
	}
	public Integer getMinimumAmount() {
		return minimumAmount;
	}
	public void setMinimumAmount(Integer minimumAmount) {
		this.minimumAmount = minimumAmount;
	}
	public Integer getFixedAmount() {
		return fixedAmount;
	}
	public void setFixedAmount(Integer fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
	public Integer getTaxRefundType() {
		return taxRefundType;
	}
	public void setTaxRefundType(Integer taxRefundType) {
		this.taxRefundType = taxRefundType;
	}
	public String getTicketedTimeUnit() {
		return ticketedTimeUnit;
	}
	public void setTicketedTimeUnit(String ticketedTimeUnit) {
		this.ticketedTimeUnit = ticketedTimeUnit;
	}
	public String getDepartrueTimeUnit() {
		return departrueTimeUnit;
	}
	public void setDepartrueTimeUnit(String departrueTimeUnit) {
		this.departrueTimeUnit = departrueTimeUnit;
	}
	public BigDecimal getCalUnusedPfarePercent() {
		return calUnusedPfarePercent;
	}
	public void setCalUnusedPfarePercent(BigDecimal calUnusedPfarePercent) {
		this.calUnusedPfarePercent = calUnusedPfarePercent;
	}
	public String getSpecRbd() {
		return specRbd;
	}
	public void setSpecRbd(String specRbd) {
		this.specRbd = specRbd;
	}
	public BigDecimal getRefundAllowedTag() {
		return refundAllowedTag;
	}
	public void setRefundAllowedTag(BigDecimal refundAllowedTag) {
		this.refundAllowedTag = refundAllowedTag;
	}
}
