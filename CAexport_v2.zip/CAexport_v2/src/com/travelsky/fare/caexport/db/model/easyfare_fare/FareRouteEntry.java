package com.travelsky.fare.caexport.db.model.easyfare_fare;

import java.util.List;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class FareRouteEntry implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: false	FARE_REC_NO
	private Integer fareRecNo;
	//Nullable: false	ROUTE_NO
	private Integer routeNo;
	//Nullable: false	ENTRY_NO
	private Integer entryNo;
	//Nullable: true	FROM_CODE
	private String fromCode;
	//Nullable: true	FROM_CODE_TYPE
	private Integer fromCodeType;
	//Nullable: true	TO_CODE
	private String toCode;
	//Nullable: true	TO_CODE_TYPE
	private Integer toCodeType;
	//Nullable: true	STOPOVER_OR_TRANSFER
	private String stopoverOrTransfer;
	//Nullable: true	OPEN_JAW_FOR_BTWN
	private Integer openJawForBtwn;
	//Nullable: true	Q_CHARGE_AMT
	private Integer qChargeAmt;
	//Nullable: false	SUB_FARE_REC_NO
	private Integer subFareRecNo;
	//Nullable: true	MIN_STAY
	private Integer minStay;
	//Nullable: true	MAX_STAY
	private Integer maxStay;
	private List<FareRouteFlightNo> flightNoes;
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Integer getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(Integer fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public Integer getRouteNo() {
		return routeNo;
	}
	public void setRouteNo(Integer routeNo) {
		this.routeNo = routeNo;
	}
	public Integer getEntryNo() {
		return entryNo;
	}
	public void setEntryNo(Integer entryNo) {
		this.entryNo = entryNo;
	}
	public String getFromCode() {
		return fromCode;
	}
	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}
	public Integer getFromCodeType() {
		return fromCodeType;
	}
	public void setFromCodeType(Integer fromCodeType) {
		this.fromCodeType = fromCodeType;
	}
	public String getToCode() {
		return toCode;
	}
	public void setToCode(String toCode) {
		this.toCode = toCode;
	}
	public Integer getToCodeType() {
		return toCodeType;
	}
	public void setToCodeType(Integer toCodeType) {
		this.toCodeType = toCodeType;
	}
	public String getStopoverOrTransfer() {
		return stopoverOrTransfer;
	}
	public void setStopoverOrTransfer(String stopoverOrTransfer) {
		this.stopoverOrTransfer = stopoverOrTransfer;
	}
	public Integer getOpenJawForBtwn() {
		return openJawForBtwn;
	}
	public void setOpenJawForBtwn(Integer openJawForBtwn) {
		this.openJawForBtwn = openJawForBtwn;
	}
	public Integer getqChargeAmt() {
		return qChargeAmt;
	}
	public void setqChargeAmt(Integer qChargeAmt) {
		this.qChargeAmt = qChargeAmt;
	}
	public Integer getSubFareRecNo() {
		return subFareRecNo;
	}
	public void setSubFareRecNo(Integer subFareRecNo) {
		this.subFareRecNo = subFareRecNo;
	}
	public Integer getMinStay() {
		return minStay;
	}
	public void setMinStay(Integer minStay) {
		this.minStay = minStay;
	}
	public Integer getMaxStay() {
		return maxStay;
	}
	public void setMaxStay(Integer maxStay) {
		this.maxStay = maxStay;
	}
	public List<FareRouteFlightNo> getFlightNoes() {
		return flightNoes;
	}
	public void setFlightNoes(List<FareRouteFlightNo> flightNoes) {
		this.flightNoes = flightNoes;
	}
	
	@Override
	public String toString() {
		return "FareRouteEntry [locationCode=" + locationCode + ", refNo="
				+ refNo + ", fareRecNo=" + fareRecNo + ", routeNo=" + routeNo
				+ ", entryNo=" + entryNo + ", fromCode=" + fromCode
				+ ", fromCodeType=" + fromCodeType + ", toCode=" + toCode
				+ ", toCodeType=" + toCodeType + ", stopoverOrTransfer="
				+ stopoverOrTransfer + ", openJawForBtwn=" + openJawForBtwn
				+ ", qChargeAmt=" + qChargeAmt + ", subFareRecNo="
				+ subFareRecNo + ", minStay=" + minStay + ", maxStay="
				+ maxStay + ", flightNoes=" + flightNoes + "]";
	}
}