package com.travelsky.fare.caexport.db.dao.airtis.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.model.common.fbr.FBRDetail;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;

public class AirFBRDetailDaoImpl extends CommonDaoImpl implements IFareDao<FBRDetail> {
	private Log log = LogFactory.getLog("FBR");
	private Map<String, Object> param = new HashMap<String, Object>();

	//��ѯָ�����ڵ�����//����saledate��Ч�ڰ����˸������ڵ� FBRDetail����
	public List<FBRDetail> queryAllByDate( String carrier,Date date ) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", date);
		return (List<FBRDetail>) queryForList(FBRDetail.class, "selectEffectiveFBRDtl", param);
	}
	//��ѯָ�����ڷ�Χ�ڵ�����������
	public List<FBRDetail> queryInsertByDays( String carrier, PairDays days) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", days.getFirstDate() );
		param.put("discdate", days.getLastDate() );
		return (List<FBRDetail>) queryForList(FBRDetail.class, "selectIncrementEffectiveFBRDtl", param);
	}
	//��ѯָ�����ڷ�Χ�ڵ��޸ĵ�����
	public List<FBRDetail> queryUpdateByDays( String carrier, PairDays days ) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", days.getFirstDate() );
		return (List<FBRDetail>) queryForList(FBRDetail.class, "selectModifiedFBRDtl", param);
	}
	@Override
	public long countAllByDate(String carrier, Date saleDate)
			throws NoFatalException, FatalException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public long countInsertByDays(String carrier, PairDays days)
			throws NoFatalException, FatalException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public long countUpdateByDays(String carrier, PairDays days)
			throws NoFatalException, FatalException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<FBRDetail> queryAllByDateForPage(String carrier, Date saleDate,
			int pageNum, int pageSize) throws NoFatalException, FatalException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<FBRDetail> queryInsertByDaysForPage(String carrier,
			PairDays days, int pageNum, int pageSize) throws NoFatalException,
			FatalException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<FBRDetail> queryUpdateByDaysForPage(String carrier,
			PairDays days, int pageNum, int pageSize) throws NoFatalException,
			FatalException {
		// TODO Auto-generated method stub
		return null;
	}

}
