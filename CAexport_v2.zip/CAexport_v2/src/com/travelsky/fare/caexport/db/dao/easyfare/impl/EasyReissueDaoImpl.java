package com.travelsky.fare.caexport.db.dao.easyfare.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.ICommonDao;
import com.travelsky.fare.caexport.db.model.common.reissue.Reissue;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class EasyReissueDaoImpl extends CommonDaoImpl implements ICommonDao<Reissue>{

	Log log = LogFactory.getLog(this.getClass());
	
	public List<Reissue> queryAll(String carrier) throws NoFatalException, FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode",carrier);
		return (List<Reissue>) queryForList(Reissue.class,"Easy_SelectAll",param);
	}
	
	public List<Reissue> queryAllFrom(String carrier , Date startdate) throws NoFatalException, FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode",carrier);
		param.put("start",startdate);
		return (List<Reissue>) queryForList(Reissue.class,"Easy_SelectAll",param);
	}

	public List<Reissue> queryIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {
		return queryIncOfDays(carrier , new PairDays(DateUtil.getYesterday(date) ,date));
	}

	public List<Reissue> queryIncOfDays(String carrier,PairDays days) throws NoFatalException, FatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode",carrier);
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<Reissue>) queryForList(Reissue.class,"Easy_SelectInc",param);
	}


	public static void main(String[] args) throws NoFatalException, FatalException {
		EasyReissueDaoImpl dao = new EasyReissueDaoImpl();
		String carrier = "CA";
		PairDays days = new PairDays( "2015-01-01","2015-05-30" );
		Date date = DateUtil.getDate("2015-01-01");
		
		int pageNum = 1;
		int pageSize = 50;
		
		long total = 0;
		List<Reissue> list = new ArrayList<Reissue>();
		List<Reissue> page = new ArrayList<Reissue>();
		
		total = dao.countAll(carrier);
		list = dao.queryAll(carrier);
		page = dao.queryAllForPage(carrier, pageNum, pageSize);
		dao.log.info( total );
		dao.log.info( list.size() );
		dao.log.info( page.size() );
		
		total = dao.countAllFrom(carrier, date);
		list = dao.queryAllFrom(carrier, date);
		page = dao.queryAllFromForPage(carrier, date, pageNum, pageSize);
		dao.log.info( total );
		dao.log.info( list.size() );
		dao.log.info( page.size() );
		
		total = dao.countIncOfDate(carrier, date);
		list = dao.queryIncOfDate(carrier, date);
		page = dao.queryIncOfDateForPage(carrier, date, pageNum, pageSize);
		dao.log.info( total );
		dao.log.info( list.size() );
		dao.log.info( page.size() );
		
		total = dao.countIncOfDays(carrier, days);
		list = dao.queryIncOfDays(carrier,days);
		page = dao.queryIncOfDaysForPage(carrier, days, pageNum, pageSize);
		dao.log.info( total );
		dao.log.info( list.size() );
		dao.log.info( page.size() );
	}

	@Override
	public long countAll(String carrier) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryAll(carrier);
		return page.getTotal();
	}

	@Override
	public long countAllFrom(String carrier, Date startDate) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryAllFrom(carrier, startDate);
		return page.getTotal();
	}

	@Override
	public long countIncOfDate(String carrier, Date date) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryIncOfDate(carrier, date);
		return page.getTotal();
	}

	@Override
	public long countIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryIncOfDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	public List<Reissue> queryAllForPage(String carrier,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryAll(carrier);
	}
	
	@Override
	public List<Reissue> queryAllFromForPage(String carrier,Date startDate,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryAllFrom(carrier, startDate);
	}
	
	@Override
	public List<Reissue> queryIncOfDateForPage(String carrier,Date date,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryIncOfDate(carrier, date);
	}
	
	@Override
	public List<Reissue> queryIncOfDaysForPage(String carrier,PairDays days,int pageNum,int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum,pageSize,false);
		return queryIncOfDays(carrier, days);
	}

}
