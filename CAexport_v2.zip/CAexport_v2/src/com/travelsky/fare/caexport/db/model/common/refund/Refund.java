package com.travelsky.fare.caexport.db.model.common.refund;

import java.util.List;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class Refund implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REFUND_RULE_ID
	private String refundRuleId;
	//Nullable: false	REFUND_TYPE
	private Integer refundType;
	//Nullable: true	UNUSED_SECTOR_TAX
	private Integer unusedSectorTax;
	//Nullable: true	VOLUNTARY_TXT
	private String voluntaryTxt;
	//Nullable: true	INVOLUNTARY_TXT
	private String involuntaryTxt;
	//Nullable: false	RULE_TYPE
	private Integer ruleType;
	//Nullable: true	REFUND_YQTAX_ALLOWED
	private Integer refundYqtaxAllowed;
	private List<RefundEntry> entries;
	
	public Refund() {}
	public Refund(String refundRuleId, String locationCode, Integer refundType,
			Integer unusedSectorTax, String voluntaryTxt,
			String involuntaryTxt, Integer ruleType,
			Integer refundYqtaxAllowed) {
		this.refundRuleId = refundRuleId;
		this.locationCode = locationCode;
		this.refundType = refundType;
		this.unusedSectorTax = unusedSectorTax;
		this.voluntaryTxt = voluntaryTxt;
		this.involuntaryTxt = involuntaryTxt;
		this.ruleType = ruleType;
		this.refundYqtaxAllowed = refundYqtaxAllowed;
	}
	
	public String getRefundRuleId() {
		return refundRuleId;
	}
	public void setRefundRuleId(String refundRuleId) {
		this.refundRuleId = refundRuleId;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public Integer getRefundType() {
		return refundType;
	}
	public void setRefundType(Integer type) {
		this.refundType = type;
	}
	public Integer getUnusedSectorTax() {
		return unusedSectorTax;
	}
	public void setUnusedSectorTax(Integer unusedSectorTax) {
		this.unusedSectorTax = unusedSectorTax;
	}
	public String getVoluntaryTxt() {
		return voluntaryTxt;
	}
	public void setVoluntaryTxt(String voluntaryTxt) {
		this.voluntaryTxt = voluntaryTxt;
	}
	public String getInvoluntaryTxt() {
		return involuntaryTxt;
	}
	public void setInvoluntaryTxt(String involuntaryTxt) {
		this.involuntaryTxt = involuntaryTxt;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}
	public Integer getRefundYqtaxAllowed() {
		return refundYqtaxAllowed;
	}
	public void setRefundYqtaxAllowed(Integer refundYqtaxAllowed) {
		this.refundYqtaxAllowed = refundYqtaxAllowed;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<RefundEntry> getEntries() {
		return entries;
	}
	public void setEntries(List<RefundEntry> entries) {
		this.entries = entries;
	}
}