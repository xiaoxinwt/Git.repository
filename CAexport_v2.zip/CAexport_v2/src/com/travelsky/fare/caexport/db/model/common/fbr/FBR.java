package com.travelsky.fare.caexport.db.model.common.fbr;

import java.util.Date;
import java.util.List;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class FBR implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	FARE_BY_RULE_ID
	private String fareByRuleId;
	//Nullable: true	FBR_DESC
	private String fbrDesc;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: true	SOURCE
	private String source;
	//Nullable: true	WHEN_CREATE
	private Date whenCreate;
	//Nullable: true	WHO_CREATE
	private String whoCreate;
	//Nullable: true	WHERE_CREATE
	private String whereCreate;
	private List<FBRDetail> fbrDetails;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getFareByRuleId() {
		return fareByRuleId;
	}
	public void setFareByRuleId(String fareByRuleId) {
		this.fareByRuleId = fareByRuleId;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getFbrDesc() {
		return fbrDesc;
	}
	public void setFbrDesc(String fbrDesc) {
		this.fbrDesc = fbrDesc;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Date getWhenCreate() {
		return whenCreate;
	}
	public void setWhenCreate(Date whenCreate) {
		this.whenCreate = whenCreate;
	}
	public String getWhoCreate() {
		return whoCreate;
	}
	public void setWhoCreate(String whoCreate) {
		this.whoCreate = whoCreate;
	}
	public String getWhereCreate() {
		return whereCreate;
	}
	public void setWhereCreate(String whereCreate) {
		this.whereCreate = whereCreate;
	}
	public List<FBRDetail> getFbrDetails() {
		return fbrDetails;
	}
	public void setFbrDetails(List<FBRDetail> fbrDetails) {
		this.fbrDetails = fbrDetails;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}