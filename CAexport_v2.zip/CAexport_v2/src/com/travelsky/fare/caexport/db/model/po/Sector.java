package com.travelsky.fare.caexport.db.model.po;

public class Sector {
	//Nullable: true	SECTOR_RANGE_LOWER
	private Integer sectorRangeLower;
	//Nullable: true	SECTOR_RANGE_UPPER
	private Integer sectorRangeUpper;
	public Integer getSectorRangeLower() {
		return sectorRangeLower;
	}
	public void setSectorRangeLower(Integer sectorRangeLower) {
		this.sectorRangeLower = sectorRangeLower;
	}
	public Integer getSectorRangeUpper() {
		return sectorRangeUpper;
	}
	public void setSectorRangeUpper(Integer sectorRangeUpper) {
		this.sectorRangeUpper = sectorRangeUpper;
	}
}
