package com.travelsky.fare.caexport.db.model.po;

import java.math.BigDecimal;

public class Money {
	private BigDecimal value = new BigDecimal("0.000");
	// Nullable: false CURR_CODE
	private String currCode = "CNY";
	
	public Money(BigDecimal value){
		this.value = value;
		this.currCode = "CNY";
	}
	public Money(BigDecimal value,String currCode){
		this.value = value;
		this.currCode = currCode;
	}

	public BigDecimal getValue() {
		return value;
	}
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	public String getCurrCode() {
		return currCode;
	}
	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}
}
