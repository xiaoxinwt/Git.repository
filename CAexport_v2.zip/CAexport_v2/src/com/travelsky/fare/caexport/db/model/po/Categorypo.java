package com.travelsky.fare.caexport.db.model.po;

public class Categorypo {
	//Nullable: false	CATEGORY_TYPE
	private String categoryType;
	//Nullable: false	CATEGORY_ID
	private String categoryId;
	
	public String getCategoryType() {
		return categoryType;
	}
	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
}
