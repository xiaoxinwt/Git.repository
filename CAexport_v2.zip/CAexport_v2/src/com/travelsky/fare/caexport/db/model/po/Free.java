package com.travelsky.fare.caexport.db.model.po;

public class Free {
	//Nullable: true	FREE_STOPOVER_OUTBOUND
	private Integer freeStopoverOutbound;
	//Nullable: true	FREE_STOPOVER_INBOUND
	private Integer freeStopoverInbound;
	//Nullable: true	FREE_STOPOVER_TOTAL
	private Integer freeStopoverTotal;
	public Integer getFreeStopoverOutbound() {
		return freeStopoverOutbound;
	}
	public void setFreeStopoverOutbound(Integer freeStopoverOutbound) {
		this.freeStopoverOutbound = freeStopoverOutbound;
	}
	public Integer getFreeStopoverInbound() {
		return freeStopoverInbound;
	}
	public void setFreeStopoverInbound(Integer freeStopoverInbound) {
		this.freeStopoverInbound = freeStopoverInbound;
	}
	public Integer getFreeStopoverTotal() {
		return freeStopoverTotal;
	}
	public void setFreeStopoverTotal(Integer freeStopoverTotal) {
		this.freeStopoverTotal = freeStopoverTotal;
	}
}
