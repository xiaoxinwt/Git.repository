package com.travelsky.fare.caexport.db.model.po;

public class Dayof_del {
	//Nullable: true	DAY_OF_WEEK_RESTRICTION
	private Integer dayOfWeekRestriction;
	//Nullable: true	DAY_OF_WEEK_RESTRICTION_IN
	private Integer dayOfWeekRestrictionIn;
	public Integer getDayOfWeekRestriction() {
		return dayOfWeekRestriction;
	}
	public void setDayOfWeekRestriction(Integer dayOfWeekRestriction) {
		this.dayOfWeekRestriction = dayOfWeekRestriction;
	}
	public Integer getDayOfWeekRestrictionIn() {
		return dayOfWeekRestrictionIn;
	}
	public void setDayOfWeekRestrictionIn(Integer dayOfWeekRestrictionIn) {
		this.dayOfWeekRestrictionIn = dayOfWeekRestrictionIn;
	}
}
