package com.travelsky.fare.caexport.db.model.po;

public class Amount {

	//Nullable: true	MINIMUM_AMOUNT
	private Integer minimumAmount;
	//Nullable: true	FIXED_AMOUNT
	private Integer fixedAmount;
	//Nullable: true	CHARGE_AMOUNT
	private Integer chargeAmount;
	public Integer getMinimumAmount() {
		return minimumAmount;
	}
	public void setMinimumAmount(Integer minimumAmount) {
		this.minimumAmount = minimumAmount;
	}
	public Integer getFixedAmount() {
		return fixedAmount;
	}
	public void setFixedAmount(Integer fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
	public Integer getChargeAmount() {
		return chargeAmount;
	}
	public void setChargeAmount(Integer chargeAmount) {
		this.chargeAmount = chargeAmount;
	}
}
