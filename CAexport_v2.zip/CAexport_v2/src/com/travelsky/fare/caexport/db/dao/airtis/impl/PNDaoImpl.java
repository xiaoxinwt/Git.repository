package com.travelsky.fare.caexport.db.dao.airtis.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.model.airtis_fare.PNFare;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class PNDaoImpl extends CommonDaoImpl implements IFareDao<PNFare> {

	Map<String, Object> param = null;
	private static IFareDao<PNFare> dao = new PNDaoImpl();
	
	@Override
	public List<PNFare> queryAllByDate(String carrier, Date saleDate) throws FatalException, NoFatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("saleDate", saleDate );
		return (List<PNFare>) queryForList(PNFare.class, "selectAllOfDate", param);
	}

	@Override
	public List<PNFare> queryInsertByDays(String carrier, PairDays days) throws FatalException, NoFatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<PNFare>) queryForList(PNFare.class,"selectIncOfDays",param);
	}

	@Override
	public List<PNFare> queryUpdateByDays(String carrier, PairDays days) throws FatalException, NoFatalException {
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<PNFare>) queryForList(PNFare.class,"selectUpdateOfDays",param);
	}
	
	
	@Override
	public long countAllByDate(String carrier ,Date saleDate) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryAllByDate(carrier, saleDate);
		return page.getTotal();
	}
	
	@Override
	public long countInsertByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryInsertByDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	public long countUpdateByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryUpdateByDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	/*��ĳһ���ȫ��*/
	public List<PNFare> queryAllByDateForPage(String carrier, Date saleDate, int pageNum , int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryAllByDate(carrier, saleDate);
	}
	
	@Override
	public List<PNFare> queryInsertByDaysForPage(String carrier, PairDays days, int pageNum , int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryInsertByDays(carrier, days);
	}
	
	@Override
	public List<PNFare> queryUpdateByDaysForPage(String carrier, PairDays days,int pageNum , int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryUpdateByDays(carrier, days);
	}
	
	public static List<PNFare> pnListOfDate = null;
	//���ݺ��չ�˾��Ų�ѯ�������� ����sale��Ч�ڵ�����PNFare
	public static List<PNFare> getAllPnListOfDate(String carrier,Date saleDate, int pageNum , int pageSize) throws FatalException, NoFatalException{
//		if(pnListOfDate==null)
			pnListOfDate = dao.queryAllByDateForPage(carrier, saleDate, pageNum , pageSize);
		return pnListOfDate;
	}
	
	private static List<PNFare> incPnList = null;
	//���ݺ��չ�˾��������� ��ѯ  sale��ʼ��������Ϊ�������ڵ�������ЧPNFare
	public static List<PNFare> getIncPnList(String carrier, PairDays days, int pageNum , int pageSize) throws FatalException, NoFatalException{
		incPnList = dao.queryInsertByDaysForPage(carrier, days, pageNum , pageSize);
		return incPnList;
	}
	
	private static List<PNFare> updatePnList = null;
	//���ݺ��չ�˾��������� ��ѯ  ����޸���������Ϊ�������ڵ�������Ч��PNFare
	public static List<PNFare> getUpdatePnList(String carrier, PairDays days, int pageNum , int pageSize) throws FatalException, Throwable{
		updatePnList = dao.queryUpdateByDaysForPage(carrier, days, pageNum , pageSize);
		return updatePnList;
	}


	public static void main(String[] args) throws FatalException, NoFatalException {
		IFareDao<PNFare> dao = new PNDaoImpl();
		String carrier = "MU";
		PairDays days = new PairDays("2004-04-19","2005-04-20");
		Date saleDate = DateUtil.getDate("2004-04-20");
		System.out.println( saleDate );
		List<PNFare> list = null;
		long count = 0;
		count = dao.countAllByDate(carrier, saleDate);
		list = dao.queryAllByDateForPage(carrier, saleDate ,1 , 5000);
		System.out.println("�ϼƣ�"+count);
		System.out.println( saleDate.toLocaleString()+"�����ȫ���� "+ list.size() );
		count = dao.countInsertByDays(carrier, days);
		list = dao.queryInsertByDaysForPage(carrier, days , 1, 5000 );
		System.out.println("�ϼƣ�"+count);
		System.out.println( days.toString() + "�ڼ��������"+list.size() );
		count = dao.countUpdateByDays(carrier, days);
		list = dao.queryUpdateByDaysForPage(carrier, days , 1, 5000 );
		System.out.println("�ϼƣ�"+count);
		System.out.println( days.toString() + "�ڼ��޸ĵģ�"+list.size() );
	}
	
}
