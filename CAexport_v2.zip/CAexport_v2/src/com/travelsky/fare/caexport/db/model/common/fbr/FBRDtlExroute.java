package com.travelsky.fare.caexport.db.model.common.fbr;

import java.util.Date;
import java.util.List;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class FBRDtlExroute implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	FARE_BY_RULE_ID
	private String fareByRuleId;
	//Nullable: false	FARE_BY_RULE_DTL_ID
	private String fareByRuleDtlId;
	//Nullable: false	EXROUTE_NO
	private Integer exrouteNo;
	//Nullable: true	ENTRY_LASTNUM
	private Integer entryLastnum;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: true	SOURCE
	private String source;
	private List<FBRDtlExrouteEntry> routeEntries;
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getFareByRuleId() {
		return fareByRuleId;
	}
	public void setFareByRuleId(String fareByRuleId) {
		this.fareByRuleId = fareByRuleId;
	}
	public String getFareByRuleDtlId() {
		return fareByRuleDtlId;
	}
	public void setFareByRuleDtlId(String fareByRuleDtlId) {
		this.fareByRuleDtlId = fareByRuleDtlId;
	}
	public Integer getExrouteNo() {
		return exrouteNo;
	}
	public void setExrouteNo(Integer exrouteNo) {
		this.exrouteNo = exrouteNo;
	}
	public Integer getEntryLastnum() {
		return entryLastnum;
	}
	public void setEntryLastnum(Integer entryLastnum) {
		this.entryLastnum = entryLastnum;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public List<FBRDtlExrouteEntry> getRouteEntries() {
		return routeEntries;
	}
	public void setRouteEntries(List<FBRDtlExrouteEntry> routeEntries) {
		this.routeEntries = routeEntries;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}