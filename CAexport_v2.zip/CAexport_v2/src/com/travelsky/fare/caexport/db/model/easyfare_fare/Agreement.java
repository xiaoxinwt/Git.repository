package com.travelsky.fare.caexport.db.model.easyfare_fare;

import java.util.List;

import com.travelsky.fare.caexport.db.model.po.Approval;
import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.Fromtopo;

public class Agreement implements Entity {
	
	private static final long serialVersionUID = 1L;
	//Nullable: true	CARRIER_CODE
	private String carrierCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: true	SEND_FOR_APPROVAL
	private Integer sendForApproval;
	//Nullable: true	APPROVED
	private Integer approved;
	//Nullable: true	AGREEMENT_DESC
	private String desc;
	private Fromtopo fromto = new Fromtopo();
	//Nullable: true	FARE_REC_LASTNUM
	private Integer fareRecLastnum;
	//Nullable: false	CURRENCY_CODE
	private String currencyCode;
	//Nullable: false	CURRENCY_CODE2
	private String currencyCode2;
	//Nullable: true	ALGORITHM_NAME
	private String algorithmName;
	//Nullable: true	PREFIX
	private String prefix;
	//Nullable: true	SUFFIX
	private String suffix;
	//Nullable: true	REMARKS
	private String remarks;
	private Approval app = new Approval();
	//Nullable: false	EXTENSION_ID
	private String extensionId;
	//Nullable: false	DISTRIBUTION_STATUS
	private Integer distributionStatus;
	//Nullable: true	FARE_CATEGORY
	private Integer fareCategory;
	//Nullable: true	RPT_FILE_NO
	private String rptFileNo;
	private List<String> groupIds;
	private List<Fare> fares;
	private List<FareDistribution> distributes;
	public String getCarrierCode() {
		return carrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Integer getSendForApproval() {
		return sendForApproval;
	}
	public void setSendForApproval(Integer sendForApproval) {
		this.sendForApproval = sendForApproval;
	}
	public Integer getApproved() {
		return approved;
	}
	public void setApproved(Integer approved) {
		this.approved = approved;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Fromtopo getFromto() {
		return fromto;
	}
	public void setFromto(Fromtopo fromto) {
		this.fromto = fromto;
	}
	public Integer getFareRecLastnum() {
		return fareRecLastnum;
	}
	public void setFareRecLastnum(Integer fareRecLastnum) {
		this.fareRecLastnum = fareRecLastnum;
	}
	public List<String> getGroupIds() {
		return groupIds;
	}
	public void setGroupIds(List<String> groupIds) {
		this.groupIds = groupIds;
	}
	public List<Fare> getFares() {
		return fares;
	}
	public void setFares(List<Fare> fares) {
		this.fares = fares;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getCurrencyCode2() {
		return currencyCode2;
	}
	public void setCurrencyCode2(String currencyCode2) {
		this.currencyCode2 = currencyCode2;
	}
	public String getAlgorithmName() {
		return algorithmName;
	}
	public void setAlgorithmName(String algorithmName) {
		this.algorithmName = algorithmName;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Approval getApp() {
		return app;
	}
	public void setApp(Approval app) {
		this.app = app;
	}
	public String getExtensionId() {
		return extensionId;
	}
	public void setExtensionId(String extensionId) {
		this.extensionId = extensionId;
	}
	public Integer getDistributionStatus() {
		return distributionStatus;
	}
	public void setDistributionStatus(Integer distributionStatus) {
		this.distributionStatus = distributionStatus;
	}
	public Integer getFareCategory() {
		return fareCategory;
	}
	public void setFareCategory(Integer fareCategory) {
		this.fareCategory = fareCategory;
	}
	public String getRptFileNo() {
		return rptFileNo;
	}
	public void setRptFileNo(String rptFileNo) {
		this.rptFileNo = rptFileNo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<FareDistribution> getDistributes() {
		return distributes;
	}
	public void setDistributes(List<FareDistribution> distributes) {
		this.distributes = distributes;
	}
}