package com.travelsky.fare.caexport.db.model.po;

public class Depart {
	//Nullable: true	DEPARTRUE_TIME_TYPE
	private Integer departrueTimeType;
	//Nullable: true	FIRST_DEPARTRUE_TIME
	private Integer firstDepartrueTime;
	//Nullable: true	LAST_DEPARTRUE_TIME
	private Integer lastDepartrueTime;
	//Nullable: true	DEPARTRUE_TIME_UNIT
	private String departrueTimeUnit;
	
	public Integer getDepartrueTimeType() {
		return departrueTimeType;
	}
	public void setDepartrueTimeType(Integer departrueTimeType) {
		this.departrueTimeType = departrueTimeType;
	}
	public Integer getFirstDepartrueTime() {
		return firstDepartrueTime;
	}
	public void setFirstDepartrueTime(Integer firstDepartrueTime) {
		this.firstDepartrueTime = firstDepartrueTime;
	}
	public Integer getLastDepartrueTime() {
		return lastDepartrueTime;
	}
	public void setLastDepartrueTime(Integer lastDepartrueTime) {
		this.lastDepartrueTime = lastDepartrueTime;
	}
	public String getDepartrueTimeUnit() {
		return departrueTimeUnit;
	}
	public void setDepartrueTimeUnit(String departrueTimeUnit) {
		this.departrueTimeUnit = departrueTimeUnit;
	}

}
