package com.travelsky.fare.caexport.db.dao.airtis.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.model.airtis_fare.PSFare;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class PSDaoImpl extends CommonDaoImpl implements IFareDao<PSFare>{
	
	@Override
	public List<PSFare> queryAllByDate(String carrier, Date saleDate) throws NoFatalException, FatalException{
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("saleDate", saleDate );
		return (List<PSFare>) queryForList(PSFare.class, "selectAllOfDate", param);
	}

	@Override
	public List<PSFare> queryInsertByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<PSFare>) queryForList(PSFare.class, "selectIncOfDays" ,param);
	}

	@Override
	public List<PSFare> queryUpdateByDays(String carrier, PairDays days) throws NoFatalException, FatalException{
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate() );
		param.put("end", days.getLastDate() );
		return (List<PSFare>) queryForList(PSFare.class, "selectUpdateOfDays", param);
	}
	
	@Override
	public long countAllByDate(String carrier , Date saleDate) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryAllByDate(carrier, saleDate);
		return page.getTotal();
	}
	
	@Override
	public long countInsertByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryInsertByDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	public long countUpdateByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		queryUpdateByDays(carrier, days);
		return page.getTotal();
	}
	
	@Override
	//���ݺ��չ�˾�����ڲ�ѯ���е�����Ч��PSFare
	public List<PSFare> queryAllByDateForPage(String carrier, Date saleDate,int pageNum , int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize, false);
		return queryAllByDate(carrier, saleDate);
	}
	
	@Override
	//���ݺ��չ�˾�����ڲ�ѯ������ʼ������������Ϊ�������ЧPSFare
	public List<PSFare> queryInsertByDaysForPage(String carrier, PairDays days, int pageNum , int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize, false);
		return queryInsertByDays(carrier, days);
	}
	
	@Override
	//���ݺ��չ�˾�����ڲ�ѯ��������޸���������Ϊ�������ЧPSFare
	public List<PSFare> queryUpdateByDaysForPage(String carrier, PairDays days,int pageNum, int pageSize) throws FatalException, NoFatalException {
		PageHelper.startPage(pageNum, pageSize, false);
		return queryUpdateByDays(carrier, days);
	}
	

	public static void main(String[] args) throws FatalException, NoFatalException {
		
		PairDays days = new PairDays("2004-04-19","2005-04-20");
		Date saleDate = DateUtil.getDate("2004-04-20");
		IFareDao<PSFare> dao = new PSDaoImpl();
		String carrier = "MU";
		List<PSFare> list = null;
		long count = 0 ;
		count = dao.countAllByDate(carrier, saleDate);
		list = dao.queryAllByDateForPage(carrier, saleDate,1,5000 );
		System.out.println( "�ܼƣ�"+ count );
		System.out.println( saleDate.toLocaleString()+"�����ȫ����"+list.size() );
		list = dao.queryInsertByDaysForPage(carrier, days , 1,5000 );
		count = dao.countInsertByDays(carrier, days);
		System.out.println( "�ܼƣ�"+ count );
		System.out.println( days.toString()+"�����ڵ�������"+list.size() );
		count = dao.countUpdateByDays(carrier, days);
		list = dao.queryUpdateByDaysForPage(carrier, days ,1,5000);
		System.out.println( "�ܼƣ�"+ count );
		System.out.println( days.toString()+"�����ڵ��޸ģ�"+list.size() );

	}

}
