package com.travelsky.fare.caexport.db.model.po;

import java.math.BigDecimal;

public class Child {
	//Nullable: true	CHILD_DISCOUNT_AMOUNT
	private BigDecimal childDiscountAmount;
	//Nullable: true	CHILD_DISCOUNT_PERCENT
	private Integer childDiscountPercent;
	//Nullable: true	CHILD_ABSOLUTE_AMT_ENTERED
	private Integer childAbsoluteAmtEntered;
	//Nullable: true	CHILD_VALUE_CODE
	private String childValueCode;
	//Nullable: true	CHILD_TOUR_CODE
	private String childTourCode;
	//Nullable: true	CHILD_RSF_AMT
	private Integer childRsfAmt;
	//Nullable: true	CHILD_PUBLISHED_FBC
	private String childPublishedFbc;
	//Nullable: true	CHILD_VALUE_CODE2
	private String childValueCode2;
	//Nullable: true	CHILD_BAGGAGE_ALLOWANCE
	private Integer childBaggageAllowance;
	public BigDecimal getChildDiscountAmount() {
		return childDiscountAmount;
	}
	public void setChildDiscountAmount(BigDecimal childDiscountAmount) {
		this.childDiscountAmount = childDiscountAmount;
	}
	public Integer getChildDiscountPercent() {
		return childDiscountPercent;
	}
	public void setChildDiscountPercent(Integer childDiscountPercent) {
		this.childDiscountPercent = childDiscountPercent;
	}
	public Integer getChildAbsoluteAmtEntered() {
		return childAbsoluteAmtEntered;
	}
	public void setChildAbsoluteAmtEntered(Integer childAbsoluteAmtEntered) {
		this.childAbsoluteAmtEntered = childAbsoluteAmtEntered;
	}
	public String getChildValueCode() {
		return childValueCode;
	}
	public void setChildValueCode(String childValueCode) {
		this.childValueCode = childValueCode;
	}
	public String getChildTourCode() {
		return childTourCode;
	}
	public void setChildTourCode(String childTourCode) {
		this.childTourCode = childTourCode;
	}
	public Integer getChildRsfAmt() {
		return childRsfAmt;
	}
	public void setChildRsfAmt(Integer childRsfAmt) {
		this.childRsfAmt = childRsfAmt;
	}
	public String getChildPublishedFbc() {
		return childPublishedFbc;
	}
	public void setChildPublishedFbc(String childPublishedFbc) {
		this.childPublishedFbc = childPublishedFbc;
	}
	public String getChildValueCode2() {
		return childValueCode2;
	}
	public void setChildValueCode2(String childValueCode2) {
		this.childValueCode2 = childValueCode2;
	}
	public Integer getChildBaggageAllowance() {
		return childBaggageAllowance;
	}
	public void setChildBaggageAllowance(Integer childBaggageAllowance) {
		this.childBaggageAllowance = childBaggageAllowance;
	}
}
