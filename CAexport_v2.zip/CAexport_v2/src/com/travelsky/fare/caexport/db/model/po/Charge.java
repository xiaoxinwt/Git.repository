package com.travelsky.fare.caexport.db.model.po;

public class Charge {
	//Nullable: true	CHARGEABLE_STOPOVER_OUTBOUND
	private Integer chargeableStopoverOutbound;
	//Nullable: true	CHARGEABLE_STOPOVER_INBOUND
	private Integer chargeableStopoverInbound;
	//Nullable: true	CHARGEABLE_STOPOVER_TOTAL
	private Integer chargeableStopoverTotal;
	//Nullable: true	CHARGE_TYPE
	private Integer chargeType;
	//Nullable: true	CHARGE_CURRENCY_CODE
	private String chargeCurrencyCode;
	//Nullable: true	CHARGE_UNIT
	private Integer chargeUnit;
	//Nullable: true	CHARGE_MIN_AMOUNT
	private Integer chargeMinAmount;
	//Nullable: true	CHARGE_MIN_CURRENCY_CODE
	private String chargeMinCurrencyCode;
	public Integer getChargeType() {
		return chargeType;
	}
	public void setChargeType(Integer chargeType) {
		this.chargeType = chargeType;
	}
	public String getChargeCurrencyCode() {
		return chargeCurrencyCode;
	}
	public void setChargeCurrencyCode(String chargeCurrencyCode) {
		this.chargeCurrencyCode = chargeCurrencyCode;
	}
	public Integer getChargeUnit() {
		return chargeUnit;
	}
	public void setChargeUnit(Integer chargeUnit) {
		this.chargeUnit = chargeUnit;
	}
	public Integer getChargeMinAmount() {
		return chargeMinAmount;
	}
	public void setChargeMinAmount(Integer chargeMinAmount) {
		this.chargeMinAmount = chargeMinAmount;
	}
	public String getChargeMinCurrencyCode() {
		return chargeMinCurrencyCode;
	}
	public void setChargeMinCurrencyCode(String chargeMinCurrencyCode) {
		this.chargeMinCurrencyCode = chargeMinCurrencyCode;
	}
	public Integer getChargeableStopoverOutbound() {
		return chargeableStopoverOutbound;
	}
	public void setChargeableStopoverOutbound(Integer chargeableStopoverOutbound) {
		this.chargeableStopoverOutbound = chargeableStopoverOutbound;
	}
	public Integer getChargeableStopoverInbound() {
		return chargeableStopoverInbound;
	}
	public void setChargeableStopoverInbound(Integer chargeableStopoverInbound) {
		this.chargeableStopoverInbound = chargeableStopoverInbound;
	}
	public Integer getChargeableStopoverTotal() {
		return chargeableStopoverTotal;
	}
	public void setChargeableStopoverTotal(Integer chargeableStopoverTotal) {
		this.chargeableStopoverTotal = chargeableStopoverTotal;
	}
}
