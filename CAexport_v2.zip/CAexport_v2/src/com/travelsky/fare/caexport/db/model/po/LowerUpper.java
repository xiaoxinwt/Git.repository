package com.travelsky.fare.caexport.db.model.po;

public class LowerUpper {
	//Nullable: true	LOWER_VALUE
	private Integer lowerValue;
	//Nullable: true	LOWER_RELATE
	private String lowerRelate;
	//Nullable: true	UPPER_VALUE
	private Integer upperValue;
	//Nullable: true	UPPER_RELATE
	private String upperRelate;
	public Integer getLowerValue() {
		return lowerValue;
	}
	public void setLowerValue(Integer lowerValue) {
		this.lowerValue = lowerValue;
	}
	public String getLowerRelate() {
		return lowerRelate;
	}
	public void setLowerRelate(String lowerRelate) {
		this.lowerRelate = lowerRelate;
	}
	public Integer getUpperValue() {
		return upperValue;
	}
	public void setUpperValue(Integer upperValue) {
		this.upperValue = upperValue;
	}
	public String getUpperRelate() {
		return upperRelate;
	}
	public void setUpperRelate(String upperRelate) {
		this.upperRelate = upperRelate;
	}
}
