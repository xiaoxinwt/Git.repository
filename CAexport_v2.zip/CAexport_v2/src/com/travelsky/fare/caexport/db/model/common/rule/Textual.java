package com.travelsky.fare.caexport.db.model.common.rule;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class Textual implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: true	APPLICATION
	private String application;
	//Nullable: true	ELIGIBILITY
	private String eligibility;
	//Nullable: true	MAXIMUM_GROUP_SIZE
	private String maximumGroupSize;
	//Nullable: true	EXTENSION_OF_VALIDITY
	private String extensionOfValidity;
	//Nullable: true	PAYMENT
	private String payment;
	//Nullable: true	TICKETING
	private String ticketing;
	//Nullable: true	CANCELLATION_N_REFUNDS
	private String cancellationNRefunds;
	//Nullable: true	REBOOKING_N_REROUTING
	private String rebookingNRerouting;
	//Nullable: true	TRAVEL_TOGETHER
	private String travelTogether;
	//Nullable: true	OTHER_CONDITIONS
	private String otherConditions;
	//Nullable: true	RULE_SEQ_ID
	private Integer ruleSeqId;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getEligibility() {
		return eligibility;
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	public String getMaximumGroupSize() {
		return maximumGroupSize;
	}
	public void setMaximumGroupSize(String maximumGroupSize) {
		this.maximumGroupSize = maximumGroupSize;
	}
	public String getExtensionOfValidity() {
		return extensionOfValidity;
	}
	public void setExtensionOfValidity(String extensionOfValidity) {
		this.extensionOfValidity = extensionOfValidity;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getTicketing() {
		return ticketing;
	}
	public void setTicketing(String ticketing) {
		this.ticketing = ticketing;
	}
	public String getCancellationNRefunds() {
		return cancellationNRefunds;
	}
	public void setCancellationNRefunds(String cancellationNRefunds) {
		this.cancellationNRefunds = cancellationNRefunds;
	}
	public String getRebookingNRerouting() {
		return rebookingNRerouting;
	}
	public void setRebookingNRerouting(String rebookingNRerouting) {
		this.rebookingNRerouting = rebookingNRerouting;
	}
	public String getTravelTogether() {
		return travelTogether;
	}
	public void setTravelTogether(String travelTogether) {
		this.travelTogether = travelTogether;
	}
	public String getOtherConditions() {
		return otherConditions;
	}
	public void setOtherConditions(String otherConditions) {
		this.otherConditions = otherConditions;
	}
	public Integer getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(Integer ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}