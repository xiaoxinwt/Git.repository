package com.travelsky.fare.caexport.db.model.easyfare_fare;

import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.MinMax;

public class FareRule implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	REF_NO
	private String refNo;
	//Nullable: false	FARE_REC_NO
	private Integer fareRecNo;
	private MinMax mm = new MinMax();
	//Nullable: false	SUB_FARE_REC_NO
	private Integer subFareRecNo;
	
	/**�������ӵĸ����ֶ�*/
	private String ruleId;
	//Nullable: false	RULE_NO
	private String ruleNo;
	//Nullable: true	RULE_ID_NO
	private String ruleIdNo;
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Integer getFareRecNo() {
		return fareRecNo;
	}
	public void setFareRecNo(Integer fareRecNo) {
		this.fareRecNo = fareRecNo;
	}
	public MinMax getMm() {
		return mm;
	}
	public void setMm(MinMax mm) {
		this.mm = mm;
	}
	public Integer getSubFareRecNo() {
		return subFareRecNo;
	}
	public void setSubFareRecNo(Integer subFareRecNo) {
		this.subFareRecNo = subFareRecNo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getRuleNo() {
		return ruleNo;
	}
	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}
	public String getRuleIdNo() {
		return ruleIdNo;
	}
	public void setRuleIdNo(String ruleIdNo) {
		this.ruleIdNo = ruleIdNo;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	@Override
	public String toString() {
		return "FareRule [locationCode=" + locationCode + ", refNo=" + refNo
				+ ", fareRecNo=" + fareRecNo + ", mm=" + mm + ", subFareRecNo="
				+ subFareRecNo + ", ruleId=" + ruleId + ", ruleNo=" + ruleNo
				+ ", ruleIdNo=" + ruleIdNo + "]";
	}
}