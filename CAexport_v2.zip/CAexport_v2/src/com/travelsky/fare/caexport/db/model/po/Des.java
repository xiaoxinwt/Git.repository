package com.travelsky.fare.caexport.db.model.po;

public class Des {
	
	//Nullable: false	DES_STN
	private String desStn;
	//Nullable: false	DES_TYPE
	private String desType;
	//Nullable: false	DES_CITY
	private String desCity;
	//Nullable: false	DES_FLG
	private String desFlg;

	public String getDesStn() {
		return desStn;
	}
	public void setDesStn(String desStn) {
		this.desStn = desStn;
	}
	public String getDesType() {
		return desType;
	}
	public void setDesType(String desType) {
		this.desType = desType;
	}
	public String getDesCity() {
		return desCity;
	}
	public void setDesCity(String desCity) {
		this.desCity = desCity;
	}
	public String getDesFlg() {
		return desFlg;
	}
	public void setDesFlg(String desFlg) {
		this.desFlg = desFlg;
	}
}
