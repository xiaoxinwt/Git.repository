package com.travelsky.fare.caexport.db.model.common.rule;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class HourRestrictionIn implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: false	FROM_NO
	private Integer fromNo;
	//Nullable: true	TO_NO
	private Integer toNo;
	//Nullable: true	RULE_SEQ_ID
	private Integer ruleSeqId;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public Integer getFromNo() {
		return fromNo;
	}
	public void setFromNo(Integer fromNo) {
		this.fromNo = fromNo;
	}
	public Integer getToNo() {
		return toNo;
	}
	public void setToNo(Integer toNo) {
		this.toNo = toNo;
	}
	public Integer getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(Integer ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}