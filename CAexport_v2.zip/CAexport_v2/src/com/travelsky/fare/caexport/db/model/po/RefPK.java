/**============================================================
 * ��Ȩ�� Travelsky ��Ȩ���� (c) 2008 - 2009
 * �ļ��� domain.model.valueobject.RefPK
 * ������: RefPK
 * �޸ļ�¼��
 * ����                		����                		����
 * =============================================================
 * 2011-7-14         liye(liye@travelsky.com)    �����ļ���ʵ�ֻ�������
 * ============================================================*/

package com.travelsky.fare.caexport.db.model.po;

public class RefPK {
	private String locationCode;
    private String refNo;
    private String carrier;
    
    public RefPK(){}

    public RefPK(String carrier,String locationCode,String refNo){
    	this.locationCode=locationCode;
    	this.refNo=refNo;
    	this.carrier = carrier;
    }

	public boolean equals(Object obj){
		if(obj==null){return false;}
		if(! (obj instanceof RefPK)){return false;}
		
		RefPK other=(RefPK)obj;
		if(locationCode==null){
			if(other.getLocationCode()!=null){
				return false;
			}
		} else if(!locationCode.equals(other.getLocationCode())){
			return false;
		}
		
		if(refNo==null){
			if(other.getRefNo()!=null){
				return false;
			}
		} else if(!refNo.equals(other.getRefNo())){
			return false;
		}
		
		if(carrier==null){
			if(other.getCarrier()!=null) 
				return false;
		}else if( !carrier.equals(other.getCarrier() )) 
			return false;
		
		return true;
	}
	
	public int hashCode(){
		int hash = 1;
        hash = hash * 31 + (locationCode == null ? 0 : locationCode.hashCode() );
        hash = hash * 31 + (refNo == null ? 0 : refNo.hashCode() );
        hash = hash * 31 + (carrier == null ? 0 : carrier.hashCode() );
        return hash;
	}

    
	public String getLocationCode() {
		return locationCode;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	@Override
	public String toString() {
		return "RefPK [locationCode=" + locationCode + ", refNo=" + refNo
				+ ", carrier=" + carrier + "]";
	}

}
