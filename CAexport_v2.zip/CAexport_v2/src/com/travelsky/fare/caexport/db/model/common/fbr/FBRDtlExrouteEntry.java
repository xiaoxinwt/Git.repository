package com.travelsky.fare.caexport.db.model.common.fbr;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class FBRDtlExrouteEntry implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	FARE_BY_RULE_ID
	private String fareByRuleId;
	//Nullable: false	FARE_BY_RULE_DTL_ID
	private String fareByRuleDtlId;
	//Nullable: false	EXROUTE_NO
	private Integer exrouteNo;
	//Nullable: false	ENTRY_NO
	private Integer entryNo;
	//Nullable: true	FROM_CODE
	private String fromCode;
	//Nullable: true	TO_CODE
	private String toCode;
	//Nullable: true	SOURCE
	private String source;
	
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getFareByRuleId() {
		return fareByRuleId;
	}
	public void setFareByRuleId(String fareByRuleId) {
		this.fareByRuleId = fareByRuleId;
	}
	public String getFareByRuleDtlId() {
		return fareByRuleDtlId;
	}
	public void setFareByRuleDtlId(String fareByRuleDtlId) {
		this.fareByRuleDtlId = fareByRuleDtlId;
	}
	public Integer getExrouteNo() {
		return exrouteNo;
	}
	public void setExrouteNo(Integer exrouteNo) {
		this.exrouteNo = exrouteNo;
	}
	public Integer getEntryNo() {
		return entryNo;
	}
	public void setEntryNo(Integer entryNo) {
		this.entryNo = entryNo;
	}
	public String getFromCode() {
		return fromCode;
	}
	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}
	public String getToCode() {
		return toCode;
	}
	public void setToCode(String toCode) {
		this.toCode = toCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}