package com.travelsky.fare.caexport.db.model.airtis_fare;

import java.util.List;

import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRoute;
import com.travelsky.fare.caexport.db.model.easyfare_fare.FareRule;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class PSFare extends AbstractPxFare implements Entity {
	private static final long serialVersionUID = 1L;

	private String clsCode;
	private Double discPer;
	private Integer serviceClass;
	//Nullable: false	ROUTEFLAG
	private String routeflag;
	//Nullable: false	RULE_NO
	private String ruleId;
	//Nullable: true	RULE_ID_NO
	private String ruleIdNo;
	private List<FareRoute> routes;
	private List<FareRule> rules;
	
	public PSFare(){}

	public String getClsCode() {
		return clsCode;
	}
	public void setClsCode(String clsCode) {
		this.clsCode = clsCode;
	}
	public Double getDiscPer() {
		return discPer;
	}
	public void setDiscPer(Double discPer) {
		this.discPer = discPer;
	}
	public Integer getServiceClass() {
		return serviceClass;
	}
	public void setServiceClass(Integer serviceClass) {
		this.serviceClass = serviceClass;
	}
	public String getRouteflag() {
		return routeflag;
	}
	public void setRouteflag(String routeflag) {
		this.routeflag = routeflag;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getRuleIdNo() {
		return ruleIdNo;
	}
	public void setRuleIdNo(String ruleIdNo) {
		this.ruleIdNo = ruleIdNo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<FareRoute> getRoutes() {
		return routes;
	}
	public void setRoutes(List<FareRoute> routes) {
		this.routes = routes;
	}
	public List<FareRule> getRules() {
		return rules;
	}
	public void setRules(List<FareRule> rules) {
		this.rules = rules;
	}

	@Override
	public String toString() {
		return "PSFare [clsCode=" + clsCode + ", discPer=" + discPer
				+ ", serviceClass=" + serviceClass + ", routeflag=" + routeflag
				+ ", ruleId=" + ruleId + ", ruleIdNo=" + ruleIdNo + "]";
	}
}