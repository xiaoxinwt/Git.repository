package com.travelsky.fare.caexport.db.model.po;

public class Discount {
	//Nullable: true	DISCOUNT_CALCULATE_TYPE
	private Integer discountCalculateType;
	//Nullable: true	DISCOUNT_BOOKING_CLASS
	private String discountBookingClass;
	//Nullable: true	DISCOUNT_PERCENT
	private Integer discountPercent;
	//Nullable: true	DISCOUNT_CODE
	private String discountCode;

	public Integer getDiscountCalculateType() {
		return discountCalculateType;
	}
	public void setDiscountCalculateType(Integer discountCalculateType) {
		this.discountCalculateType = discountCalculateType;
	}
	public String getDiscountBookingClass() {
		return discountBookingClass;
	}
	public void setDiscountBookingClass(String discountBookingClass) {
		this.discountBookingClass = discountBookingClass;
	}
	public Integer getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(Integer discountPercent) {
		this.discountPercent = discountPercent;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
}
