package com.travelsky.fare.caexport.db.model.easyfare_fare;

import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.RefPK;

public class FareDistribution implements Entity {
	private static final long serialVersionUID = 1L;
	private RefPK refpk;
	private String groupId;
	public FareDistribution(String carrierCode,String locationCode ,String refNo){
		this.refpk = new RefPK(carrierCode,locationCode,refNo);
	}
	
	public RefPK getRefpk() {
		return refpk;
	}
	public void setRefpk(RefPK refpk) {
		this.refpk = refpk;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}