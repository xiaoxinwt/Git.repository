package com.travelsky.fare.caexport.db.model.po;

public class Baggage {

	//Nullable: true	BAGGAGE_ALLOWANCE
	private Integer baggageAllowance;
	//Nullable: true	BAGGAGE_UNIT
	private Integer baggageUnit;
	public Integer getBaggageAllowance() {
		return baggageAllowance;
	}
	public void setBaggageAllowance(Integer baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}
	public Integer getBaggageUnit() {
		return baggageUnit;
	}
	public void setBaggageUnit(Integer baggageUnit) {
		this.baggageUnit = baggageUnit;
	}

}
