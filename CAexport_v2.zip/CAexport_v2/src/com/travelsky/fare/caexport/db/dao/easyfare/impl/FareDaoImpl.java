package com.travelsky.fare.caexport.db.dao.easyfare.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.model.easyfare_fare.Fare;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.model.po.RefPK;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.FareDistCache;
import com.travelsky.fare.caexport.util.StringUtil;

public class FareDaoImpl extends CommonDaoImpl implements IFareDao<Fare> {
	
	private Map<String,Object> param = null;
	private Log log = LogFactory.getLog( FareDaoImpl.class );
	private FareDistCache cache = null;
	private ClearDirtyDataHandler handler = null;
	
	public List<Fare> queryAllByDate(String carrier, Date startDate) throws NoFatalException, FatalException{
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("saleDate", startDate);
		//��ȡ������Ϣ
		cache = FareDistCache.getInstance( FareDistCache.All, startDate);
		if( cache==null ) return null;
		
		handler = new ClearDirtyDataHandler(cache);
		queryByHandler(Fare.class, "selectAllFares", param, handler);
		return handler.farelist;
	}
	
	public List<Fare> queryInsertByDays(String carrier ,PairDays days) throws NoFatalException, FatalException{
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate());
		param.put( "end", days.getLastDate());
		queryByHandler(Fare.class, "selectInsertFares", param, handler);
		return handler.farelist;
	}
	
	public List<Fare> queryUpdateByDays(String carrier, PairDays days) throws NoFatalException, FatalException{
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier );
		param.put("start", days.getFirstDate());
		param.put("end", days.getLastDate());
		queryByHandler(Fare.class, "selectUpdateFares", param, handler);
		return handler.farelist;
	}

	@Override
	public long countAllByDate(String carrier , Date startDate) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("saleDate", startDate);
		queryForList(Fare.class, "selectAllFares", param);
		return page.getTotal();
	}
	@Override
	public long countInsertByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("start", days.getFirstDate());
		param.put( "end", days.getLastDate());
		queryForList( Fare.class, "selectInsertFares", param);
		return page.getTotal();
	}

	@Override
	public long countUpdateByDays(String carrier , PairDays days) throws NoFatalException, FatalException{
		Page<?> page = PageHelper.startPage(1, -1);
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier );
		param.put("start", days.getFirstDate());
		param.put("end", days.getLastDate());
		queryForList( Fare.class, "selectUpdateFares", param);
		return page.getTotal();
	}
	
	@Override
	public List<Fare> queryAllByDateForPage(String carrier , Date startDate, int pageNum , int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum, pageSize,false);
		return queryAllByDate(carrier, startDate);
	}
	
	//������
	@Override
	public List<Fare> queryInsertByDaysForPage(String carrier , PairDays days, int pageNum , int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum, pageSize,false);
		return queryInsertByDays(carrier, days);
	}
	
	//���޸�
	@Override
	public List<Fare> queryUpdateByDaysForPage(String carrier , PairDays days,int pageNum , int pageSize) throws NoFatalException, FatalException{
		PageHelper.startPage(pageNum, pageSize,false);
		return queryUpdateByDays(carrier, days);
	}
	
	//���������� 
	//[ ��Щ������fare_rcvd_currency�����У�����ȴû�з���Ⱥ�� ��Ҫ������ ]
	class ClearDirtyDataHandler implements ResultHandler<Fare>{
		
		List<Fare> farelist = new ArrayList<Fare>();
		
		Fare fare = null;
		RefPK refpk = null;
		FareDistCache cache  = null;
		List<String> groupIds = null;
		
		public ClearDirtyDataHandler(FareDistCache cache) {
			this.cache = cache;
		}

		@Override
		public void handleResult(ResultContext<? extends Fare> context) {
			fare = context.getResultObject();
			refpk = new RefPK( fare.getCarrier(),fare.getLocationCode(),fare.getRefNo() );
			//�˳���Ч����
			if( fare.getDest()!=null && !StringUtil.isNullOrEmpty( fare.getDest().getDestCityCode() ) ){
				
				//Ϊ��Ч��������groupids
				groupIds = cache.getDistGroups( refpk );
				if( groupIds!=null && groupIds.size()>0 ){
					//����GroupIdֵ
					fare.setGroupIds( groupIds );
					farelist.add( fare );
				}
			}
		}
	}
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		String carrier = "CA";
		Date startdate = DateUtil.getDate("2015-01-01");
		Date enddate = DateUtil.getDate("2015-01-05");
		PairDays days = new PairDays( startdate , enddate );
		days = new PairDays("2015-01-01","2015-01-02");
		Date saleDate = DateUtil.getDate("2015-01-01");
		int pageSize = 500;
		FareDaoImpl dao = new FareDaoImpl();
//		FareDistributeDaoImpl disdao = new FareDistributeDaoImpl();
		
		long total = 0;
		long real = 0;
		List<Fare> list = null;
		
		total = dao.countAllByDate(carrier, saleDate);
		System.out.println( saleDate.toLocaleString()+"��ȫ����"+total );
		list = dao.queryAllByDate(carrier, saleDate);
		System.out.println( saleDate.toLocaleString()+"��ʵ��������"+ list.size() );
//		list = dao.queryAllByDateForPage(carrier, startdate, 1, pageSize);
//		System.out.println( "ȫ������ҳ��"+list.size() );
		
//		total = dao.countInsertByDays(carrier, days);
//		System.out.println( days.toString()+"�ڵ�insert:"+ total );
//		list = dao.queryInsertByDaysForPage(carrier, days, 1, pageSize);
//		System.out.println( "Insert,��ҳ��"+ list.size() );
		
//		total = dao.countUpdateByDays(carrier, days);
//		System.out.println( days.toString()+"�ڵ�update:"+ total );
//		list = dao.queryUpdateByDaysForPage(carrier, days, 1, pageSize);
//		System.out.println( "Update,��ҳ��"+list.size() );
		
		
		
	}

}
