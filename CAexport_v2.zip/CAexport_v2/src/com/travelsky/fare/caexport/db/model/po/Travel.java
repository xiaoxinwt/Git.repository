package com.travelsky.fare.caexport.db.model.po;

import java.util.Date;

public class Travel {

	//Nullable: true	FIRST_TRAVEL_DATE
	private Date firstTravelDate;
	//Nullable: false	LAST_TRAVEL_DATE
	private Date lastTravelDate;
	//Nullable: true	TRAVEL_COMPLETE_DAYS_RESTR
	private Integer travelCompleteDaysRestr;
	//Nullable: false	TRAVEL_TYPE
	private String travelType;
	//Nullable: false	TRAVEL_EFF_DATE
	private Date travelEffDate;
	//Nullable: false	TRAVEL_DISC_DATE
	private Date travelDiscDate;
	//Nullable: true	TRAVEL_COMPLETE_DATE
	private Date travelCompleteDate;
	public Date getFirstTravelDate() {
		return firstTravelDate;
	}
	public void setFirstTravelDate(Date firstTravelDate) {
		this.firstTravelDate = firstTravelDate;
	}
	public Date getLastTravelDate() {
		return lastTravelDate;
	}
	public void setLastTravelDate(Date lastTravelDate) {
		this.lastTravelDate = lastTravelDate;
	}
	public Integer getTravelCompleteDaysRestr() {
		return travelCompleteDaysRestr;
	}
	public void setTravelCompleteDaysRestr(Integer travelCompleteDaysRestr) {
		this.travelCompleteDaysRestr = travelCompleteDaysRestr;
	}
	public String getTravelType() {
		return travelType;
	}
	public void setTravelType(String travelType) {
		this.travelType = travelType;
	}
	public Date getTravelEffDate() {
		return travelEffDate;
	}
	public void setTravelEffDate(Date travelEffDate) {
		this.travelEffDate = travelEffDate;
	}
	public Date getTravelDiscDate() {
		return travelDiscDate;
	}
	public void setTravelDiscDate(Date travelDiscDate) {
		this.travelDiscDate = travelDiscDate;
	}
	public Date getTravelCompleteDate() {
		return travelCompleteDate;
	}
	public void setTravelCompleteDate(Date travelCompleteDate) {
		this.travelCompleteDate = travelCompleteDate;
	}
}
