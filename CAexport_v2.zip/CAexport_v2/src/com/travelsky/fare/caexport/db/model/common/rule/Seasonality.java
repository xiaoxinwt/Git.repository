package com.travelsky.fare.caexport.db.model.common.rule;

import java.util.Date;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class Seasonality implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RULE_ID
	private String ruleId;
	//Nullable: false	FROM_DATE
	private Date fromDate;
	//Nullable: true	TO_DATE
	private Date toDate;
	//Nullable: true	RULE_SEQ_ID
	private Integer ruleSeqId;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Integer getRuleSeqId() {
		return ruleSeqId;
	}
	public void setRuleSeqId(Integer ruleSeqId) {
		this.ruleSeqId = ruleSeqId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}