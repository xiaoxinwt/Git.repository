package com.travelsky.fare.caexport.db.model.po;

public class Adult {
	//Nullable: true	ADULT_RSF_AMT
	private Integer adultRsfAmt;
	public Integer getAdultRsfAmt() {
		return adultRsfAmt;
	}
	public void setAdultRsfAmt(Integer adultRsfAmt) {
		this.adultRsfAmt = adultRsfAmt;
	}

}
