package com.travelsky.fare.caexport.db.model.common.group;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class GroupEntry implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	GROUP_ID
	private String groupId;
	//Nullable: false	AGENCY_ID_PCC
	private String agencyIdPcc;
	//Nullable: true	AGENCY_ID_IATA
	private String agencyIdIata;
	//Nullable: true	CITY_CODE
	private String cityCode;
	//Nullable: true	AGENCY_NAME
	private String agencyName;
	//Nullable: true	DIS_NAME
	private String disName;
	//Nullable: true	SYS_CODE
	private String sysCode;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getAgencyIdPcc() {
		return agencyIdPcc;
	}
	public void setAgencyIdPcc(String agencyIdPcc) {
		this.agencyIdPcc = agencyIdPcc;
	}
	public String getAgencyIdIata() {
		return agencyIdIata;
	}
	public void setAgencyIdIata(String agencyIdIata) {
		this.agencyIdIata = agencyIdIata;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getDisName() {
		return disName;
	}
	public void setDisName(String disName) {
		this.disName = disName;
	}
	public String getSysCode() {
		return sysCode;
	}
	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
}