package com.travelsky.fare.caexport.db.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.session.ResultHandler;
import org.apache.log4j.Logger;
import com.travelsky.fare.caexport.db.dao.basedao.BaseDao;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.ErrorLog;

public class CommonDaoImpl extends BaseDao{

	private Logger log=Logger.getLogger("DefaultDao");
	private static CommonDaoImpl dao = new CommonDaoImpl();
	
	//��ѯ���е�Carrier��Ϣ
	public static List<String> getAllCarriers() {
		List<String> carriers = new ArrayList<String>();
		try {
			carriers = (List<String>) dao.queryForList( BaseDao.class, "queryAllCarriers", null);
		} catch (Exception e) {
			ErrorLog.log( e );
		}
		return carriers;
	}
		
	//��ѯ����
	protected List<?> queryForList( Class<?> mappercls, String method,Map<String,Object> param) throws NoFatalException, FatalException{
		String statementId = getMapper( mappercls )+"."+method;
		return selectForList( statementId, param);
	}
	
	protected Map queryForObject( Class<?> mappercls, String method,Map<String,Object> param, String key) throws NoFatalException,FatalException{
		String statementId = getMapper(mappercls)+"."+method;
		return selectForObject( statementId, param , key);
	}

	//��ѯ����
	protected Object queryForOne( Class<?> mappercls, String method, Map<String,Object> param) throws NoFatalException, FatalException{
		String statementId = getMapper(mappercls)+"."+method;
		return selectForOne(statementId, param);
	}
	
	protected void queryByHandler( Class<?> mappercls , String method , Map<String,Object> params, ResultHandler<?> handler) throws NoFatalException, FatalException{
		String statementId = getMapper(mappercls)+"."+method;
		selectByHandler(statementId, handler, params);
	}

	public static void main(String[] args) throws NoFatalException, FatalException {
		
		CommonDaoImpl dao = new CommonDaoImpl();
		
		List<String> carriers = dao.getAllCarriers();
		for (String carrier : carriers) {
			dao.log.info( carrier );
		}
		
//		Class<?> mappercls = Refund.class;
//		String method = "selectAll";
//		Map<String,Object> param = new HashMap<String, Object>();
//		param.put("carrCode", "CA");
//		PairDays days = new PairDays( "2010-10-10","2013-11-10" );
		
//		List<?> list = dao.queryForList( mappercls, method, param);
//		log.info( "list: "+list.size() );

		//��ʽ2
//		PageHelper.startPage(2, 10, false);
//		List<?> list = dao.queryForList(mappercls, method, param);
//		PageInfo page = new PageInfo(list);
//		log.info( list.size() );
//		log.info( page.getPageSize()+"\t"+page.getPageNum() );
//		log.info( page.getPages() );
//		log.info( page.getNavigatePages() );
//		int[] navigatepageNums = page.getNavigatepageNums();
//		for (int i : navigatepageNums) {
//			log.info( i );
//		}
		
		
//		SqlSession session = MyBatisUtil.getSessionFactory().openSession();
//		Configuration config = session.getConfiguration();
//		Collection<String> names = config.getMappedStatementNames();
//		for (String id : names) {
//			System.out.println( id );
//		}
//		String statementId = "dao.easyfare.impl.mybatis.AirportMapper.selectACMap";
//		System.out.println( "names.contains(statemendId):"+names.contains(statementId) );
	}
	
}
