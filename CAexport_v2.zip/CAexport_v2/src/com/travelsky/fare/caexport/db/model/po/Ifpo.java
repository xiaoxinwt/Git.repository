package com.travelsky.fare.caexport.db.model.po;

public class Ifpo {
	//Nullable: true	IF_D_RBD_OPEN_SEQ
	private Integer ifDRbdOpenSeq;
	//Nullable: true	IF_SAME_BASEFARE_RULE
	private Integer ifSameBasefareRule;
	//Nullable: true	IF_ONLY_DIRECT_FARE
	private Integer ifOnlyDirectFare;
	//Nullable: true	IF_SAME_BASEFARE_GROUP
	private Integer ifSameBasefareGroup;
	//Nullable: true	IF_USE_OTHER_RULE_RESTRICTION
	private Integer ifUseOtherRuleRestriction;
	public Integer getIfSameBasefareRule() {
		return ifSameBasefareRule;
	}
	public void setIfSameBasefareRule(Integer ifSameBasefareRule) {
		this.ifSameBasefareRule = ifSameBasefareRule;
	}
	public Integer getIfDRbdOpenSeq() {
		return ifDRbdOpenSeq;
	}
	public void setIfDRbdOpenSeq(Integer ifDRbdOpenSeq) {
		this.ifDRbdOpenSeq = ifDRbdOpenSeq;
	}
	public Integer getIfOnlyDirectFare() {
		return ifOnlyDirectFare;
	}
	public void setIfOnlyDirectFare(Integer ifOnlyDirectFare) {
		this.ifOnlyDirectFare = ifOnlyDirectFare;
	}
	public Integer getIfSameBasefareGroup() {
		return ifSameBasefareGroup;
	}
	public void setIfSameBasefareGroup(Integer ifSameBasefareGroup) {
		this.ifSameBasefareGroup = ifSameBasefareGroup;
	}
	public Integer getIfUseOtherRuleRestriction() {
		return ifUseOtherRuleRestriction;
	}
	public void setIfUseOtherRuleRestriction(Integer ifUseOtherRuleRestriction) {
		this.ifUseOtherRuleRestriction = ifUseOtherRuleRestriction;
	}
}
