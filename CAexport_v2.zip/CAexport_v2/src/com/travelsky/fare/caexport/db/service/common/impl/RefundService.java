package com.travelsky.fare.caexport.db.service.common.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.travelsky.fare.caexport.db.dao.ICommonDao;
import com.travelsky.fare.caexport.db.model.common.refund.Refund;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.RefundImportor;
import com.travelsky.fare.caexport.dexp.vo.refund.XRefundImport;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DaoUtil;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.PageUtil;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.ActionType;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class RefundService implements IExport<Refund>{
	
	private Log log = LogFactory.getLog( this.getClass() );
	private IImportor<Refund, XRefundImport> importor = new RefundImportor();
	private final int pageSize = 5000;
	
	private ICommonDao<Refund> dao;
	private CAType catype = null;
	private CAModule camodule = null;

	public RefundService(CAType catype) {
		this.catype = catype;
		this.camodule = CAModule.Refund;
		dao = (ICommonDao<Refund>) DaoUtil.getDaoImpl( this.catype,this.camodule );
	}
	
	//��������
	public Export exportAll(String carrier) throws NoFatalException, FatalException{
		List<Refund> refundlist = null;
		XRefundImport imp = null;
		long total = dao.countAll(carrier);
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				refundlist = dao.queryAllForPage(carrier, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(refundlist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			refundlist = dao.queryAll(carrier);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(refundlist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier,imp,this.catype,this.camodule,exptype);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportAllOfDate(String carrier , Date startDate) throws NoFatalException, FatalException{
		List<Refund> refundlist = null;
		XRefundImport imp = null;
		long total = dao.countAllFrom(carrier, startDate);
		ExpType exptype = ExpType.All;
		ActionType actype = ActionType.Insert;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				refundlist = dao.queryAllFromForPage(carrier,startDate, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(refundlist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,startDate,pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			refundlist = dao.queryAllFrom(carrier, startDate);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(refundlist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype,startDate);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(startDate);
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportIncOfDate(String carrier , Date date) throws NoFatalException, FatalException{
		List<Refund> refundlist = null;
		XRefundImport imp = null;
		long total = dao.countIncOfDate(carrier, date);
		ExpType exptype = ExpType.Inc;
		ActionType actype = ActionType.Update;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				refundlist = dao.queryIncOfDateForPage(carrier,date, pageNum, pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(refundlist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,date,pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			refundlist = dao.queryIncOfDate(carrier, date);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(refundlist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype,date);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(DateUtil.getYesterday(date));
		exp.setEndDate( date );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	public Export exportIncOfDays(String carrier, PairDays days) throws NoFatalException, FatalException{
		List<Refund> refundlist = null;
		XRefundImport imp = null;
		long total = dao.countIncOfDays(carrier, days);
//			List<Date> dates = DateUtil.getDates(days.getFirstDate(),days.getLastDate());
		ExpType exptype = ExpType.Inc;
		ActionType actype = ActionType.Update;
		long count = 0;
		long querycost = 0;
		long toxmlcost = 0;
		if(total>pageSize){
			//��ҳ����
			int pages = PageUtil.getPageCount(total, pageSize);
			for (int pageNum = 1; pageNum <= pages; pageNum++) {
				long querystart = System.currentTimeMillis();
				refundlist = dao.queryIncOfDaysForPage(carrier,days,pageNum,pageSize);
				querycost += (System.currentTimeMillis()-querystart);
				
				imp = importor.getImport(refundlist, carrier,this.catype,actype);
				count += importor.getCount();
				
				long xmlstart = System.currentTimeMillis();
				ExportUtil.ExportToXmlForPage(carrier,imp,this.catype,this.camodule,exptype,null,pageNum);
				toxmlcost += (System.currentTimeMillis()-xmlstart);
			}
		}else{
			long querystart = System.currentTimeMillis();
			refundlist = dao.queryIncOfDays(carrier, days);
			querycost += (System.currentTimeMillis()-querystart);
			
			imp = importor.getImport(refundlist, carrier,this.catype,actype);
			count += importor.getCount();
			
			long xmlstart = System.currentTimeMillis();
			ExportUtil.ExportToXml(carrier, imp, catype, camodule, exptype);
			toxmlcost += (System.currentTimeMillis()-xmlstart);
		}
		Export exp = new Export(carrier, catype, camodule ,exptype);
		exp.setStartDate(days.getFirstDate());
		exp.setEndDate( days.getLastDate() );
		exp.setExpectTotal( total );
		exp.setCount( count );
		exp.setExpdate( new Date() );
		exp.setQueryCost( querycost );
		exp.setToxmlCost( toxmlcost );
		return exp;
	}
	
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		
		IExport<Refund> exportor = null;
//		exportor = new RefundService(CAType.Airtis);
		exportor = new RefundService(CAType.Easyfare);
		
		String carrier = "MU";
		
		PairDays days = new PairDays("2015-01-01","2015-05-30");
		Date date = DateUtil.getDate("2015-01-01");
		
		Export exp = null;
//		exp = exportor.exportAll(carrier);
		exp = exportor.exportAllOfDate(carrier, date);
//		exp = exportor.exportIncOfDate(carrier, date);
//		exp = exportor.exportIncOfDays(carrier, days);
		ExportUtil.writeInfo(exp);
	}

}
