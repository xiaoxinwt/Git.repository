package com.travelsky.fare.caexport.db.model.po;

public class Group {
	//Nullable: false	GROUP_FLAG
	private Integer groupFlag;
	//Nullable: true	GROUP_FROM
	private Integer groupFrom;
	//Nullable: true	GROUP_TO
	private Integer groupTo;
	public Integer getGroupFlag() {
		return groupFlag;
	}
	public void setGroupFlag(Integer groupFlag) {
		this.groupFlag = groupFlag;
	}
	public Integer getGroupFrom() {
		return groupFrom;
	}
	public void setGroupFrom(Integer groupFrom) {
		this.groupFrom = groupFrom;
	}
	public Integer getGroupTo() {
		return groupTo;
	}
	public void setGroupTo(Integer groupTo) {
		this.groupTo = groupTo;
	}
}
