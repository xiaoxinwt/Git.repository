package com.travelsky.fare.caexport.db.model.common.fbr;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class FBRBasefare implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	FARE_BY_RULE_ID
	private String fareByRuleId;
	//Nullable: false	FARE_BY_RULE_DTL_ID
	private String fareByRuleDtlId;
	//Nullable: false	BASEFARE_ID
	private String basefareId;
	//Nullable: true	ORI_CODE_TYPE
	private Integer oriCodeType;
	//Nullable: true	ORI_CODE
	private String oriCode;
	//Nullable: true	DEST_CODE_TYPE
	private Integer destCodeType;
	//Nullable: true	DEST_CODE
	private String destCode;
	//Nullable: true	JOURNEY_TYPE
	private String journeyType;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: true	FARE_BASIS
	private String fareBasis;
	//Nullable: true	DISTRIBUTION_TYPE
	private String distributionType;
	//Nullable: true	AGENCY_ID
	private String agencyId;
	//Nullable: true	IF_D_RBD_OPEN_SEQ
	private Integer ifDRbdOpenSeq;
	//Nullable: true	D_RBD_OPEN_SEQ
	private String dRbdOpenSeq;
	//Nullable: true	Z_VALUE_MIN
	private Integer zValueMin;
	//Nullable: true	Z_VALUE_MAX
	private Integer zValueMax;
	//Nullable: true	Z_VALUE_MIN_SYMBOL
	private Integer zValueMinSymbol;
	//Nullable: true	Z_VALUE_MAX_SYMBOL
	private Integer zValueMaxSymbol;
	//Nullable: true	IF_Z_VALUE_CHECK
	private Integer ifZValueCheck;
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getFareByRuleId() {
		return fareByRuleId;
	}
	public void setFareByRuleId(String fareByRuleId) {
		this.fareByRuleId = fareByRuleId;
	}
	public String getFareByRuleDtlId() {
		return fareByRuleDtlId;
	}
	public void setFareByRuleDtlId(String fareByRuleDtlId) {
		this.fareByRuleDtlId = fareByRuleDtlId;
	}
	public String getBasefareId() {
		return basefareId;
	}
	public void setBasefareId(String basefareId) {
		this.basefareId = basefareId;
	}
	public Integer getOriCodeType() {
		return oriCodeType;
	}
	public void setOriCodeType(Integer oriCodeType) {
		this.oriCodeType = oriCodeType;
	}
	public String getOriCode() {
		return oriCode;
	}
	public void setOriCode(String oriCode) {
		this.oriCode = oriCode;
	}
	public Integer getDestCodeType() {
		return destCodeType;
	}
	public void setDestCodeType(Integer destCodeType) {
		this.destCodeType = destCodeType;
	}
	public String getDestCode() {
		return destCode;
	}
	public void setDestCode(String destCode) {
		this.destCode = destCode;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public String getDistributionType() {
		return distributionType;
	}
	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}
	public String getAgencyId() {
		return agencyId;
	}
	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}
	public Integer getIfDRbdOpenSeq() {
		return ifDRbdOpenSeq;
	}
	public void setIfDRbdOpenSeq(Integer ifDRbdOpenSeq) {
		this.ifDRbdOpenSeq = ifDRbdOpenSeq;
	}
	public String getdRbdOpenSeq() {
		return dRbdOpenSeq;
	}
	public void setdRbdOpenSeq(String dRbdOpenSeq) {
		this.dRbdOpenSeq = dRbdOpenSeq;
	}
	public Integer getzValueMin() {
		return zValueMin;
	}
	public void setzValueMin(Integer zValueMin) {
		this.zValueMin = zValueMin;
	}
	public Integer getzValueMax() {
		return zValueMax;
	}
	public void setzValueMax(Integer zValueMax) {
		this.zValueMax = zValueMax;
	}
	public Integer getzValueMinSymbol() {
		return zValueMinSymbol;
	}
	public void setzValueMinSymbol(Integer zValueMinSymbol) {
		this.zValueMinSymbol = zValueMinSymbol;
	}
	public Integer getzValueMaxSymbol() {
		return zValueMaxSymbol;
	}
	public void setzValueMaxSymbol(Integer zValueMaxSymbol) {
		this.zValueMaxSymbol = zValueMaxSymbol;
	}
	public Integer getIfZValueCheck() {
		return ifZValueCheck;
	}
	public void setIfZValueCheck(Integer ifZValueCheck) {
		this.ifZValueCheck = ifZValueCheck;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}