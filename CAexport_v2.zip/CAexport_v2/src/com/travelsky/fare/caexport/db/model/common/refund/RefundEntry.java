package com.travelsky.fare.caexport.db.model.common.refund;

import com.travelsky.fare.caexport.db.model.po.Amount;
import com.travelsky.fare.caexport.db.model.po.Cal;
import com.travelsky.fare.caexport.db.model.po.Depart;
import com.travelsky.fare.caexport.db.model.po.Entity;
import com.travelsky.fare.caexport.db.model.po.LowerUpper;
import com.travelsky.fare.caexport.db.model.po.Ticket;

public class RefundEntry implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	REFUND_RULE_ID
	private String refundRuleId;
	//Nullable: false	SEQ_ID
	private Integer seqId;
	//Nullable: true	PASSENGER_TYPE
	private String passengerType;
	//Nullable: true	JOURNEY_TYPE
	private String journeyType;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	private String fareBasis;
	private Ticket ticket = new Ticket();
	private Depart depart = new Depart();
	private Cal cal = new Cal();
	//Nullable: true	PERCENT
	private Integer percent;
	private Amount amount = new Amount();
	//Nullable: false	TAX_REFUND_TYPE
	private Integer taxRefundType;
	//Nullable: true	SPEC_RBD
	private String specRbd;
	//Nullable: true	ENTRY_TRANSLATE
	private String entryTranslate;
	private LowerUpper lowup = new LowerUpper();
	//Nullable: false	RULE_TYPE
	private Integer ruleType;
	//Nullable: true	REFUND_ALLOWED_TAG
	private Integer refundAllowedTag;
	//Nullable: true	REFUND_YQTAX_ALLOWED
	private Integer refundYqtaxAllowed;
	//Nullable: true	OTHER_REFUND_CARRIER_LIST
	private String otherRefundCarrierList;

	public RefundEntry() {}
	public RefundEntry(String refundRuleId, Integer seqId,
			String passengerType, String journeyType, String bookingClass,
			String fareBasis, Ticket ticket, Depart depart, Cal cal,
			Integer percent, Amount amount, Integer taxRefundType,
			String specRbd, String entryTranslate,
			LowerUpper lowup, Integer ruleType, Integer refundAllowedTag,
			Integer refundYqtaxAllowed, String otherRefundCarrierList) {
		this.refundRuleId = refundRuleId;
		this.seqId = seqId;
		this.passengerType = passengerType;
		this.journeyType = journeyType;
		this.bookingClass = bookingClass;
		this.fareBasis = fareBasis;
		this.ticket = ticket;
		this.depart = depart;
		this.cal = cal;
		this.percent = percent;
		this.amount = amount;
		this.taxRefundType = taxRefundType;
		this.specRbd = specRbd;
		this.entryTranslate = entryTranslate;
		this.lowup = lowup;
		this.ruleType = ruleType;
		this.refundAllowedTag = refundAllowedTag;
		this.refundYqtaxAllowed = refundYqtaxAllowed;
		this.otherRefundCarrierList = otherRefundCarrierList;
	}
	
	public String getRefundRuleId() {
		return refundRuleId;
	}
	public void setRefundRuleId(String refundRuleId) {
		this.refundRuleId = refundRuleId;
	}
	public Integer getSeqId() {
		return seqId;
	}
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}
	public String getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public String getFareBasis() {
		return fareBasis;
	}
	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}
	public Ticket getTicket() {
		if( ticket==null ) ticket = new Ticket();
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public Depart getDepart() {
		if( depart==null ) depart = new Depart();
		return depart;
	}
	public void setDepart(Depart depart) {
		this.depart = depart;
	}
	public Cal getCal() {
		if(cal==null) cal = new Cal();
		return cal;
	}
	public void setCal(Cal cal) {
		this.cal = cal;
	}
	public Integer getPercent() {
		return percent;
	}
	public void setPercent(Integer percent) {
		this.percent = percent;
	}
	public Amount getAmount() {
		if( amount==null ) amount = new Amount();
		return amount;
	}
	public void setAmount(Amount amount) {
		this.amount = amount;
	}
	public Integer getTaxRefundType() {
		return taxRefundType;
	}
	public void setTaxRefundType(Integer taxRefundType) {
		this.taxRefundType = taxRefundType;
	}
	public String getSpecRbd() {
		return specRbd;
	}
	public void setSpecRbd(String specRbd) {
		this.specRbd = specRbd;
	}
	public String getEntryTranslate() {
		return entryTranslate;
	}
	public void setEntryTranslate(String entryTranslate) {
		this.entryTranslate = entryTranslate;
	}
	public LowerUpper getLowup() {
		if(lowup==null) lowup = new LowerUpper();
		return lowup;
	}
	public void setLowup(LowerUpper lowup) {
		this.lowup = lowup;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}
	public Integer getRefundAllowedTag() {
		return refundAllowedTag;
	}
	public void setRefundAllowedTag(Integer refundAllowedTag) {
		this.refundAllowedTag = refundAllowedTag;
	}
	public Integer getRefundYqtaxAllowed() {
		return refundYqtaxAllowed;
	}
	public void setRefundYqtaxAllowed(Integer refundYqtaxAllowed) {
		this.refundYqtaxAllowed = refundYqtaxAllowed;
	}
	public String getOtherRefundCarrierList() {
		return otherRefundCarrierList;
	}
	public void setOtherRefundCarrierList(String otherRefundCarrierList) {
		this.otherRefundCarrierList = otherRefundCarrierList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}