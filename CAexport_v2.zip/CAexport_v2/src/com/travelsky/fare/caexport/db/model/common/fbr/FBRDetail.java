package com.travelsky.fare.caexport.db.model.common.fbr;

import java.util.Date;
import java.util.List;
import com.travelsky.fare.caexport.db.model.po.Entity;

public class FBRDetail implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	CARR_CODE
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	FARE_BY_RULE_ID
	private String fareByRuleId;
	//Nullable: false	FARE_BY_RULE_DTL_ID
	private String fareByRuleDtlId;
	//Nullable: true	ACCOUNT_CODE
	private String accountCode;
	//Nullable: true	FBR_DTL_PRIOR
	private Integer fbrDtlPrior;
	//Nullable: false	SALE_EFF_DATE
	private Date saleEffDate;
	//Nullable: true	SALE_DISC_DATE
	private Date saleDiscDate;
	//Nullable: false	FIRST_TRAVEL_DATE
	private Date firstTravelDate;
	//Nullable: true	LAST_TRAVEL_DATE
	private Date lastTravelDate;
	//Nullable: true	ORI_CODE_TYPE
	private Integer oriCodeType;
	//Nullable: true	ORI_CODE
	private String oriCode;
	//Nullable: true	DEST_CODE_TYPE
	private Integer destCodeType;
	//Nullable: true	DEST_CODE
	private String destCode;
	//Nullable: true	JOURNEY_TYPE
	private String journeyType;
	//Nullable: true	BOOKING_CLASS
	private String bookingClass;
	//Nullable: true	BASEFARE_TYPE
	private Integer basefareType;
	//Nullable: true	PRICE_CHOOSE
	private Integer priceChoose;
	//Nullable: true	RULE_NO
	private String ruleNo;
	//Nullable: true	RULE_LOCATION_CODE
	private String ruleLocationCode;
	//Nullable: true	IF_SAME_BASEFARE_RULE
	private Integer ifSameBasefareRule;
	//Nullable: true	IF_ONLY_DIRECT_FARE
	private Integer ifOnlyDirectFare;
	//Nullable: true	IF_SAME_BASEFARE_GROUP
	private Integer ifSameBasefareGroup;
	//Nullable: true	IF_USE_OTHER_RULE_RESTRICTION
	private Integer ifUseOtherRuleRestriction;
	//Nullable: true	OUTBOUND_PERMITTED
	private Integer outboundPermitted;
	//Nullable: true	INBOUND_PERMITTED
	private Integer inboundPermitted;
	//Nullable: true	MINIMUM_STAY
	private Integer minimumStay;
	//Nullable: true	MINIMUM_STAY_UNIT
	private String minimumStayUnit;
	//Nullable: true	MAXIMUM_STAY
	private Integer maximumStay;
	//Nullable: true	MAXIMUM_STAY_UNIT
	private String maximumStayUnit;
	//Nullable: true	RSTF_CACULATE_TYPE
	private Integer rstfCaculateType;
	//Nullable: true	RSTF_AMT
	private Integer rstfAmt;
	//Nullable: true	RSTF_CURRENCY_CODE
	private String rstfCurrencyCode;
	//Nullable: true	RSTF_PERCENT
	private Integer rstfPercent;
	//Nullable: true	ROUND_RULE
	private Integer roundRule;
	//Nullable: true	RSTF_DISPLAY_IF_SAME_BASEFARE
	private Integer rstfDisplayIfSameBasefare;
	//Nullable: true	RSTF_DISPLAY_FARE_BASIS
	private String rstfDisplayFareBasis;
	//Nullable: true	RSTF_DISPLAY_ADT_CMN_AMT
	private Integer rstfDisplayAdtCmnAmt;
	//Nullable: true	RSTF_DISPLAY_BASE_CMN_AMT
	private Integer rstfDisplayBaseCmnAmt;
	//Nullable: true	RSTF_DISPLAY_ADT_CMN_PCT
	private Integer rstfDisplayAdtCmnPct;
	//Nullable: true	RSTF_DISPLAY_BASE_CMN_PCT
	private Integer rstfDisplayBaseCmnPct;
	//Nullable: true	RSTF_DISPLAY_TOURCODE
	private String rstfDisplayTourcode;
	//Nullable: true	RSTF_DISPLAY_ENDORSMENT
	private String rstfDisplayEndorsment;
	//Nullable: true	DISTRIBUTION_STATUS
	private Integer distributionStatus;
	//Nullable: true	DISTRIBUTION_DATE
	private Date distributionDate;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: true	BAGGAGE_ALLOWANCE
	private Integer baggageAllowance;
	//Nullable: true	BAGGAGE_UNIT
	private Integer baggageUnit;
	//Nullable: true	DISCOUNT_CODE
	private String discountCode;
	//Nullable: true	SOURCE
	private String source;
	//Nullable: true	RSTF_DISPLAY_IF_FREE_YQ
	private Integer rstfDisplayIfFreeYq;
	//Nullable: true	ETERM_RSTF_DISPLAY_ENDORSMENT
	private String etermRstfDisplayEndorsment;
	//Nullable: true	Y_CABIN_PRICE_CHOOSE_IF
	private Integer yCabinPriceChooseIf;
	//Nullable: true	MIN_Y_CABIN_PRICE
	private Integer minYCabinPrice;
	//Nullable: true	MAX_Y_CABIN_PRICE
	private Integer maxYCabinPrice;
	//Nullable: true	ACCOUNT_CODE_FLAG
	private Integer accountCodeFlag;
	//Nullable: true	REMARK
	private String remark;
	//Nullable: true	WHEN_CREATE
	private Date whenCreate;
	//Nullable: true	WHO_CREATE
	private String whoCreate;
	//Nullable: true	WHERE_CREATE
	private String whereCreate;
	//Nullable: true	BRAND_SOURCE
	private String brandSource;
	//Nullable: true	SUB_CLASS_FLAG
	private Integer subClassFlag;
	//Nullable: true	RSTF_THRESHOLD_CAL_TYPE
	private Integer rstfThresholdCalType;
	//Nullable: true	RSTF_THRESHOLD_CAL_PERCENT
	private Integer rstfThresholdCalPercent;
	private List<FBRBasefare> basefares;
	private List<FBRDtlExroute> fbrDetailRoutes;
	private List<String> groupids;
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getFareByRuleId() {
		return fareByRuleId;
	}
	public void setFareByRuleId(String fareByRuleId) {
		this.fareByRuleId = fareByRuleId;
	}
	public String getFareByRuleDtlId() {
		return fareByRuleDtlId;
	}
	public void setFareByRuleDtlId(String fareByRuleDtlId) {
		this.fareByRuleDtlId = fareByRuleDtlId;
	}
	public String getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	public Integer getFbrDtlPrior() {
		return fbrDtlPrior;
	}
	public void setFbrDtlPrior(Integer fbrDtlPrior) {
		this.fbrDtlPrior = fbrDtlPrior;
	}
	public Date getSaleEffDate() {
		return saleEffDate;
	}
	public void setSaleEffDate(Date saleEffDate) {
		this.saleEffDate = saleEffDate;
	}
	public Date getSaleDiscDate() {
		return saleDiscDate;
	}
	public void setSaleDiscDate(Date saleDiscDate) {
		this.saleDiscDate = saleDiscDate;
	}
	public Date getFirstTravelDate() {
		return firstTravelDate;
	}
	public void setFirstTravelDate(Date firstTravelDate) {
		this.firstTravelDate = firstTravelDate;
	}
	public Date getLastTravelDate() {
		return lastTravelDate;
	}
	public void setLastTravelDate(Date lastTravelDate) {
		this.lastTravelDate = lastTravelDate;
	}
	public Integer getOriCodeType() {
		return oriCodeType;
	}
	public void setOriCodeType(Integer oriCodeType) {
		this.oriCodeType = oriCodeType;
	}
	public String getOriCode() {
		return oriCode;
	}
	public void setOriCode(String oriCode) {
		this.oriCode = oriCode;
	}
	public Integer getDestCodeType() {
		return destCodeType;
	}
	public void setDestCodeType(Integer destCodeType) {
		this.destCodeType = destCodeType;
	}
	public String getDestCode() {
		return destCode;
	}
	public void setDestCode(String destCode) {
		this.destCode = destCode;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public String getBookingClass() {
		return bookingClass;
	}
	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}
	public Integer getBasefareType() {
		return basefareType;
	}
	public void setBasefareType(Integer basefareType) {
		this.basefareType = basefareType;
	}
	public Integer getPriceChoose() {
		return priceChoose;
	}
	public void setPriceChoose(Integer priceChoose) {
		this.priceChoose = priceChoose;
	}
	public String getRuleNo() {
		return ruleNo;
	}
	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}
	public String getRuleLocationCode() {
		return ruleLocationCode;
	}
	public void setRuleLocationCode(String ruleLocationCode) {
		this.ruleLocationCode = ruleLocationCode;
	}
	public Integer getIfSameBasefareRule() {
		return ifSameBasefareRule;
	}
	public void setIfSameBasefareRule(Integer ifSameBasefareRule) {
		this.ifSameBasefareRule = ifSameBasefareRule;
	}
	public Integer getIfOnlyDirectFare() {
		return ifOnlyDirectFare;
	}
	public void setIfOnlyDirectFare(Integer ifOnlyDirectFare) {
		this.ifOnlyDirectFare = ifOnlyDirectFare;
	}
	public Integer getIfSameBasefareGroup() {
		return ifSameBasefareGroup;
	}
	public void setIfSameBasefareGroup(Integer ifSameBasefareGroup) {
		this.ifSameBasefareGroup = ifSameBasefareGroup;
	}
	public Integer getIfUseOtherRuleRestriction() {
		return ifUseOtherRuleRestriction;
	}
	public void setIfUseOtherRuleRestriction(Integer ifUseOtherRuleRestriction) {
		this.ifUseOtherRuleRestriction = ifUseOtherRuleRestriction;
	}
	public Integer getOutboundPermitted() {
		return outboundPermitted;
	}
	public void setOutboundPermitted(Integer outboundPermitted) {
		this.outboundPermitted = outboundPermitted;
	}
	public Integer getInboundPermitted() {
		return inboundPermitted;
	}
	public void setInboundPermitted(Integer inboundPermitted) {
		this.inboundPermitted = inboundPermitted;
	}
	public Integer getMinimumStay() {
		return minimumStay;
	}
	public void setMinimumStay(Integer minimumStay) {
		this.minimumStay = minimumStay;
	}
	public String getMinimumStayUnit() {
		return minimumStayUnit;
	}
	public void setMinimumStayUnit(String minimumStayUnit) {
		this.minimumStayUnit = minimumStayUnit;
	}
	public Integer getMaximumStay() {
		return maximumStay;
	}
	public void setMaximumStay(Integer maximumStay) {
		this.maximumStay = maximumStay;
	}
	public String getMaximumStayUnit() {
		return maximumStayUnit;
	}
	public void setMaximumStayUnit(String maximumStayUnit) {
		this.maximumStayUnit = maximumStayUnit;
	}
	public Integer getRstfCaculateType() {
		return rstfCaculateType;
	}
	public void setRstfCaculateType(Integer rstfCaculateType) {
		this.rstfCaculateType = rstfCaculateType;
	}
	public Integer getRstfAmt() {
		return rstfAmt;
	}
	public void setRstfAmt(Integer rstfAmt) {
		this.rstfAmt = rstfAmt;
	}
	public String getRstfCurrencyCode() {
		return rstfCurrencyCode;
	}
	public void setRstfCurrencyCode(String rstfCurrencyCode) {
		this.rstfCurrencyCode = rstfCurrencyCode;
	}
	public Integer getRstfPercent() {
		return rstfPercent;
	}
	public void setRstfPercent(Integer rstfPercent) {
		this.rstfPercent = rstfPercent;
	}
	public Integer getRoundRule() {
		return roundRule;
	}
	public void setRoundRule(Integer roundRule) {
		this.roundRule = roundRule;
	}
	public Integer getRstfDisplayIfSameBasefare() {
		return rstfDisplayIfSameBasefare;
	}
	public void setRstfDisplayIfSameBasefare(Integer rstfDisplayIfSameBasefare) {
		this.rstfDisplayIfSameBasefare = rstfDisplayIfSameBasefare;
	}
	public String getRstfDisplayFareBasis() {
		return rstfDisplayFareBasis;
	}
	public void setRstfDisplayFareBasis(String rstfDisplayFareBasis) {
		this.rstfDisplayFareBasis = rstfDisplayFareBasis;
	}
	public Integer getRstfDisplayAdtCmnAmt() {
		return rstfDisplayAdtCmnAmt;
	}
	public void setRstfDisplayAdtCmnAmt(Integer rstfDisplayAdtCmnAmt) {
		this.rstfDisplayAdtCmnAmt = rstfDisplayAdtCmnAmt;
	}
	public Integer getRstfDisplayBaseCmnAmt() {
		return rstfDisplayBaseCmnAmt;
	}
	public void setRstfDisplayBaseCmnAmt(Integer rstfDisplayBaseCmnAmt) {
		this.rstfDisplayBaseCmnAmt = rstfDisplayBaseCmnAmt;
	}
	public Integer getRstfDisplayAdtCmnPct() {
		return rstfDisplayAdtCmnPct;
	}
	public void setRstfDisplayAdtCmnPct(Integer rstfDisplayAdtCmnPct) {
		this.rstfDisplayAdtCmnPct = rstfDisplayAdtCmnPct;
	}
	public Integer getRstfDisplayBaseCmnPct() {
		return rstfDisplayBaseCmnPct;
	}
	public void setRstfDisplayBaseCmnPct(Integer rstfDisplayBaseCmnPct) {
		this.rstfDisplayBaseCmnPct = rstfDisplayBaseCmnPct;
	}
	public String getRstfDisplayTourcode() {
		return rstfDisplayTourcode;
	}
	public void setRstfDisplayTourcode(String rstfDisplayTourcode) {
		this.rstfDisplayTourcode = rstfDisplayTourcode;
	}
	public String getRstfDisplayEndorsment() {
		return rstfDisplayEndorsment;
	}
	public void setRstfDisplayEndorsment(String rstfDisplayEndorsment) {
		this.rstfDisplayEndorsment = rstfDisplayEndorsment;
	}
	public Integer getDistributionStatus() {
		return distributionStatus;
	}
	public void setDistributionStatus(Integer distributionStatus) {
		this.distributionStatus = distributionStatus;
	}
	public Date getDistributionDate() {
		return distributionDate;
	}
	public void setDistributionDate(Date distributionDate) {
		this.distributionDate = distributionDate;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public Integer getBaggageAllowance() {
		return baggageAllowance;
	}
	public void setBaggageAllowance(Integer baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}
	public Integer getBaggageUnit() {
		return baggageUnit;
	}
	public void setBaggageUnit(Integer baggageUnit) {
		this.baggageUnit = baggageUnit;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Integer getRstfDisplayIfFreeYq() {
		return rstfDisplayIfFreeYq;
	}
	public void setRstfDisplayIfFreeYq(Integer rstfDisplayIfFreeYq) {
		this.rstfDisplayIfFreeYq = rstfDisplayIfFreeYq;
	}
	public String getEtermRstfDisplayEndorsment() {
		return etermRstfDisplayEndorsment;
	}
	public void setEtermRstfDisplayEndorsment(String etermRstfDisplayEndorsment) {
		this.etermRstfDisplayEndorsment = etermRstfDisplayEndorsment;
	}
	public Integer getyCabinPriceChooseIf() {
		return yCabinPriceChooseIf;
	}
	public void setyCabinPriceChooseIf(Integer yCabinPriceChooseIf) {
		this.yCabinPriceChooseIf = yCabinPriceChooseIf;
	}
	public Integer getMinYCabinPrice() {
		return minYCabinPrice;
	}
	public void setMinYCabinPrice(Integer minYCabinPrice) {
		this.minYCabinPrice = minYCabinPrice;
	}
	public Integer getMaxYCabinPrice() {
		return maxYCabinPrice;
	}
	public void setMaxYCabinPrice(Integer maxYCabinPrice) {
		this.maxYCabinPrice = maxYCabinPrice;
	}
	public Integer getAccountCodeFlag() {
		return accountCodeFlag;
	}
	public void setAccountCodeFlag(Integer accountCodeFlag) {
		this.accountCodeFlag = accountCodeFlag;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getWhenCreate() {
		return whenCreate;
	}
	public void setWhenCreate(Date whenCreate) {
		this.whenCreate = whenCreate;
	}
	public String getWhoCreate() {
		return whoCreate;
	}
	public void setWhoCreate(String whoCreate) {
		this.whoCreate = whoCreate;
	}
	public String getWhereCreate() {
		return whereCreate;
	}
	public void setWhereCreate(String whereCreate) {
		this.whereCreate = whereCreate;
	}
	public String getBrandSource() {
		return brandSource;
	}
	public void setBrandSource(String brandSource) {
		this.brandSource = brandSource;
	}
	public Integer getSubClassFlag() {
		return subClassFlag;
	}
	public void setSubClassFlag(Integer subClassFlag) {
		this.subClassFlag = subClassFlag;
	}
	public Integer getRstfThresholdCalType() {
		return rstfThresholdCalType;
	}
	public void setRstfThresholdCalType(Integer rstfThresholdCalType) {
		this.rstfThresholdCalType = rstfThresholdCalType;
	}
	public Integer getRstfThresholdCalPercent() {
		return rstfThresholdCalPercent;
	}
	public void setRstfThresholdCalPercent(Integer rstfThresholdCalPercent) {
		this.rstfThresholdCalPercent = rstfThresholdCalPercent;
	}
	public List<FBRBasefare> getBasefares() {
		return basefares;
	}
	public void setBasefares(List<FBRBasefare> basefares) {
		this.basefares = basefares;
	}
	public List<FBRDtlExroute> getFbrDetailRoutes() {
		return fbrDetailRoutes;
	}
	public void setFbrDetailRoutes(List<FBRDtlExroute> fbrDetailRoutes) {
		this.fbrDetailRoutes = fbrDetailRoutes;
	}
	public List<String> getGroupids() {
		return groupids;
	}
	public void setGroupids(List<String> groupids) {
		this.groupids = groupids;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}