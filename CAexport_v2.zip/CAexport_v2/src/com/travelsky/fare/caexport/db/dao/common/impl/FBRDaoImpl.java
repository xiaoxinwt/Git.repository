package com.travelsky.fare.caexport.db.dao.common.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.model.common.fbr.FBR;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.exception.FatalException;
import com.travelsky.fare.caexport.exception.NoFatalException;
import com.travelsky.fare.caexport.util.DateUtil;

public class FBRDaoImpl extends CommonDaoImpl implements IFareDao<FBR> {
	
	private Log log = LogFactory.getLog( this.getClass() );
	private Map<String, Object> param = new HashMap<String, Object>();

	//��ѯָ�����ڵ�����//����saledate��Ч�ڰ����˸������ڵ� FBRDetail����
	public List<FBR> queryAllByDate( String carrier,Date date ) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", date);
		return (List<FBR>) queryForList(FBR.class, "selectAllOfDate", param);
	}
	//��ѯָ�����ڷ�Χ�ڵ�����������
	public List<FBR> queryInsertByDays( String carrier, PairDays days) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", days.getFirstDate() );
		param.put("discdate", days.getLastDate() );
		return (List<FBR>) queryForList(FBR.class, "selectIncOfDays", param);
	}
	//��ѯָ�����ڷ�Χ�ڵ��޸ĵ�����
	public List<FBR> queryUpdateByDays( String carrier, PairDays days ) throws NoFatalException, FatalException {
		param = new HashMap<String, Object>();
		param.put("carrCode", carrier);
		param.put("effdate", days.getFirstDate() );
		return (List<FBR>) queryForList(FBR.class, "selectUpdateOfDays", param);
	}
	@Override
	public long countAllByDate(String carrier, Date effdate) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryAllByDate(carrier, effdate);
		return page.getTotal();
	}
	@Override
	public long countInsertByDays(String carrier, PairDays days) throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryInsertByDays(carrier, days);
		return page.getTotal();
	}
	@Override
	public long countUpdateByDays(String carrier, PairDays days)throws NoFatalException, FatalException {
		Page<?> page = PageHelper.startPage(1, -1);
		queryUpdateByDays(carrier, days);
		return page.getTotal();
	}
	@Override
	public List<FBR> queryAllByDateForPage(String carrier, Date effdate, int pageNum, int pageSize) throws NoFatalException, FatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryAllByDate(carrier, effdate);
	}
	@Override
	public List<FBR> queryInsertByDaysForPage(String carrier, PairDays days, int pageNum, int pageSize) throws NoFatalException, FatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryInsertByDays(carrier, days);
	}
	@Override
	public List<FBR> queryUpdateByDaysForPage(String carrier, PairDays days, int pageNum, int pageSize) throws NoFatalException, FatalException {
		PageHelper.startPage(pageNum, pageSize,false);
		return queryUpdateByDays(carrier, days);
	}
	
	public static void main(String[] args) throws NoFatalException, FatalException {
		String carrier = "CA";
		Date effdate = DateUtil.getDate("2015-01-01");
		Date discdate = DateUtil.getDate("2015-01-05");
		PairDays days = new PairDays( effdate , discdate );
		days = new PairDays("2015-01-01","2015-01-02");
		Date saleDate = DateUtil.getDate("2015-01-01");
		int pageSize = 500;
		FBRDaoImpl dao = new FBRDaoImpl();
		
		long allcount = dao.countAllByDate(carrier, saleDate);
		System.out.println( saleDate.toLocaleString()+"��ȫ����"+allcount );
		List<FBR> alllist = dao.queryAllByDateForPage(carrier, effdate, 1, pageSize);
		System.out.println( "ȫ������ҳ��"+alllist.size() );
		
//		long insertcount = dao.countInsertByDays(carrier, days);
//		System.out.println( days.toString()+"�ڵ�insert:"+ insertcount );
//		List<FBR> insertlist = dao.queryInsertByDaysForPage(carrier, days, 1, pageSize);
//		System.out.println( "Insert,��ҳ��"+ insertlist.size() );
		
//		long updatecount = dao.countUpdateByDays(carrier, days);
//		System.out.println( days.toString()+"�ڵ�update:"+ updatecount );
//		List<FBR> updatelist = dao.queryUpdateByDaysForPage(carrier, days, 1, pageSize);
//		System.out.println( "Update,��ҳ��"+updatelist.size() );
	}

}
