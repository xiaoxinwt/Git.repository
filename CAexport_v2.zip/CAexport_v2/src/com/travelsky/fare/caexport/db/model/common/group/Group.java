package com.travelsky.fare.caexport.db.model.common.group;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.travelsky.fare.caexport.db.model.po.Entity;

public class Group implements Entity {
	private static final long serialVersionUID = 1L;
	private String carrCode;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	GROUP_ID
	private String groupId;
	//Nullable: true	GROUP_DESC
	private String groupDesc;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: true	GROUP_TYPE
	private Integer groupType;
	private List<GroupEntry> gentrys;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCarrCode() {
		return carrCode;
	}
	public void setCarrCode(String carrCode) {
		this.carrCode = carrCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupDesc() {
		return groupDesc;
	}
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public Integer getGroupType() {
		return groupType;
	}
	public void setGroupType(Integer groupType) {
		this.groupType = groupType;
	}
	public List<GroupEntry> getGentrys() {
		if( gentrys==null )gentrys = new ArrayList<GroupEntry>();
		return gentrys;
	}
	public void setGentrys(List<GroupEntry> gentrys) {
		this.gentrys = gentrys;
	}
}