package com.travelsky.fare.caexport.db.model.common.rule;

import com.travelsky.fare.caexport.db.model.po.Entity;

import java.util.Date;

public class EndorsemtRestriction implements Entity {
	private static final long serialVersionUID = 1L;
	//Nullable: false	LOCATION_CODE
	private String locationCode;
	//Nullable: false	RESTRICTION_ID
	private Integer restrictionId;
	//Nullable: false	CATEGORY
	private String category;
	//Nullable: true	RESTRICTION_DESC
	private String restrictionDesc;
	//Nullable: false	RESTRICTION_TYPE
	private Integer restrictionType;
	//Nullable: true	WHO_LAST_UPDATE
	private String whoLastUpdate;
	//Nullable: true	WHERE_LAST_UPDATE
	private String whereLastUpdate;
	//Nullable: true	WHEN_LAST_UPDATE
	private Date whenLastUpdate;
	//Nullable: true	ETERM_RESTRICTION_DESC
	private String etermRestrictionDesc;
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public Integer getRestrictionId() {
		return restrictionId;
	}
	public void setRestrictionId(Integer restrictionId) {
		this.restrictionId = restrictionId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRestrictionDesc() {
		return restrictionDesc;
	}
	public void setRestrictionDesc(String restrictionDesc) {
		this.restrictionDesc = restrictionDesc;
	}
	public Integer getRestrictionType() {
		return restrictionType;
	}
	public void setRestrictionType(Integer restrictionType) {
		this.restrictionType = restrictionType;
	}
	public String getWhoLastUpdate() {
		return whoLastUpdate;
	}
	public void setWhoLastUpdate(String whoLastUpdate) {
		this.whoLastUpdate = whoLastUpdate;
	}
	public String getWhereLastUpdate() {
		return whereLastUpdate;
	}
	public void setWhereLastUpdate(String whereLastUpdate) {
		this.whereLastUpdate = whereLastUpdate;
	}
	public Date getWhenLastUpdate() {
		return whenLastUpdate;
	}
	public void setWhenLastUpdate(Date whenLastUpdate) {
		this.whenLastUpdate = whenLastUpdate;
	}
	public String getEtermRestrictionDesc() {
		return etermRestrictionDesc;
	}
	public void setEtermRestrictionDesc(String etermRestrictionDesc) {
		this.etermRestrictionDesc = etermRestrictionDesc;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "EndorsemtRestriction [locationCode=" + locationCode
				+ ", restrictionId=" + restrictionId + ", category=" + category
				+ ", restrictionDesc=" + restrictionDesc + ", restrictionType="
				+ restrictionType + ", whoLastUpdate=" + whoLastUpdate
				+ ", whereLastUpdate=" + whereLastUpdate + ", whenLastUpdate="
				+ whenLastUpdate + ", etermRestrictionDesc="
				+ etermRestrictionDesc + "]";
	}
}