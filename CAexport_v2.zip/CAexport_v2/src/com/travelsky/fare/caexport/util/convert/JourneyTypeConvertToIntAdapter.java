package com.travelsky.fare.caexport.util.convert;



import javax.xml.bind.annotation.adapters.XmlAdapter;



public class JourneyTypeConvertToIntAdapter extends XmlAdapter<Integer,String> {

	@Override
	public Integer marshal(String v) throws Exception {
		// TODO Auto-generated method stub
		if(v==null){
			return null;
		}
		else if(v.equalsIgnoreCase("OW")){
			return 1;
		}else if(v.equalsIgnoreCase("RT")){
			return 2;
		}
		return null;
	}

	@Override
	public String unmarshal(Integer v) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
