package com.travelsky.fare.caexport.util;

import java.math.BigDecimal;

public class Formatter {

	public static BigDecimal formatToDecimal(Integer amount, String scn) {
		return null;
	}
	
	public static void main(String[] args) {
		formatToDecimal( 12,"0.000");
	}

}
