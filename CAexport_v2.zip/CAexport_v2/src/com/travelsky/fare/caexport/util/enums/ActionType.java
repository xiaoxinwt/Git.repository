package com.travelsky.fare.caexport.util.enums;

public enum ActionType {
	Insert("insert"),Update("update"),Null("");
	
	public String code;
	ActionType(String val){
		this.code = val;
	}
	
}
