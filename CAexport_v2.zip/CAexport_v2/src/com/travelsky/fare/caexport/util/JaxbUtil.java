package com.travelsky.fare.caexport.util;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.namespace.QName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.beans.Introspector;
 
/**
 * Created by John Jiang on 9/6/2015.
 */
public class JaxbUtil {
	
    private static final Log log = LogFactory.getLog(JaxbUtil.class);
    public static final String DEFAULT_ENCODING = "UTF-8";
    
    
    /**
     * dtoתΪxml�ַ���
     * @throws Exception
     */
    public static <T extends Object> String dto2xml(T t) throws Exception{
        JAXBContext context = JAXBContext.newInstance(t.getClass());   
        Marshaller marshaller = context.createMarshaller();   
        marshaller.setProperty(Marshaller.JAXB_ENCODING,"UTF-8");//�����ʽ
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);//�Ƿ��ʽ�����ɵ�xml��   
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, false);//�Ƿ�ʡ��xmlͷ��Ϣ
        StringWriter writer = new StringWriter();
        marshaller.marshal(t, writer);   
        return writer.toString();
    }
    
    public static <T extends Object> String dto2xml(T t ,boolean hasHeader) throws Exception{
        JAXBContext context = JAXBContext.newInstance(t.getClass());   
        Marshaller marshaller = context.createMarshaller();   
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);//�Ƿ��ʽ�����ɵ�xml��   
        marshaller.setProperty(Marshaller.JAXB_ENCODING,"UTF-8");//�����ʽ
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, hasHeader);//�Ƿ�ʡ��xmlͷ��Ϣ
        StringWriter writer = new StringWriter();
        marshaller.marshal(t, writer);   
        return writer.toString();
    }
     
    /**
     * xml�ַ���תΪdto����
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
	public static <T extends Object> T xml2dto(String xml, Class<T> clazz) throws Exception{
        JAXBContext context = JAXBContext.newInstance(clazz);   
        Unmarshaller unmarshaller = context.createUnmarshaller();
        StringReader reader = new StringReader(xml.trim());   
        T t = (T)unmarshaller.unmarshal(reader);
        return t;
    }

    
 
    /**
     * <p>convert bean to xml. default using UTF8 encoding</p>
     *
     * @param obj
     * @return
     */
    public static String convertToXml(Object obj) {
        return convertToXml(obj, DEFAULT_ENCODING);
    }
 
    /**
     * <p>convert bean to xml.</p>
     *
     * @param obj
     * @param encoding
     * @return
     */
    public static String convertToXml(Object obj, String encoding) {
        String result = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            convertToXml(obj, encoding, baos);
            result = baos.toString(encoding);
        } catch (Exception e) {
            log.error("convert java bean to xml error", e);
        }
        return result;
    }
 
    /**
     * convert bean to xml using utf-8 encoding.then write it to outputStream
     *
     * @param obj
     * @param outputStream
     * @throws JAXBException
     */
    public static void convertToXml(Object obj, OutputStream outputStream) throws JAXBException {
        convertToXml(obj, DEFAULT_ENCODING, outputStream);
    }
 
    /**
     * <p>convert bean to xml. then write to outputStream</p>
     *
     * @param obj
     * @param encoding
     * @return
     */
    public static void convertToXml(Object obj, String encoding, OutputStream outputStream) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(obj.getClass());
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.setProperty(Marshaller.JAXB_ENCODING, encoding);
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, false);//�Ƿ�ʡ��xmlͷ��Ϣ
        marshaller.marshal(obj, outputStream);
    }
 
 
    /**
     * xmlת����JavaBean
     *
     * @param xml
     * @param c
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T convertToJavaBean(String xml, Class<T> c) {
        T t = null;
        try {
            JAXBContext context = JAXBContext.newInstance(c);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            t = (T) unmarshaller.unmarshal(new StringReader(xml));
        } catch (Exception e) {
            log.error("convert xml to JavaBean error", e);
        }
        return t;
    }
    /**
     * get the JAXB marshal-able object one JaxbObject or an object has XmlRootElement annotation.
     *
     * @param originObject
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object getJaxbRootObject(Object originObject) {
        Object ret = null;
        if (originObject instanceof JAXBElement) {
            ret = originObject;
        } else {
            Class<?> clazz = originObject.getClass();
            XmlRootElement r = clazz.getAnnotation(XmlRootElement.class);
            if (r == null) {
                QName name = buildQname(clazz);
                ret = new JAXBElement(name, clazz, originObject);
            } else {
                ret = originObject;
            }
        }
        return ret;
    }
 
    /**
     * build Jaxb QName for marshal type.
     * @param clazz
     * @return
     */
    private static QName buildQname(Class<?> clazz) {
        String beanName = Introspector.decapitalize(clazz.getSimpleName());
        XmlSchema xmlSchema = clazz.getPackage().getAnnotation(XmlSchema.class);
        String namespaceUri = xmlSchema.namespace();
        QName name = new QName(namespaceUri, beanName, "");
        return name;
    }
}
