package com.travelsky.fare.caexport.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.annotation.Resources;
import com.travelsky.fare.caexport.db.model.common.rule.FlightNoRestriction;
import com.travelsky.fare.caexport.util.entry.DBColumn;

public class DBHelper {

	private static final String DRIVERNAME = "oracle.jdbc.driver.OracleDriver";
//	private static final String URL = "jdbc:oracle:thin:@//172.30.10.41:1525/farerd2";
	private static final String URL = "jdbc:oracle:thin:@//192.168.31.231:1521/pdborcl";
	private static final String PASSWORD = "nfsadminabc";
//	private static final String URL = "jdbc:oracle:thin:@//172.30.10.41:1522/farerd";
	private static final String USERNAME = "nfsadmin";
//	private static final String PASSWORD = "nfsadmin";
	
	static{
		try {
			Class.forName(DRIVERNAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private static Connection getconn() throws SQLException{
		return DriverManager.getConnection(URL, USERNAME, PASSWORD);
	}
	
	private static List<Map<String,Object>> query(String sql){
		
		List<Map<String, Object>> list = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = getconn();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery(sql);
			list = ResultsetUtil.dealQueryResult(rs);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			close(conn,ps,rs);
		}
		
		return list;
	}
	
	private static void close(Connection conn, PreparedStatement ps,ResultSet rs) {
		try {
			if(rs!=null) rs.close();
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static List<String> querytabls(String schema){
		String sql = "select * from all_tab_comments WHERE OWNER='"+schema+"'";
		List<String> tablist = new ArrayList<String>();
		List<Map<String, Object>> list = query(sql);
		for (Map<String, Object> map : list) {
			tablist.add( (String)map.get("TABLE_NAME"));
		}
		return tablist;
	}
	
	public static List<DBColumn> querycols(String schema ,String tabname){
		
		List<DBColumn> collist = new ArrayList<DBColumn>();

		String sql = 
			"SELECT " +
				"t.COLUMN_ID AS ColumnId,t.OWNER AS SchemaName,t.TABLE_NAME AS TableName,t.COLUMN_NAME AS ColumnName, " +
				"t.DATA_TYPE AS ColumnTypeName,t.DATA_LENGTH AS ColumnDisplaySize,t.NULLABLE AS Nullable, " +
				"NVL( (SELECT c.COMMENTS FROM all_col_comments c WHERE c.OWNER=t.OWNER AND c.TABLE_NAME=t.TABLE_NAME AND c.COLUMN_NAME=t.COLUMN_NAME) ,t.COLUMN_NAME) AS ColumnLabel, " +
				"t.COLUMN_NAME AS CatalogName,t.DATA_PRECISION AS Precision,t.DATA_SCALE AS Scale " +
			"FROM all_tab_columns t WHERE t.OWNER='"+schema+"' AND t.TABLE_NAME='"+tabname+"' ORDER BY t.COLUMN_ID";
		
		List<Map<String, Object>> list = query(sql);
		DBColumn col;
		Integer typeCode = -1;
		String typeName = "";
		String className = "";
		for (Map<String, Object> map : list) {
			col = new DBColumn();
			col.setCatalogName( map.get("CATALOGNAME").toString() );
			col.setColid( Integer.parseInt( String.valueOf(map.get("COLUMNID")) ) );
			col.setCollabel( (String)map.get("COLUMNLABEL") );
			col.setColname( (String)map.get("COLUMNNAME") );
			col.setColscale( (Integer)map.get("SCALE") );
			col.setDatalength( (Integer)map.get("COLUMNDISPLAYSIZE") );
			col.isNullable( ((String)map.get("NULLABLE")).equals("N")?false:true );
			col.setOwner( (String)map.get("SCHEMANAME") );
			col.setPrecision( (Integer)map.get("PRECISION") );
			col.setSchemaName( (String)map.get("SCHEMANAME") );
			col.setTableName( (String)map.get("TABLENAME") );
			
			typeCode = fixTypeCodeOfTypeName( (String)map.get("COLUMNTYPENAME") );
			typeName = JDBCUtils.getTypeNameByTypeCode(typeCode);
			className = JDBCUtils.getJavaTypeByTypeCode( typeCode ).getName();
			
			col.setColtype( typeCode );
			col.setTypeName( typeName );
			col.setClassName( className );
//			System.out.println( col.getColtype()+"\t" + col.getTypeName() +"\t" +col.getClassName() );
			
			collist.add(col);
		}
		return collist;
	}
	
	private static int fixTypeCodeOfTypeName(String typeName) {
		int typeCode = -1;
		if( typeName.equals("VARCHAR2") ){
			typeCode = Types.VARCHAR;
		}else if( typeName.equals("NUMBER")){
			typeCode = Types.INTEGER;
		}else{
			typeCode = JDBCUtils.getTypeCodeByTypeName( typeName );
		}
		return typeCode;
	}

	//�������ֶ�����ʵ����
	public static String generalEntityStr(String schema,String tabname,String entname){
		String str = "";
		String packagename = entname.substring(0,entname.lastIndexOf("."));
		String entclsshortname = getClassName( entname.substring(entname.lastIndexOf(".")+1) );
		str = "package "+packagename+";";
		str += "\n";
		str += "\nimport java.util.List;";
		str += "\nimport java.util.ArrayList;";
		str += "\nimport java.util.HashMap;";
		str += "\nimport java.util.List;";
		str += "\nimport java.util.Map;";
		str += "\nimport java.util.Date;";
		str += "\nimport java.math.BigDecimal;";
		str += "\nimport com.travelsky.fare.caexport.db.model.po.Entity;";
		str += "\n";
		str += "\npublic class "+entclsshortname+" implements Entity {";
		str += "\n\tprivate static final long serialVersionUID = 1L;";
		List<DBColumn> collist = querycols(schema,tabname);
		String className = "";
		for (DBColumn col : collist) {
			className = col.getClassName();
			className = className.substring(className.lastIndexOf(".")+1);
			str += "\n\t//Nullable: "+col.isNullable()+"\t"+col.getColname();
			str += "\n\tprivate "+ className +" "+getEntName(col,entclsshortname)+";";
		}
		str += "\n}";
		return str;
	}
	
	public static String generalEntityAndResultMapStr(String schema,String tabname,String clsFullName){
		String str = "";
		List<DBColumn> collist = querycols(schema,tabname);
		String entclsshortname = getClassName( clsFullName );
		String fieldJavaClassType = "";		//�ֶε�Java����
		for (DBColumn col : collist) {
			fieldJavaClassType = col.getClassName();
			fieldJavaClassType = fieldJavaClassType.substring(fieldJavaClassType.lastIndexOf(".")+1);
			str += "\n//Nullable: "+col.isNullable()+"\t"+col.getColname();
			str += "\nprivate "+ fieldJavaClassType +" "+getEntName(col,entclsshortname)+";";
		}
		
		str+="\n\n";
		
		str += "\n<resultMap id=\""+entclsshortname+"Map\" type=\""+clsFullName+"\">";
		for (DBColumn col : collist) {
			str += "\n\t<result property=\""+getEntName(col,entclsshortname)+"\" column=\""+col.getColname()+"\" jdbcType=\""+col.getTypeName()+"\"/>";
		}
		str += "\n</resultMap>";
		
		return str;
	}
	
	@SuppressWarnings("unused")
	public static String generalMapperStr(String schema,String tabname,String entname,String tabnick){
		
		schema = schema.toUpperCase();
		tabname = tabname.toUpperCase();
		
		String str = "";
		String packagename = entname.substring(0,entname.lastIndexOf("."));
		String entclsshortname = entname.substring(entname.lastIndexOf(".")+1);
		str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		str += "\n<!DOCTYPE mapper PUBLIC \"-//ibatis.apache.org//DTD Mapper 3.0//EN\" \"http://ibatis.apache.org/dtd/ibatis-3-mapper.dtd\">";
		str += "\n<mapper namespace=\""+entclsshortname+"Mapper\">";
		str += "\n";

		str += "\n\t<resultMap id=\""+entclsshortname+"Map\" type=\""+entname+"\">";
		List<DBColumn> collist = querycols(schema,tabname);
		for (DBColumn col : collist) {
			str += "\n\t\t<result property=\""+getEntName(col,entclsshortname)+"\" column=\""+col.getColname()+"\" jdbcType=\""+col.getTypeName()+"\"/>";
		}
		str += "\n\t</resultMap>";
		
		str += "\n\n";
		
		String sqlid = "sqlSelect"+entclsshortname;
		String colstr = getcolstr(collist,tabnick);
		str += "\n\t<sql id=\""+sqlid+"\">";
		str += "\n\tSELECT ";
		str += "\n\t\t"+colstr+" ";
		str += "\n\tFROM "+(schema.contains("NFS")?"NFS_${carrCode}":schema)+"."+tabname+" "+tabnick;
		str += "\n\t</sql>";
		str += "\n";
		str += "\n\t<select id=\"selectAll\" parameterType=\"map\" resultMap=\""+entclsshortname+"Map\">";
		str += "\n\t<include refid=\""+sqlid+"\"/>";
		str += "\n\t<![CDATA[  ]]>";
		str += "\n\t</select>";
		str += "\n";
		str += "\n\t<select id=\"selectInc\" parameterType=\"map\" resultMap=\""+entclsshortname+"Map\">";
		str += "\n\t<include refid=\""+sqlid+"\"/>";
		str += "\n\t<![CDATA[";
		String lastUpdateStr = getLastUpdateStr( Arrays.asList( colstr.split(",") ),tabnick );
		str += "\n\t\t"+( ( lastUpdateStr!=null && lastUpdateStr.trim().length()>0 )?"WHERE "+lastUpdateStr:"" );
		str += "\n\t]]>";
		str += "\n\t</select>";
		
		str += "\n\n</mapper>";
		return str;
	}
	
	private static String getLastUpdateStr(List<String> fields, String tabnick) {
		List<String> lastdatefieldarr = Arrays.asList( new String[]{"WHEN_LAST_UPDATE","LAST_UPDATE"} );
		String tempfield = "";
		for (String colfield : fields) {
//			System.out.println( colfield );
			tempfield = colfield.replace( tabnick+".", "");
//			System.out.println( tempfield );
			for (String lastfield : lastdatefieldarr) {
//				System.out.println( lastfield );
//				System.out.println( tempfield.equals(lastfield) );
				if( tempfield.equals( lastfield ) ){
					return colfield+" BETWEEN #{first} AND #{last}";
				}				
			}
		}
		return null;
	}

	private static String getcolstr(List<DBColumn> collist,String tabnick){
		if( collist==null || collist.size()==0) return tabnick+".*";
		String colstr = "";
		for (DBColumn col : collist) {
			colstr += (colstr.trim().length()>0?",":"")+tabnick+"."+col.getColname();
		}
		return colstr;
	}
	
	//�������ݿ��ֶ�����������
	private static String getEntName(String srcname,String filterstr){
//		if(srcname.startsWith(filterstr.toLowerCase())){
//			srcname = srcname.substring(filterstr.length()+1);
//		}
		
		String entname = "";
		String[] narr = srcname.split("_");
		String tmp = "";
		for (int i = 0; i < narr.length; i++) {
			if(i==0) entname=narr[0].toLowerCase();
			else{
				tmp = narr[i].substring(0, 1).toUpperCase()+ narr[i].substring(1).toLowerCase();
				entname += tmp;
			}
		}
		return entname;
	}
	
	private static String getEntName(DBColumn col,String filterstr) {
		String srcname = col.getColname().toLowerCase();
		return getEntName(srcname,filterstr);
	}
	
	//����ĸ��д
	private static String getClassName(String clsFullName) {
		String classNickName = "";
		String classTmpName = clsFullName.substring( clsFullName.lastIndexOf(".")+1 );
		classNickName = classTmpName.substring(0, 1).toUpperCase()+classTmpName.substring(1);
		return classNickName;
	}
	
	@SuppressWarnings("unused")
	public static boolean grantEntryWithMapper(String schema,String tabname,String entname,String tabnick){
		
		if(schema==null || tabname==null || entname==null) return false;
		schema = schema.toUpperCase();
		tabname = tabname.toUpperCase();
		
		String srcpath = Resources.class.getResource("/").getPath();
		srcpath = srcpath.substring(1, srcpath.length()-1);
		srcpath = srcpath.endsWith("bin")?srcpath.substring(0, srcpath.lastIndexOf("/")):srcpath;
		srcpath = srcpath.startsWith("/")?srcpath:srcpath +File.separator+"src"+File.separator;
//		System.out.println( srcpath );
		String packagename = entname.substring(0,entname.lastIndexOf("."));
		String classname = entname.substring(entname.lastIndexOf(".")+1 );
		String packagepath = packagename.replaceAll("\\.", "/");
//		System.out.println( packagepath );
		
		String javafdir = srcpath+packagepath;
		new File(javafdir).mkdirs();
		String mapperdir = srcpath+packagepath;
		new File(mapperdir).mkdirs();

		String javafname = classname +".java";
		String javafilepath = javafdir+File.separator+javafname;
		File javafile = new File(javafilepath);
		System.out.println( javafilepath );

		String mappername = classname+"Mapper" + ".xml";
		String mapperfilepath = mapperdir+File.separator+mappername;
		File mapperfile = new File(mapperfilepath);
		System.out.println( mapperfile );
					
		String javacontent = generalEntityStr(schema,tabname,entname);
		String mappercontent = generalMapperStr(schema,tabname,entname,tabnick);
		String entryAndResultmapStr = generalEntityAndResultMapStr(schema,tabname,entname);
//		System.out.println( mappercontent );
//		System.out.println( javacontent );
		System.out.println( entryAndResultmapStr );
		return true;
		
//		try {
//			createFileWithContent(javafile , javacontent);
//			createFileWithContent(mapperfile,mappercontent);
//			System.out.println("finish");
//			return true;
//		} catch (IOException e) {
//			e.printStackTrace();
//			return false;
//		}
	}
	
	@SuppressWarnings("unused")
	private static void createFileWithContent(File file ,String content) throws IOException{
		file.createNewFile();
		FileWriter writer = new FileWriter( file );
		writer.write( content );
		writer.close();
	}
	
	public static void main(String[] args) {
		
//		String[] tabs = new String[]{"fare_by_rule",
//			"BASE_FARE","FARE_BY_RULE_DTL","FARE_BY_RULE_DTL_DISTRIBUTION","FARE_BY_RULE_DTL_EXROUTE",
//			"FARE_BY_RULE_DTL_EXROUTE_ENTRY"
//		};
//		
//		String packagename = "com.travelsky.fare.caexport.db.model.easyfare.fbr";
//		for (int i = 0; i < tabs.length; i++) {
//			String tabname = tabs[i].toUpperCase();
//			String tabnick = "T"+(i>0?i:"");
//			String entname = getEntName(tabname.toLowerCase(),"rule");
//			entname = packagename+"."+entname;
////			System.out.println( entname );
//			grantEntryWithMapper(schema ,tabname , entname, tabnick);
//			System.out.println( entname +" --> success");
//		}
		
		String tabnick = "T";
		String tabFullName = "NFS_TA.FARE_BY_RULE".toUpperCase();
		Class<?> cls = FlightNoRestriction.class;
		String entname = null;
		entname = cls.getName();
		entname = "com.travelsky.fare.caexport.db.model.common.fbr.FareByRule";
		System.out.println( entname );
		grantEntryWithMapper( tabFullName.split("\\.")[0] ,tabFullName.split("\\.")[1] , entname, tabnick);
		
//		querycols(schema, tabname);
//		System.out.println( String.valueOf(Integer.MIN_VALUE).length() );
//		System.out.println(Long.class.getName());
		
//		List<DBColumn> list = querycols(schema, tabname);
//		for (DBColumn col : list) {
//			System.out.println(col.getColname()+"-"+col.getTypeName()+"-"+col.getDatalength() );
//		}
		
	}

}
