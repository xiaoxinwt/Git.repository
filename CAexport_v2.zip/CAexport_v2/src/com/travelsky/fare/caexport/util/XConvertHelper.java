package com.travelsky.fare.caexport.util;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;
import com.travelsky.fare.caexport.db.model.common.fbr.FBRDetail;

public class XConvertHelper {

	//�õ�ĳһ���������setter����
	public static void getAllSetter(Class<?> cls,String xname,String name){
		
		System.out.println( xname+" = new "+cls.getSimpleName()+"();");
		System.out.println();
		
		Set<String> list = new TreeSet<String>();
		Method[] methods = cls.getMethods();
		for (Method method : methods) {
			if(method.getName().startsWith("set") || method.getName().startsWith("is")){
				list.add( xname+"."+method.getName()+"( "+name+" );" );
			}
		}
		for (String str : list) {
			System.out.println( str );
		}
		
		System.out.println();
//		System.out.println( xname+"s.add("+xname+");");
	}
	
	public static void getAllClone(Class<?> cls,String objname ){
		System.out.println( objname+" = new "+cls.getSimpleName()+"();");
		System.out.println();
		
		Set<String> list = new TreeSet<String>();
		Method[] methods = cls.getMethods();
		String objval = "";
		String val = "";
		for (Method method : methods) {
			objval = method.getName();
			if( objval.startsWith("set") || objval.startsWith("is")){
				if( objval.startsWith("set") )
					objval = objval.replaceFirst("set", "");
				else if( objval.startsWith("is") )
					objval = objval.replaceFirst("is", "");
				
				val = objval.substring(0, 1).toLowerCase()+objval.substring(1); 
				list.add( objname+"."+method.getName()+"( "+val+" );" );
			}
		}
		for (String str : list) {
			System.out.println( str );
		}
		
		System.out.println();
	}
	
	public static void getAllGetter(Class<?> cls , String name){
		Set<String> list = new TreeSet<String>();
		Method[] methods = cls.getMethods();
		for (Method method : methods) {
			if(method.getName().startsWith("get") || method.getName().startsWith("is")){
				list.add( name+"."+method.getName()+"();" );
			}
		}
		for (String str : list) {
			System.out.println( str );
		}
		
		System.out.println();
	}
	
	public static void getAllSetter(Class<?> cla , String name){
		getAllSetter( cla , "x"+name, name);
	}
	
	
	public static void main(String[] args) {
//		getAllSetter( XRuleCombination.class, "xcomb","comb" );
		getAllClone( FBRDetail.class, "fareByRuleDetail");
//		getAllGetter( XRuleCombination.class, "comb" );
	}
}
