/**============================================================
 * ��Ȩ�� Travelsky ��Ȩ���� (c) 2008 - 2009
 * �ļ��� util.FareDistCache
 * ������: FareDistCache
 * �޸ļ�¼��
 * ����                		����                		����
 * =============================================================
 * 2016-01-29         liye(liye@travelsky.com)    �����ļ���ʵ�ֻ�������
 * ============================================================*/

package com.travelsky.fare.caexport.util;

import java.util.Date;
import java.util.List;
import java.util.Map;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.FareDistributeDaoImpl;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.model.po.RefPK;

/**
 * <p>��˵��</p>
 * <p>ʹ��˵��</p>
 * @version 2011-7-14
 * @author liye
 */
public class FareDistCache {
	public static final int All=0;
	public static final int New=1;
	public static final int Update=2;
	
	private static FareDistCache cache = new FareDistCache();
	private static Map<RefPK, List<String>> map;
	private FareDistributeDaoImpl disdao = new FareDistributeDaoImpl();
	private static Date effDate=null;
	private static Date firstDate=null;
	private static Date lastDate=null;
	private static int type;

	public FareDistCache(){}
	
	public static FareDistCache getInstance(int distype,Date date) {
		effDate=date;
		type=distype;
		return cache;
	}
	
	public static FareDistCache getInstance(int distype, PairDays days) {
		firstDate=days.getFirstDate();
		lastDate=days.getLastDate();
		type=distype;
		return cache;
	}

	private void buildCache(String carrier){
		System.out.println(new Date()+" build cache of "+getCacheType(type)+" start ....");
		try {
			if(type==All){
				map=disdao.queryAvailByDate(carrier, effDate);
			} else if (type==New){
				map=disdao.queryIncByDays(carrier, new PairDays(firstDate , lastDate));
			} else if (type==Update){
				map=disdao.queryUpdateByDays(carrier, new PairDays(firstDate,lastDate));
			}
			System.out.println(new Date()+" build cache of "+getCacheType(type)+" end   ....");
		} catch (Exception e) {
			ErrorLog.log( e );
			System.out.println( "Failure: " + new Date()+" build cache of "+getCacheType(type)+" failure   ....");
		}
	}

	public List<String> getDistGroups(RefPK refPK){
		if (map == null) {
			buildCache(refPK.getCarrier());
		}
		List<String> groupList = map.get(refPK);
		return groupList;
	}
	
	public static Map<RefPK, List<String>> getMap(){
		return map;
	}
	public static void clearCache(){
		map=null;
	}
	
	public static String getCacheType(int distype){
		String ret = "";
		switch (distype) {
		case 0:
			ret = "All";
			break;
		case 1:
			ret = "New";
			break;
		case 2:
			ret = "Update";
			break;
		default:
			break;
		}
		return ret;
	}

}

