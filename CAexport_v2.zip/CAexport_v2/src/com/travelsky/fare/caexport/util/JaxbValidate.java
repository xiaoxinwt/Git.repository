package com.travelsky.fare.caexport.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.InputSource;

import com.travelsky.fare.caexport.util.enums.CAType;

public class JaxbValidate {
	
	private static String xsddir = null;
	
	static{
		//linux��
		xsddir = FileUtil.getDirPath( System.getProperty("user.dir")+File.separator+"resources"+File.separator+"schema" );
		//windows��
//		xsddir = "D:\\hx.projects\\2015_12\\CAexport_v2\\resources\\schema\\";
	}
	
	public static void main(String[] args) {
		
		List<CAType> catypelist = new ArrayList<CAType>();
//		catypelist.add( CAType.Airtis );
		catypelist.add( CAType.Easyfare );
		String xmldir = null;
		System.out.println( xsddir );
		for (CAType catype : catypelist) {
			xmldir = "D:\\hx\\CAexport\\CA\\"+catype.val;
			
//			validateGroup(xmldir);
//			validateFare(xmldir);
//			validateRule(xmldir);
//			validateRefund(xmldir);
//			validateReissue(xmldir);
			validateFbr(xmldir);
		}
		
	}
	
	public static void validateRule(String xmldir){
		String xsdname = "rule.xsd";
		final String keyname = "Rule";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	public static void validateFare(String xmldir){
		String xsdname = "agreement_fare.xsd";
		final String keyname = "Fare";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	public static void validateRefund(String xmldir){
		String xsdname = "rule_refund.xsd";
		final String keyname = "Refund";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	public static void validateReissue(String xmldir){
		String xsdname = "rule_reissue.xsd";
		final String keyname = "Reissue";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	public static void validateGroup(String xmldir){
		String xsdname = "group.xsd";
		final String keyname = "Group";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	public static void validateFbr(String xmldir){
		String xsdname = "fbr.xsd";
		final String keyname = "FBR";
		FilenameFilter filter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.indexOf( keyname )>0;
			}
		};
		validateXML( xsddir+xsdname , xmldir , filter);
	}
	
	private static void validateXML(String xsdpath , String xmlpath){
		try
        {
			System.out.println( "�ļ���"+xmlpath );
			System.out.println( "������֤������");
            String schemaLanguage = XMLConstants.W3C_XML_SCHEMA_NS_URI;
            SchemaFactory schemaFactory = SchemaFactory.newInstance(schemaLanguage);
            Schema schema = schemaFactory.newSchema(new File(xsdpath));

            Validator validator = schema.newValidator();
            InputSource inputSource = new InputSource(new FileInputStream(new File(xmlpath)));
            Source source = new SAXSource(inputSource);
            validator.validate(source);
            System.out.println("success");
        }
        catch (Exception e)
        {
        	System.out.println("У��δͨ��.");
            e.printStackTrace();
        }
	}
	
	private static void validateXML(String xsdpath , String xmldir , FilenameFilter namefilter){
		File[] list = new File(xmldir).listFiles(namefilter);
		for (File xmlfile : list) {
			validateXML( xsdpath , xmlfile.getPath() );
		}
	}
}
