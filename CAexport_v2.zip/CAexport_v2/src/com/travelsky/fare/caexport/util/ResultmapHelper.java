package com.travelsky.fare.caexport.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import com.travelsky.fare.caexport.db.model.common.refund.RefundEntry;

public class ResultmapHelper {
	
    public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    	ResultmapHelper.getResultMap(RefundEntry.class,true);
	}

    public static void getResultMap(Class<?> cls ,boolean needcols){
    	
    	Field[] fields = cls.getDeclaredFields();
		String fieldName = "";
		String dbColumnName = "";
		Annotation anno;
		
		System.out.println("<resultMap id=\""+cls.getSimpleName()+"ResultMap\" type=\""+cls.getName()+"\">");
		for (Field field : fields) {
			fieldName = field.getName();
//			System.out.println( fieldName );
			anno = field.getAnnotations()[0];
//			System.out.println( anno.annotationType()+"\t\t"+anno.toString() );
			Class<? extends Annotation> anc = anno.annotationType();
			Object invoke = null;
			for (Method m : anc.getDeclaredMethods()) {
				try {
					invoke = m.invoke(anno);
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				
				String newResultMapName = "";
				if(m.getName().equals("name")){
					dbColumnName = (String) invoke;
//					System.out.println( "FiledName:"+ fieldName+"\tFieldClass:" + field.getType().getName()+"\tColnumName:"+dbColumnName );
					if(field.getType().getName().equals("java.util.List")){
//						System.out.println("<collection property=\""+fieldName+"\" ofType=\""+field.getType().getName()+"\" column=\"{carrCode=CARRIER_CODE,locationCode=LOCATION_CODE}\" select=\"selectRouteEntry\" />");
						String fieldType = field.getGenericType().toString();
						fieldType = fieldType.substring(fieldType.indexOf("<")+1,fieldType.indexOf(">"));
						try {
							newResultMapName = Class.forName(fieldType).getSimpleName()+"ResultMap";
						} catch (ClassNotFoundException e) {
							e.printStackTrace();
						}
						System.out.println("\t<collection property=\""+fieldName+"\" " +
								(needcols?"column=\"{"+getColumnStr(fieldType,"name")+"}\" ":"") +
								"ofType=\""+fieldType+"\" " +
								"resultMap=\""+newResultMapName+"\" " +
						"/>");
					}else if(field.getType().getName().contains("domain.model.easyfare.entity") || 
							field.getType().getName().contains("com.travelsky.fare.caexport.dto.entity") ){
						System.out.println("\t<association property=\""+fieldName+"\" " +
								(needcols?"column=\"{"+getColumnStr(field.getType().getName(),"name")+"}\" ":"") +
								"javaType=\""+field.getType().getName()+"\" />");
					}else{
						System.out.println("\t<result property=\""+fieldName+"\" column=\""+dbColumnName+"\" />");						
					}
					
				}
			}
		}
		System.out.println("</resultMap>");
    }
    
    private static String getColumnStr(String className ,String annoField){
    	String columnStr = "";
    	Class<?> cls = null;
    	try {
			cls=Class.forName( className );
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "";
		}
		Field[] fields = cls.getDeclaredFields();
		String fieldName = "";
		String colName = "";
		Annotation anno = null;
		for (Field field : fields) {
			fieldName = field.getName();
			if( field.getAnnotations().length==0 ) continue;
			else{
				anno = field.getAnnotations()[0];
				if(anno.annotationType().getName().equals("javax.xml.bind.annotation.XmlTransient") ) continue;
			}
			colName = (String)getValInAnnotation(anno).get(annoField);	//��ȡAnnotation��ĳһ���Ե�ֵ
			columnStr += (columnStr.trim().length()>0?",":"")+fieldName+"="+colName;
		}
    	return columnStr;
    }
    
    private static Map<String,Object> getValInAnnotation(Annotation anno){
    	Map<String ,Object> annomap = new HashMap<String,Object>();
    	try {
			Class<? extends Annotation> anc = anno.annotationType();
			for (Method m : anc.getDeclaredMethods()) {
				Object invoke = m.invoke(anno);
				if(annomap.containsKey(m.getName() )) continue;
				else{					
//					System.out.println("invoke methd " + m.getName() + " result:" + invoke);
//					if (invoke.getClass().isArray()) {
//						Object[] temp = (Object[]) invoke;
//						for (Object o : temp) {
//							System.out.println(o);
//						}
//					}
					annomap.put( m.getName(), invoke);
				}
			}
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

    	return annomap;
    }

}
