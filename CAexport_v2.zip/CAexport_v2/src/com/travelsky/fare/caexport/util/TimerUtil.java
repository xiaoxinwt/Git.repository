package com.travelsky.fare.caexport.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.lang3.StringUtils;

public class TimerUtil {
	private static Timer timer = new Timer();
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static void addAirtisAllJob(String times,Class<?> targetClass,Method method,Object[] param,long delay,boolean ifImmediate){
    	if(StringUtils.isEmpty(times)){
    		return;
    	}
    	//�����Ӧ��ʱ��
    	SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    	String dateString = format.format(new Date());
    	SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd HH:mm");
    	String[] timeList = times.split(",");
    	String time = null;
    	for(int i = 0;i<timeList.length;i++){
    		time = timeList[i];
    		String temp = " "+time;
    		Date firstDate = null;
    		try {
    			firstDate = format2.parse(dateString+temp);
    			if(ifImmediate){
    				firstDate=new Date(firstDate.getTime()+5*60*1000);
    			} else{
    				firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
    			}
			} catch (ParseException e) {
				e.printStackTrace();
			}
            //����ִ���ࡢִ�в���
			ExportAirtisAllTask exportTask = new ExportAirtisAllTask();
	    	exportTask.setTargetClass(targetClass);
	    	if(param!=null&&param.length>1){
	    	    param[param.length-1] = i+1;
	    	}
	    	Object[] paramClone = param.clone();
	    	exportTask.setParam(paramClone);
	    	exportTask.setMethod(method);
	    	timer.scheduleAtFixedRate(exportTask, firstDate,delay);
    	}
    }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void addAirtisIncJob(String times,Class<?> targetClass,Method method,Object[] param,long delay,boolean ifImmediate){
		if(StringUtils.isEmpty(times)){
			return;
		}
		//�����Ӧ��ʱ��
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		String dateString = format.format(new Date());
		SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd HH:mm");
		String[] timeList = times.split(",");
		String time = null;
		for(int i = 0;i<timeList.length;i++){
			time = timeList[i];
			String temp = " "+time;
			Date firstDate = null;
			try {
				firstDate = format2.parse(dateString+temp);
				if(i==0){
					//������һ�ε��������������в��������Ƿ�����ִ��
					if(ifImmediate){
						firstDate=new Date(firstDate.getTime()+5*60*1000);
					} else{
						firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
					}
				} else {
					//�������ർ����ִ��ʱ���뵱ǰʱ��Ƚϣ����ִ��ʱ���ڵ�ǰʱ��֮ǰ�������ִ�У������ڵ����ʱ��ִ��
					if(firstDate.getTime()>new Date().getTime()){
						firstDate=new Date(firstDate.getTime()+5*60*1000);
					} else {
						firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
					}
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			//����ִ���ࡢִ�в���,i��ʾ����ִ�еĴ���������"10�ŵ�һ�β���������"
			ExportIncTask exportTask = new ExportIncTask(i);
			exportTask.setTargetClass(targetClass);
			if(param!=null&&param.length>1){
				param[param.length-1] = i+1;
			}
			Object[] paramClone = param.clone();
			exportTask.setParam(paramClone);
			exportTask.setMethod(method);
			timer.scheduleAtFixedRate(exportTask, firstDate,delay);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void addEasyfareAllJob(String times,Class<?> targetClass,Method method,Object[] param,long delay,boolean ifImmediate){
		if(StringUtils.isEmpty(times)){
			return;
		}
		//�����Ӧ��ʱ��
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		String dateString = format.format(new Date());
		SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd HH:mm");
		String[] timeList = times.split(",");
		String time = null;
		for(int i = 0;i<timeList.length;i++){
			time = timeList[i];
			String temp = " "+time;
			Date firstDate = null;
			try {
				firstDate = format2.parse(dateString+temp);
				if(ifImmediate){
					firstDate=new Date(firstDate.getTime()+5*60*1000);
				} else{
					firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			//����ִ���ࡢִ�в���
			ExportEasyfareAllTask exportTask = new ExportEasyfareAllTask();
			exportTask.setTargetClass(targetClass);
			if(param!=null&&param.length>1){
				param[param.length-1] = i+1;
			}
			Object[] paramClone = param.clone();
			exportTask.setParam(paramClone);
			exportTask.setMethod(method);
			timer.scheduleAtFixedRate(exportTask, firstDate,delay);
		}
	}
	
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static void addEasyfareIncJob(String times,Class<?> targetClass,Method method,Object[] param,long delay,boolean ifImmediate){
    	if(StringUtils.isEmpty(times)){
    		return;
    	}
    	//�����Ӧ��ʱ��
    	SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    	String dateString = format.format(new Date());
    	SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd HH:mm");
    	String[] timeList = times.split(",");
    	String time = null;
    	for(int i = 0;i<timeList.length;i++){
    		time = timeList[i];
    		String temp = " "+time;
    		Date firstDate = null;
    		try {
    			firstDate = format2.parse(dateString+temp);
    			if(i==0){
    				//������һ�ε��������������в��������Ƿ�����ִ��
    				if(ifImmediate){
        				firstDate=new Date(firstDate.getTime()+5*60*1000);
        			} else{
        				firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
        			}
    			} else {
    				//�������ർ����ִ��ʱ���뵱ǰʱ��Ƚϣ����ִ��ʱ���ڵ�ǰʱ��֮ǰ�������ִ�У������ڵ����ʱ��ִ��
    				if(firstDate.getTime()>new Date().getTime()){
    					firstDate=new Date(firstDate.getTime()+5*60*1000);
    				} else {
    					firstDate=new Date(firstDate.getTime()+24*3600*1000+5*60*1000);
    				}
    			}
			} catch (ParseException e) {
				e.printStackTrace();
			}
            //����ִ���ࡢִ�в���,i��ʾ����ִ�еĴ���������"10�ŵ�һ�β���������"
			ExportIncTask exportTask = new ExportIncTask(i);
	    	exportTask.setTargetClass(targetClass);
	    	if(param!=null&&param.length>1){
	    	    param[param.length-1] = i+1;
	    	}
	    	Object[] paramClone = param.clone();
	    	exportTask.setParam(paramClone);
	    	exportTask.setMethod(method);
	    	timer.scheduleAtFixedRate(exportTask, firstDate,delay);
    	}
    }
    
    public static class ExportIncTask<T> extends TimerTask {
        private Class<T> targetClass;
        private Method method;
        private Object[] param;
        private int time=-1;
        
    	public ExportIncTask(int time) {
    		this.time=time;
    	}

    	public Method getMethod() {
    		return method;
    	}

    	public void setMethod(Method method) {
    		this.method = method;
    	}

    	public Object[] getParam() {
    		return param;
    	}
    	public void setParam(Object[] param) {
    		this.param = param;
    	}

    	public Class<T> getTargetClass() {
    		return targetClass;
    	}
    	public void setTargetClass(Class<T> targetClass) {
    		this.targetClass = targetClass;
    	}

    	@Override
    	public void run() {
    		try {//!10hao || ! time==0
    			String exportDate=PropertiesUtil.getTimerAllProperty("EXPORT_DATE");
    			int exportDateInt=-1;
    			if(exportDate!=null){
    				exportDateInt=Integer.parseInt(exportDate);
    			}
    			if(exportDateInt!=new GregorianCalendar().get(Calendar.DAY_OF_MONTH)
    					|| time!=0){
    				T obj = targetClass.newInstance();
        		    method.invoke(obj, param);
    			}
    			
    		} catch (InstantiationException e) {
    			e.printStackTrace();
    		} catch (IllegalAccessException e) {
    			e.printStackTrace();
    		} catch (IllegalArgumentException e) {
    			e.printStackTrace();
    		} catch (InvocationTargetException e) {
    			e.printStackTrace();
    		}
    	}
    }
    
    public static class ExportAirtisAllTask<T> extends TimerTask {
        private Class<T> targetClass;
        private Method method;
        private Object[] param;
        
    	public ExportAirtisAllTask() {
    	}

    	public Method getMethod() {
    		return method;
    	}

    	public void setMethod(Method method) {
    		this.method = method;
    	}

    	public Object[] getParam() {
    		return param;
    	}
    	public void setParam(Object[] param) {
    		this.param = param;
    	}

    	public Class<T> getTargetClass() {
    		return targetClass;
    	}
    	public void setTargetClass(Class<T> targetClass) {
    		this.targetClass = targetClass;
    	}

    	@Override
    	public void run() {
    		try {
    			T obj = targetClass.newInstance();
    		    method.invoke(obj, param);
    		} catch (InstantiationException e) {
    			e.printStackTrace();
    		} catch (IllegalAccessException e) {
    			e.printStackTrace();
    		} catch (IllegalArgumentException e) {
    			e.printStackTrace();
    		} catch (InvocationTargetException e) {
    			e.printStackTrace();
    		}
    	}
    }
    
    public static class ExportEasyfareAllTask<T> extends TimerTask {
        private Class<T> targetClass;
        private Method method;
        private Object[] param;
        
    	public ExportEasyfareAllTask() {
    	}

    	public Method getMethod() {
    		return method;
    	}

    	public void setMethod(Method method) {
    		this.method = method;
    	}

    	public Object[] getParam() {
    		return param;
    	}
    	public void setParam(Object[] param) {
    		this.param = param;
    	}

    	public Class<T> getTargetClass() {
    		return targetClass;
    	}
    	public void setTargetClass(Class<T> targetClass) {
    		this.targetClass = targetClass;
    	}

    	@Override
    	public void run() {
    		try {
    			String exportDate=PropertiesUtil.getTimerAllProperty("EXPORT_DATE");
    			int exportDateInt=-1;
    			if(exportDate!=null){
    				exportDateInt=Integer.parseInt(exportDate);
    			}
    			if(exportDateInt==-1 ||
    					exportDateInt==new GregorianCalendar().get(Calendar.DAY_OF_MONTH)){
	    			T obj = targetClass.newInstance();
	    		    method.invoke(obj, param);
    			}
    		} catch (InstantiationException e) {
    			e.printStackTrace();
    		} catch (IllegalAccessException e) {
    			e.printStackTrace();
    		} catch (IllegalArgumentException e) {
    			e.printStackTrace();
    		} catch (InvocationTargetException e) {
    			e.printStackTrace();
    		}
    	}
    }
}
