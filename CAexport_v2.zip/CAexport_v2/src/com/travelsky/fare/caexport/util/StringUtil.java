package com.travelsky.fare.caexport.util;

import java.util.ArrayList;
import java.util.List;

public class StringUtil {

	public static boolean isNullOrEmptyOrEqualsTargetStr(String src,String target) {
		return src==null || src.equals("") || src.trim().length()==0 || src.trim().equals(target.trim());
	}

	public static boolean isNullOrEmpty(String str) {
		return str==null || str.trim().length()==0 || str.equals("");
	}
	
	/**
	 * ���������ַ���
	 * @param s
	 * @param t
	 * @return
	 */
	public static String combineString(String s, String t){
		StringBuffer sb = new StringBuffer();
		sb.append(s);
		sb.append(t);
		return sb.toString();
	}
	
	/**
	 * �����ո�
	 * @param s
	 * @param t
	 * @return
	 */
	public static String toDBString(String s, int t){
		if (s == null) {
			return null;
		}
		int m = s.getBytes().length;
		for (int i = 0; i < t-m; i++){
			s = combineString(s, " ");
		}
		return s;
	}
	
	/**
	 * �����ַ���
	 * @param s
	 * @return
	 */
	public static String getValue(String s) {
		if (s == null) {
			return null;
		} else {
			return s.trim();
		}
	}
	
	public static String getValue(String val, String defaultval) {
		if( val==null ) return defaultval;
		else 
			return val.trim();
	}
	
	
	public static void main(String args[]){
		String a = StringUtil.toDBString("pub", 5);
		System.out.println(a.length());
		System.out.println(("aa  ".trim()).equals("aa"));
		
		List<String> desc = new ArrayList<String>();
		desc.add("BUDEQIANZHUAN����ǩתBUDEGENGGAI���ø���RMYX");
		desc.add(null);
		desc.add("16255562");
		System.out.println( listToString(desc) );
	}
	
	/**
	 * ��String���͵�listƴ��Ϊһ��String�ַ���
	 * @param restrictionDesc
	 * @return
	 */
	public static String listToString(List<String> list) {
		if( list==null || list.size()==0 ) return null;
		
		String retstr = null;
		for (int i = 0; i < list.size(); i++) {
			if(!StringUtil.isNullOrEmptyOrEqualsTargetStr(list.get(i), "null")){
				if(i==0) retstr = "";
				retstr += list.get(i);
				if((i+1)<list.size()){
					retstr += ",";
				}
			}
		}
		return retstr;
	}


}
