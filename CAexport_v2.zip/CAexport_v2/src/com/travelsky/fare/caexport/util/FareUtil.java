package com.travelsky.fare.caexport.util;

import java.math.BigDecimal;

import com.travelsky.fare.caexport.db.model.airtis_fare.NewFare;

public class FareUtil {
	
	public static BigDecimal getDiscPer(NewFare nfare) {
		String flag = nfare.getFlag();
		if (flag.equals("1")) {
			return null;
		}
		if (flag.equals("0")) {
			return new BigDecimal(nfare.getDiscPer());
		}
		return new BigDecimal(nfare.getDiscPer());
	}
	
	/**
	 * ��ȡ���۵���������
	 * @param nfare
	 * @return
	 */
	public static String getJourneyType(NewFare nfare) {
		String travelType = nfare.getTravelType();
		if ( StringUtil.isNullOrEmpty(travelType) ) {
			return null;
		}
		if (travelType.trim().equals("0")) {
			return "OR";
		} else if (travelType.trim().equals("1")){
			return "OW";
		} else if (travelType.trim().equals("2")){
			return "RT";
		}
		return null;
	}
	
	/**
	 * ��ȡ���۵ĳ���Ʊ��
	 * @param nfare
	 * @return
	 */
	public static BigDecimal getAmount(NewFare nfare) {
		String flag = nfare.getFlag();
		if( StringUtil.isNullOrEmpty(flag) ) {
			return null;
		}
		if (flag.trim().equals("1")) {
			return new BigDecimal(nfare.getFlag());
		} else if (flag.trim().equals("0")) {
			return new BigDecimal(-2);
		}
		return null;
	}
	
	/**
	 * ��ȡ���۵Ĺ�����
	 * @param nfare
	 * @return
	 */
	public static String getRuleId(NewFare nfare) {
		String ruleId = nfare.getRuleId();
		if (ruleId == null || ruleId.trim().equals("")) {
			return null;
		}
		if (ruleId.trim().equals("////")) {
			return null;
		} else {
			return ruleId;
		}
	}
	
}
