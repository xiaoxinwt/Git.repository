package com.travelsky.fare.caexport.util;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.sun.org.apache.xerces.internal.impl.dv.util.HexBin;
import com.travelsky.fare.caexport.util.entry.DBColumn;

public class ResultsetUtil {
	
	public static Map<String ,DBColumn> getMataMap(ResultSet rs){
		
		Map<String ,DBColumn> metamap = new HashMap<String, DBColumn>();
		try {
			ResultSetMetaData meta = rs.getMetaData();
			String colname = "";
			DBColumn column = null;
			for (int i = 1; i <= meta.getColumnCount(); i++) {
				colname = meta.getColumnName(i);
				
				column = new DBColumn();
				column.setColid( i );
				column.isNullable(true);
				
				column.setCatalogName( meta.getCatalogName(i) );
				column.setCollabel( meta.getColumnLabel(i) );
				column.setColname( meta.getColumnName(i) );
				column.setColscale( meta.getScale(i) );
				column.setColtype( meta.getColumnType(i) );
				column.setDatalength( meta.getColumnDisplaySize(i) );
				column.setOwner( meta.getSchemaName(i) );
				column.setPrecision( meta.getPrecision(i) );
				column.setSchemaName( meta.getSchemaName(i) );
				column.setTableName( meta.getTableName(i) );
				column.setTypeName( meta.getColumnTypeName(i) );
				
				fixTypeCodeOfNumber( column );
//				System.out.println( column.getColtype()+"\t" + column.getTypeName() +"\t" +column.getClassName() );
				metamap.put(colname.toUpperCase() , column);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
//		for (String colname : metamap.keySet()) {
//			System.out.println( colname );
//			DBColumn col = metamap.get(colname);
//			System.out.println( col.getColid()+"\t"+col.getColname() );
//		}

		return metamap;
	}
	
	//�ȴ�type�õ�ԭʼjavaclassname,��ͨ��col�õ��������javaclassname��typecode,���javaclassname,typecode���¸���col
	//������������ӳ�������java����
	public static Integer fixTypeCodeOfNumber(DBColumn col){
		
		if(col==null || col.getColtype()==null ) return null;
		
		int typecode = col.getColtype();
		String className = JDBCUtils.getJavaTypeByTypeCode( typecode ).getName();
		col.setClassName( className );
		
		if( !className.equals(BigDecimal.class.getName())) return typecode;
		
		int scale = col.getColscale();
		int preci = col.getPrecision();
		scale = scale<0?0:scale;
		if(scale==0){	//С��λ��
			if(preci<10){	//��λ��
				typecode = Types.INTEGER;
			}else{
				typecode = Types.BIGINT;
			}
		}else{
			if(scale<=2){
				typecode = Types.DOUBLE;
			}else{
				typecode = Types.DECIMAL;
			}
		}
		col.setColtype( typecode );
		col.setTypeName( JDBCUtils.getTypeNameByTypeCode(typecode) );
		col.setClassName( JDBCUtils.getJavaTypeByTypeCode( typecode ).getName() );
		
		return typecode;
	}
	
	/**
	 * 处理 Query 操作的数�?
	 * @param queryresult
	 * @throws SQLException 
	 */
	public static List< Map<String ,Object >> dealQueryResult(ResultSet rs) throws SQLException {
		
		Map<String ,DBColumn> metamap = getMataMap(rs);
		List< Map<String ,Object >> retlist = new ArrayList<Map<String,Object>>();
		while( rs.next() ){
			retlist.add( parseToMapByTypeCode( rs , metamap ) );
		}
		return retlist;
	}
	
	/**
	 * ���е�ת����Ҫ����DBColumn�е�colType���ͽ���ת������Ҫ����Ҳ��Ҫ������Ӧ��colType,������ֱ���޸���ӳ�����java����
	 * @param rs
	 * @param metamap
	 * @return
	 * @throws SQLException
	 */
	public static Map<String, Object> parseToMapByTypeCode(ResultSet rs,Map<String ,DBColumn> metamap) throws SQLException{
		Map<String, Object> resultmap = new HashMap<String,Object>();

		Integer typeCode = -1;
		DBColumn col = null;
		for (String colname : metamap.keySet()){
			col = metamap.get( colname );
			typeCode = col.getColtype();
			
			if (typeCode == Types.VARCHAR || typeCode == Types.CHAR || typeCode == Types.NVARCHAR || typeCode == Types.NCHAR) {
				resultmap.put(colname, rs.getString(colname) );
			} else if (typeCode == Types.DATE) {
			    resultmap.put(colname, rs.getDate(colname) );
			} else if (typeCode == Types.BIT || typeCode == Types.BOOLEAN) {
				resultmap.put(colname, rs.getBoolean(colname) );
			} else if (typeCode == Types.TINYINT) {
			    resultmap.put(colname, rs.getByte(colname) );
			} else if (typeCode == Types.SMALLINT) {  
				resultmap.put(colname, rs.getShort(colname) );
			} else if (typeCode == Types.INTEGER) {
				resultmap.put(colname, rs.getInt(colname) );
			} else if (typeCode == Types.BIGINT) {  
				resultmap.put(colname, rs.getLong(colname) );
			} else if (typeCode == Types.NUMERIC){
				resultmap.put(colname, rs.getBigDecimal(colname) );
			} else if (typeCode == Types.DOUBLE){
				resultmap.put(colname, rs.getDouble(colname) );
			} else if (typeCode == Types.DECIMAL){
				resultmap.put(colname, rs.getBigDecimal(colname) );				
			} else if (typeCode == Types.FLOAT){
				resultmap.put(colname, rs.getFloat(colname) );
			} else if (typeCode == Types.BINARY){
				resultmap.put(colname, rs.getBinaryStream(colname) );
			} else if (typeCode == Types.ARRAY){
				resultmap.put(colname, rs.getArray(colname) );
			} else if (typeCode == Types.TIMESTAMP) {  
			    resultmap.put(colname, rs.getTimestamp(colname) );  
			} else if (typeCode == Types.CLOB) {  
				resultmap.put(colname, rs.getClob(colname) );
			} else if (typeCode == Types.JAVA_OBJECT) {
				resultmap.put(colname , rs.getObject(colname) );
			} else if (typeCode == Types.LONGVARCHAR) {  
				resultmap.put(colname , rs.getString(colname) );
			} else if (typeCode == Types.NULL) {  
			    resultmap.put(colname , null);
			} else {
				Object obj = rs.getObject(colname);
				if( obj instanceof byte[] ){
					resultmap.put(colname, (byte[])obj );
					HexBin.encode( (byte[])obj );
				}else{
					resultmap.put(colname, obj);
				}
			}
		}
		return resultmap;
	}
	
}
