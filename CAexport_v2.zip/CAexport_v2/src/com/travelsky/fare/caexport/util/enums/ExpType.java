package com.travelsky.fare.caexport.util.enums;

public enum ExpType {
	All("All"),Inc("Inc");
	
	public String val;
	ExpType(String val){
		this.val = val;
	}
}
