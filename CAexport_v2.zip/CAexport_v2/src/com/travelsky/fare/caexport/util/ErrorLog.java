package com.travelsky.fare.caexport.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ErrorLog {
	
	private static Log log = LogFactory.getLog("Exception_Msg:");
	public static void log(Exception e){
		log.info( e );
		e.printStackTrace();
	}

}
