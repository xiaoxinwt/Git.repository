package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.zip.CRC32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ZipUtil {
	
	private static Log log = LogFactory.getLog(ZipUtil.class);
	
	//private String fileName = null;
	//private String zipFilePath = null;
	//private String unZipFilePath = null;
	private BufferedReader in = null;
	private FileOutputStream fos = null;
	private ZipOutputStream zos = null;
	private CheckedOutputStream ch = null;
	
	public void open(String fileName, String zipFilePath) throws IOException{
		File zipFile = new File(zipFilePath);
		if(zipFile.getParentFile()!=null)
			zipFile.getParentFile().mkdirs();
		
		fos = new FileOutputStream(zipFilePath);
		ch = new CheckedOutputStream(fos, new CRC32());
		zos = new ZipOutputStream(new BufferedOutputStream(ch));
		zos.putNextEntry(new ZipEntry(fileName));
		zos.setLevel(9);
	}
	public void open(String fileName, String path, String zipFileName) throws IOException{
		File zipFile = new File(path+File.separator+zipFileName);
		fos = new FileOutputStream(zipFile);
		ch = new CheckedOutputStream(fos, new CRC32());
		zos = new ZipOutputStream(new BufferedOutputStream(ch));
		zos.putNextEntry(new ZipEntry(fileName));
		zos.setLevel(9);
	}
	public void write(String str){
		try {
			zos.write(str.getBytes("utf-8"));
			zos.flush();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void close(){
        try {
        	if(zos!=null) zos.close();
			if(in!=null) in.close();
			if(fos!=null) fos.close();
			if(ch!=null) ch.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void writeZipFile(String zipPath, String filepath, String entrypath) {
		try {
			File file = new File(filepath);
			File zipFile = new File(zipPath);
			zipFile.getParentFile().mkdirs();

			in = new BufferedReader(new InputStreamReader(new FileInputStream(file),"utf-8"));
	        fos = new FileOutputStream(zipFile);
	        ch = new CheckedOutputStream(fos, new CRC32());
	        zos = new ZipOutputStream(new BufferedOutputStream(ch));
	        zos.putNextEntry(new ZipEntry(entrypath));
	        zos.setLevel(9);
	        String c;
	        while ((c = in.readLine()) != null){
	        	zos.write(c.getBytes("utf-8"));
	        	zos.flush();
	        }
		} catch (Exception e) {
			log.error("Zipped file failure!" + e.getMessage() + e.fillInStackTrace().toString() );
		} finally{
			close();
		}		
	}
		
	public static boolean writeZipFile(String zippath,File[] files) {
		try {
			File zipfile = new File(zippath);
			if(zipfile.exists()) zipfile.delete();
			zipfile.createNewFile();
			if( files==null || files.length==0 ) return false;
			
			FileOutputStream fos = new FileOutputStream( zipfile );
			CheckedOutputStream ch = new CheckedOutputStream(fos, new CRC32());
			ZipOutputStream zos = new ZipOutputStream(ch);
//			zos.setLevel(9);
			zos.setLevel(5);
			
			final int BUFFER = 1024;
			BufferedInputStream bis = null;
			for (File file : files) {
				bis = new BufferedInputStream( new FileInputStream(file));  
			    zos.putNextEntry( new ZipEntry(file.getName()) );  
			    byte data[] = new byte[BUFFER];
			    int count = -1;
			    while ((count = bis.read(data, 0, BUFFER)) != -1) {  
			        zos.write(data, 0, count);  
			    }  
			    bis.close();  
			}
			zos.close();
			fos.close();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static void main(String[] args) throws IOException {
		ZipUtil ziputil = new ZipUtil();
		ziputil.writeZipFile("D:\\xml\\fare.xml", "fare.xml", "E:\\xml\\xml.zip");
	}

}
