package com.travelsky.fare.caexport.util;

public class PageUtil {

	public static int getPageCount(long total, int pageSize) {
		return (int) ((total+pageSize-1)/pageSize);
	}

}
