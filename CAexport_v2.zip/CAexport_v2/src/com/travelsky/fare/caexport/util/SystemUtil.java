package com.travelsky.fare.caexport.util;

public class SystemUtil {

	public static double getDiffTimes(long starttime, long endtime) {
		return (endtime-starttime)/1000.0;
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		long start = System.currentTimeMillis();
		Thread.sleep(6328);
		long end = System.currentTimeMillis();
		System.out.println( getDiffTimes(start,end)+" s" );
		
		
	}
}
