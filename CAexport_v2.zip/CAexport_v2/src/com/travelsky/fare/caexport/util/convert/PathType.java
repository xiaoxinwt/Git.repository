package com.travelsky.fare.caexport.util.convert;


public enum PathType{
	Xml,Zip,Info,Dir
}
