package com.travelsky.fare.caexport.util;

import java.util.ArrayList;
import java.util.List;

public class ListUtil {

	public static <E> List<E> concat(List<E> first,List<E> second) {
		List<E> retlist = new ArrayList<E>(first);
		retlist.addAll( second );
		return retlist;
	}
	
	public static <E> List<E> append(List<E> first,List<E> second) {
		first.addAll(second);
		return first;
	}
	
	public static <E> List<E> appendTo(List<E> first,List<E> second){
		second.addAll(first);
		return second;
	}

}
