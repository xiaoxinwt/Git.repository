package com.travelsky.fare.caexport.util.enums;

public enum CAType {
	Airtis("Airtis"),Easyfare("Easyfare");
	
	public String val;
	CAType(String val){
		this.val = val;
	}
}
