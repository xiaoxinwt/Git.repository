package com.travelsky.fare.caexport.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import com.travelsky.fare.caexport.db.model.po.ExportInfo;

public class WriterUtil {
	
	public static void writeInfo(String fileName,ExportInfo exportInfo){
    	File file = new File(fileName); 
    	BufferedWriter out = null;  
    	try {
			 out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file,true)));
			 out.write(exportInfo.toString());
		} catch (Exception e) {
			ErrorLog.log( e );
		} finally {
			IOUtil.close( out );
		}
    }

    
    public static void writeInfo(String path,String fileName,String exportInfo){
    	File file = new File(path+File.separator+fileName); 
    	BufferedWriter out = null;
    	try {
    		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
    		out.write(exportInfo);
    		out.close();
		} catch (Exception e) {
			ErrorLog.log( e );
		} finally{
			IOUtil.close( out );
		}
    }
}
