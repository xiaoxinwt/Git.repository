package com.travelsky.fare.caexport.util;

import com.travelsky.fare.caexport.dexp.vo.importor.IImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.AirtisFareImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.EasyfareFareImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.FBRImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.RefundImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.ReissueImportor;
import com.travelsky.fare.caexport.dexp.vo.importor.impl.RuleImportor;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;

public class ImportUtil {

	public static IImportor<?,?> getImportor(CAType type, CAModule module) {
		IImportor<?,?> importor = null;
		
		if( module.equals(CAModule.Fare) ){
			if( type.equals(CAType.Airtis) ){
				importor = new AirtisFareImportor();
			}else if( type.equals(CAType.Easyfare) ){
				importor = new EasyfareFareImportor();
			}
		}else if( module.equals( CAModule.FBR )){
			importor = new FBRImportor();
		}else if( module.equals( CAModule.Refund )){
			importor = new RefundImportor();
		}else if( module.equals( CAModule.Reissue )){
			importor = new ReissueImportor();
		}else if( module.equals( CAModule.Rule )){
			importor = new RuleImportor();
		}
		
		return importor;
	}

}
