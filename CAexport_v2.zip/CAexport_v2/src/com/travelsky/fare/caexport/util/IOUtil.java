package com.travelsky.fare.caexport.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class IOUtil {

	public static void close(InputStream is){
		try {
			if( is!=null ){
				is.close();
			}
		} catch (IOException e) {
			ErrorLog.log( e );
		}
	}
	
	public static void close(OutputStream os){
		try {
			if( os!=null ){
				os.close();
			}
		} catch (IOException e) {
			ErrorLog.log( e );
		}
	}

	public static void close(BufferedWriter write) {
		try {
			if( write!=null ){
				write.close();
			}
		} catch (IOException e) {
			ErrorLog.log(e);
		}
	}
}
