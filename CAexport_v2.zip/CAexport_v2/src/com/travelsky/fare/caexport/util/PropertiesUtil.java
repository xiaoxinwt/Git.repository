package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.util.enums.PropertiesType;

public class PropertiesUtil {
    private static Properties timerIncProperties = new Properties();
    private static Properties timerAllProperties = new Properties();
    private static Properties sysProperties = null;
    
    private static Map<PropertiesType,Properties> propermap = new HashMap<PropertiesType,Properties>();

    static{
    	loadProperties();
    	sysProperties = getProperties(PropertiesType.SYS);
    	timerIncProperties = getProperties(PropertiesType.INCTIMER);
    	timerAllProperties = getProperties(PropertiesType.ALLTIMER);
    }
    
    public static void loadProperties(){
		Properties p;
		String propath = "";
		InputStream in = null;
		File profile = null;
		for (PropertiesType ptype : PropertiesType.values()) {
			if( !propermap.containsKey(ptype) || propermap.get(ptype)==null ){
				p = new Properties();
				try {
					propath = System.getProperty("user.dir")+ptype.val;
					profile = new File(propath);
					if(profile.exists()){
//						System.out.println( ptype+" Path1:"+ propath);
						in = new BufferedInputStream(new FileInputStream(propath));
					}else{
//						System.out.println( ptype+" Path2:"+PropertiesUtil.class.getResource( ptype.val ));
						in = PropertiesUtil.class.getResourceAsStream( ptype.val );
					}
					p.load( in );
//					System.out.println( ptype.val+"���سɹ�...");
				} catch (Exception e) {
//					System.out.println( ptype.val+"����ʧ��...");
					e.printStackTrace();
				}finally{
					IOUtil.close(in);
				}
				propermap.put(ptype, p);
			}
		}
    }
    
    public static Properties getProperties(PropertiesType properType){
    	if(properType==null) return null;
    	if(propermap==null || !propermap.containsKey(properType)){
    		loadProperties();
    	}
    	return propermap.get(properType);
    }
    
    public static void storeSysProperties(String fileName){
    	try {
			OutputStream os = new FileOutputStream(fileName);
			sysProperties.store(os, "refreash start time");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public static PairDays abtainIncPairDays(String key,int index){
        // ��������Ŀ�ʼ�ͽ���ʱ��
		String startTime = PropertiesUtil.getSysProperty(key);
		SimpleDateFormat dateFormat=new  SimpleDateFormat("yyyyMMdd HH:mm:ss");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyyMMdd");
		Date begin = null; 
		Date end = null;
		try {
			begin = dateFormat.parse(startTime);
			String endString = dateFormat2.format(new Date());
			endString +=" " +PropertiesUtil.getTimerIncProperty(key).split(",")[index]+":00";
			end = dateFormat.parse(endString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		PairDays days = new PairDays(begin,end);
		return days;
    }
    
    public static String getTimerIncProperty(String key){
    	return  timerIncProperties.getProperty(key);
    }
    
    public static String getTimerAllProperty(String key){
    	return  timerAllProperties.getProperty(key);
    }
    
    public static String getSysProperty(String key){
    	return  sysProperties.getProperty(key);
    }
    
    public static void putSysProperties(String key,String value){
    	sysProperties.put(key, value);
    }
    
}
