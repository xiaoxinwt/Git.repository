package com.travelsky.fare.caexport.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class FileNameGenerator {
	
	//D:\\hx\\CAexport\\%type%\\%carrcode%
	public static String genertExportDir(String carrier,CAType catype){
		String expDirPath = FileUtil.getDirPath( PropertiesUtil.getSysProperty(Const.EXP_PATH) );
		expDirPath = expDirPath.replaceFirst("%carrcode%", carrier);
		expDirPath = expDirPath.replaceFirst("%type%", catype.val);
		expDirPath = FileUtil.getDirPath(expDirPath);
		File dir = new File(expDirPath);
		if(!dir.exists()) dir.mkdirs();
		return expDirPath;
	}
	
	//�õ�����·����/home/test/bak/CA/20151224/EASYFARE/
	public static String genertBakPath(String carrier,CAType catype){
		String backDirPath = FileUtil.getDirPath( PropertiesUtil.getSysProperty(Const.BAK) );
		backDirPath = backDirPath.replaceFirst("%carrcode%", carrier);
		backDirPath = backDirPath.replaceFirst("%type%", catype.val);
		backDirPath = FileUtil.getDirPath(backDirPath);
		File dir = new File(backDirPath);
		if( !dir.exists() ) dir.mkdirs();
		return backDirPath;
	}
	
	public static String genertXmlPath(String carrier,CAType catype,CAModule camodule,ExpType exptype,Date expdate){
		return genertXmlPath(carrier, catype, camodule, exptype, expdate,null);
	}
	public static String genertXmlPath(String carrier,CAType catype,CAModule camodule,ExpType exptype,Date expdate,Integer idx){
		String expDirPath = genertExportDir(carrier,catype);
		
		//�õ�CA_EASYFARE_FARE.xml
		String xmlName = carrier+"_"+catype+"_"+camodule;
		
		//�õ� CA_EASYFARE_FARE_All.xml
		if( ExpType.All.equals( exptype ) ){
			xmlName += "_"+ExpType.All.val;
		}
		
		//�õ� CA_EASYFARE_FARE_01.xml
		//�õ� CA_EASYFARE_FARE_All_01.xml
		if( expdate!=null ){
			xmlName += "_"+dateToString( expdate );
		}

		if( idx!=null ){
			xmlName += "_"+(idx<10?"0"+idx:idx);
		}
		xmlName += ".xml";
		return expDirPath + xmlName;
	}
	
	public static String genertZipPath(String carrier, CAType catype, ExpType exptype){
		String expDirPath = genertExportDir(carrier,catype );
		//�õ�CA_EASYFARE_20151224.zip
		String zipName = carrier+"_"+catype;
		if(exptype==ExpType.All){
			zipName+="_All";
		}
		zipName+="_"+dateToString( new Date() );
		zipName+=".zip";
		return expDirPath + zipName;
	}
	
	public static String genertInfoPath(String carrier,CAType catype){
		String expDirPath = genertExportDir(carrier,catype);
		//�õ�D:\hx\CAexport\20151224\CA\CA_EASYFARE.info
		String infoName = carrier+"_"+catype+".info";
		return expDirPath + infoName;
	}
	
	
	public static void main(String[] args) {
		String carrier = "CA";

		Date expdate = new Date();
		CAType catype = CAType.Airtis;
		CAModule camodule = CAModule.Refund;
		
		String xmlpath = genertXmlPath(carrier, catype, camodule, ExpType.All, expdate);
		System.out.println( xmlpath );
		String zippath = genertZipPath(carrier, catype, ExpType.All);
		System.out.println( zippath );
		String backpath = genertBakPath(carrier, catype);
		System.out.println( backpath );
		String dirpath = genertExportDir(carrier, catype);
		System.out.println( dirpath );
		String infopath = genertInfoPath(carrier, catype);
		System.out.println( infopath );
	}
    
	

    private static String dateToString(Date date){
    	return new SimpleDateFormat(Const.DATE_FORMAT_TITLE).format( date==null?new Date():date );
    }
    
}
