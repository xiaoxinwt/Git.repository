package com.travelsky.fare.caexport.util;

import com.travelsky.fare.caexport.db.dao.ICommonDao;
import com.travelsky.fare.caexport.db.dao.IFareDao;
import com.travelsky.fare.caexport.db.dao.airtis.impl.AirFBRDetailDaoImpl;
import com.travelsky.fare.caexport.db.dao.airtis.impl.AirGroupDaoImpl;
import com.travelsky.fare.caexport.db.dao.airtis.impl.AirRefundDaoImpl;
import com.travelsky.fare.caexport.db.dao.airtis.impl.AirReissueDaoImpl;
import com.travelsky.fare.caexport.db.dao.airtis.impl.AirRuleDaoImpl;
import com.travelsky.fare.caexport.db.dao.common.impl.FBRDaoImpl;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.EasyGroupDaoImpl;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.EasyRefundDaoImpl;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.EasyReissueDaoImpl;
import com.travelsky.fare.caexport.db.dao.easyfare.impl.EasyRuleDaoImpl;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;

public class DaoUtil {
	
	public static IFareDao<?> getFareDao(CAType type, CAModule module){
		IFareDao<?> dao = null;
		if( type.equals( CAType.Airtis )){
			if( module.equals( CAModule.FBR )){
				dao = new AirFBRDetailDaoImpl();
			}
		}else if( type.equals( CAType.Easyfare )){
			if( module.equals( CAModule.FBR )){
				dao = new FBRDaoImpl();
			}			
		}
		return dao;
	}

	public static ICommonDao<?> getDaoImpl(CAType type, CAModule module) {
		ICommonDao<?> dao = null;
		if( type.equals( CAType.Airtis )){
			if( module.equals( CAModule.Group )){
				dao = new AirGroupDaoImpl();
			}else if( module.equals( CAModule.Refund )){
				dao = new AirRefundDaoImpl();
			}else if( module.equals( CAModule.Reissue )){
				dao = new AirReissueDaoImpl();
			}else if( module.equals( CAModule.Rule )){
				dao = new AirRuleDaoImpl();
			}
		}else if( type.equals( CAType.Easyfare )){
			if( module.equals( CAModule.Group )){
				dao = new EasyGroupDaoImpl();
			}else if( module.equals( CAModule.Refund )){
				dao = new EasyRefundDaoImpl();
			}else if( module.equals( CAModule.Reissue )){
				dao = new EasyReissueDaoImpl();
			}else if( module.equals( CAModule.Rule )){
				dao = new EasyRuleDaoImpl();
			}
		}
		return dao;
	}
	
	

}
