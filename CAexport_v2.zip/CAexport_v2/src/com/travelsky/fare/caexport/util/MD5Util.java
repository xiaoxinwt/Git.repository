/**============================================================
 * ��Ȩ�� Travelsky ��Ȩ���� (c) 2008 - 2009
 * �ļ��� util.MD5Util
 * ������: MD5Util
 * �޸ļ�¼��
 * ����                		����                		����
 * =============================================================
 * 2010-12-9         liye(liye@travelsky.com)    �����ļ���ʵ�ֻ�������
 * ============================================================*/

package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
	private static char[] hexChar = { '0', '1', '2', '3', '4', '5', '6', '7',
			'8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
	
	private static final String hashType = "MD5";

	public synchronized static String getHash(String fileName){
		try{
			InputStream fis = new BufferedInputStream(new FileInputStream(fileName));
			byte[] buffer = new byte[1024];
			MessageDigest md5 = MessageDigest.getInstance(hashType);
			int numRead = 0;
			while ((numRead = fis.read(buffer)) > 0) {
				md5.update(buffer, 0, numRead);
			}
			fis.close();
			return toHexString(md5.digest()).toUpperCase();
		} catch(IOException ioe){
			System.out.println(ioe.getMessage());
		} catch(NoSuchAlgorithmException nsae){
			System.out.println(nsae.getMessage());
		}
		return null;
	}

	/**
	 * תΪ16����
	 * 
	 * @param b
	 * @return
	 */
	private static String toHexString(byte[] b) {
		StringBuilder sb = new StringBuilder(b.length << 1);
		for (int i = 0; i < b.length; i++) {
			sb.append(hexChar[(b[i] & 0xf0) >>> 4]);
			sb.append(hexChar[b[i] & 0x0f]);
		}
		return sb.toString();
	}
}
