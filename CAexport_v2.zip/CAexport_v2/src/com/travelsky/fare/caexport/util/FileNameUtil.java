package com.travelsky.fare.caexport.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileNameUtil {
	public static String getAllPath(String cat){    	
    	String path = (cat.equals("airtis")==true?PropertiesUtil.getSysProperty("RESULT_AIRTIS"):
    		PropertiesUtil.getSysProperty("RESULT_EASYFARE"))+File.separator+
    		dateToString()+"_all_00_"+cat;
    	return path;
    }
	public static String getAllBakPath(String cat){    	
    	String path = PropertiesUtil.getSysProperty("BAK")+File.separator+dateToString()+"_all_00_"+cat;
    	return path;
    }
	
    public static String getAllName(String cat,String type,int time,boolean isCompressed){    	
    	String path = (cat.equals("airtis")==true?PropertiesUtil.getSysProperty("RESULT_AIRTIS"):
    		PropertiesUtil.getSysProperty("RESULT_EASYFARE"))+File.separator+
    		dateToString()+"_"+"all"+"_"+(time<10?"0"+time:time)+"_"+cat;
    	File file = new File(path);
    	if(!file.exists()){
    		file.mkdir();
    	}
    	String fileName = dateToString()+"_"+"all"+"_"+(time<10?"0"+time:time)+"_"+cat+"_"+type+(isCompressed?".zip":".xml");
    	return path+File.separator+fileName;
    }
    
    public static String getIncPath(String cat,int time){
    	String path =PropertiesUtil.getSysProperty("RESULT_EASYFARE")+File.separator+
    		dateToString()+"_inc_"+(time<9?"0"+(time+1):time+1)+"_"+cat;
    	return path;
    }
    
    public static String getIncBakPath(String cat,int time){
    	String path =PropertiesUtil.getSysProperty("BAK")+File.separator+
    		dateToString()+"_inc_"+(time<9?"0"+(time+1):time+1)+"_"+cat;
    	return path;
    }
    
    public static String getIncName(String cat,String type,int time,boolean isCompressed){
    	String path = (cat.equals("airtis")==true?PropertiesUtil.getSysProperty("RESULT_AIRTIS"):
    		PropertiesUtil.getSysProperty("RESULT_EASYFARE"))+File.separator+
    		dateToString()+"_"+"inc"+"_"+(time<9?"0"+(time+1):time+1)+"_"+cat;
    	File file = new File(path);
    	if(!file.exists()){
    		file.mkdir();
    	}
    	String fileName = dateToString()+"_"+"inc"+"_"+(time<9?"0"+(time+1):(time+1))+"_"+cat+"_"+type+(isCompressed?".zip":".xml");
    	return path+File.separator+fileName;
    }
    
    public static String getInfoName(String cat,boolean isAll,int time){
    	String temp = "";
    	if(isAll){
    		temp = "all";
    	}
    	else{
    		temp = "inc";
    		time = time+1;
    	}
    	String path = (cat.equals("airtis")==true?PropertiesUtil.getSysProperty("RESULT_AIRTIS"):
    		PropertiesUtil.getSysProperty("RESULT_EASYFARE"))+File.separator+
    		dateToString()+"_"+temp+"_"+(time<10?"0"+time:time)+"_"+cat;
    	File file = new File(path);
    	if(!file.exists()){
    		file.mkdir();
    	}
    	String fileName = dateToString()+"_"+temp+"_"+(time<10?"0"+time:time)+"_"+cat+".info";
    	return path+File.separator+fileName;
    }
    
    private static String dateToString(){
    	DateFormat f = new SimpleDateFormat("yyyyMMdd");
    	return f.format(new Date());
    }
}
