package com.travelsky.fare.caexport.util.entry;

public class DBColumn {
	
	private Integer colid;
	private String owner;
	private String catalogName;
	private String className;
	private String collabel;
	private String colname;
	private String typeName;
	private String schemaName;
	private String tableName;
	private Integer datalength;
	private Integer coltype;
	private Integer precision;
	private Integer colscale;
	private Boolean isNullable;
	
	public DBColumn() {}
	
	public Integer getColid() {
		return colid;
	}
	public void setColid(Integer colid) {
		this.colid = colid;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getCatalogName() {
		return catalogName;
	}
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getCollabel() {
		return collabel;
	}
	public void setCollabel(String collabel) {
		this.collabel = collabel;
	}
	public String getColname() {
		return colname;
	}
	public void setColname(String colname) {
		this.colname = colname;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public Integer getDatalength() {
		return datalength;
	}
	public void setDatalength(Integer datalength) {
		this.datalength = datalength;
	}
	public Integer getColtype() {
		return coltype;
	}
	public void setColtype(Integer coltype) {
		this.coltype = coltype;
	}
	public Integer getPrecision() {
		return precision;
	}
	public void setPrecision(Integer precision) {
		this.precision = precision;
	}
	public Integer getColscale() {
		return colscale;
	}
	public void setColscale(Integer colscale) {
		this.colscale = colscale;
	}
	public Boolean isNullable() {
		return isNullable;
	}
	public void isNullable(Boolean isNullable) {
		this.isNullable = isNullable;
	}
}
