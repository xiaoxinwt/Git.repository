package com.travelsky.fare.caexport.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.travelsky.fare.caexport.db.dao.CommonDaoImpl;
import com.travelsky.fare.caexport.db.model.po.ExportInfo;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.db.service.IExport;
import com.travelsky.fare.caexport.db.service.airtis.impl.AirtisFareService;
import com.travelsky.fare.caexport.db.service.common.impl.FBRService;
import com.travelsky.fare.caexport.db.service.common.impl.GroupService;
import com.travelsky.fare.caexport.db.service.common.impl.RefundService;
import com.travelsky.fare.caexport.db.service.common.impl.ReissueService;
import com.travelsky.fare.caexport.db.service.common.impl.RuleService;
import com.travelsky.fare.caexport.db.service.easyfare.impl.EasyfareFareService;
import com.travelsky.fare.caexport.dexp.vo.group.XAgent;
import com.travelsky.fare.caexport.dexp.vo.group.XGroup;
import com.travelsky.fare.caexport.dexp.vo.group.XGroupImport;
import com.travelsky.fare.caexport.util.entry.Export;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class ExportUtil {

	private static Log log = LogFactory.getLog("ExportUtil");
	
	private static IExport<?> ruleExportor = null;
	private static IExport<?> refundExportor = null;
	private static IExport<?> reissueExportor = null;
	private static IExport<?> groupExportor = null;
	private static IExport<?> fareExportor = null;
	private static IExport<?> fbrExportor = null;
	
	private static Export ruleExp = null;
	private static Export refundExp = null;
	private static Export reissueExp = null;
	private static Export groupExp = null;
	private static Export fareExp = null;
	private static Export fbrExp = null;
	
	private static void initExportor(CAType catype){
		ruleExportor = new RuleService(catype);
		refundExportor = new RefundService(catype);
		reissueExportor = new ReissueService(catype);
		groupExportor = new GroupService(catype);
		if( catype==CAType.Airtis ){
			fareExportor = new AirtisFareService();
		}else if( catype==CAType.Easyfare ){
			fareExportor = new EasyfareFareService();
			fbrExportor = new FBRService(catype);
		}
		
		ruleExp = null;
		refundExp = null;
		reissueExp = null;
		groupExp = null;
		fareExp = null;
		fbrExp = null;
	}
	
	@SuppressWarnings("deprecation")
	public static boolean exportAllOfDate(String carrier,Date date,CAType catype){
		
		log.info( "�������ͣ�" + catype.val );

		boolean sign = false;
		initExportor(catype);
		try {
//			log.info( "All Export By Date Begining..." );
//			//����ָ�����ڵ�ȫ��
//			log.info( "Being to export Rule..." );
//			ruleExp = ruleExportor.exportAllOfDate(carrier, date);
//			log.info( "Rule export finished..." );
			
//			log.info( "Being to export Refund..." );
//			refundExp = refundExportor.exportAllOfDate(carrier, date);
//			log.info( "Refund export finished..." );
			
//			log.info( "Being to export Reissue..." );
//			reissueExp = reissueExportor.exportAllOfDate(carrier, date);
//			log.info( "Reissue export finished..." );
			
//			log.info( "Being to export Group..." );
//			groupExp = groupExportor.exportAllOfDate(carrier, date);
//			log.info( "Group export finished..." );
			
//			if(catype==CAType.Airtis){
//				log.info( "Being to export Easyfare_Fare..." );
//				fareExp = fareExportor.exportAllOfDate(carrier, date);
//				log.info( "Easyfare_Fare export finished..." );
//			}else if(catype==CAType.Easyfare){
				log.info( "Being to export FBR..." );
				fbrExp = fbrExportor.exportAllOfDate(carrier, date);
				log.info( "FBR export finished..." );
//			}
			
			ExportUtil.CompressToZip(carrier, catype, ExpType.All);
			sign = true;
		}catch (Exception e) {
			ErrorLog.log( e );
			log.info("����"+date.toLocaleString()+"��ȫ������ʧ��!");
		} finally{
			writeInfo();
			log.info( "All Export By Date ==> "+sign );
		}
		return sign;
	}
	
	@SuppressWarnings("deprecation")
	public static boolean exportIncOfDate(String carrier,Date date,CAType catype){
		
		log.info( "�������ͣ�" + catype.val );
		
		boolean sign = false;
		initExportor(catype);
		try {
			log.info( "Inc Export By Date Begining..." );
			//����ָ�����ڵ�ȫ��
			log.info( "Being to export Rule..." );
			ruleExp = ruleExportor.exportIncOfDate(carrier, date);
			log.info( "Rule export finished..." );
			
			log.info( "Being to export Refund..." );
			refundExp = refundExportor.exportIncOfDate(carrier, date);
			log.info( "Refund export finished..." );
			
			log.info( "Being to export Reissue..." );
			reissueExp = reissueExportor.exportIncOfDate(carrier, date);
			log.info( "Reissue export finished..." );
			
			log.info( "Being to export Group..." );
			groupExp = groupExportor.exportIncOfDate(carrier, date);
			log.info( "Group export finished..." );
			if(catype==CAType.Airtis){
				log.info( "Being to export Easyfare_Fare..." );
				fareExp = fareExportor.exportIncOfDate(carrier, date);
				log.info( "Easyfare_Fare export finished..." );
			}else if(catype==CAType.Easyfare){
				log.info( "Being to export FBR..." );
				fbrExp = fbrExportor.exportIncOfDate(carrier, date);
				log.info( "FBR export finished..." );
			}
			ExportUtil.CompressToZip(carrier, catype, ExpType.Inc);
			sign = true;
		}catch (Exception e) {
			ErrorLog.log( e );
			log.info("����"+date.toLocaleString()+"����������ʧ��!");
		} finally{
			writeInfo();
			log.info( "Inc Export By Date ==> "+sign );
		}
		return sign;
	}
	
	public static boolean exportIncOfDays(String carrier,PairDays days,CAType catype){

		log.info( "�������ͣ�" + catype.val );

		boolean sign = false;
		initExportor(catype);
		try {
			log.info( "Inc Export By Days Begining..." );
			//����ָ�����ڵ�ȫ��
			log.info( "Being to export Rule..." );
			ruleExp = ruleExportor.exportIncOfDays(carrier, days);
			log.info( "Rule export finished..." );
			
			log.info( "Being to export Refund..." );
			refundExp = refundExportor.exportIncOfDays(carrier, days);
			log.info( "Refund export finished..." );
			
			log.info( "Being to export Reissue..." );
			reissueExp = reissueExportor.exportIncOfDays(carrier, days);
			log.info( "Reissue export finished..." );
			
			log.info( "Being to export Group..." );
			groupExp = groupExportor.exportIncOfDays(carrier, days);
			log.info( "Group export finished..." );
			if(catype==CAType.Airtis){
				log.info( "Being to export Easyfare_Fare..." );
				fareExp = fareExportor.exportIncOfDays(carrier, days);
				log.info( "Easyfare_Fare export finished..." );
			}else if(catype==CAType.Easyfare){
				log.info( "Being to export FBR..." );
				fbrExp = fbrExportor.exportIncOfDays(carrier, days);
				log.info( "FBR export finished..." );
			}
			
			ExportUtil.CompressToZip(carrier, catype, ExpType.Inc);
			sign = true;
		}catch (Exception e) {
			ErrorLog.log( e );
			log.info("���ڷ�Χ"+days.toString()+"����������ʧ��!");
		} finally{
			writeInfo();
			log.info( "Inc Export By Days ==> "+sign );
		}
		return sign;
	}
	
	
	
	private static void writeInfo() {
		if( ruleExp!=null ){
			ExportUtil.writeInfo( ruleExp );
		}
		if( refundExp!=null ){
			ExportUtil.writeInfo( refundExp );
		}
		if( reissueExp!=null ){
			ExportUtil.writeInfo( reissueExp );
		}
		if( groupExp!=null ){
			ExportUtil.writeInfo( groupExp );
		}
		if( fareExp!=null ){
			ExportUtil.writeInfo( fareExp );			
		}
		if( fbrExp!=null ){
			ExportUtil.writeInfo( fbrExp );
		}
	}

	//���ɵ�ǰ���ڵ�XML�ļ�������
	public static boolean ExportToXml(String carrier, Object imp, CAType catype, CAModule camodule,ExpType exptype) {
		return ExportToXml(carrier,imp,catype,camodule,exptype,null);
	}
	//����ָ�����ڵ�XML�ļ�������
	public static boolean ExportToXml(String carrier,Object imp,CAType catype, CAModule camodule,ExpType exptype, Date expdate){
		String xmlpath = FileNameGenerator.genertXmlPath(carrier, catype, camodule, exptype, expdate);
		log.info( xmlpath );
		
		File xmlfile = new File(xmlpath);
		if(xmlfile.exists()) xmlfile.delete();
		OutputStream os = null;
		try {
			os = new FileOutputStream(xmlfile);
			JaxbUtil.convertToXml(imp, "UTF-8", os);
			return true;
		} catch (Exception e) {
			ErrorLog.log( e );
			return false;
		} finally{
			IOUtil.close( os );
		}
	}
	
	
	//���ɵ�ǰ����+��ŵ�XML�ļ�������
	public static boolean ExportToXmlForPage(String carrier,Object imp,CAType catype,CAModule camodule,ExpType exptype,int pagenum){
		return ExportToXmlForPage(carrier,imp,catype,camodule,exptype,null,pagenum);
	}
	//����ָ������+��ŵ�XML�ļ�������
	public static boolean ExportToXmlForPage(String carrier,Object imp,CAType catype,CAModule camodule,ExpType exptype,Date expdate,int pagenum){
		String xmlpath = FileNameGenerator.genertXmlPath(carrier, catype, camodule, exptype, expdate, pagenum);
		log.info( xmlpath );
		
		File xmlfile = new File(xmlpath);
		if(xmlfile.exists()) xmlfile.delete();
		OutputStream os = null;
		try {
			os = new FileOutputStream(xmlfile);
			JaxbUtil.convertToXml(imp, "UTF-8", os);
			return true;
		} catch (Exception e) {
			ErrorLog.log( e );
			return false;
		} finally{
			IOUtil.close( os );
		}
	}
	
	public static void CompressToZip(final String carrier,final CAType catype,final ExpType exptype) {
		
		String zipPath = FileNameGenerator.genertZipPath(carrier, catype, exptype);
		
		String xmldir = FileNameGenerator.genertExportDir(carrier,catype);
		File[] files = new File( xmldir ).listFiles( new FilenameFilter(){
			@Override
			public boolean accept(File dir, String name) {
				if( name.startsWith( carrier+"_"+catype.val ) && name.endsWith(".xml")){
					if(exptype==ExpType.All){
						if(name.indexOf(ExpType.All.val)>0) return true;
					}else if(exptype==ExpType.Inc){
						if(name.indexOf(ExpType.All.val)==-1) return true;
					}
				}
				return false;
			}}
		);
		
		if( ZipUtil.writeZipFile(zipPath, files) ){
			log.info( exptype+"Zip:" + zipPath );
			for(File file : files) file.delete();
		}
	}
	
	
	public static void writeInfo(Export exp) {
		log.info("Creating info file");
		
		ExportInfo exportInfo = new ExportInfo();
		exportInfo.setDataType(exp.getModule().val);
		exportInfo.setFlag( exp.getCatype().val );
		exportInfo.setExportType( exp.getExptype() );	//Inc Or All
		exportInfo.setTotal( exp.getExpectTotal() );
		exportInfo.setCount( exp.getCount() );
		exportInfo.setQueryCost( exp.getQueryCost()/1000.00 );
		exportInfo.setToXMLCost( exp.getToxmlCost()/1000.00 );
		
		exportInfo.setStartDate( exp.getStartDate() );
		exportInfo.setEndDate( exp.getEndDate() );
		
		String md5=MD5Util.getHash( exp.getZipPath() );
		exportInfo.setMd5(md5);
		
		WriterUtil.writeInfo( exp.getInfoPath() , exportInfo);
		log.info("Info file has been finished");
	}

	//����
	public static void backup(Export exp) {
//		Tools.copyDirectiory(PropertiesUtil.getSysProperty("RESULT_AIRTIS"), PropertiesUtil.getSysProperty("BAK"));
	}
	
	
	/**
	 * ��ѯ��Ч�ĺ��չ�˾����
	 * @return
	 */
	public static List<String> getCarriers() {
		//Ҫִ�е���������carrier
		List<String> carriers = new ArrayList<String>();
		String carrierstr = (String)PropertiesUtil.getSysProperty( "CARRCODE" );
		if( StringUtil.isNullOrEmpty( carrierstr )){
			carriers = CommonDaoImpl.getAllCarriers();
		}else{
			carriers.addAll( Arrays.asList( carrierstr.split(",")) );
		}
		return carriers;
	}
	
	public static void main(String[] args) {
		
		String carrier = "CA";
		CAType catype = CAType.Airtis;
		CompressToZip(carrier, catype,ExpType.Inc);
	}
	
}
