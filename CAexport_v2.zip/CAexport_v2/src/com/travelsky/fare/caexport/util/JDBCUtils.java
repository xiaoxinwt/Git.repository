package com.travelsky.fare.caexport.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Types;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

public class JDBCUtils {

	private static Map<String, Integer> typeCodeOfNameMap;
	private static Map<Integer, String> typeNameOfCodeMap;
	private static Map<Integer, Class<?>> javaTypeOfTypeCodeMap;
	
	static {
		//Key-name	Value-Code
		typeCodeOfNameMap = new TreeMap<String, Integer>();
		//Key-Code	Value-Name
		typeNameOfCodeMap = new TreeMap<Integer, String>();
		//Key-Code	Value-Java对象
		javaTypeOfTypeCodeMap = new TreeMap<Integer, Class<?>>();
		
		//反射获取java.sql.Types类型中的�?�� 字段 [Fields]信息
		Field[] fields = java.sql.Types.class.getFields();
		for (int i=0, len=fields.length; i<len; ++i) {
			if (Modifier.isStatic(fields[i].getModifiers())) {
				try {
					String typeName = fields[i].getName();
					Integer typeCode = (Integer) fields[i].get(java.sql.Types.class);
					typeCodeOfNameMap.put(typeName, typeCode);	//TypeName:BIT
					typeNameOfCodeMap.put(typeCode, typeName);	//TypeCode:-7
				} catch (IllegalArgumentException e) {
				} catch (IllegalAccessException e) {
				}
			}
		}
		
		// 初始化javaTypeOfTypeCodeMap�?
		javaTypeOfTypeCodeMap.put(Types.LONGNVARCHAR, String.class);// -16 字符�?
		javaTypeOfTypeCodeMap.put(Types.NCHAR, String.class);		// -15 字符�?
		javaTypeOfTypeCodeMap.put(Types.NVARCHAR, String.class);	// -9 字符�?
		javaTypeOfTypeCodeMap.put(Types.ROWID, String.class);		// -8 字符�?
		javaTypeOfTypeCodeMap.put(Types.BIT, Boolean.class);		// -7 布尔
		javaTypeOfTypeCodeMap.put(Types.TINYINT, Byte.class);		// -6 数字
		javaTypeOfTypeCodeMap.put(Types.BIGINT, Long.class);		// -5 数字 
		javaTypeOfTypeCodeMap.put(Types.LONGVARBINARY, Blob.class);	// -4 二进�?
		javaTypeOfTypeCodeMap.put(Types.VARBINARY, Blob.class);		// -3 二进�?
		javaTypeOfTypeCodeMap.put(Types.BINARY, Blob.class);		// -2 二进�?
		javaTypeOfTypeCodeMap.put(Types.LONGVARCHAR, String.class);	// -1 字符�?
		javaTypeOfTypeCodeMap.put(Types.NULL, String.class);		// 0 /
		javaTypeOfTypeCodeMap.put(Types.CHAR, String.class);		// 1 字符�?
		javaTypeOfTypeCodeMap.put(Types.NUMERIC, BigDecimal.class);	// 2 数字
		javaTypeOfTypeCodeMap.put(Types.DECIMAL, BigDecimal.class);	// 3 数字
		javaTypeOfTypeCodeMap.put(Types.INTEGER, Integer.class);	// 4 数字
		javaTypeOfTypeCodeMap.put(Types.SMALLINT, Short.class);		// 5 数字
//		javaTypeOfTypeCodeMap.put(Types.FLOAT, BigDecimal.class);	// 6 数字
		javaTypeOfTypeCodeMap.put(Types.FLOAT, Float.class);		// 6 数字
		javaTypeOfTypeCodeMap.put(Types.REAL, BigDecimal.class);	// 7 数字
//		javaTypeOfTypeCodeMap.put(Types.DOUBLE, BigDecimal.class);	// 8 数字
		javaTypeOfTypeCodeMap.put(Types.DOUBLE, Double.class);		// 8 数字
		javaTypeOfTypeCodeMap.put(Types.VARCHAR, String.class);		// 12 字符�?
		javaTypeOfTypeCodeMap.put(Types.BOOLEAN, Boolean.class);	// 16 布尔
		javaTypeOfTypeCodeMap.put(Types.DATALINK, URL.class);		// 70 /
		javaTypeOfTypeCodeMap.put(Types.DATE, Date.class);			// 91 日期
		javaTypeOfTypeCodeMap.put(Types.TIME, Date.class);			// 92 日期
		javaTypeOfTypeCodeMap.put(Types.TIMESTAMP, Date.class);		// 93 日期
		javaTypeOfTypeCodeMap.put(Types.OTHER, Object.class);		// 1111 其他类型�?
		javaTypeOfTypeCodeMap.put(Types.JAVA_OBJECT, Object.class);	// 2000 
		javaTypeOfTypeCodeMap.put(Types.DISTINCT, String.class);	// 2001 
		javaTypeOfTypeCodeMap.put(Types.STRUCT, String.class);		// 2002 
		javaTypeOfTypeCodeMap.put(Types.ARRAY, String.class);		// 2003 
		javaTypeOfTypeCodeMap.put(Types.BLOB, Blob.class);			// 2004 二进�?
		javaTypeOfTypeCodeMap.put(Types.CLOB, Clob.class);			// 2005 大文�?
		javaTypeOfTypeCodeMap.put(Types.REF, String.class);			// 2006 
		javaTypeOfTypeCodeMap.put(Types.SQLXML, String.class);		// 2009 
		javaTypeOfTypeCodeMap.put(Types.NCLOB, Clob.class);			// 2011 大文�?
	}
	
	
	/**
	 * 根据JDBC-TypeName得到其对应的TypeCode
	 * @param typeName
	 * @return
	 */
	public static Integer getTypeCodeByTypeName(String typeName){
		return typeCodeOfNameMap.get( typeName );
	}
	
	
	/**
	 * 根据JDBC-TypeCode得到其对应的TypeName
	 * @param typeCode
	 * @return
	 */
	public static String getTypeNameByTypeCode(Integer typeCode){
		return typeNameOfCodeMap.get( typeCode );
	}
	
	/**
	 * 根据JDBC-TypeCode得到其对应的JavaType
	 * @param typeCode
	 * @return
	 */
	public static Class<?> getJavaTypeByTypeCode(Integer typeCode){
		return javaTypeOfTypeCodeMap.get( typeCode );
	}
	
	public static Class<?> getJavaTypeByTypeName(String typeName){
		return javaTypeOfTypeCodeMap.get( typeCodeOfNameMap.get(typeName) );
	}
	
	/**
	 * �?��应的Java对象是否是数字类�?
	 * @param typeCode
	 * @return
	 */
	public static boolean isJavaNumberType(Integer typeCode){
		Class<?> javaType = javaTypeOfTypeCodeMap.get( typeCode );
		if( javaType==null ) return false;
		return Number.class.isAssignableFrom( javaType );
	}
	
	public static boolean isJavaNumberType(String typeName){
		return isJavaNumberType( typeCodeOfNameMap.get(typeName) );
	}
	
}
