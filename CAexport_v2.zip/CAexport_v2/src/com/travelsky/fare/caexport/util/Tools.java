package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.travelsky.fare.caexport.exception.FatalException;

public class Tools {
	private static SimpleDateFormat ddf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat dtf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
	private static SimpleDateFormat dhf = new SimpleDateFormat("yyyyMMdd HH");

	public static Date parseDate(String date) {
		java.util.Date dateFormatter = null;
		try {
			dateFormatter = ddf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateFormatter;
	}

	public static Date parseDate2(String date) {
		java.util.Date dateFormatter = null;
		try {
			dateFormatter = dtf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateFormatter;
	}

	public static Date parseDate3(String date) {
		java.util.Date dateFormatter = null;
		try {
			dateFormatter = dhf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateFormatter;
	}

	public static String getStringDate(Date date) {
		return date==null?null:ddf.format(date);
	}

	public static String getStringDate2(Date date) {
		return date==null?null:dtf.format(date);
	}

	public static String getStringDate3(Date date) {
		return date==null?null:dhf.format(date);
	}

	public static Date plusDate(Date date, int plusDate) {
		Calendar dateCalendar = Calendar.getInstance();
		dateCalendar.setTime(date);
		dateCalendar.add(Calendar.DATE, plusDate);
		return dateCalendar.getTime();
	}

	//������������
	public static String plusDate(String date, int plusNumber) throws FatalException {
		String plusDate = new String();
		Calendar dateCalendar = Calendar.getInstance();
		try {
			java.util.Date dateFormatter = ddf.parse(date);
			dateCalendar.setTime(dateFormatter);
			dateCalendar.add(Calendar.DATE, plusNumber);
			plusDate = ddf.format(dateCalendar.getTime());
		} catch (Exception e) {
			throw new FatalException(e.getMessage());
		}
		return plusDate;
	}

	public static Date getTimeOfToday(String hour) {
		Calendar time = Calendar.getInstance();
		time.set(time.get(Calendar.YEAR), time.get(Calendar.MONTH), time
				.get(Calendar.DATE), Integer.valueOf(hour).intValue(), 0, 0);
		return time.getTime();
	}

	//��һ���ļ������������ȫ����������һ���ļ����£�֮��ɾ��ԭ�ļ����е�����
	public static void copyDirectiory(String sourceDir, String targetDir) {
		
		// �½�Ŀ��Ŀ¼
		(new File(targetDir)).mkdirs();
		// ��ȡԴ�ļ��е�ǰ�µ��ļ���Ŀ¼
		File[] file = (new File(sourceDir)).listFiles();
		for (int i = 0; i < file.length; i++) {
			if (file[i].isFile()) {
				// Դ�ļ�
				File sourceFile = file[i];
				// Ŀ���ļ�
				File targetFile = new File(new File(targetDir).getAbsolutePath() + File.separator + file[i].getName());
				try {
					copyFile(sourceFile,targetFile);
					sourceFile.delete();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (file[i].isDirectory()) {
				// ׼�����Ƶ�Դ�ļ���
				String dir1 = sourceDir + "/" + file[i].getName();
				// ׼�����Ƶ�Ŀ���ļ���
				String dir2 = targetDir + "/" + file[i].getName();
				copyDirectiory(dir1, dir2);
				file[i].delete();
			}
		}
	}
	
	//�����ļ�    
	public static void copyFile(File sourceFile,File targetFile) throws IOException{   
		// �½��ļ����������������л���    
		FileInputStream input = new FileInputStream(sourceFile);   
		BufferedInputStream inBuff=new BufferedInputStream(input);   
		
		// �½��ļ���������������л���    
		FileOutputStream output = new FileOutputStream(targetFile);   
		BufferedOutputStream outBuff=new BufferedOutputStream(output);   
		
		// ��������    
		byte[] b = new byte[1024 * 5];   
		int len;   
		while ((len =inBuff.read(b)) != -1) {   
			outBuff.write(b, 0, len);   
		}   
		// ˢ�´˻���������    
		outBuff.flush();   	           
		//�ر���    
		inBuff.close();   
		outBuff.close();   
		output.close();   
		input.close();   
	} 
	
	public static void main(String[] args){
		Tools.copyDirectiory("result", "bak");
	}

}
