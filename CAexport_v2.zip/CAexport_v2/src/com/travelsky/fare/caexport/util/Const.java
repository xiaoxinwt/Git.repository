package com.travelsky.fare.caexport.util;

public interface Const {

	final String MYBATIS_CONFIG_FILE_NAME="/MybatisConfig.xml";
	
	final String EXP_PATH = "EXPORT_PATH";
	final String DATE_FORMAT_TITLE = "yyyyMMdd";
	final String yyyyMMdd = "yyyyMMdd";
	final String DATE_FORMAT_NORMAL = "yyyy-MM-dd";
	final String DATE_FORMAT_US	= "yyyy/MM/dd";
	final String DATE_FORMAT_ZH = "yyyy��MM��dd��";
	final String BAK = "BAK";

	final String AIRTIS_FARE_XMLNUM = "AIRTIS_FARE_LIMITNUM";
	final String AIRTIS_RULE_XMLNUM = "AIRTIS_RULE_LIMITNUM";
	final String AIRTIS_REFUND_XMLNUM = "AIRTIS_REFUND_LIMITNUM";
	final String AIRTIS_REISSUE_XMLNUM = "AIRTIS_REISSUE_LIMITNUM";
	final String AIRTIS_GROUP_XMLNUM = "AIRTIS_GROUP_LIMITNUM";
	final String EASYFARE_FARE_XMLNUM = "EASYFARE_FARE_LIMITNUM";
	final String EASYFARE_RULE_XMLNUM = "EASYFARE_RULE_LIMITNUM";
	final String EASYFARE_REFUND_XMLNUM = "EASYFARE_REFUND_LIMITNUM";
	final String EASYFARE_REISSUE_XMLNUM = "EASYFARE_REISSUE_LIMITNUM";
	final String EASYFARE_GROUP_XMLNUM = "EASYFARE_GROUP_LIMITNUM";

	final String AIRTIS_LOCATION_CODE = "PUB";

}
