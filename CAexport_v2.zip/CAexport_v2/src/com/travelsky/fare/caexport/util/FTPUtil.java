/**============================================================
 * ��Ȩ�� Travelsky ��Ȩ���� (c) 2008 - 2009
 * �ļ��� util.FTPUtil
 * ������: FTPUtil
 * �޸ļ�¼��
 * ����                		����                		����
 * =============================================================
 * 2010-12-18         liye(liye@travelsky.com)    �����ļ���ʵ�ֻ�������
 * ============================================================*/

package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;


/**
 * <p>��˵��</p>
 *
 * <p>ʹ��˵��</p>
 *
 * @version 2010-12-18
 * @author liye
 * 
 */
public class FTPUtil {
	private Log log = LogFactory.getLog("SYSTEM");
	public void uploadDir(FtpParam ftpParam,String flag){
		FTPClient ftp = new FTPClient();
	    try {
	        ftp.connect(ftpParam.getIp(),ftpParam.getPort());
	        ftp.login(ftpParam.getUser(), ftpParam.getPassword());
	        int reply = ftp.getReplyCode();   
	        System.out.println( "ftp reply:" + reply + "\t FTP�ϴ��ɹ�!" );

	        if (!FTPReply.isPositiveCompletion(reply)) {   
	        	ftp.disconnect();
	        	log.error("login ftp failed!");
	        } else {
	        	ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
	        	upload(ftp,ftpParam.getLocalDir(),ftpParam.getRemoteDir());
	        	OutputStreamWriter out = new OutputStreamWriter(ftp.appendFileStream(flag));
	        	out.close();
	        }
	        ftp.logout();
	    } catch(IOException e){
	    	log.error(e.getMessage());
	    }
//	    Tools.copyDirectiory(ftpParam.getLocalDir(),ftpParam.getBakDir());
	}
	
	private void upload(FTPClient ftp, String localDir,String remoteDir){
		try{
			ftp.changeWorkingDirectory(remoteDir);
			File locDir=new File(localDir);
			String[] files=locDir.list();
			if(files!=null){
				for(int i=0;i<files.length;i++){
					String fileName=files[i];
					File tmpFile=new File(localDir+File.separator+fileName);
					if(tmpFile.isDirectory()){
						//String subDir=remoteDir+"/"+fileName;
						//ftp.makeDirectory(subDir);
						upload(ftp,tmpFile.getPath(),remoteDir);
					} else {
						uploadFile(ftp,tmpFile,remoteDir);
					}
				}
			}
		} catch(IOException e){
			log.error(e.getMessage());
		}
	}
	
	private void uploadFile(FTPClient ftp, File localFile,String remoteDir){
		try{
			ftp.changeWorkingDirectory(remoteDir);
			InputStream is=new BufferedInputStream(new FileInputStream(localFile));
			ftp.storeFile(localFile.getName(), is);
			is.close();
			System.out.println( "File: "+localFile.getPath()+"==>"+remoteDir+"/"+localFile.getName()+" Success!" );
		} catch(IOException e){
			log.error(e.getMessage());
		}
	}
}

