package com.travelsky.fare.caexport.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import com.travelsky.fare.caexport.db.model.po.PairDays;

public class DateUtil {
	
	private static Map<String,String> dfmap = new HashMap<String,String>();
	private static DateFormat df = null;
	
	private static Locale locale = Locale.ENGLISH;
	
	static{
		
		String rq1 = "^\\d{4}-\\d{1,2}-\\d{1,2}";	//yyyy-M-d
		String rq2 = "^\\d{4}-\\d{2}-\\d{2}";		//yyyy-MM-dd
		String rq3 = "^\\d{4}/\\d{1,2}/\\d{1,2}";	//yyyy/M/d
		String rq4 = "^\\d{4}/\\d{2}/\\d{2}";		//yyyy/MM/dd
		String rq5 = "[A-Z]{1}[a-z]+\\s+[0-9]{1,2},\\s*[0-9{4}]";	//MMM d,yyyy
		String rq6 = "[A-Z]{1}[a-z]+\\s+[0-9]{2},\\s*[0-9{4}]";		//MMM dd,yyyy
		String rq7 = "[A-Za-z]{3}\\s+[A-Za-z]{3}\\s+\\d{1,2}";		//E MMM d
		String rq8 = "[A-Za-z]{3}\\s+[A-Za-z]{3}\\s+\\d{2}";		//E MMM dd
		
		String sj1 = "\\d{1,2}:\\d{1,2}:\\d{1,2}";				//H:m:s
		String sj2 = "\\d{1,2}:\\d{1,2}:\\d{1,2}:\\d{1,3}";		//H:m:s:S
		String sj3 = "\\d{2}:\\d{2}:\\d{2}";					//HH:mm:ss
		String sj4 = "\\d{2}:\\d{2}:\\d{2}:\\d{3}";				//HH:mm:ss:SSS
		
		String sq1 = "[A-Z]{3}\\s+\\d{4}";		//z yyyy	--ʱ��
		
		dfmap.put( rq1, "yyyy-M-d");
		dfmap.put( rq2, "yyyy-MM-dd");
		dfmap.put( rq3, "yyyy/M/d");
		dfmap.put( rq4, "yyyy/MM/dd");
		dfmap.put( rq5, "MMM d,yyyy");
		dfmap.put( rq6, "MMM dd,yyyy");
		dfmap.put( rq7, "E MMM d");
		dfmap.put( rq8, "E MMM dd");
		dfmap.put( sj1, "H:m:s");
		dfmap.put( sj2, "HH:mm:ss");
		dfmap.put( sj3, "HH:mm:ss:SSS");
		dfmap.put( sj4, "HH:mm:ss:SSS");
		
		dfmap.put( rq1+"\\s+"+sj1, "yyyy-M-d H:m:s");
		dfmap.put( rq1+"\\s+"+sj2, "yyyy-M-d H:m:s:S");
		dfmap.put( rq1+"\\s+"+sj3, "yyyy-M-d HH:mm:ss");
		dfmap.put( rq1+"\\s+"+sj4, "yyyy-M-d HH:mm:ss:SSS");
		
		dfmap.put( rq2+"\\s+"+sj1, "yyyy-MM-dd H:m:s");
		dfmap.put( rq2+"\\s+"+sj2, "yyyy-MM-dd H:m:s:S");
		dfmap.put( rq2+"\\s+"+sj3, "yyyy-MM-dd HH:mm:ss");
		dfmap.put( rq2+"\\s+"+sj4, "yyyy-MM-dd HH:mm:ss:SSS");
		
		dfmap.put( rq3+"\\s+"+sj1, "yyyy/M/d H:m:s");
		dfmap.put( rq3+"\\s+"+sj2, "yyyy/M/d H:m:s:S");
		dfmap.put( rq3+"\\s+"+sj3, "yyyy/M/d HH:mm:ss");
		dfmap.put( rq3+"\\s+"+sj4, "yyyy/M/d HH:mm:ss:SSS");
		
		dfmap.put( rq4+"\\s+"+sj1, "yyyy/MM/dd H:m:s");
		dfmap.put( rq4+"\\s+"+sj2, "yyyy/MM/dd H:m:s:S");
		dfmap.put( rq4+"\\s+"+sj3, "yyyy/MM/dd HH:mm:ss");
		dfmap.put( rq4+"\\s+"+sj4, "yyyy/MM/dd HH:mm:ss:SSS");
		
		dfmap.put( rq5+"\\s+"+sj1, "MMM d,yyyy H:m:s");
		dfmap.put( rq5+"\\s+"+sj2, "MMM d,yyyy H:m:s:S");
		dfmap.put( rq5+"\\s+"+sj3, "MMM d,yyyy HH:mm:ss");
		dfmap.put( rq5+"\\s+"+sj4, "MMM d,yyyy HH:mm:ss:SSS");
		
		dfmap.put( rq6+"\\s+"+sj1, "MMM dd,yyyy H:m:s");
		dfmap.put( rq6+"\\s+"+sj2, "MMM dd,yyyy H:m:s:S");
		dfmap.put( rq6+"\\s+"+sj3, "MMM dd,yyyy HH:mm:ss");
		dfmap.put( rq6+"\\s+"+sj4, "MMM dd,yyyy HH:mm:ss:SSS");
		
		dfmap.put( rq7+"\\s+"+sj1, "E MMM d H:m:s");
		dfmap.put( rq7+"\\s+"+sj2, "E MMM d H:m:s:S");
		dfmap.put( rq7+"\\s+"+sj3, "E MMM d HH:mm:ss");
		dfmap.put( rq7+"\\s+"+sj4, "E MMM d HH:mm:ss:SSS");
		
		dfmap.put( rq8+"\\s+"+sj1, "E MMM dd H:m:s");
		dfmap.put( rq8+"\\s+"+sj2, "E MMM dd H:m:s:S");
		dfmap.put( rq8+"\\s+"+sj3, "E MMM dd HH:mm:ss");
		dfmap.put( rq8+"\\s+"+sj4, "E MMM dd HH:mm:ss:SSS");
		
		dfmap.put( rq7+"\\s+"+sj1+"\\s+"+sq1, "E MMM d H:m:s z yyyy");
		dfmap.put( rq7+"\\s+"+sj2+"\\s+"+sq1, "E MMM d H:m:s:S z yyyy");
		dfmap.put( rq7+"\\s+"+sj3+"\\s+"+sq1, "E MMM d HH:mm:ss z yyyy");
		dfmap.put( rq7+"\\s+"+sj4+"\\s+"+sq1, "E MMM d HH:mm:ss:SSS z yyyy");
		
		dfmap.put( rq8+"\\s+"+sj1+"\\s+"+sq1, "E MMM dd H:m:s z yyyy");
		dfmap.put( rq8+"\\s+"+sj2+"\\s+"+sq1, "E MMM dd H:m:s:S z yyyy");
		dfmap.put( rq8+"\\s+"+sj3+"\\s+"+sq1, "E MMM dd HH:mm:ss z yyyy");
		dfmap.put( rq8+"\\s+"+sj4+"\\s+"+sq1, "E MMM dd HH:mm:ss:SSS z yyyy");
		
		dfmap.put( rq2+"T"+sj3+"Z", "yyyy-MM-dd'T'HH:mm:ssZ");
	}
	
	
	public static void main(String[] args) {
		
		String dtr = "2016-01-12T19:22:14+08:00";
		System.out.println( getPattern(dtr) );
		System.out.println( Pattern.matches( "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\+\\d{2}:\\d{2}", dtr) );
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		System.out.println( format.format( new Date() ));
	}
	
	
	/**
	 * ���ݴ���������ַ�����ȡ���ַ�������Ӧ�����ڸ�ʽ��formatter
	 * �磺 �������ڸ�ʽΪ��xxxx-xx-xx �õ�  yyyy-MM-dd
	 * �磺 �������ڸ�ʽΪ��xxxx/xx/xx xx:xx:xx �õ� yyyy/MM/dd HH:mm:ss
	 * �磺 �������ڸ�ʽΪ ��Fri Dec 25 18:36:35 CST 2015  �õ� E MMM d HH:mm:ss z yyyy ��
	 * @param dateStr
	 * @return
	 */
	public static String getPattern(String dateStr){
		
		String formaterstr = "yyyy-MM-dd HH:mm:ss";
		if( StringUtil.isNullOrEmpty(dateStr) ) return formaterstr;
		
		dateStr = dateStr.trim();
		for (String patternstr : dfmap.keySet() ) {
			if(Pattern.matches( patternstr, dateStr)){
				formaterstr = dfmap.get(patternstr);
				return formaterstr;
			}
		}
		return formaterstr;
	}
	
	public static String getDateStr(Date date){
//		df = new SimpleDateFormat( PatternType.Date.val, locale);
//		return df.format( date );
		return getDateStr(date,PatternType.Date.val);
	}
	
	public static String getTimeStr(Date time){
//		df = new SimpleDateFormat( PatternType.Time.val, locale);
//		return df.format( time );
		return getDateStr(time,PatternType.Time.val);
	}
	
	public static String getDateTimeStr( Date date){
//		df = new SimpleDateFormat( PatternType.DateTime.val, locale);
//		return df.format(date);
		return getDateStr(date,PatternType.DateTime.val);
	}
	
	public static String getDateStr(Date date,String formater){
		try {
			df = new SimpleDateFormat( formater, locale);
			return df.format( date );
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date getDate(String dstr) {
		
		Date retdate = new Date();
		try {
			if( dstr==null || dstr.trim().length()==0 ) return retdate;
			else if( dstr.equalsIgnoreCase("now") || dstr.equalsIgnoreCase("n") ){
				return retdate;
			}else if( dstr.equalsIgnoreCase("src") || dstr.equalsIgnoreCase("s") ){
				return getDate("1970-01-01");
			}else{
				String formater = getPattern(dstr);
//				System.out.println( formater );
				DateFormat df = new SimpleDateFormat(formater, locale);
				retdate = df.parse(dstr);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return retdate;
	}

	public static Date getEarlier(Date a, Date b) {
		return earlierThan(a,b)?a:b;
	}
	/**
	 * �Ƚ� a�����Ƿ�����b����
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean earlierThan(Date a , Date b) {
		return a.compareTo(b)<=0;
	}
	
	/**
	 * �Ƚ� ����a �Ƿ����� ����b
	 * @param a
	 * @param b
	 * @return
	 */
	public static Date getLater(Date a, Date b){
		return laterThan(a,b)?a:b;
	}
	public static boolean laterThan(Date a, Date b){
		return a.compareTo(b)>0;
	}
	
	public enum PatternType{
		Date("yyyy-MM-dd"),Time("HH:mm:ss"),DateTime("yyyy-MM-dd HH:mm:ss");
		
		public String val;
		PatternType(String val){
			this.val = val;
		}
	}

	public static Date getPreDay(Date date, int i) {
		Calendar cal = Calendar.getInstance(Locale.ENGLISH);
		cal.setTime( date );
		cal.add( Calendar.DATE, -i);
		return cal.getTime();
	}
	
	public static Date getNextDay(Date date , int i){
		Calendar cal = Calendar.getInstance(Locale.ENGLISH);
		cal.setTime( date );
		cal.add( Calendar.DATE, i);
		return cal.getTime();
	}
	
	public static Date getYesterday(Date date){
		return getPreDay(date,1);
	}
	public static Date getTomorrow(Date date){
		return getNextDay(date,1);
	}
	
	/**
     * Get the Dates between Start Date and End Date.
     * @param p_start   Start Date
     * @param p_end     End Date
     * @return Dates List
     */
    public static List<Date> getDates(Date startdate, Date enddate) {
    	Calendar p_start = Calendar.getInstance(Locale.ENGLISH);
    	p_start.setTime( startdate );
    	Calendar p_end = Calendar.getInstance(Locale.ENGLISH);
    	p_end.setTime( enddate );
    	p_end.add(Calendar.DAY_OF_YEAR, 1);
    	
        List<Date> result = new ArrayList<Date>();
        while (p_start.before(p_end)) {
            result.add(p_start.getTime());
            p_start.add(Calendar.DAY_OF_YEAR, 1);
        }
        return result;
    }
    
	/**
	 * 
	 * @param s
	 * @return
	 */
	public static Date parseDate(String s) {
		Date date = null;
		if (s != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			try {
				date = sdf.parse(s);
			} catch (ParseException  e) {
				e.printStackTrace();
			}
		}
		return date;
	}
	
	/**
	 * date���
	 * @param date
	 * @return
	 */
	public static Date cloneDate(Date date) {
		if (date == null){
			return null;
		} else {
			return (Date)date.clone();
		}	
	}
	
	public static Date endDate(Date date) {
		return endDate(date,null);
	}
	//һ��yyyyMMdd����ת��ΪyyyyMMdd 23��59��59
	public static Date endDate(Date date,Date defdate) {
		if( date==null ) return defdate;
		
		String s = new SimpleDateFormat("yyyyMMdd").format(date);
		try {
			date = new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(s + " 23:59:59");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	public static void main2(String[] args) {
//		Date date = getDate("2016-01-11");
//		System.out.println( getDateStr( getPreDay(date,1) ) );
//		System.out.println( getDateStr( getPreDay(date,-1) ) );
//		System.out.println( getDateStr( getNextDay(date,1) ) );
//		System.out.println( getDateStr( getNextDay(date,-1) ) );
//		
//		Date date2 = getDate("2016-02-30");
		List<Date> dates ;
//		dates = getDates(date,date2);
		
		String d1 = "2010-10-10";
		String d2 = "2011-02-11";
		PairDays days = new PairDays(d1, d2);
		System.out.println( days.getFirstDate() );
		System.out.println( days.getLastDate() );
		dates = getDates(days.getFirstDate(),days.getLastDate());
		for (Date d : dates) {
			System.out.println( getDateTimeStr(d) );
		}
		
		
	}
	
	@SuppressWarnings("unused")
	public static void main1(String[] args) throws ParseException {
		
		String ps = "[A-Z]{1}[a-z]{2}\\s+[A-Z]{1}[a-z]{2}\\s+\\d{1,2}\\s+\\d{2}:\\d{2}:\\d{2}\\s+[A-Z]{3}\\s+[1-2]{1}\\d{3}";
		Pattern ddp1 = Pattern.compile(ps);
		DateFormat df = new SimpleDateFormat("E MMM d HH:mm:ss z yyyy" ,locale);
		
		System.out.println( new Date() );
		
		String dd1 = "2010-12-12";
		String dd2 = "2012/12/12";
		String dt1 = "12:23:44";
		String dt2 = "23:59:25:384";
		String ddt1 = "2015-12-25 18:18:18";
		String ddt2 = "Fri Dec 25 18:36:35 CST 2015";
//		ddt2 = "Fri Dec 25 18:49:37";
		
		Matcher m = null;
		m = ddp1.matcher(ddt2);
		System.out.println( m.matches() );
		
//		Date da = getDate(dd1);
//		Date db = getDate(dd2);
//		Date dc = getDate(ddt1);
		
		String dstr = "Thu Jan 07 15:16:42 CST 2016";
		dstr = "Thu Jan 07 15:16:42 CST";
		dstr = "Thu Jan 07 15:16:42";
		dstr = "Thu Jan 07";
		dstr = "Thu Jan 07 ";
		
		df = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy", locale);
		df = new SimpleDateFormat("E MMM dd HH:mm:ss z", locale);
		df = new SimpleDateFormat("E MMM dd HH:mm:ss", locale);
		df = new SimpleDateFormat("E MMM dd", locale);
		df = new SimpleDateFormat("E MMM d", locale);
		
		System.out.println( getPattern(dstr) );
		System.out.println( getDateStr( df.parse(dstr) ) );
		System.out.println( getDateStr( getDate(dstr)) );
		
//		Date date = new Date();
//		System.out.println( date );
//		System.out.println( df.format(date) );
//		Date dc = getDate("Thu Jan 07 ");
		
//		System.out.println( getDateStr(dc,"MM dd,yyyy HH:mm:ss") );
//		System.out.println( getDateStr(dc,"MMM dd,yyyy HH:mm:ss") );
//		System.out.println( getDateStr(dc,"E MMM d HH:mm:ss z yyyy") );
//		System.out.println( getDateStr(dc,"E MMM dd HH:mm:ss z yyyy") );
		
//		System.out.println( da+" <=> "+db+"\t"+ getEarlier(da,db) );
//		System.out.println( dc+" <=> "+dd+"\t"+ getLater(dc,dd) );
		
		
	}

	
	public static XMLGregorianCalendar getXMLGregorianCalendar(Date date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		XMLGregorianCalendar gc = null;
		try {
			gc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return gc;
	}
	
	public static Date convertToDate(XMLGregorianCalendar cal) throws Exception{
		GregorianCalendar ca = cal.toGregorianCalendar();
		return ca.getTime();
	}
	
	public static void main3(String[] args) {
		XMLGregorianCalendar d = getXMLGregorianCalendar(new Date());
		System.out.println(d.getDay());
		XMLGregorianCalendar cal = null;
		try {
			cal = DatatypeFactory.newInstance().newXMLGregorianCalendar();
			cal.setMonth(06);
			cal.setYear(2010); 
			Date date = convertToDate(cal);
			String format = "yyyy-MM-dd HH:mm:ss";
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			System.out.println(formatter.format(date));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
