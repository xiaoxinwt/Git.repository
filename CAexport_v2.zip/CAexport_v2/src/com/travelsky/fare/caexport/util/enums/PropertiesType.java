package com.travelsky.fare.caexport.util.enums;

public enum PropertiesType {
	
	SYS("/Sys.properties"),
	INCTIMER("/IncTimer.properties"),
	ALLTIMER("/AllTimer.properties");
	
	PropertiesType(String val){
		this.val = val;
	}
	public String val;
}
