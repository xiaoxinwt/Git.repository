package com.travelsky.fare.caexport.util.enums;

public enum CAModule {
	Fare("Fare"),FBR("Fbr"),Refund("Refund"),Reissue("Reissue"),Rule("Rule"),Group("Group");
	
	public String val;
	CAModule(String val){
		this.val = val;
	}
}
