package com.travelsky.fare.caexport.util;

public class FtpParam {
    private String ip;
    private int port;
    private String user;
    private String password;
    private String localDir;
    private String remoteDir;
    private String bakDir;
    
    
	public FtpParam() {
	}
	public FtpParam(String ip, int port, String user, String password, String localDir, String remoteDir,String bakDir) {
		this.ip = ip;
		this.port = port;
		this.user = user;
		this.password = password;
		this.localDir = localDir;
		this.remoteDir = remoteDir;
		this.bakDir = bakDir;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getLocalDir() {
		return localDir;
	}
	public void setLocalDir(String localDir) {
		this.localDir = localDir;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getRemoteDir() {
		return remoteDir;
	}
	public void setRemoteDir(String remoteDir) {
		this.remoteDir = remoteDir;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getBakDir() {
		return bakDir;
	}
	public void setBakDir(String bakDir) {
		this.bakDir = bakDir;
	}
    
    
}
