package com.travelsky.fare.caexport.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MyBatisUtil {

	private static SqlSessionFactory sqlSessionFactory = null;

	static {
		InputStream in = null;
		Reader reader = null;
		try {
			String configPath = System.getProperty("user.dir")+Const.MYBATIS_CONFIG_FILE_NAME;
//			System.out.println( configPath );
			if(new File( configPath ).exists()){
//				System.out.println("path1");
				in = new BufferedInputStream(new FileInputStream(configPath));
			}else{
//				System.out.println("path2");
				in = PropertiesUtil.class.getResourceAsStream( Const.MYBATIS_CONFIG_FILE_NAME );
			}
//			System.out.println( "��ȡ�ɹ�" );
			reader = new InputStreamReader(in);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (IOException e) {
			e.printStackTrace();
//			System.out.println( "��ȡʧ��" );
		} finally{
			IOUtil.close(in);
		}
	}
	
	public static SqlSessionFactory getSessionFactory(){
		return sqlSessionFactory;
	}
	
}