package com.travelsky.fare.caexport.util.entry;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import com.travelsky.fare.caexport.util.ErrorLog;
import com.travelsky.fare.caexport.util.FileNameGenerator;
import com.travelsky.fare.caexport.util.enums.CAModule;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

public class Export {

	private String carrier;
	private CAType catype;
	private CAModule module;
	private ExpType exptype;
	private Date expdate;
	private Date startDate;
	private Date endDate;
	private long time;
	private long count;
	private long expectTotal;
	private String infoPath;
	private double queryCost;
	private double toxmlCost;
	private String zipPath;
	
	public Export(String carrier,CAType catype, CAModule module ,ExpType exptype) {
		this.carrier = carrier;
		this.catype = catype;
		this.module = module;
		this.exptype = exptype;
		this.zipPath = FileNameGenerator.genertZipPath(carrier, catype, exptype);
		this.infoPath = FileNameGenerator.genertInfoPath(carrier, catype);
		try {
			new File(this.zipPath).createNewFile();
		} catch (IOException e) {
			ErrorLog.log(e);
		}
	}
	
	public CAType getCatype() {
		return catype;
	}
	public void setCatype(CAType catype) {
		this.catype = catype;
	}
	public CAModule getModule() {
		return module;
	}
	public void setModule(CAModule module) {
		this.module = module;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public ExpType getExptype() {
		return exptype;
	}
	public void setExptype(ExpType exptype) {
		this.exptype = exptype;
	}
	public Date getExpdate() {
		return expdate;
	}
	public void setExpdate(Date expdate) {
		this.expdate = expdate;
	}
	public long getTime() {
		return time;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getInfoPath() {
		return infoPath;
	}
	public void setInfoPath(String infoPath) {
		this.infoPath = infoPath;
	}
	public double getQueryCost() {
		return queryCost;
	}
	public void setQueryCost(double queryCost) {
		this.queryCost = queryCost;
	}
	public double getToxmlCost() {
		return toxmlCost;
	}
	public void setToxmlCost(double toxmlCost) {
		this.toxmlCost = toxmlCost;
	}
	public long getExpectTotal() {
		return expectTotal;
	}
	public void setExpectTotal(long expectTotal) {
		this.expectTotal = expectTotal;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getZipPath() {
		return zipPath;
	}
	public void setZipPath(String zipPath) {
		this.zipPath = zipPath;
	}
}
