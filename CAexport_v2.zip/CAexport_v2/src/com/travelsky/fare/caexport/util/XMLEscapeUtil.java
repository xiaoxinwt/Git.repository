package com.travelsky.fare.caexport.util;

public class XMLEscapeUtil {
	public static String escape(String content) {
		if (content != null) {
			content = content.replaceAll("&", "&amp;");
			content = content.replaceAll("\"", "&quot;");
			content = content.replaceAll("\'", "&apos;");
			content = content.replaceAll("<", "&lt;");
			content = content.replaceAll(">", "&gt;");
		}
		return content;
	}

}
