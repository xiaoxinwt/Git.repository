package com.travelsky.fare.caexport;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.travelsky.fare.caexport.db.model.po.PairDays;
import com.travelsky.fare.caexport.util.DateUtil;
import com.travelsky.fare.caexport.util.ErrorLog;
import com.travelsky.fare.caexport.util.ExportUtil;
import com.travelsky.fare.caexport.util.FileNameGenerator;
import com.travelsky.fare.caexport.util.enums.CAType;
import com.travelsky.fare.caexport.util.enums.ExpType;

/**
 * CAExport�����������
 */
public class CaExportRunner {
	
	private static Log log = LogFactory.getLog(CaExportRunner.class);
	
	public static void main(String[] args) {
		
		if(args.length<2) { log.info("������Ч"); return; }
		
		CAType catype = null;
		ExpType exptype = null;
		Date startdate = null;
		Date enddate = null;
		PairDays days = null;
		if( args.length>=2 ){
			
			if( args[0].equalsIgnoreCase("airtis") ) catype = CAType.Airtis;
			else if( args[0].equalsIgnoreCase("easyfare") ) catype = CAType.Easyfare;
			else { log.info( "������Ч" ); return; }
			
			if(args[1].equalsIgnoreCase("all")){
				exptype = ExpType.All;
				if( args.length==2 ){
					log.info("ȫ������ȱ����Ч����,�����˳���");
					return;
				}else{
					startdate = DateUtil.getDate(args[2]);				
				}
			}else if(args[1].equalsIgnoreCase("inc")){
				exptype = ExpType.Inc;
				if( args.length==2 ){
					startdate = new Date();
				}else if(args.length>=3){
					startdate = DateUtil.getDate(args[2]);
					if(args.length==4){
						enddate = DateUtil.getDate(args[3]);
						days = new PairDays(startdate,enddate);
					}
				}
			}
			else{ log.info("������Ч");return; }
			
		}

		List<String> carriers = ExportUtil.getCarriers();
		boolean sign = false;
		for (String carrier : carriers) {
			log.info( carrier );
			log.info( exptype+"\t"+startdate );
			log.info( exptype+"\t"+days );
			
			if(exptype==ExpType.All){
				sign = ExportUtil.exportAllOfDate(carrier, startdate, catype);
			}else{
				if(enddate==null){
					log.info( "expByDate:" + startdate );
					sign = ExportUtil.exportIncOfDate(carrier, startdate, catype);
				}else{
					log.info( "expByDays:" + days );
					sign = ExportUtil.exportIncOfDays(carrier, days, catype);
				}
			}
			
			if( sign ){
				log.info( carrier + " Export Success!" );
				try {
					new File( FileNameGenerator.genertExportDir(carrier, catype)+carrier+"flag.dat" ).createNewFile();
				} catch (IOException e) {
					ErrorLog.log( e );
				}
			}else{
				log.info( carrier+" ����ʧ��!" );
			}
		}
		
		System.exit(-1);

	}
}
